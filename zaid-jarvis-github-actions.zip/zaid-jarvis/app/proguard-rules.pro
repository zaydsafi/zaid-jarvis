# Zaid Jarvis — R8 / ProGuard rules (Phase 1)
# Keep rules for the libraries that need them at release time.

# Hilt
-keep class dagger.hilt.** { *; }
-keep class * extends dagger.hilt.internal.GeneratedComponent { *; }

# Room
-keep class * extends androidx.room.RoomDatabase { *; }
-keep @androidx.room.Entity class * { *; }

# Kotlin Serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**

# Retrofit / OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**

# SQLCipher
-keep class net.sqlcipher.** { *; }
