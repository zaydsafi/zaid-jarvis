package com.zaid.jarvis.screens

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zaid.jarvis.core.confirmation.AuditEntry
import com.zaid.jarvis.ui.components.RiskTierChip
import com.zaid.jarvis.viewmodel.AuditLogViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Audit Log screen (Master Prompt §6): every tool call Jarvis attempted,
 * with its approval and result. Search, detail, CSV export, delete, and
 * undo (undo runs the tool's inverse through the Confirmation Engine).
 */
@Composable
fun AuditLogScreen(viewModel: AuditLogViewModel = hiltViewModel()) {
    val entries by viewModel.entries.collectAsState()
    val query by viewModel.searchQuery.collectAsState()
    val undoMessage by viewModel.undoMessage.collectAsState()
    val context = LocalContext.current
    var selected by remember { mutableStateOf<AuditEntry?>(null) }
    var showClearConfirm by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Audit Log", style = MaterialTheme.typography.headlineMedium)
        Text(
            text = "Everything Jarvis has done or tried to do — with Zaid's decision each time.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        OutlinedTextField(
            value = query,
            onValueChange = viewModel::setSearchQuery,
            label = { Text("Search tool, action, or target") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = {
                    val share = Intent(Intent.ACTION_SEND).apply {
                        type = "text/csv"
                        putExtra(Intent.EXTRA_SUBJECT, "Zaid Jarvis audit log")
                        putExtra(Intent.EXTRA_TEXT, viewModel.exportCsv())
                    }
                    context.startActivity(Intent.createChooser(share, "Export audit log"))
                },
                enabled = entries.isNotEmpty(),
            ) {
                Text("Export CSV")
            }
            OutlinedButton(
                onClick = { showClearConfirm = true },
                enabled = entries.isNotEmpty(),
            ) {
                Text("Clear all")
            }
        }

        if (entries.isEmpty()) {
            Text(
                text = if (query.isBlank()) {
                    "No entries yet. Approved, denied, and expired actions will appear here."
                } else {
                    "No entries match “$query”."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(entries, key = { it.id }) { entry ->
                    AuditEntryRow(entry = entry, onClick = { selected = entry })
                }
            }
        }
    }

    selected?.let { entry ->
        AuditEntryDetailDialog(
            entry = entry,
            onDismiss = { selected = null },
            onDelete = {
                viewModel.deleteEntry(entry.id)
                selected = null
            },
            onUndo = { viewModel.undo(entry) },
        )
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("Clear the audit log?") },
            text = { Text("All ${entries.size} entries will be permanently deleted.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAll()
                        showClearConfirm = false
                    },
                ) {
                    Text("Clear all")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showClearConfirm = false }) {
                    Text("Cancel")
                }
            },
        )
    }

    undoMessage?.let { text ->
        AlertDialog(
            onDismissRequest = viewModel::clearUndoMessage,
            title = { Text("Undo") },
            text = { Text(text) },
            confirmButton = {
                Button(onClick = viewModel::clearUndoMessage) { Text("OK") }
            },
        )
    }
}

@Composable
private fun AuditEntryRow(entry: AuditEntry, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(entry.action, style = MaterialTheme.typography.titleSmall)
                RiskTierChip(tier = entry.tier)
            }
            Text(
                text = "${entry.toolName} · ${entry.decision.displayName}" +
                    if (entry.undone) " · undone" else "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = formatTime(entry.timestampMillis),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun AuditEntryDetailDialog(
    entry: AuditEntry,
    onDismiss: () -> Unit,
    onDelete: () -> Unit,
    onUndo: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(entry.action) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DetailRow("Tool", entry.toolName)
                DetailRow("Tier", "Tier ${entry.tier.level} · ${entry.tier.displayName}")
                DetailRow("Target", entry.target)
                DetailRow("Parameters", entry.paramsSummary)
                DetailRow("Decision", entry.decision.displayName)
                DetailRow("Result", entry.resultSummary ?: "—")
                DetailRow("Time", formatTime(entry.timestampMillis))
                if (entry.undoable) {
                    DetailRow("Undo", entry.undoDescription ?: "Reversible action")
                }
                if (entry.undone) {
                    Text("This action was undone.", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (entry.undoable && !entry.undone) {
                    Button(onClick = onUndo) { Text("Undo") }
                }
                TextButton(onClick = onDelete) { Text("Delete") }
                TextButton(onClick = onDismiss) { Text("Close") }
            }
        },
    )
}

@Composable
private fun DetailRow(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

private fun formatTime(millis: Long): String =
    SimpleDateFormat("d MMM yyyy, HH:mm:ss", Locale.getDefault()).format(Date(millis))
