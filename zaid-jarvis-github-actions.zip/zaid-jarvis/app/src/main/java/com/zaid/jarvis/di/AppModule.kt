package com.zaid.jarvis.di

import android.content.Context
import com.zaid.jarvis.accessibility.AccessibilityAutomationDevice
import com.zaid.jarvis.accessibility.RoomMacroStore
import com.zaid.jarvis.analytics.AnalyticsSinkImpl
import com.zaid.jarvis.backup.AppFileWipe
import com.zaid.jarvis.core.analytics.AnalyticsSink
import com.zaid.jarvis.core.confirmation.AuditLog
import com.zaid.jarvis.core.confirmation.ConfirmationEngine
import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.core.confirmation.TrustedActionStore
import com.zaid.jarvis.data.datastore.PluginStateRepository
import com.zaid.jarvis.data.datastore.ProactiveStateRepository
import com.zaid.jarvis.data.datastore.SettingsRepository
import com.zaid.jarvis.data.db.JarvisDatabase
import com.zaid.jarvis.data.device.DeviceContextProvider
import com.zaid.jarvis.data.repository.AnalyticsRepository
import com.zaid.jarvis.data.repository.ApiKeyRepository
import com.zaid.jarvis.data.repository.DataWipeService
import com.zaid.jarvis.data.repository.FocusSessionRepository
import com.zaid.jarvis.data.repository.LastAnswerRepository
import com.zaid.jarvis.data.repository.MacroRepository
import com.zaid.jarvis.data.repository.RoomDatabaseWipe
import com.zaid.jarvis.data.repository.ScheduledPostRepository
import com.zaid.jarvis.data.repository.SocialAccountRepository
import com.zaid.jarvis.data.repository.TaskRepository
import com.zaid.jarvis.data.security.SecureKeyStore
import com.zaid.jarvis.phone.AndroidPhoneDevice
import com.zaid.jarvis.productivity.CalendarContractReader
import com.zaid.jarvis.productivity.FocusSessionManagerImpl
import com.zaid.jarvis.productivity.RoomTaskStore
import com.zaid.jarvis.productivity.UsageStatsScreenTimeReader
import com.zaid.jarvis.productivity.WellnessNotifier
import com.zaid.jarvis.productivity.WorkManagerReminderScheduler
import com.zaid.jarvis.social.SocialAccountStoreImpl
import com.zaid.jarvis.social.WorkManagerSocialScheduler
import com.zaid.jarvis.tools.automation.AutomationDevice
import com.zaid.jarvis.tools.automation.MacroStore
import com.zaid.jarvis.tools.phone.PhoneDevice
import com.zaid.jarvis.tools.productivity.CalendarReader
import com.zaid.jarvis.tools.productivity.FocusSessionManager
import com.zaid.jarvis.tools.productivity.ReminderScheduler
import com.zaid.jarvis.tools.productivity.ScreenTimeReader
import com.zaid.jarvis.tools.productivity.TaskStore
import com.zaid.jarvis.tools.social.SocialAccountStore
import com.zaid.jarvis.tools.social.SocialScheduler
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * App-level bindings.
 *
 * NOTE: AppDispatchers, SecureKeyStore, JarvisDatabase, MemoryDao,
 * AuditLogDao, AuditLog, and TrustedActionStore are provided by :data
 * (DataModule) — do not re-provide them here or Hilt will fail with a
 * duplicate-binding error.
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    /** One kill switch for the whole app (Master Prompt §2.4). */
    @Provides
    @Singleton
    fun provideKillSwitch(): KillSwitch = KillSwitch()

    /**
     * One confirmation engine for the whole app (Master Prompt §6).
     * Every tool call passes through it via GatedToolExecutor.
     */
    @Provides
    @Singleton
    fun provideConfirmationEngine(
        auditLog: AuditLog,
        trustedStore: TrustedActionStore,
        killSwitch: KillSwitch,
    ): ConfirmationEngine = ConfirmationEngine(auditLog, trustedStore, killSwitch)

    /**
     * The phone's capabilities, as the Phase 5 tools see them. The
     * Android implementation lives in :app; the tools in :tools only
     * know the [PhoneDevice] interface, which keeps them unit-testable
     * on the JVM.
     */
    @Provides
    @Singleton
    fun providePhoneDevice(
        @ApplicationContext context: Context,
        deviceContextProvider: DeviceContextProvider,
    ): PhoneDevice = AndroidPhoneDevice(context, deviceContextProvider)

    /**
     * The screen-automation capabilities, as the Phase 6 tools see them.
     * Backed by the AccessibilityService; the tools in :tools only know
     * the [AutomationDevice] interface, which keeps them unit-testable
     * on the JVM.
     */
    @Provides
    @Singleton
    fun provideAutomationDevice(
        settingsRepository: SettingsRepository,
    ): AutomationDevice = AccessibilityAutomationDevice(settingsRepository)

    /** The macro storage the `run_macro` tool reads (Phase 6). */
    @Provides
    @Singleton
    fun provideMacroStore(
        macroRepository: MacroRepository,
    ): MacroStore = RoomMacroStore(macroRepository)

    // ── Social publishing (Phase 8) ───────────────────────────────────

    /** The account/token store the publisher and OAuth flow use. */
    @Provides
    @Singleton
    fun provideSocialAccountStore(
        repository: SocialAccountRepository,
    ): SocialAccountStore = SocialAccountStoreImpl(repository)

    /** The WorkManager-backed scheduler the `schedule_post` tool uses. */
    @Provides
    @Singleton
    fun provideSocialScheduler(
        @ApplicationContext context: Context,
        repository: ScheduledPostRepository,
    ): SocialScheduler = WorkManagerSocialScheduler(context, repository)

    // ── Productivity & wellness (Phase 9) ─────────────────────────────
    //
    // The productivity tools in :tools only know the interfaces below,
    // which keeps them unit-testable on the JVM; the Android
    // implementations live here in :app. WellnessNotifier and
    // WellnessScheduler are @Inject-constructed @Singletons and need
    // no provider.

    /** The task storage the productivity tools read and write. */
    @Provides
    @Singleton
    fun provideTaskStore(
        repository: TaskRepository,
    ): TaskStore = RoomTaskStore(repository)

    /** The WorkManager-backed reminder scheduler the `set_reminder` tool uses. */
    @Provides
    @Singleton
    fun provideReminderScheduler(
        @ApplicationContext context: Context,
        taskRepository: TaskRepository,
    ): ReminderScheduler = WorkManagerReminderScheduler(context, taskRepository)

    /** The read-only device calendar the `list_events` tool reads. */
    @Provides
    @Singleton
    fun provideCalendarReader(
        @ApplicationContext context: Context,
    ): CalendarReader = CalendarContractReader(context)

    /** The UsageStats-backed screen-time reader. */
    @Provides
    @Singleton
    fun provideScreenTimeReader(
        @ApplicationContext context: Context,
    ): ScreenTimeReader = UsageStatsScreenTimeReader(context)

    /** The focus-session manager (DND + service + end worker). */
    @Provides
    @Singleton
    fun provideFocusSessionManager(
        @ApplicationContext context: Context,
        focusSessionRepository: FocusSessionRepository,
        phoneDevice: PhoneDevice,
        wellnessNotifier: WellnessNotifier,
        analyticsSink: AnalyticsSink,
    ): FocusSessionManager = FocusSessionManagerImpl(
        context = context,
        repository = focusSessionRepository,
        phoneDevice = phoneDevice,
        wellnessNotifier = wellnessNotifier,
        analyticsSink = analyticsSink,
    )

    // ── Analytics (Phase 10) ──────────────────────────────────────────
    //
    // The single analytics sink: the gated executor, the publisher,
    // and the focus manager all record through it. Events are local
    // only, non-personal, and honour the "Usage insights" toggle.

    /** The analytics sink every recorder in the app uses. */
    @Provides
    @Singleton
    fun provideAnalyticsSink(
        repository: AnalyticsRepository,
    ): AnalyticsSink = AnalyticsSinkImpl(repository)

    // ── Delete all data (Phase 11) ────────────────────────────────────
    //
    // The one place that lists what "all data" means, in the order the
    // wipe runs (see DataWipeService): database file first (while the
    // passphrase still exists), then DataStore files, then secrets
    // (the passphrase last, so leftover encrypted bytes are
    // unrecoverable), then files. Add a step here when Jarvis gains a
    // new store — the wipe must never silently miss one.

    /** The delete-all-data coordinator (Settings → Danger zone). */
    @Provides
    @Singleton
    fun provideDataWipeService(
        @ApplicationContext context: Context,
        database: JarvisDatabase,
        settingsRepository: SettingsRepository,
        proactiveStateRepository: ProactiveStateRepository,
        pluginStateRepository: PluginStateRepository,
        trustedStore: TrustedActionStore,
        lastAnswerRepository: LastAnswerRepository,
        socialAccountRepository: SocialAccountRepository,
        apiKeyRepository: ApiKeyRepository,
        secureKeyStore: SecureKeyStore,
        fileWipe: AppFileWipe,
    ): DataWipeService {
        val databaseWipe = RoomDatabaseWipe(database, context)
        return DataWipeService(
            listOf(
                DataWipeService.WipeStep("Database") { databaseWipe.wipe() },
                DataWipeService.WipeStep("Settings") { settingsRepository.clearAll() },
                DataWipeService.WipeStep("Proactive state") { proactiveStateRepository.clear() },
                DataWipeService.WipeStep("Plugin state") { pluginStateRepository.clear() },
                DataWipeService.WipeStep("Trusted actions") { trustedStore.revokeAll() },
                DataWipeService.WipeStep("Last answer") { lastAnswerRepository.clear() },
                DataWipeService.WipeStep("Social accounts") { socialAccountRepository.clearAll() },
                DataWipeService.WipeStep("API keys") { apiKeyRepository.clearAllApiKeys() },
                DataWipeService.WipeStep("Secrets") { secureKeyStore.deleteAllSecrets() },
                DataWipeService.WipeStep("Files") { fileWipe.wipe() },
            ),
        )
    }
}
