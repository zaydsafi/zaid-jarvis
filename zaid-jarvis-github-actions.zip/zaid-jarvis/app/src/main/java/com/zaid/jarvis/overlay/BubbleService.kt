package com.zaid.jarvis.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Recomposer
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.AndroidUiDispatcher
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import com.zaid.jarvis.MainActivity
import com.zaid.jarvis.chat.ChatSession
import com.zaid.jarvis.core.confirmation.ConfirmationEngine
import com.zaid.jarvis.core.voice.OverlayStateMachine
import com.zaid.jarvis.core.voice.OverlayStateMachine.Event
import com.zaid.jarvis.core.voice.OverlayStateMachine.State
import com.zaid.jarvis.data.datastore.SettingsRepository
import com.zaid.jarvis.ui.components.JarvisOrb
import com.zaid.jarvis.voice.VoiceStateStore
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlin.math.abs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/**
 * The floating bubble (Master Prompt §5.3): a foreground service that
 * draws the Jarvis orb over other apps via WindowManager
 * (TYPE_APPLICATION_OVERLAY).
 *
 * - Tap the orb → expands to a compact overlay chat (same [ChatSession]
 *   as the main chat screen; approvals appear inside it).
 * - Drag the orb → moves it; a drag never counts as a tap.
 * - Long-press the orb → dismisses the bubble (and turns the Settings
 *   toggle off, so the state stays honest).
 * - The state machine ([OverlayStateMachine]) is pure Kotlin and
 *   unit-tested; this service only applies its transitions to the
 *   real window.
 *
 * The overlay hosts Compose content without an Activity, so it owns
 * its own [Recomposer] (driven by AndroidUiDispatcher) and a minimal
 * [LifecycleOwner] (RESUMED while shown). No ViewModels are used
 * inside the overlay — the service injects the session and engine
 * directly and passes them to the composable.
 *
 * Requires "Display over other apps" (Settings → Voice → Floating
 * bubble). The service is foreground so the bubble survives while
 * Zaid uses other apps.
 */
@AndroidEntryPoint
class BubbleService : Service() {

    @Inject lateinit var chatSession: ChatSession

    @Inject lateinit var engine: ConfirmationEngine

    @Inject lateinit var settingsRepository: SettingsRepository

    @Inject lateinit var voiceStateStore: VoiceStateStore

    private val scope = CoroutineScope(Dispatchers.Main.immediate + Job())
    private lateinit var windowManager: WindowManager
    private lateinit var composeView: ComposeView
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var recomposer: Recomposer
    private val lifecycleOwner = ServiceLifecycleOwner()

    private val overlayState = MutableStateFlow<State>(State.Collapsed)

    private val handler = Handler(Looper.getMainLooper())
    private var longPressRunnable: Runnable? = null
    private var downX: Float = 0f
    private var downY: Float = 0f
    private var downParamsX: Int = 0
    private var downParamsY: Int = 0
    private var dragged: Boolean = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!OverlayPermission.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        windowManager = getSystemService(WindowManager::class.java)
        setupOverlayView()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            dismissBubble()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        runCatching { windowManager.removeView(composeView) }
        recomposer.cancel()
        lifecycleOwner.handleDestroy()
        scope.coroutineContext[Job]?.cancel()
        super.onDestroy()
    }

    private fun setupOverlayView() {
        val density = resources.displayMetrics.density
        val orbSize = (ORB_SIZE_DP * density).toInt()
        params = WindowManager.LayoutParams(
            orbSize,
            orbSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (16 * density).toInt()
            y = (resources.displayMetrics.heightPixels / 3)
        }

        recomposer = Recomposer(AndroidUiDispatcher.Main)
        scope.launch { recomposer.runRecomposeAndApplyChanges() }
        lifecycleOwner.handleCreate()
        lifecycleOwner.handleResume()

        composeView = ComposeView(this).apply {
            // The overlay has no Activity window, so it supplies its own
            // parent composition context (the manual Recomposer above).
            setParentCompositionContext(recomposer)
            setViewTreeLifecycleOwner(lifecycleOwner)
            setOnTouchListener(touchListener)
            setContent {
                val state by overlayState.collectAsState()
                when (state) {
                    State.Hidden -> Unit
                    State.Collapsed, State.Dragging -> {
                        Box(modifier = Modifier.fillMaxSize()) {
                            JarvisOrb(size = ORB_SIZE_DP.dp)
                        }
                    }
                    State.Expanded -> {
                        OverlayChatContent(
                            chatSession = chatSession,
                            engine = engine,
                            onClose = { applyEvent(Event.Close) },
                            onOpenApp = { openApp(startVoice = false) },
                            onMicTap = { openApp(startVoice = true) },
                        )
                    }
                }
            }
        }
        windowManager.addView(composeView, params)
    }

    private val touchListener = View.OnTouchListener { _, event ->
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                downParamsX = params.x
                downParamsY = params.y
                dragged = false
                longPressRunnable = Runnable {
                    applyEvent(Event.LongPressDismiss)
                    dismissBubble()
                }.also { handler.postDelayed(it, LONG_PRESS_MILLIS) }
                true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downX
                val dy = event.rawY - downY
                if (!dragged && (abs(dx) > DRAG_THRESHOLD_PX || abs(dy) > DRAG_THRESHOLD_PX)) {
                    dragged = true
                    cancelLongPress()
                    if (overlayState.value == State.Collapsed) {
                        applyEvent(Event.DragStart)
                    }
                }
                if (dragged && overlayState.value == State.Dragging) {
                    params.x = downParamsX + dx.toInt()
                    params.y = downParamsY + dy.toInt()
                    windowManager.updateViewLayout(composeView, params)
                }
                true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                cancelLongPress()
                if (dragged) {
                    applyEvent(Event.DragEnd)
                } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                    applyEvent(Event.Tap)
                }
                dragged = false
                true
            }
            else -> false
        }
    }

    private fun cancelLongPress() {
        longPressRunnable?.let { handler.removeCallbacks(it) }
        longPressRunnable = null
    }

    private fun applyEvent(event: Event) {
        val next = OverlayStateMachine.transition(overlayState.value, event)
        if (next == overlayState.value) return
        overlayState.value = next
        applyWindowForState(next)
    }

    /** Resizes / refocuses the window for the new state. */
    private fun applyWindowForState(state: State) {
        val density = resources.displayMetrics.density
        when (state) {
            State.Hidden -> {
                runCatching { windowManager.removeView(composeView) }
            }
            State.Collapsed, State.Dragging -> {
                val orbSize = (ORB_SIZE_DP * density).toInt()
                params.width = orbSize
                params.height = orbSize
                params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                params.gravity = Gravity.TOP or Gravity.START
                windowManager.updateViewLayout(composeView, params)
            }
            State.Expanded -> {
                params.width = WindowManager.LayoutParams.MATCH_PARENT
                params.height = (resources.displayMetrics.heightPixels * 0.66).toInt()
                params.x = 0
                params.y = 0
                // Focusable so the keyboard works; touches outside the
                // window still reach the app underneath.
                params.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                params.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                windowManager.updateViewLayout(composeView, params)
            }
        }
    }

    private fun openApp(startVoice: Boolean) {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MainActivity.EXTRA_DESTINATION, MainActivity.DESTINATION_CHAT)
            if (startVoice) {
                putExtra(MainActivity.EXTRA_START_VOICE, true)
            }
        }
        startActivity(intent)
    }

    /** Long-press dismiss: hide the bubble and turn the toggle off. */
    private fun dismissBubble() {
        scope.launch {
            settingsRepository.updateSettings { it.copy(floatingBubbleEnabled = false) }
        }
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "Floating bubble",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "The Jarvis bubble is showing over other apps."
            },
        )
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this,
            0,
            Intent(this, BubbleService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Jarvis bubble is showing")
            .setContentText("Tap the orb to chat. Long-press it to dismiss.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Dismiss", stopIntent)
            .build()
    }

    /** Minimal LifecycleOwner so Compose content in the overlay can resume. */
    private class ServiceLifecycleOwner : LifecycleOwner {
        private val registry = LifecycleRegistry(this)

        override val lifecycle: Lifecycle get() = registry

        fun handleCreate() {
            registry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        }

        fun handleResume() {
            registry.handleLifecycleEvent(Lifecycle.Event.ON_START)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        }

        fun handleDestroy() {
            registry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        }
    }

    companion object {
        const val CHANNEL_ID: String = "jarvis_bubble"
        const val ACTION_STOP: String = "com.zaid.jarvis.overlay.ACTION_STOP"
        private const val NOTIFICATION_ID: Int = 1002
        private const val ORB_SIZE_DP: Float = 72f
        private const val LONG_PRESS_MILLIS: Long = 600L
        private const val DRAG_THRESHOLD_PX: Float = 12f
    }
}
