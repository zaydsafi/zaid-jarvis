package com.zaid.jarvis.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zaid.jarvis.core.social.ScheduledPost
import com.zaid.jarvis.core.social.ScheduledPostStatus
import com.zaid.jarvis.viewmodel.ScheduledPostsViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Scheduled posts (Phase 8): upcoming, published, failed, and
 * cancelled posts. Cancel a scheduled post (approval card first) or
 * retry a failed one (fresh approval card with the exact text and
 * the new time — 5 minutes from now).
 */
@Composable
fun ScheduledPostsScreen(
    viewModel: ScheduledPostsViewModel = hiltViewModel(),
) {
    val posts by viewModel.posts.collectAsState()
    val message by viewModel.message.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Scheduled posts", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Posts waiting to publish, and what happened to past ones. " +
                "If a draft is edited after scheduling, its post is cancelled " +
                "instead of publishing the old text.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (posts.isEmpty()) {
            Text(
                "No scheduled posts yet. Schedule one from a draft: open an " +
                    "APPROVED draft and tap Schedule.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(posts, key = { it.id }) { post ->
                ScheduledPostCard(
                    post = post,
                    onCancel = { viewModel.cancelPost(post.id) },
                    onRetry = { viewModel.retryPost(post) },
                )
            }
        }
    }

    message?.let {
        AlertDialog(
            onDismissRequest = viewModel::clearMessage,
            confirmButton = {
                TextButton(onClick = viewModel::clearMessage) { Text("OK") }
            },
            text = { Text(it) },
        )
    }
}

@Composable
private fun ScheduledPostCard(
    post: ScheduledPost,
    onCancel: () -> Unit,
    onRetry: () -> Unit,
) {
    val uriHandler = LocalUriHandler.current
    val timeFormat = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault())
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                "${post.platform.displayName} · @${post.accountHandle}",
                style = MaterialTheme.typography.titleMedium,
            )
            Text(
                when (post.status) {
                    ScheduledPostStatus.SCHEDULED ->
                        "Scheduled for ${timeFormat.format(Date(post.scheduledAtMillis))}"
                    ScheduledPostStatus.PUBLISHED ->
                        "Published ${timeFormat.format(Date(post.updatedAtMillis))}"
                    ScheduledPostStatus.FAILED ->
                        "Failed — ${post.failureReason ?: "unknown reason"}"
                    ScheduledPostStatus.CANCELLED ->
                        "Cancelled — ${post.failureReason ?: "cancelled"}"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = when (post.status) {
                    ScheduledPostStatus.FAILED -> MaterialTheme.colorScheme.error
                    ScheduledPostStatus.CANCELLED -> MaterialTheme.colorScheme.onSurfaceVariant
                    else -> MaterialTheme.colorScheme.onSurface
                },
            )
            post.postUrl?.let { url ->
                TextButton(onClick = { uriHandler.openUri(url) }) {
                    Text("Open published post")
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (post.status == ScheduledPostStatus.SCHEDULED) {
                    OutlinedButton(onClick = onCancel) { Text("Cancel") }
                }
                if (post.status == ScheduledPostStatus.FAILED) {
                    OutlinedButton(onClick = onRetry) { Text("Retry (in 5 minutes)") }
                }
            }
        }
    }
}
