package com.zaid.jarvis.accessibility

import com.zaid.jarvis.core.automation.NodeSelector
import com.zaid.jarvis.core.automation.ScreenSnapshot
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.datastore.SettingsRepository
import com.zaid.jarvis.tools.automation.AutomationDevice
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The [AutomationDevice] implementation (Phase 6): delegates to the
 * bound [JarvisAccessibilityService], if any.
 *
 * Availability has two parts, both checked by [checkAvailable] before
 * every action:
 * 1. **The automation toggle** (Settings → Automation) must be on.
 *    It defaults to off and can only be turned on once the service is
 *    enabled — so automation is never live by accident.
 * 2. **The service must be connected** — the user enabled it in system
 *    Settings and Android has it bound right now.
 *
 * The toggle value is cached from SettingsRepository (a Flow) so the
 * check is synchronous; the cache is refreshed by a background
 * collection started in the constructor.
 *
 * The banking-app and password-screen guards live in the service
 * itself, not here — so they apply to every caller, including future
 * ones, and cannot be skipped by using a different device.
 */
@Singleton
class AccessibilityAutomationDevice @Inject constructor(
    settingsRepository: SettingsRepository,
) : AutomationDevice {

    @Volatile
    private var automationEnabled: Boolean = false

    init {
        CoroutineScope(SupervisorJob() + Dispatchers.Default).launch {
            settingsRepository.settings.collectLatest { settings ->
                automationEnabled = settings.automationEnabled
            }
        }
    }

    override suspend fun checkAvailable(): JarvisResult<Unit> {
        if (!automationEnabled) {
            return JarvisResult.Failure(
                "Automation is turned off. Turn it on in Settings → Automation " +
                    "(after enabling the Jarvis Accessibility service in system Settings).",
            )
        }
        if (AccessibilityServiceHolder.service == null) {
            return JarvisResult.Failure(
                "Jarvis's Accessibility service is not connected. Enable it in " +
                    "Settings → Accessibility → Zaid Jarvis, then try again.",
            )
        }
        return JarvisResult.Success(Unit)
    }

    override suspend fun snapshot(): JarvisResult<ScreenSnapshot> {
        val service = serviceOrFailure() ?: return serviceFailure()
        return service.snapshot()
    }

    override suspend fun tap(selector: NodeSelector): JarvisResult<String> {
        val service = serviceOrFailure() ?: return serviceFailure()
        return service.tap(selector)
    }

    override suspend fun tapAt(x: Int, y: Int): JarvisResult<String> {
        val service = serviceOrFailure() ?: return serviceFailure()
        return service.tapAt(x, y)
    }

    override suspend fun typeText(selector: NodeSelector?, text: String): JarvisResult<String> {
        val service = serviceOrFailure() ?: return serviceFailure()
        return service.typeText(selector, text)
    }

    override suspend fun scroll(forward: Boolean): JarvisResult<String> {
        val service = serviceOrFailure() ?: return serviceFailure()
        return service.scroll(forward)
    }

    override suspend fun pressBack(): JarvisResult<String> {
        val service = serviceOrFailure() ?: return serviceFailure()
        return service.pressBack()
    }

    override suspend fun pressHome(): JarvisResult<String> {
        val service = serviceOrFailure() ?: return serviceFailure()
        return service.pressHome()
    }

    /** The bound service, or null when it is not connected. */
    private fun serviceOrFailure(): JarvisAccessibilityService? =
        AccessibilityServiceHolder.service

    private fun <T> serviceFailure(): JarvisResult<T> =
        JarvisResult.Failure(
            "Jarvis's Accessibility service is not connected. Enable it in " +
                "Settings → Accessibility → Zaid Jarvis, then try again.",
        )
}
