package com.zaid.jarvis.screens

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zaid.jarvis.components.TimePickerDialog
import com.zaid.jarvis.core.productivity.QuietHours
import com.zaid.jarvis.core.productivity.formatDuration
import com.zaid.jarvis.permissions.PermissionHelper
import com.zaid.jarvis.viewmodel.WellnessViewModel
import kotlinx.coroutines.delay

/**
 * Wellness screen (Phase 9): screen time, focus sessions, break
 * reminders, wind-down, and quiet hours — all on-device, all
 * opt-in except the (quiet) overdue reminders.
 *
 * Screen time needs usage access, granted in system Settings via the
 * button below — Jarvis explains why before asking. Break reminders
 * and wind-down are off by default; quiet hours silence all of them
 * (except the wind-down nudge itself, whose bedtime is normally
 * inside quiet hours — you chose the time, so it still fires).
 */
@Composable
fun WellnessScreen(
    viewModel: WellnessViewModel = hiltViewModel(),
) {
    val settings by viewModel.settings.collectAsState()
    val screenTime by viewModel.screenTime.collectAsState()
    val screenTimeError by viewModel.screenTimeError.collectAsState()
    val currentSession by viewModel.currentSession.collectAsState()
    val focusHistory by viewModel.focusHistory.collectAsState()
    val message by viewModel.message.collectAsState()
    val context = LocalContext.current
    val hasUsageAccess = viewModel.hasUsageAccess()

    // Tick the focus countdown once a second while a session runs.
    var nowMillis by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(currentSession != null) {
        while (currentSession != null) {
            delay(1_000)
            nowMillis = System.currentTimeMillis()
        }
    }

    var customFocusMinutes by remember { mutableStateOf("") }
    var showBedtimePicker by remember { mutableStateOf(false) }
    var showQuietStartPicker by remember { mutableStateOf(false) }
    var showQuietEndPicker by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Wellness", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Screen time, focus, and wind-down — everything here stays on your phone. " +
                "Nothing is uploaded anywhere.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        // ── Screen time ─────────────────────────────────────────────
        Text("Screen time today", style = MaterialTheme.typography.titleMedium)
        if (!hasUsageAccess) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        "To show your screen time, Jarvis needs usage access — Android " +
                            "requires you to grant it in system Settings. Jarvis only reads " +
                            "today's totals and top apps; the data never leaves your phone.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Button(
                        onClick = {
                            context.startActivity(PermissionHelper.usageAccessSettingsIntent())
                        },
                    ) {
                        Text("Open usage access settings")
                    }
                    OutlinedButton(onClick = viewModel::refresh) { Text("Check again") }
                }
            }
        } else if (screenTime != null) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        "Total: ${formatDuration(screenTime!!.totalMillis)}",
                        style = MaterialTheme.typography.titleLarge,
                    )
                    if (screenTime!!.topApps.isEmpty()) {
                        Text(
                            "No app usage recorded yet today.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    } else {
                        Text("Top apps", style = MaterialTheme.typography.titleSmall)
                        screenTime!!.topApps.forEach { app ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text(
                                    appLabel(context, app.packageName),
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.weight(1f),
                                )
                                Text(
                                    formatDuration(app.totalTimeInForegroundMillis),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                    OutlinedButton(onClick = viewModel::refresh) { Text("Refresh") }
                }
            }
        } else if (screenTimeError != null) {
            Text(
                screenTimeError!!,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error,
            )
        }

        // ── Focus mode ──────────────────────────────────────────────
        Text("Focus mode", style = MaterialTheme.typography.titleMedium)
        Text(
            "While you focus, Jarvis turns on Do Not Disturb (alarms still ring) and " +
                "restores it when the session ends. Starting a session always asks first.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (currentSession != null) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    val remaining = currentSession!!.remainingMillis(nowMillis)
                    Text(
                        "Focusing — ${formatDuration(remaining.coerceAtLeast(0))} left",
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Text(
                        "Do Not Disturb is on. Break reminders are paused during focus.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Button(onClick = viewModel::stopFocus) { Text("Stop focus early") }
                }
            }
        } else {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf(25, 50, 90).forEach { minutes ->
                    Button(onClick = { viewModel.startFocus(minutes) }) {
                        Text("$minutes min")
                    }
                }
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = customFocusMinutes,
                    onValueChange = { customFocusMinutes = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Custom minutes (5–240)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                val custom = customFocusMinutes.toIntOrNull()
                Button(
                    onClick = { custom?.let { viewModel.startFocus(it) } },
                    enabled = custom != null && custom in 5..240,
                ) {
                    Text("Start")
                }
            }
        }
        if (focusHistory.isNotEmpty()) {
            Text("Recent sessions", style = MaterialTheme.typography.titleSmall)
            focusHistory.take(5).forEach { session ->
                Text(
                    "${session.durationMinutes} min — ${session.status.name.lowercase()}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        // ── Break reminders ─────────────────────────────────────────
        Text("Break reminders", style = MaterialTheme.typography.titleMedium)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Remind me to take a break",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f),
            )
            Switch(
                checked = settings.breakRemindersEnabled,
                onCheckedChange = viewModel::setBreakRemindersEnabled,
            )
        }
        Text(
            "At most once an hour, only after ${settings.breakReminderIntervalMinutes} minutes " +
                "of continuous screen time, never during quiet hours or focus.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(30, 60, 90, 120).forEach { minutes ->
                FilterChip(
                    selected = settings.breakReminderIntervalMinutes == minutes,
                    onClick = { viewModel.setBreakReminderIntervalMinutes(minutes) },
                    label = { Text("$minutes min") },
                )
            }
        }

        // ── Wind-down ───────────────────────────────────────────────
        Text("Sleep wind-down", style = MaterialTheme.typography.titleMedium)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Wind-down reminder at bedtime",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f),
            )
            Switch(
                checked = settings.windDownEnabled,
                onCheckedChange = viewModel::setWindDownEnabled,
            )
        }
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Bedtime: ${formatTimeOfDay(settings.windDownHour, settings.windDownMinute)}",
                style = MaterialTheme.typography.bodyMedium,
            )
            OutlinedButton(onClick = { showBedtimePicker = true }) { Text("Change") }
        }
        Text(
            "At bedtime Jarvis suggests winding down. Tapping “Wind down now” asks you " +
                "first, then turns on Do Not Disturb and dims the screen.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Button(onClick = viewModel::windDownNow) { Text("Wind down now") }

        // ── Quiet hours ─────────────────────────────────────────────
        Text("Quiet hours", style = MaterialTheme.typography.titleMedium)
        Text(
            "During quiet hours Jarvis posts no proactive notifications — no digest, " +
                "no break or overdue nudges. Your own reminders and publish results " +
                "still come through.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                QuietHours(
                    settings.quietHoursStartMinute,
                    settings.quietHoursEndMinute,
                ).displayLabel(),
                style = MaterialTheme.typography.bodyMedium,
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { showQuietStartPicker = true }) {
                Text(
                    "Start ${formatTimeOfDay(
                        settings.quietHoursStartMinute / 60,
                        settings.quietHoursStartMinute % 60,
                    )}",
                )
            }
            OutlinedButton(onClick = { showQuietEndPicker = true }) {
                Text(
                    "End ${formatTimeOfDay(
                        settings.quietHoursEndMinute / 60,
                        settings.quietHoursEndMinute % 60,
                    )}",
                )
            }
        }
        Text(
            "Tip: set start and end to the same time to turn quiet hours off.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }

    if (showBedtimePicker) {
        TimePickerDialog(
            title = "Bedtime",
            initialHour = settings.windDownHour,
            initialMinute = settings.windDownMinute,
            onDismiss = { showBedtimePicker = false },
            onTimeSelected = { hour, minute ->
                viewModel.setWindDownTime(hour, minute)
                showBedtimePicker = false
            },
        )
    }
    if (showQuietStartPicker) {
        TimePickerDialog(
            title = "Quiet hours start",
            initialHour = settings.quietHoursStartMinute / 60,
            initialMinute = settings.quietHoursStartMinute % 60,
            onDismiss = { showQuietStartPicker = false },
            onTimeSelected = { hour, minute ->
                viewModel.setQuietHours(hour * 60 + minute, settings.quietHoursEndMinute)
                showQuietStartPicker = false
            },
        )
    }
    if (showQuietEndPicker) {
        TimePickerDialog(
            title = "Quiet hours end",
            initialHour = settings.quietHoursEndMinute / 60,
            initialMinute = settings.quietHoursEndMinute % 60,
            onDismiss = { showQuietEndPicker = false },
            onTimeSelected = { hour, minute ->
                viewModel.setQuietHours(settings.quietHoursStartMinute, hour * 60 + minute)
                showQuietEndPicker = false
            },
        )
    }

    message?.let {
        AlertDialog(
            onDismissRequest = viewModel::clearMessage,
            confirmButton = {
                TextButton(onClick = viewModel::clearMessage) { Text("OK") }
            },
            text = { Text(it) },
        )
    }
}

private fun formatTimeOfDay(hour: Int, minute: Int): String =
    "%02d:%02d".format(hour, minute)

/** Friendly app name for a package (falls back to the last package segment). */
private fun appLabel(context: Context, packageName: String): String {
    return runCatching {
        val appInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.packageManager.getApplicationInfo(
                packageName,
                PackageManager.ApplicationInfoFlags.of(0),
            )
        } else {
            @Suppress("DEPRECATION")
            context.packageManager.getApplicationInfo(packageName, 0)
        }
        context.packageManager.getApplicationLabel(appInfo).toString()
    }.getOrElse { packageName.substringAfterLast('.') }
}
