package com.zaid.jarvis.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.zaid.jarvis.components.ApprovalHost
import com.zaid.jarvis.screens.AuditLogScreen
import com.zaid.jarvis.screens.BackupScreen
import com.zaid.jarvis.screens.ChatScreen
import com.zaid.jarvis.screens.ConnectedAccountsScreen
import com.zaid.jarvis.screens.DraftEditorScreen
import com.zaid.jarvis.screens.DraftsScreen
import com.zaid.jarvis.screens.HomeScreen
import com.zaid.jarvis.screens.InsightsScreen
import com.zaid.jarvis.screens.MacrosScreen
import com.zaid.jarvis.screens.MemoryScreen
import com.zaid.jarvis.screens.NotesScreen
import com.zaid.jarvis.screens.PluginsScreen
import com.zaid.jarvis.screens.ResearchScreen
import com.zaid.jarvis.screens.ScheduledPostsScreen
import com.zaid.jarvis.screens.SettingsScreen
import com.zaid.jarvis.screens.TasksScreen
import com.zaid.jarvis.screens.WellnessScreen
import com.zaid.jarvis.viewmodel.ConfirmationViewModel
import com.zaid.jarvis.voice.VoiceStateStore
import kotlinx.serialization.Serializable

/** Type-safe destinations (Navigation Compose + Kotlin Serialization). */
@Serializable object HomeDestination
@Serializable object ChatDestination
@Serializable object SettingsDestination

/** Audit Log is reachable from Home and Settings, not from the bottom bar. */
@Serializable object AuditLogDestination

/** Memory is reachable from Settings, not from the bottom bar. */
@Serializable object MemoryDestination

/** Macros are reachable from Home and Settings, not from the bottom bar. */
@Serializable object MacrosDestination

/** Research history is reachable from Home and Settings, not from the bottom bar. */
@Serializable object ResearchDestination

/** Drafts are reachable from Home and Settings, not from the bottom bar. */
@Serializable object DraftsDestination

/** One draft in the editor (draftId 0 = a new blank draft). */
@Serializable data class DraftEditorDestination(val draftId: Long)

/** Connected social accounts (Phase 8), reachable from Settings. */
@Serializable object ConnectedAccountsDestination

/** Scheduled posts (Phase 8), reachable from Home, Settings, and Drafts. */
@Serializable object ScheduledPostsDestination

/** Tasks (Phase 9), reachable from Home and Settings, not from the bottom bar. */
@Serializable object TasksDestination

/** Wellness (Phase 9), reachable from Home and Settings, not from the bottom bar. */
@Serializable object WellnessDestination

/** Plugins (Phase 10), reachable from Settings, not from the bottom bar. */
@Serializable object PluginsDestination

/** Notes (Phase 10), reachable from Home and Settings, not from the bottom bar. */
@Serializable object NotesDestination

/** Backup (Phase 10), reachable from Settings, not from the bottom bar. */
@Serializable object BackupDestination

/** Insights (Phase 10), reachable from Settings, not from the bottom bar. */
@Serializable object InsightsDestination

private data class TopLevelDestination(
    val route: Any,
    val label: String,
    val icon: ImageVector,
)

private val topLevelDestinations = listOf(
    TopLevelDestination(HomeDestination, "Home", Icons.Filled.Home),
    TopLevelDestination(ChatDestination, "Chat", Icons.Filled.Chat),
    TopLevelDestination(SettingsDestination, "Settings", Icons.Filled.Settings),
)

/**
 * Single-activity navigation: a bottom bar with Home, Chat, and Settings,
 * plus a top bar with the kill switch (Master Prompt §2.4 — one tap,
 * visible on every screen) and the approval host mounted once so an
 * approval card can arrive while Zaid is on any screen.
 * Phase 4: the overlay bubble, widget, and Quick Settings tile deep-link
 * into these same destinations via [VoiceStateStore] request counters.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JarvisNavGraph(
    confirmationViewModel: ConfirmationViewModel = hiltViewModel(),
    startDestination: Any = HomeDestination,
    voiceStateStore: VoiceStateStore = VoiceStateStore(),
) {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val killGeneration by confirmationViewModel.killGeneration.collectAsState()
    val voiceNonce by voiceStateStore.voiceStartRequests.collectAsState()
    val openChatNonce by voiceStateStore.openChatRequests.collectAsState()
    val openTasksNonce by voiceStateStore.openTasksRequests.collectAsState()
    val openWellnessNonce by voiceStateStore.openWellnessRequests.collectAsState()

    // Deep-links (widget / tile / wake word / overlay): show Chat.
    LaunchedEffect(openChatNonce, voiceNonce) {
        if (openChatNonce > 0 || voiceNonce > 0) {
            navController.navigate(ChatDestination) {
                launchSingleTop = true
            }
        }
    }

    // Deep-links (Phase 9 notifications): show Tasks / Wellness.
    LaunchedEffect(openTasksNonce) {
        if (openTasksNonce > 0) {
            navController.navigate(TasksDestination) {
                launchSingleTop = true
            }
        }
    }
    LaunchedEffect(openWellnessNonce) {
        if (openWellnessNonce > 0) {
            navController.navigate(WellnessDestination) {
                launchSingleTop = true
            }
        }
    }

    // Feedback when the kill switch is used.
    LaunchedEffect(killGeneration) {
        if (killGeneration > 0) {
            snackbarHostState.showSnackbar("All automation stopped.")
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val onAuditLog = navBackStackEntry?.destination?.hierarchy?.any {
                it.hasRoute(AuditLogDestination::class) || it.hasRoute(MemoryDestination::class) ||
                    it.hasRoute(MacrosDestination::class) ||
                    it.hasRoute(ResearchDestination::class) ||
                    it.hasRoute(DraftsDestination::class) ||
                    it.hasRoute(DraftEditorDestination::class) ||
                    it.hasRoute(ConnectedAccountsDestination::class) ||
                    it.hasRoute(ScheduledPostsDestination::class) ||
                    it.hasRoute(TasksDestination::class) ||
                    it.hasRoute(WellnessDestination::class) ||
                    it.hasRoute(PluginsDestination::class) ||
                    it.hasRoute(NotesDestination::class) ||
                    it.hasRoute(BackupDestination::class) ||
                    it.hasRoute(InsightsDestination::class)
            } == true
            TopAppBar(
                title = { Text("Zaid Jarvis") },
                navigationIcon = {
                    if (onAuditLog) {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = {
                    IconButton(onClick = confirmationViewModel::stopAll) {
                        Icon(
                            Icons.Filled.Stop,
                            contentDescription = "Stop all automation (kill switch)",
                            tint = MaterialTheme.colorScheme.error,
                        )
                    }
                },
            )
        },
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination
                topLevelDestinations.forEach { destination ->
                    val selected = currentDestination?.hierarchy?.any {
                        it.hasRoute(destination.route::class)
                    } == true
                    NavigationBarItem(
                        icon = { Icon(destination.icon, contentDescription = destination.label) },
                        label = { Text(destination.label) },
                        selected = selected,
                        onClick = {
                            navController.navigate(destination.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                    )
                }
            }
        },
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = Modifier.padding(innerPadding),
        ) {
            composable<HomeDestination> {
                HomeScreen(
                    confirmationViewModel = confirmationViewModel,
                    onNavigateToAuditLog = { navController.navigate(AuditLogDestination) },
                    onNavigateToMacros = { navController.navigate(MacrosDestination) },
                    onNavigateToResearch = { navController.navigate(ResearchDestination) },
                    onNavigateToDrafts = { navController.navigate(DraftsDestination) },
                    onNavigateToScheduledPosts = { navController.navigate(ScheduledPostsDestination) },
                    onNavigateToTasks = { navController.navigate(TasksDestination) },
                    onNavigateToWellness = { navController.navigate(WellnessDestination) },
                    onNavigateToNotes = { navController.navigate(NotesDestination) },
                    onNavigateToChat = { navController.navigate(ChatDestination) },
                    onOrbTap = {
                        voiceStateStore.requestVoiceStart()
                        navController.navigate(ChatDestination) {
                            launchSingleTop = true
                        }
                    },
                )
            }
            composable<ChatDestination> { ChatScreen(voiceStartNonce = voiceNonce) }
            composable<SettingsDestination> {
                SettingsScreen(
                    onNavigateToAuditLog = { navController.navigate(AuditLogDestination) },
                    onNavigateToMemory = { navController.navigate(MemoryDestination) },
                    onNavigateToMacros = { navController.navigate(MacrosDestination) },
                    onNavigateToResearch = { navController.navigate(ResearchDestination) },
                    onNavigateToDrafts = { navController.navigate(DraftsDestination) },
                    onNavigateToConnectedAccounts = { navController.navigate(ConnectedAccountsDestination) },
                    onNavigateToScheduledPosts = { navController.navigate(ScheduledPostsDestination) },
                    onNavigateToTasks = { navController.navigate(TasksDestination) },
                    onNavigateToWellness = { navController.navigate(WellnessDestination) },
                    onNavigateToPlugins = { navController.navigate(PluginsDestination) },
                    onNavigateToNotes = { navController.navigate(NotesDestination) },
                    onNavigateToBackup = { navController.navigate(BackupDestination) },
                    onNavigateToInsights = { navController.navigate(InsightsDestination) },
                )
            }
            composable<AuditLogDestination> { AuditLogScreen() }
            composable<MemoryDestination> { MemoryScreen() }
            composable<MacrosDestination> { MacrosScreen() }
            composable<ResearchDestination> { ResearchScreen() }
            composable<DraftsDestination> {
                DraftsScreen(
                    onOpenDraft = { draftId ->
                        navController.navigate(DraftEditorDestination(draftId))
                    },
                    onNavigateToScheduledPosts = { navController.navigate(ScheduledPostsDestination) },
                )
            }
            composable<DraftEditorDestination> { backStackEntry ->
                val destination = backStackEntry.toRoute<DraftEditorDestination>()
                DraftEditorScreen(
                    draftId = destination.draftId,
                    onBack = { navController.popBackStack() },
                )
            }
            composable<ConnectedAccountsDestination> { ConnectedAccountsScreen() }
            composable<ScheduledPostsDestination> { ScheduledPostsScreen() }
            composable<TasksDestination> { TasksScreen() }
            composable<WellnessDestination> { WellnessScreen() }
            composable<PluginsDestination> { PluginsScreen() }
            composable<NotesDestination> { NotesScreen() }
            composable<BackupDestination> { BackupScreen() }
            composable<InsightsDestination> { InsightsScreen() }
        }
    }

    // Approval cards overlay every screen.
    ApprovalHost(viewModel = confirmationViewModel)
}
