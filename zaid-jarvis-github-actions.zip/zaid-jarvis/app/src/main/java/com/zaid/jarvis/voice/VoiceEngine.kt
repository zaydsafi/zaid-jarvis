package com.zaid.jarvis.voice

import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.core.voice.SpeechInputState
import com.zaid.jarvis.core.voice.VoiceState
import dagger.hilt.android.scopes.ActivityRetainedScoped
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Coordinates speech input and output (Master Prompt §5.2): one place
 * owns the mic and the speaker, so the chat screen, the overlay bubble,
 * and the wake-word service never fight over them.
 *
 * - [startListening] begins one recognizer session; final transcripts
 *   are emitted on [finalTranscripts] (the ChatViewModel routes them —
 *   "Jarvis stop" to the kill switch, anything else to the planner).
 * - [speak] reads an answer aloud at the Settings speed; a new request
 *   or the kill switch stops it immediately.
 * - The kill switch ([KillSwitch]) stops both listening and speaking:
 *   "Jarvis stop" silences Jarvis mid-sentence.
 *
 * Scoped to the activity-retained component: the engine lives as long
 * as the app's UI process, and the tile/service entry points share it
 * through [VoiceStateStore] instead of holding the mic themselves.
 */
@ActivityRetainedScoped
class VoiceEngine @Inject constructor(
    private val speechInput: SpeechInput,
    private val speechOutput: SpeechOutput,
    private val killSwitch: KillSwitch,
    private val voiceStateStore: VoiceStateStore,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _state = MutableStateFlow<VoiceState>(VoiceState.Idle)
    val state: StateFlow<VoiceState> = _state.asStateFlow()

    private val _finalTranscripts = MutableSharedFlow<String>(extraBufferCapacity = 1)
    /** Final transcripts, in order. Only the ChatViewModel collects this. */
    val finalTranscripts: SharedFlow<String> = _finalTranscripts.asSharedFlow()

    init {
        // The kill switch silences Jarvis immediately.
        killSwitch.addOnCancelListener {
            stopSpeaking()
            stopListening()
        }
        scope.launch {
            speechInput.state.collect { inputState ->
                when (inputState) {
                    is SpeechInputState.Idle -> {
                        if (_state.value is VoiceState.Listening) {
                            _state.value = VoiceState.Idle
                            voiceStateStore.setListening(false)
                        }
                    }
                    is SpeechInputState.Listening -> {
                        _state.value = VoiceState.Listening(inputState.partialTranscript)
                        voiceStateStore.setListening(true)
                    }
                    is SpeechInputState.Final -> {
                        _state.value = VoiceState.Processing
                        voiceStateStore.setListening(false)
                        _finalTranscripts.tryEmit(inputState.text)
                    }
                    is SpeechInputState.Error -> {
                        _state.value = VoiceState.Error(inputState.message)
                        voiceStateStore.setListening(false)
                    }
                }
            }
        }
        scope.launch {
            speechOutput.isSpeaking.collect { speaking ->
                if (speaking) {
                    _state.value = VoiceState.Speaking
                } else if (_state.value is VoiceState.Speaking) {
                    _state.value = VoiceState.Idle
                }
            }
        }
    }

    /** True when a recognizer exists on this device. */
    val isAvailable: Boolean get() = speechInput.isAvailable

    /** Starts one listening session in [languageTag] (BCP 47). */
    fun startListening(languageTag: String) {
        stopSpeaking()
        speechInput.start(languageTag)
    }

    /** Stops listening; a final result (if any) is still delivered. */
    fun stopListening() {
        speechInput.stop()
    }

    /** Cancels listening without a result. */
    fun cancelListening() {
        speechInput.cancel()
        if (_state.value is VoiceState.Listening || _state.value is VoiceState.Error) {
            _state.value = VoiceState.Idle
        }
        voiceStateStore.setListening(false)
    }

    /** Speaks [text] aloud; stops any speech already playing. */
    fun speak(text: String, speechRate: Float, languageTag: String) {
        speechOutput.speak(text, speechRate, languageTag)
    }

    /** Stops speaking immediately. */
    fun stopSpeaking() {
        speechOutput.stop()
        if (_state.value is VoiceState.Speaking) {
            _state.value = VoiceState.Idle
        }
    }

    /** Marks the engine idle once a voice run has finished answering. */
    fun markIdle() {
        if (_state.value is VoiceState.Processing) {
            _state.value = VoiceState.Idle
        }
    }
}
