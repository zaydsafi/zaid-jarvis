package com.zaid.jarvis

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.fragment.app.FragmentActivity
import androidx.hilt.navigation.compose.hiltViewModel
import com.zaid.jarvis.navigation.ChatDestination
import com.zaid.jarvis.navigation.HomeDestination
import com.zaid.jarvis.navigation.JarvisNavGraph
import com.zaid.jarvis.navigation.TasksDestination
import com.zaid.jarvis.navigation.WellnessDestination
import com.zaid.jarvis.ui.theme.JarvisTheme
import com.zaid.jarvis.viewmodel.SettingsViewModel
import com.zaid.jarvis.voice.VoiceStateStore
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Zaid Jarvis — single activity. All screens are Compose destinations
 * in the Navigation Compose graph (see JarvisNavGraph).
 *
 * Extends FragmentActivity (not plain ComponentActivity) because Tier 3
 * approvals use BiometricPrompt, which requires a FragmentActivity host.
 *
 * Deep-links (Phase 4): the widget, the Quick Settings tile, the
 * wake-word service, and the overlay bubble launch this activity with
 * extras — [EXTRA_DESTINATION] picks the start screen and
 * [EXTRA_START_VOICE] asks the chat screen to start listening. The
 * activity is singleTop, so a warm launch arrives in [onNewIntent]
 * and is routed through [VoiceStateStore] instead of recreating the UI.
 * Phase 9 adds [DESTINATION_TASKS] and [DESTINATION_WELLNESS] for the
 * productivity notification taps.
 */
@AndroidEntryPoint
class MainActivity : FragmentActivity() {

    @Inject lateinit var voiceStateStore: VoiceStateStore

    private var startDestination: Any by mutableStateOf<Any>(HomeDestination)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent, coldStart = true)
        enableEdgeToEdge()
        setContent {
            val settingsViewModel: SettingsViewModel = hiltViewModel()
            val settings by settingsViewModel.settings.collectAsState()
            JarvisTheme(themeMode = settings.themeMode) {
                JarvisNavGraph(
                    startDestination = startDestination,
                    voiceStateStore = voiceStateStore,
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent, coldStart = false)
    }

    private fun handleIntent(intent: Intent?, coldStart: Boolean) {
        if (intent == null) return
        val destination = intent.getStringExtra(EXTRA_DESTINATION)
        val startVoice = intent.getBooleanExtra(EXTRA_START_VOICE, false)
        if (destination == DESTINATION_CHAT) {
            if (coldStart) {
                startDestination = ChatDestination
            } else {
                voiceStateStore.requestOpenChat()
            }
        }
        if (destination == DESTINATION_TASKS) {
            if (coldStart) {
                startDestination = TasksDestination
            } else {
                voiceStateStore.requestOpenTasks()
            }
        }
        if (destination == DESTINATION_WELLNESS) {
            if (coldStart) {
                startDestination = WellnessDestination
            } else {
                voiceStateStore.requestOpenWellness()
            }
        }
        if (startVoice) {
            // Voice implies chat: make sure the nav graph shows it.
            if (coldStart) {
                startDestination = ChatDestination
            } else {
                voiceStateStore.requestOpenChat()
            }
            voiceStateStore.requestVoiceStart()
        }
    }

    companion object {
        /** [EXTRA_DESTINATION] value: open the Chat screen. */
        const val DESTINATION_CHAT: String = "chat"

        /** [EXTRA_DESTINATION] value: open the Tasks screen (Phase 9). */
        const val DESTINATION_TASKS: String = "tasks"

        /** [EXTRA_DESTINATION] value: open the Wellness screen (Phase 9). */
        const val DESTINATION_WELLNESS: String = "wellness"

        /** String extra: which screen to open ([DESTINATION_CHAT]). */
        const val EXTRA_DESTINATION: String = "com.zaid.jarvis.EXTRA_DESTINATION"

        /** Boolean extra: start voice listening once Chat is showing. */
        const val EXTRA_START_VOICE: String = "com.zaid.jarvis.EXTRA_START_VOICE"
    }
}
