package com.zaid.jarvis

import android.app.Application
import com.zaid.jarvis.backup.BackupScheduler
import com.zaid.jarvis.backup.MaintenanceScheduler
import com.zaid.jarvis.plugins.PluginRegistry
import com.zaid.jarvis.productivity.WellnessScheduler
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

@HiltAndroidApp
class JarvisApplication : Application() {

    @Inject lateinit var wellnessScheduler: WellnessScheduler

    @Inject lateinit var pluginRegistry: PluginRegistry

    @Inject lateinit var backupScheduler: BackupScheduler

    @Inject lateinit var maintenanceScheduler: MaintenanceScheduler

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        // Phase 10: register the enabled plugins' tools with the
        // planner (disabled plugins stay unregistered; trust is
        // re-applied for trusted plugins).
        applicationScope.launch {
            runCatching { pluginRegistry.sync() }
        }
        // Phase 10: re-sync the weekly auto-backup job from Settings
        // (same force-stop/update reasoning as the wellness workers).
        applicationScope.launch {
            runCatching { backupScheduler.syncAutoBackup() }
        }
        // Phase 11: make sure the weekly maintenance job (retention
        // prune) is scheduled — not gated on any setting.
        applicationScope.launch {
            runCatching { maintenanceScheduler.syncMaintenance() }
        }
        // Phase 9: WorkManager survives app restarts, but a force-stop
        // or an update can drop jobs — re-sync the digest + proactive
        // workers from Settings on every start (cheap and idempotent).
        applicationScope.launch {
            runCatching { wellnessScheduler.syncPeriodicWork() }
        }
    }
}
