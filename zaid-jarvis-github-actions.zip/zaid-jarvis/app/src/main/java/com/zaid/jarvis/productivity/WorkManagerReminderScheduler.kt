package com.zaid.jarvis.productivity

import android.content.Context
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.zaid.jarvis.core.productivity.Task
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.repository.TaskRepository
import com.zaid.jarvis.tools.productivity.ReminderScheduler
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The [ReminderScheduler] implementation (Phase 9): stores the
 * reminder time on the task and enqueues a one-time WorkManager job
 * for it.
 *
 * The job carries only the task row id — the worker re-reads the
 * task at run time and notifies only when the task still exists,
 * is still open, and still has this reminder attached. Cancelling
 * removes both the reminder and the WorkManager job. Re-scheduling
 * a task (a second set_reminder) cancels the old job first, so a
 * task never has two reminder jobs.
 *
 * User-set reminders are exempt from quiet hours (the user asked
 * for this exact time) — see [WellnessNotifier].
 */
@Singleton
class WorkManagerReminderScheduler @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: TaskRepository,
) : ReminderScheduler {

    override suspend fun schedule(taskId: Long, reminderAtMillis: Long): JarvisResult<Task> {
        val task = repository.getById(taskId)
            ?: return JarvisResult.Failure("No task with id $taskId.")
        if (task.status != com.zaid.jarvis.core.productivity.TaskStatus.OPEN) {
            return JarvisResult.Failure("“${task.title}” is already done — no reminder needed.")
        }
        val now = System.currentTimeMillis()
        if (reminderAtMillis <= now) {
            return JarvisResult.Failure("That reminder time is in the past — pick a future time.")
        }
        // A second reminder replaces the first: cancel the old job.
        task.reminderWorkId?.let { workId ->
            runCatching { WorkManager.getInstance(context).cancelWorkById(UUID.fromString(workId)) }
        }
        return try {
            val request = OneTimeWorkRequestBuilder<TaskReminderWorker>()
                .setInitialDelay(reminderAtMillis - now, TimeUnit.MILLISECONDS)
                .setInputData(
                    Data.Builder()
                        .putLong(TaskReminderWorker.KEY_TASK_ID, taskId)
                        .putLong(TaskReminderWorker.KEY_REMINDER_AT_MILLIS, reminderAtMillis)
                        .build(),
                )
                .addTag(TaskReminderWorker.WORK_TAG)
                .build()
            WorkManager.getInstance(context).enqueue(request)
            when (val saved = repository.setReminder(taskId, reminderAtMillis, request.id.toString())) {
                is JarvisResult.Success -> JarvisResult.Success(saved.value)
                is JarvisResult.Failure -> {
                    WorkManager.getInstance(context).cancelWorkById(request.id)
                    saved
                }
            }
        } catch (e: Exception) {
            JarvisResult.Failure(
                "Could not set the reminder: ${e.message ?: e::class.simpleName}. " +
                    "Try again in a moment.",
            )
        }
    }

    override suspend fun cancel(taskId: Long): JarvisResult<Unit> {
        val task = repository.getById(taskId)
            ?: return JarvisResult.Failure("No task with id $taskId.")
        task.reminderWorkId?.let { workId ->
            runCatching { WorkManager.getInstance(context).cancelWorkById(UUID.fromString(workId)) }
        }
        repository.clearReminder(taskId)
        return JarvisResult.Success(Unit)
    }
}
