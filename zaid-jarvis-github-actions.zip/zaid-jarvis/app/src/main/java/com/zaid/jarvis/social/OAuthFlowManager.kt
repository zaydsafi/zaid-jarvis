package com.zaid.jarvis.social

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.browser.customtabs.CustomTabsIntent
import com.zaid.jarvis.agent.social.OAuthClient
import com.zaid.jarvis.core.social.Pkce
import com.zaid.jarvis.core.social.SocialAccount
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.social.SocialAccountStore
import com.zaid.jarvis.tools.social.SocialPublisher
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The OAuth 2.0 Authorization Code + PKCE connect flow (Phase 8).
 *
 * Choice: PKCE implemented manually with Custom Tabs, not AppAuth —
 * AppAuth-Android is not in the project's version catalog, and the
 * flow is small (build an auth URL, open a Custom Tab, handle the
 * redirect, exchange the code). No extra dependency for something
 * four platforms share.
 *
 * Flow:
 * 1. [startConnect] checks that OAuth client credentials are stored,
 *    generates a PKCE verifier + S256 challenge and a random `state`,
 *    keeps them in memory only (never persisted — if the process dies
 *    mid-flow, the sign-in simply fails and Zaid retries), and opens
 *    the platform's authorization URL in a Custom Tab (falling back
 *    to the default browser when Custom Tabs isn't available).
 * 2. The platform redirects to `com.zaid.jarvis://oauth2redirect`,
 *    handled by [OAuthRedirectActivity], which calls [handleRedirect].
 * 3. [handleRedirect] validates `state` (CSRF protection), exchanges
 *    the code for tokens (PKCE verifier presented), stores the tokens
 *    Keystore-encrypted, and fetches the /me profile so the Connected
 *    accounts screen can show the handle.
 *
 * PKCE note: X, Threads, and LinkedIn accept the S256 code challenge
 * in the authorization URL. Instagram goes through Meta's web OAuth
 * dialog, which does not take PKCE parameters — its token exchange is
 * authenticated with the client secret instead (see OAuthClient).
 * The verifier is still generated for uniformity but only sent where
 * the platform accepts it.
 */
@Singleton
class OAuthFlowManager @Inject constructor(
    private val accountStore: SocialAccountStore,
    private val oAuthClient: OAuthClient,
    private val publisher: SocialPublisher,
) {

    /** One in-flight connect flow (in memory only — never persisted). */
    private data class PendingFlow(
        val platform: SocialPlatform,
        val codeVerifier: String,
        val state: String,
    )

    @Volatile
    private var pending: PendingFlow? = null

    /**
     * Starts the connect flow for [platform] by opening the
     * authorization page. Returns a failure when no client credentials
     * are stored (Zaid adds them in Settings → Connected accounts).
     */
    fun startConnect(activity: Activity, platform: SocialPlatform): JarvisResult<Unit> {
        val credentials = runBlockingOrNull { accountStore.getClientCredentials(platform) }
        if (credentials == null || credentials.clientId.isBlank()) {
            return JarvisResult.Failure(
                "Add your ${platform.displayName} client ID first — see the setup steps " +
                    "in the ${platform.displayName} card below (PHASE8.md has the full guide).",
            )
        }
        val verifier = Pkce.generateCodeVerifier()
        val state = Pkce.generateState()
        pending = PendingFlow(platform, verifier, state)

        val authUrl = buildAuthUrl(platform, credentials.clientId, state, verifier)
        val customTabsIntent = CustomTabsIntent.Builder().build()
        return try {
            // Falls back to the default browser when Custom Tabs isn't available.
            customTabsIntent.launchUrl(activity, Uri.parse(authUrl))
            JarvisResult.Success(Unit)
        } catch (e: Exception) {
            pending = null
            JarvisResult.Failure(
                "Could not open the ${platform.displayName} sign-in page: " +
                    "${e.message ?: e::class.simpleName}.",
            )
        }
    }

    /**
     * Handles the OAuth redirect (`com.zaid.jarvis://oauth2redirect`).
     * Validates `state`, exchanges the code, stores the tokens, and
     * fetches the profile. Called by [OAuthRedirectActivity].
     */
    suspend fun handleRedirect(uri: Uri): JarvisResult<SocialAccount> {
        val flow = pending
        pending = null
        if (flow == null) {
            return JarvisResult.Failure(
                "The sign-in was interrupted (the app restarted while you were " +
                    "signing in). Please try connecting again.",
            )
        }
        // State is validated FIRST, before the error branch (Phase 11):
        // an error redirect that fails the state check is not ours —
        // the redirect activity is exported, so any app can send it a
        // crafted URI, and without this a forged redirect could surface
        // attacker-controlled error_description text to Zaid as if it
        // came from the platform.
        if (uri.getQueryParameter("state") != flow.state) {
            return JarvisResult.Failure(
                "Sign-in to ${flow.platform.displayName} failed: the security check " +
                    "didn't match. Please try again.",
            )
        }
        uri.getQueryParameter("error")?.let { error ->
            val description = uri.getQueryParameter("error_description") ?: error
            return JarvisResult.Failure(
                "Sign-in to ${flow.platform.displayName} failed: $description",
            )
        }
        val code = uri.getQueryParameter("code")
            ?: return JarvisResult.Failure(
                "Sign-in to ${flow.platform.displayName} failed: no authorization " +
                    "code came back. Please try again.",
            )
        val credentials = accountStore.getClientCredentials(flow.platform)
            ?: return JarvisResult.Failure(
                "The ${flow.platform.displayName} client credentials are gone — " +
                    "add them again in Settings → Connected accounts.",
            )
        return when (
            val tokens = oAuthClient.exchangeCode(
                platform = flow.platform,
                code = code,
                codeVerifier = flow.codeVerifier,
                redirectUri = REDIRECT_URI,
                credentials = credentials,
            )
        ) {
            is JarvisResult.Failure -> tokens
            is JarvisResult.Success -> {
                accountStore.saveTokens(flow.platform, tokens.value)
                when (val profile = publisher.fetchProfile(flow.platform)) {
                    is JarvisResult.Success -> profile
                    is JarvisResult.Failure -> {
                        // Tokens are stored but the profile lookup
                        // failed (e.g. Instagram with no linked Page).
                        // Keep the tokens — the account row is absent,
                        // so the UI shows "not connected" with the
                        // reason in the message; Zaid can fix the
                        // underlying issue and tap Connect again.
                        profile
                    }
                }
            }
        }
    }

    /** Forgets any in-flight connect flow (e.g. the user backed out). */
    fun cancelPending() {
        pending = null
    }

    private fun buildAuthUrl(
        platform: SocialPlatform,
        clientId: String,
        state: String,
        verifier: String,
    ): String {
        val builder = Uri.parse(platform.authorizeUrl).buildUpon()
            .appendQueryParameter("response_type", "code")
            .appendQueryParameter("client_id", clientId)
            .appendQueryParameter("redirect_uri", REDIRECT_URI)
            .appendQueryParameter("scope", platform.scopes.joinToString(" "))
            .appendQueryParameter("state", state)
        if (platform != SocialPlatform.INSTAGRAM) {
            // Meta's web OAuth dialog doesn't take PKCE parameters.
            builder
                .appendQueryParameter("code_challenge", Pkce.codeChallengeS256(verifier))
                .appendQueryParameter("code_challenge_method", "S256")
        }
        return builder.build().toString()
    }

    companion object {
        /** The redirect URI, registered in every platform's developer portal. */
        const val REDIRECT_URI: String = "com.zaid.jarvis://oauth2redirect"

        /**
         * The last connect-flow error, for the Connected accounts screen
         * to show after [OAuthRedirectActivity] finishes (the redirect
         * activity has no UI of its own to show it on). Null after a
         * successful connect. In-memory only.
         */
        @Volatile
        var lastError: String? = null
    }
}

/**
 * Runs a suspending block from a non-suspending call site. Used only
 * for the tiny DataStore/SecureKeyStore read in [OAuthFlowManager.startConnect]
 * (both are fast, local reads — never network).
 */
private fun <T> runBlockingOrNull(block: suspend () -> T): T? {
    return kotlinx.coroutines.runBlocking { runCatching { block() }.getOrNull() }
}
