package com.zaid.jarvis.accessibility

import com.zaid.jarvis.core.automation.Macro
import com.zaid.jarvis.data.repository.MacroRepository
import com.zaid.jarvis.tools.automation.MacroStore
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The [MacroStore] the `run_macro` tool uses (Phase 6): a thin adapter
 * over [MacroRepository]. `:tools` cannot depend on `:data`, so the
 * interface lives in `:tools` and this implementation lives here.
 */
@Singleton
class RoomMacroStore @Inject constructor(
    private val macroRepository: MacroRepository,
) : MacroStore {
    override suspend fun getByName(name: String): Macro? =
        macroRepository.getByName(name)

    override suspend fun markRun(id: Long) {
        macroRepository.markRun(id)
    }
}
