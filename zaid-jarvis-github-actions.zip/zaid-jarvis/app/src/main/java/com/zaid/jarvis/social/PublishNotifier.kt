package com.zaid.jarvis.social

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.zaid.jarvis.MainActivity
import com.zaid.jarvis.core.social.SocialPlatform
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Publish / schedule result notifications (Phase 8).
 *
 * One channel ("Publishing"): success (tap opens the published post
 * in the browser), failure (tap opens the app, where the Scheduled
 * screen shows the reason and offers a retry), and cancellation
 * (tap opens the app). Silently skipped when the notification
 * permission isn't granted — the result is always visible in-app too,
 * so a missing permission never hides an outcome.
 */
@Singleton
class PublishNotifier @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val notificationManager: NotificationManager =
        context.getSystemService(NotificationManager::class.java)

    /** Posted when a scheduled post publishes successfully. */
    fun notifyPublished(platform: SocialPlatform, draftTitle: String, postUrl: String?) {
        val intent = if (postUrl != null) {
            Intent(Intent.ACTION_VIEW, Uri.parse(postUrl))
        } else {
            Intent(context, MainActivity::class.java)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            NOTIFICATION_ID_BASE + platform.ordinal,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val text = if (postUrl != null) {
            "“$draftTitle” is live on ${platform.displayName}. Tap to open it."
        } else {
            "“$draftTitle” is live on ${platform.displayName}."
        }
        notify(
            id = NOTIFICATION_ID_BASE + platform.ordinal,
            title = "Published to ${platform.displayName}",
            text = text,
            contentIntent = pendingIntent,
        )
    }

    /** Posted when a scheduled post fails to publish. */
    fun notifyFailed(platform: SocialPlatform, draftTitle: String, reason: String) {
        notify(
            id = NOTIFICATION_ID_BASE + 10 + platform.ordinal,
            title = "Couldn't publish to ${platform.displayName}",
            text = "“$draftTitle”: $reason",
            contentIntent = openAppIntent(platform.ordinal),
        )
    }

    /** Posted when a scheduled post is cancelled instead of publishing (stale draft). */
    fun notifyCancelled(platform: SocialPlatform, draftTitle: String, reason: String) {
        notify(
            id = NOTIFICATION_ID_BASE + 20 + platform.ordinal,
            title = "Scheduled post cancelled",
            text = "“$draftTitle” was not published to ${platform.displayName}: $reason",
            contentIntent = openAppIntent(platform.ordinal),
        )
    }

    private fun openAppIntent(requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
        return PendingIntent.getActivity(
            context,
            NOTIFICATION_ID_BASE + 100 + requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun notify(id: Int, title: String, text: String, contentIntent: PendingIntent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            // No permission — the result is still visible in-app.
            return
        }
        ensureChannel()
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(contentIntent)
            .setAutoCancel(true)
            .build()
        notificationManager.notify(id, notification)
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        if (notificationManager.getNotificationChannel(CHANNEL_ID) != null) return
        notificationManager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "Publishing",
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = "Results of scheduled social posts (published, failed, cancelled)."
            },
        )
    }

    private companion object {
        const val CHANNEL_ID: String = "jarvis_publishing"
        const val NOTIFICATION_ID_BASE: Int = 8000
    }
}
