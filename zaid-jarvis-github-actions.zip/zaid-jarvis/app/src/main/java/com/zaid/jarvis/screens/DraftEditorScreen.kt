package com.zaid.jarvis.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuAnchorType
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zaid.jarvis.core.research.ContentDraft
import com.zaid.jarvis.core.research.DraftLimits
import com.zaid.jarvis.core.research.DraftStatus
import com.zaid.jarvis.core.research.PlatformPreset
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.viewmodel.DraftsViewModel
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Draft editor (Phase 7): review and edit a draft, see the character
 * count against the platform limit, save, and approve for publishing.
 *
 * Approval is a deliberate tap — never automatic. Phase 8 adds
 * publishing from here: an APPROVED draft can be published now or
 * scheduled, both behind a Tier 2 approval card showing the exact
 * text. If the draft was edited after approval, it must be approved
 * again before it can be published (content binding).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DraftEditorScreen(
    draftId: Long,
    viewModel: DraftsViewModel = hiltViewModel(),
    onBack: () -> Unit = {},
) {
    val selected by viewModel.selectedDraft.collectAsState()
    val message by viewModel.message.collectAsState()

    LaunchedEffect(draftId) { viewModel.loadDraft(draftId) }

    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var platform by remember { mutableStateOf(PlatformPreset.X.displayName) }
    var initializedFor by remember { mutableStateOf<Long?>(null) }
    LaunchedEffect(selected) {
        val draft = selected
        if (draft != null && initializedFor != draft.id) {
            title = draft.title
            body = draft.body
            platform = draft.platform
            initializedFor = draft.id
        }
    }

    val limit = DraftLimits.limitFor(platform)
    val overLimit = body.length > limit
    val isNew = draftId == 0L
    var platformExpanded by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    // Phase 8: publish / schedule dialogs.
    var showImageUrlDialog by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }
    var pickedDateMillis by remember { mutableStateOf<Long?>(null) }
    var imageUrl by remember { mutableStateOf("") }
    val isInstagram = SocialPlatform.fromName(platform) == SocialPlatform.INSTAGRAM
    val editedSinceApproval = selected?.editedSinceApproval() == true
    val canPublish = selected?.status == DraftStatus.APPROVED && !editedSinceApproval && !overLimit

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            if (isNew) "New draft" else "Edit draft",
            style = MaterialTheme.typography.headlineMedium,
        )
        selected?.let { draft ->
            Text(
                "Status: " + when (draft.status) {
                    DraftStatus.DRAFT -> "Draft — waiting for your review"
                    DraftStatus.APPROVED -> "Approved for publishing"
                    DraftStatus.PUBLISHED -> "Published"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (editedSinceApproval) {
                Text(
                    "This draft was edited after approval — approve the edited text " +
                        "again before it can be published.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error,
                )
            }
        }

        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Title") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )

        ExposedDropdownMenuBox(
            expanded = platformExpanded,
            onExpandedChange = { platformExpanded = it },
        ) {
            OutlinedTextField(
                value = platform,
                onValueChange = {},
                readOnly = true,
                label = { Text("Platform") },
                trailingIcon = {
                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = platformExpanded)
                },
                modifier = Modifier
                    .menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable, enabled = true)
                    .fillMaxWidth(),
            )
            ExposedDropdownMenu(
                expanded = platformExpanded,
                onDismissRequest = { platformExpanded = false },
            ) {
                PlatformPreset.entries.forEach { preset ->
                    DropdownMenuItem(
                        text = { Text("${preset.displayName} (${preset.charLimit} chars)") },
                        onClick = {
                            platform = preset.displayName
                            platformExpanded = false
                        },
                    )
                }
            }
        }

        OutlinedTextField(
            value = body,
            onValueChange = { body = it },
            label = { Text("Post text") },
            minLines = 6,
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            "${body.length}/$limit characters" +
                if (overLimit) " — over the limit, please shorten it" else "",
            style = MaterialTheme.typography.bodySmall,
            color = if (overLimit) {
                MaterialTheme.colorScheme.error
            } else {
                MaterialTheme.colorScheme.onSurfaceVariant
            },
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    val draft = ContentDraft(
                        id = draftId,
                        title = title.trim(),
                        body = body.trim(),
                        platform = platform,
                        status = selected?.status ?: DraftStatus.DRAFT,
                        researchId = selected?.researchId,
                    )
                    viewModel.saveDraft(draft) { onBack() }
                },
                enabled = title.isNotBlank() && body.isNotBlank(),
            ) {
                Text("Save")
            }
            if (selected?.status == DraftStatus.DRAFT || editedSinceApproval) {
                Button(
                    onClick = { viewModel.approveDraft(draftId) },
                    enabled = !overLimit,
                ) {
                    Text(if (editedSinceApproval) "Approve edited text" else "Approve for publishing")
                }
            }
        }
        if (selected?.status == DraftStatus.DRAFT) {
            Text(
                "Approving means this draft can be published when you ask for it — " +
                    "from here, or by asking Jarvis. Nothing is published until you " +
                    "confirm it on the approval card.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        // Phase 8: publish / schedule (APPROVED drafts only).
        if (selected?.status == DraftStatus.APPROVED) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (isInstagram) {
                            showImageUrlDialog = true
                        } else {
                            viewModel.publishDraft(draftId)
                        }
                    },
                    enabled = canPublish,
                ) {
                    Text("Publish now")
                }
                OutlinedButton(
                    onClick = { showDatePicker = true },
                    enabled = canPublish,
                ) {
                    Text("Schedule…")
                }
            }
            Text(
                "Publishing shows an approval card with the exact text first. " +
                    "Scheduling needs at least 5 minutes' notice — if you edit the " +
                    "draft before then, the post is cancelled instead of publishing " +
                    "the old text.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (!isNew) {
            OutlinedButton(onClick = { confirmDelete = true }) {
                Text("Delete draft")
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
    }

    message?.let {
        AlertDialog(
            onDismissRequest = viewModel::clearMessage,
            confirmButton = {
                TextButton(onClick = viewModel::clearMessage) { Text("OK") }
            },
            text = { Text(it) },
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteDraft(draftId)
                        confirmDelete = false
                        onBack()
                    },
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Cancel") }
            },
            text = { Text("Delete this draft? This cannot be undone.") },
        )
    }
    // Instagram publish needs a public image URL (no text-only posts).
    if (showImageUrlDialog) {
        AlertDialog(
            onDismissRequest = { showImageUrlDialog = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.publishDraft(draftId, imageUrl.trim())
                        showImageUrlDialog = false
                    },
                    enabled = imageUrl.isNotBlank(),
                ) { Text("Publish") }
            },
            dismissButton = {
                TextButton(onClick = { showImageUrlDialog = false }) { Text("Cancel") }
            },
            title = { Text("Instagram photo") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Instagram cannot publish text-only posts. Paste the public " +
                            "URL of the photo to post with this text.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    OutlinedTextField(
                        value = imageUrl,
                        onValueChange = { imageUrl = it },
                        label = { Text("Public image URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
        )
    }
    // Schedule: pick a date, then a time (and an image URL for Instagram).
    if (showDatePicker) {
        val dateState = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        pickedDateMillis = dateState.selectedDateMillis
                        showDatePicker = false
                        if (dateState.selectedDateMillis != null) showTimePicker = true
                    },
                    enabled = dateState.selectedDateMillis != null,
                ) { Text("Next") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("Cancel") }
            },
        ) {
            DatePicker(state = dateState)
        }
    }
    if (showTimePicker) {
        val timeState = rememberTimePickerState()
        AlertDialog(
            onDismissRequest = { showTimePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val dateMillis = pickedDateMillis
                        if (dateMillis != null) {
                            val zone = ZoneId.systemDefault()
                            val date = Instant.ofEpochMilli(dateMillis).atZone(zone).toLocalDate()
                            val dateTime = LocalDateTime.of(
                                date,
                                java.time.LocalTime.of(timeState.hour, timeState.minute),
                            )
                            val scheduledAt = dateTime.atZone(zone).toInstant().toEpochMilli()
                            val delayMinutes =
                                (scheduledAt - System.currentTimeMillis()) / 60_000L
                            viewModel.scheduleDraft(
                                draftId,
                                delayMinutes,
                                imageUrl.trim().ifEmpty { null },
                            )
                        }
                        showTimePicker = false
                    },
                ) { Text("Schedule") }
            },
            dismissButton = {
                TextButton(onClick = { showTimePicker = false }) { Text("Cancel") }
            },
            title = { Text("Pick a time") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "At least 5 minutes from now. If the time is too soon, " +
                            "scheduling will refuse with a message.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    TimePicker(state = timeState)
                    if (isInstagram) {
                        OutlinedTextField(
                            value = imageUrl,
                            onValueChange = { imageUrl = it },
                            label = { Text("Public image URL (Instagram needs a photo)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            },
        )
    }
}
