package com.zaid.jarvis.accessibility

import com.zaid.jarvis.core.automation.MacroStep
import com.zaid.jarvis.core.automation.ObservedUiEvent
import com.zaid.jarvis.core.automation.RecorderLogic
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The macro recorder (Phase 6): while recording is active, the
 * AccessibilityService forwards the user's own taps, typing, and
 * scrolls here as [ObservedUiEvent]s, and they become macro steps.
 *
 * Privacy rules:
 * - Recording only happens while Zaid explicitly started it from the
 *   Macros screen. The service ignores all events otherwise.
 * - Text typed into password fields is never recorded: the service
 *   drops the text at the mapping site, and those events only bump
 *   [Recording.skippedPasswordEntries] so Zaid knows something was
 *   left out ("2 password entries were not recorded").
 * - Taps inside Jarvis itself are never recorded.
 *
 * This is a plain singleton (not a ViewModel): the service and the UI
 * both need it, and recording must survive leaving the Macros screen
 * (Zaid records by using *other* apps).
 */
@Singleton
class MacroRecorder @Inject constructor() {

    sealed interface RecordingState {
        data object Idle : RecordingState

        data class Recording(
            val steps: List<MacroStep>,
            val skippedPasswordEntries: Int,
            val startedAtMillis: Long,
        ) : RecordingState
    }

    private val _state = MutableStateFlow<RecordingState>(RecordingState.Idle)
    val state: StateFlow<RecordingState> = _state.asStateFlow()

    val isRecording: Boolean
        get() = _state.value is RecordingState.Recording

    /** Starts a fresh recording (discards any in-progress one). */
    fun start() {
        _state.value = RecordingState.Recording(
            steps = emptyList(),
            skippedPasswordEntries = 0,
            startedAtMillis = System.currentTimeMillis(),
        )
    }

    /**
     * Feeds one observed event into the recording. Ignored when not
     * recording. Password text events bump the skipped counter instead
     * of becoming a step.
     */
    fun observe(event: ObservedUiEvent) {
        val current = _state.value as? RecordingState.Recording ?: return
        if (event.isPassword && event.text == null) {
            // A password field was typed into: counted, never recorded.
            _state.value = current.copy(
                skippedPasswordEntries = current.skippedPasswordEntries + 1,
            )
            return
        }
        val step = RecorderLogic.eventToStep(event) ?: return
        _state.value = current.copy(steps = RecorderLogic.appendStep(current.steps, step))
    }

    /**
     * Stops recording and returns the recorded steps (empty when
     * nothing was recorded). The caller names and saves the macro.
     */
    fun stop(): List<MacroStep> {
        val current = _state.value as? RecordingState.Recording
        _state.value = RecordingState.Idle
        return current?.steps ?: emptyList()
    }

    /** How many password entries were skipped in the current recording. */
    fun skippedPasswordEntries(): Int =
        (_state.value as? RecordingState.Recording)?.skippedPasswordEntries ?: 0

    /** Discards the current recording without saving. */
    fun cancel() {
        _state.value = RecordingState.Idle
    }
}
