package com.zaid.jarvis.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zaid.jarvis.chat.ChatSession
import com.zaid.jarvis.chat.ChatUiMessage
import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.core.model.JarvisSettings
import com.zaid.jarvis.core.voice.VoiceCommandParser
import com.zaid.jarvis.core.voice.VoiceState
import com.zaid.jarvis.data.datastore.SettingsRepository
import com.zaid.jarvis.voice.VoiceEngine
import com.zaid.jarvis.voice.VoiceStateStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Chat state (Phases 3–4): the conversation itself lives in the shared
 * [ChatSession] (so the overlay bubble sees the same messages); this
 * ViewModel adds the voice layer on top.
 *
 * Voice flow: mic tap → [VoiceEngine] listens → final transcript →
 * here. "Jarvis stop" (checked on the final transcript, and on partial
 * transcripts while listening) hits the kill switch and silences TTS;
 * anything else is sent to the planner as a voice run. When a voice run
 * produces an assistant message and "voice replies" is on, the answer
 * is spoken aloud at the Settings speed.
 *
 * Microphone permission is the UI's job (ChatScreen requests it on the
 * first mic tap); [startVoiceInput] assumes it is already granted.
 */
@HiltViewModel
class ChatViewModel @Inject constructor(
    private val chatSession: ChatSession,
    private val voiceEngine: VoiceEngine,
    private val settingsRepository: SettingsRepository,
    private val killSwitch: KillSwitch,
    private val voiceStateStore: VoiceStateStore,
) : ViewModel() {

    val messages: StateFlow<List<ChatUiMessage>> = chatSession.messages
    val isThinking: StateFlow<Boolean> = chatSession.isThinking
    val statusText: StateFlow<String?> = chatSession.statusText
    val voiceState: StateFlow<VoiceState> = voiceEngine.state

    /** Bumped by widget / tile / wake word / Home orb — chat starts listening. */
    val voiceStartRequests: StateFlow<Int> = voiceStateStore.voiceStartRequests

    private val settings: StateFlow<JarvisSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), JarvisSettings())

    /** True while the current run was started by voice (so answers are spoken). */
    private var voiceRun: Boolean = false

    /** Id of the last assistant message already spoken (or offered to TTS). */
    private var lastSpokenMessageId: Long = -1L

    init {
        // Voice transcripts → stop command or planner request.
        viewModelScope.launch {
            voiceEngine.finalTranscripts.collect { transcript ->
                when (val command = VoiceCommandParser.parse(transcript)) {
                    is VoiceCommandParser.VoiceCommand.Stop -> {
                        killSwitch.cancelAll()
                        voiceEngine.stopSpeaking()
                        voiceEngine.markIdle()
                        chatSession.addSystemMessage("Stopped.")
                    }
                    is VoiceCommandParser.VoiceCommand.Request -> {
                        if (command.text.isNotBlank()) {
                            send(command.text, fromVoice = true)
                        } else {
                            voiceEngine.markIdle()
                        }
                    }
                }
            }
        }
        // "Jarvis stop" must also land on partial transcripts, mid-sentence.
        viewModelScope.launch {
            voiceEngine.state.collect { state ->
                if (state is VoiceState.Listening &&
                    VoiceCommandParser.isStopCommand(state.partialTranscript)
                ) {
                    voiceEngine.cancelListening()
                    killSwitch.cancelAll()
                    voiceEngine.stopSpeaking()
                    chatSession.addSystemMessage("Stopped.")
                }
            }
        }
        // Speak assistant answers for voice runs (when voice replies are on).
        viewModelScope.launch {
            messages.collect { list ->
                val latest = list.lastOrNull { it.role == "assistant" } ?: return@collect
                if (!voiceRun || latest.id == lastSpokenMessageId) return@collect
                lastSpokenMessageId = latest.id
                val current = settings.value
                if (current.voiceRepliesEnabled) {
                    voiceEngine.speak(latest.text, current.voiceSpeed, current.language.localeTag)
                }
            }
        }
        // A finished run ends the voice session (unless Jarvis is speaking).
        viewModelScope.launch {
            isThinking.collect { thinking ->
                if (!thinking) {
                    voiceRun = false
                    voiceEngine.markIdle()
                }
            }
        }
    }

    fun send(text: String, fromVoice: Boolean = false) {
        voiceEngine.stopSpeaking()
        voiceRun = fromVoice
        chatSession.send(text)
    }

    /** Starts one listening session (permission must already be granted). */
    fun startVoiceInput() {        if (!voiceEngine.isAvailable) {
            chatSession.addSystemMessage(
                "Speech recognition isn't available on this device. " +
                    "Install the Google app (or another recognizer) to use voice input.",
            )
            return
        }
        viewModelScope.launch {
            val languageTag = settingsRepository.settings.first().language.localeTag
            voiceEngine.startListening(languageTag)
        }
    }

    /** Explains the mic permission denial in chat (no nagging dialog). */
    fun onMicPermissionDenied() {
        chatSession.addSystemMessage(
            "Microphone permission is needed for voice input. " +
                "You can still type, or grant it in Android Settings → Apps → Zaid Jarvis.",
        )
    }

    /** Stops listening (keeps any final result) and stops speaking. */
    fun stopVoice() {
        voiceEngine.stopListening()
        voiceEngine.stopSpeaking()
    }

    /** Reads one Jarvis message aloud (the per-message speak button). */
    fun speakMessage(text: String) {
        val current = settings.value
        voiceEngine.speak(text, current.voiceSpeed, current.language.localeTag)
    }

    /** Clears the chat and the planner's short-term context. */
    fun clearChat() {
        voiceEngine.stopSpeaking()
        chatSession.clearChat()
    }
}
