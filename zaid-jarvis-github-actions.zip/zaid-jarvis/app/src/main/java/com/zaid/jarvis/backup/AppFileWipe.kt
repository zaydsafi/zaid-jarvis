package com.zaid.jarvis.backup

import android.content.Context
import com.zaid.jarvis.data.repository.FileWipe
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject

/**
 * The file side of delete-all-data (Phase 11 hardening): deletes the
 * automatic local backups (the app's private `auto_backups`
 * directory) and everything in the cache directory.
 *
 * Only these two locations are wiped: the database file is deleted by
 * [com.zaid.jarvis.data.repository.RoomDatabaseWipe], and DataStore
 * files are cleared through DataStore itself (never by deleting the
 * files — DataStore holds them open). Nothing else of Jarvis's lives
 * in the app's private storage.
 */
class AppFileWipe @Inject constructor(
    @ApplicationContext private val context: Context,
) : FileWipe {

    override fun wipe() {
        // Automatic local backups (newest 3, private storage).
        runCatching {
            AutoBackupFiles.list(context).forEach { AutoBackupFiles.delete(it) }
            AutoBackupFiles.directory(context).delete()
        }
        // Cache directory contents (not the directory itself).
        runCatching {
            context.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
        }
    }
}
