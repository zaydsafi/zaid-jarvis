package com.zaid.jarvis.productivity

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.zaid.jarvis.core.productivity.TaskStatus
import com.zaid.jarvis.data.repository.TaskRepository
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent

/**
 * The task reminder worker (Phase 9).
 *
 * Runs at the reminder time (one-time work — see
 * [WorkManagerReminderScheduler]). It re-reads the task and notifies
 * only when the task still exists, is still open, and still has THIS
 * reminder attached (same time): if Zaid completed, deleted, or
 * re-scheduled the task meanwhile, the worker stays silent. After
 * notifying, the reminder is cleared from the task (a reminder fires
 * once).
 *
 * User-set reminders are exempt from quiet hours — the user asked
 * for this exact time (see [WellnessNotifier]).
 *
 * Dependencies come from a Hilt entry point ([TaskReminderWorkerEntryPoint])
 * — same pattern as PublishPostWorker (Phase 8).
 */
class TaskReminderWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    private val entryPoint: TaskReminderWorkerEntryPoint =
        EntryPointAccessors.fromApplication(
            appContext,
            TaskReminderWorkerEntryPoint::class.java,
        )

    override suspend fun doWork(): Result {
        val taskId = inputData.getLong(KEY_TASK_ID, 0L)
        val reminderAtMillis = inputData.getLong(KEY_REMINDER_AT_MILLIS, 0L)
        if (taskId == 0L) return Result.failure()

        // A database failure here must not retry the job: retrying
        // after a successful notify would notify twice. Fail silent
        // instead — the reminder stays attached to the task, so Zaid
        // still sees it in the Tasks screen.
        return runCatching {
            val repository = entryPoint.taskRepository()
            val task = repository.getById(taskId)
            // Notify only when the task still exists, is still open,
            // and still has THIS reminder attached (same time): if Zaid
            // completed, deleted, or re-scheduled the task meanwhile,
            // the worker stays silent.
            val stillValid = task != null &&
                task.status == TaskStatus.OPEN &&
                task.reminderAtMillis == reminderAtMillis
            if (stillValid) {
                entryPoint.wellnessNotifier().notifyTaskReminder(taskId, task.title)
                repository.clearReminder(taskId)
            }
            Result.success()
        }.getOrDefault(Result.success())
    }

    companion object {
        /** Input-data key for the task row id. */
        const val KEY_TASK_ID: String = "task_id"

        /** Input-data key for the reminder time this job was scheduled for. */
        const val KEY_REMINDER_AT_MILLIS: String = "reminder_at_millis"

        /** Tag on every reminder job (for debugging / bulk cancellation). */
        const val WORK_TAG: String = "jarvis_task_reminder"
    }
}

/** Hilt entry point for [TaskReminderWorker] (WorkManager creates the worker, not Hilt). */
@EntryPoint
@InstallIn(SingletonComponent::class)
interface TaskReminderWorkerEntryPoint {
    fun taskRepository(): TaskRepository
    fun wellnessNotifier(): WellnessNotifier
}
