package com.zaid.jarvis.analytics

import com.zaid.jarvis.core.analytics.AnalyticsEvents
import com.zaid.jarvis.core.analytics.AnalyticsPayload
import com.zaid.jarvis.core.analytics.AnalyticsSink
import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.data.repository.AnalyticsRepository
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The production analytics sink (Phase 10): translates the typed
 * recording calls from the executor, the publisher, and the focus
 * manager into validated analytics events in the local database.
 * Only non-personal tokens are ever recorded (see
 * [AnalyticsPayload]); the repository drops anything invalid and
 * records nothing at all when insights are off.
 */
@Singleton
class AnalyticsSinkImpl @Inject constructor(
    private val repository: AnalyticsRepository,
) : AnalyticsSink {

    override suspend fun recordToolExecution(toolName: String, tier: RiskTier, outcome: String) {
        repository.record(
            AnalyticsEvents.TOOL_EXECUTED,
            mapOf(
                "tool" to toolName,
                "tier" to tier.name,
                "outcome" to outcome,
            ),
        )
    }

    override suspend fun recordPublish(platform: String, success: Boolean) {
        repository.record(
            AnalyticsEvents.PUBLISH,
            mapOf(
                "platform" to platform,
                "outcome" to if (success) AnalyticsEvents.OUTCOME_SUCCESS else AnalyticsEvents.OUTCOME_FAILURE,
            ),
        )
    }

    override suspend fun recordFocusSession(durationMinutes: Int, completed: Boolean) {
        repository.record(
            AnalyticsEvents.FOCUS_SESSION,
            mapOf(
                "duration_bucket" to AnalyticsPayload.durationBucket(durationMinutes),
                "outcome" to if (completed) AnalyticsEvents.OUTCOME_COMPLETED else AnalyticsEvents.OUTCOME_STOPPED_EARLY,
            ),
        )
    }
}
