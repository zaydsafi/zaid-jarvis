package com.zaid.jarvis.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.zaid.jarvis.MainActivity
import com.zaid.jarvis.core.voice.LastAnswer
import com.zaid.jarvis.data.repository.LastAnswerRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Builds and pushes widget updates (Master Prompt §5.4).
 *
 * The widget is a classic AppWidget (RemoteViews), not Glance: it
 * needs no new dependency, works on every supported API level, and
 * the layout is a single row — orb, last-answer line, mic button.
 * Updates are pushed (ChatSession calls [updateAll] after every
 * answer); the widget never polls (`updatePeriodMillis="0"`).
 *
 * Resource ids are resolved with `getIdentifier` instead of `R.*`:
 * the kotlinc verification in this VM has no generated R class, so
 * Kotlin code must not reference R directly. On a real Gradle build
 * these resolve to the same ids.
 */
object WidgetUpdater {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** Refreshes every Jarvis widget with the latest saved answer. */
    fun updateAll(context: Context) {
        scope.launch {
            val answer = runCatching {
                LastAnswerRepository(context.applicationContext).lastAnswer.first()
            }.getOrDefault("")
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                ComponentName(context, JarvisWidgetProvider::class.java),
            )
            if (ids.isEmpty()) return@launch
            val views = buildViews(context, answer) ?: return@launch
            manager.updateAppWidget(ids, views)
        }
    }

    /** Builds the widget's RemoteViews. Null when the layout is missing. */
    fun buildViews(context: Context, lastAnswer: String): RemoteViews? {
        val resources = context.resources
        val packageName = context.packageName
        val layoutId = resources.getIdentifier("widget_jarvis", "layout", packageName)
        if (layoutId == 0) return null
        val views = RemoteViews(packageName, layoutId)

        val orbId = resources.getIdentifier("widget_orb", "id", packageName)
        val launcherId = resources.getIdentifier("ic_launcher", "mipmap", packageName)
        if (orbId != 0 && launcherId != 0) {
            views.setImageViewResource(orbId, launcherId)
        }

        val answerId = resources.getIdentifier("widget_last_answer", "id", packageName)
        if (answerId != 0) {
            views.setTextViewText(answerId, LastAnswer.formatForWidget(lastAnswer))
        }

        // Mic → open Chat and start listening.
        val micId = resources.getIdentifier("widget_mic", "id", packageName)
        if (micId != 0) {
            views.setOnClickPendingIntent(micId, openChatPendingIntent(context, startVoice = true, requestCode = 1))
        }
        // Anywhere else → open Chat.
        val rootId = resources.getIdentifier("widget_root", "id", packageName)
        if (rootId != 0) {
            views.setOnClickPendingIntent(rootId, openChatPendingIntent(context, startVoice = false, requestCode = 2))
        }
        return views
    }

    private fun openChatPendingIntent(
        context: Context,
        startVoice: Boolean,
        requestCode: Int,
    ): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MainActivity.EXTRA_DESTINATION, MainActivity.DESTINATION_CHAT)
            if (startVoice) {
                putExtra(MainActivity.EXTRA_START_VOICE, true)
            }
        }
        return PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
    }
}
