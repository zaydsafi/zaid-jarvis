package com.zaid.jarvis.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.repository.NoteRepository
import com.zaid.jarvis.plugins.notes.Note
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Notes screen state (Phase 10): the list, search, and the editor.
 *
 * Editing from the UI calls the repository directly — the user is
 * pressing the button themselves (same as tasks and drafts). The
 * planner tools (save_note etc.) are the gated path for chat/voice
 * requests, and note content returned to the planner is scanned by
 * the InjectionGuard (notes are data, never instructions).
 */
@HiltViewModel
class NotesViewModel @Inject constructor(
    private val noteRepository: NoteRepository,
) : ViewModel() {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    /** Notes matching the current search, newest first. */
    val notes: StateFlow<List<Note>> = combine(
        noteRepository.observeAll(),
        _query,
    ) { all, query ->
        val trimmed = query.trim()
        val filtered = if (trimmed.isEmpty()) {
            all
        } else {
            all.filter {
                it.title.contains(trimmed, ignoreCase = true) ||
                    it.body.contains(trimmed, ignoreCase = true)
            }
        }
        filtered.sortedByDescending { it.updatedAtMillis }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** The note open in the editor (null = new note / none loaded). */
    private val _selectedNote = MutableStateFlow<Note?>(null)
    val selectedNote: StateFlow<Note?> = _selectedNote.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)

    /** One-shot result message (save result, error). */
    val message: StateFlow<String?> = _message.asStateFlow()

    fun clearMessage() {
        _message.value = null
    }

    fun setQuery(query: String) {
        _query.value = query
    }

    /** Loads a note into the editor (id 0 = a new blank note). */
    fun loadNote(id: Long) {
        if (id == 0L) {
            _selectedNote.value = null
            return
        }
        viewModelScope.launch {
            _selectedNote.value = noteRepository.getById(id)
        }
    }

    /** Saves the editor's note (new or existing). */
    fun saveNote(note: Note, onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch {
            when (val result = noteRepository.save(note)) {
                is JarvisResult.Success -> {
                    _selectedNote.value = noteRepository.getById(result.value)
                    onSaved(result.value)
                }
                is JarvisResult.Failure -> _message.value = result.message
            }
        }
    }

    /** Deletes a note. */
    fun deleteNote(id: Long) {
        viewModelScope.launch {
            noteRepository.deleteById(id)
            if (_selectedNote.value?.id == id) _selectedNote.value = null
        }
    }
}
