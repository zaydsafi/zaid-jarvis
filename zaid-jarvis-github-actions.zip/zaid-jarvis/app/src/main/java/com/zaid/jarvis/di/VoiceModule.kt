package com.zaid.jarvis.di

import android.content.Context
import com.zaid.jarvis.voice.AndroidSpeechInput
import com.zaid.jarvis.voice.AndroidSpeechOutput
import com.zaid.jarvis.voice.SpeechInput
import com.zaid.jarvis.voice.SpeechOutput
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent

/**
 * Voice bindings (Phase 4). Deliberately unscoped: the chat [VoiceEngine]
 * and the [WakeWordService] each get their own SpeechRecognizer — sharing
 * one recognizer between the foreground UI and the background wake-word
 * loop would make them steal the mic from each other. (If both try to
 * listen at once, one gets ERROR_RECOGNIZER_BUSY and reports it; see
 * PHASE4.md.)
 */
@Module
@InstallIn(SingletonComponent::class)
object VoiceModule {

    @Provides
    fun provideSpeechInput(
        @ApplicationContext context: Context,
    ): SpeechInput = AndroidSpeechInput(context)

    @Provides
    fun provideSpeechOutput(
        @ApplicationContext context: Context,
    ): SpeechOutput = AndroidSpeechOutput(context)
}
