package com.zaid.jarvis.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zaid.jarvis.core.productivity.CalendarEvent
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.repository.TaskRepository
import com.zaid.jarvis.tools.productivity.CalendarReader
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Home screen state (Phase 9): today's schedule + tasks due today.
 *
 * The calendar is read-only and optional: without READ_CALENDAR the
 * schedule section simply stays empty (with a hint to grant access
 * in Settings) — Home never fails because of a missing permission.
 */
@HiltViewModel
class HomeViewModel @Inject constructor(
    private val taskRepository: TaskRepository,
    private val calendarReader: CalendarReader,
) : ViewModel() {

    private val _tasksDueTodayCount = MutableStateFlow(0)
    val tasksDueTodayCount: StateFlow<Int> = _tasksDueTodayCount.asStateFlow()

    private val _overdueCount = MutableStateFlow(0)
    val overdueCount: StateFlow<Int> = _overdueCount.asStateFlow()

    private val _todayEvents = MutableStateFlow<List<CalendarEvent>>(emptyList())
    val todayEvents: StateFlow<List<CalendarEvent>> = _todayEvents.asStateFlow()

    private val _calendarAvailable = MutableStateFlow(false)
    val calendarAvailable: StateFlow<Boolean> = _calendarAvailable.asStateFlow()

    init {
        refresh()
    }

    /** Reloads today's tasks + events (call on resume). */
    fun refresh() {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            _tasksDueTodayCount.value = taskRepository.getDueToday(now).size
            _overdueCount.value = taskRepository.getOverdue(now).size
        }
        viewModelScope.launch {
            if (!calendarReader.hasCalendarAccess()) {
                _calendarAvailable.value = false
                _todayEvents.value = emptyList()
                return@launch
            }
            _calendarAvailable.value = true
            val zone = ZoneId.systemDefault()
            val today = LocalDate.ofInstant(Instant.ofEpochMilli(System.currentTimeMillis()), zone)
            val start = today.atStartOfDay(zone).toInstant().toEpochMilli()
            val end = today.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
            _todayEvents.value = when (val result = calendarReader.eventsBetween(start, end)) {
                is JarvisResult.Success -> result.value
                is JarvisResult.Failure -> emptyList()
            }
        }
    }
}
