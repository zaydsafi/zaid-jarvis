package com.zaid.jarvis.tile

import android.app.PendingIntent
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.zaid.jarvis.MainActivity
import com.zaid.jarvis.voice.VoiceStateStore
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Quick Settings tile (Master Prompt §5.5): "Talk to Jarvis".
 *
 * - Tap → opens the app to Chat and starts voice listening (via
 *   [MainActivity.EXTRA_START_VOICE]). The tile does not hold the
 *   recognizer itself — the chat screen stays the single owner of
 *   voice transcripts — so tapping while already listening just opens
 *   Chat, where Zaid can stop listening.
 * - Tile state reflects listening: ACTIVE while the mic is live
 *   (observed through [VoiceStateStore]), INACTIVE otherwise.
 * - Long-press → the system opens the app (standard tile behaviour).
 *
 * The tile cannot request the microphone permission itself; if it is
 * not granted, Chat asks for it on the first mic tap, as usual.
 */
@AndroidEntryPoint
class JarvisTileService : TileService() {

    @Inject lateinit var voiceStateStore: VoiceStateStore

    private val scope = CoroutineScope(Dispatchers.Main.immediate + Job())
    private var observeJob: Job? = null

    override fun onTileAdded() {
        super.onTileAdded()
        updateTile(isListening = false)
    }

    override fun onStartListening() {
        super.onStartListening()
        observeJob?.cancel()
        observeJob = scope.launch {
            voiceStateStore.isListening.collect { listening ->
                updateTile(isListening = listening)
            }
        }
    }

    override fun onStopListening() {
        observeJob?.cancel()
        observeJob = null
        super.onStopListening()
    }

    override fun onClick() {
        super.onClick()
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MainActivity.EXTRA_DESTINATION, MainActivity.DESTINATION_CHAT)
            putExtra(MainActivity.EXTRA_START_VOICE, true)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            // API 34+: the Intent overload is deprecated; use PendingIntent.
            val pendingIntent = PendingIntent.getActivity(
                this,
                0,
                intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            startActivityAndCollapse(pendingIntent)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }

    override fun onDestroy() {
        scope.coroutineContext[Job]?.cancel()
        super.onDestroy()
    }

    private fun updateTile(isListening: Boolean) {
        val tile = qsTile ?: return
        tile.state = if (isListening) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = if (isListening) "Jarvis is listening" else "Talk to Jarvis"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.subtitle = if (isListening) "Tap to open Chat" else "Tap to start listening"
        }
        tile.icon = Icon.createWithResource(this, android.R.drawable.ic_btn_speak_now)
        tile.updateTile()
    }
}
