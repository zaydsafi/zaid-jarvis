package com.zaid.jarvis.voice

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.zaid.jarvis.MainActivity
import com.zaid.jarvis.core.voice.SpeechInputState
import com.zaid.jarvis.core.voice.WakeWordMatcher
import com.zaid.jarvis.data.datastore.SettingsRepository
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Wake-word listening (Master Prompt §5.2): a foreground service that
 * keeps the platform SpeechRecognizer running in a loop and watches
 * transcripts for "Hey Jarvis".
 *
 * Honest limits — read before expecting always-on hotword behaviour:
 * - This is NOT true always-on keyword spotting. Android has no public
 *   always-on hotword API for third-party apps; real hotword detection
 *   needs a dedicated library (e.g. Porcupine, Vosk) or OEM support.
 *   This service restarts the recognizer after every result/error, so
 *   it holds the microphone continuously and uses noticeably more
 *   battery than a keyword spotter would.
 * - The recognizer pauses while another app holds the mic (calls,
 *   voice notes) and restarts afterwards.
 * - Wake word is OFF by default and only starts when Zaid enables it
 *   in Settings (which also asks for microphone permission).
 *
 * On a wake word the service opens the app to Chat with voice listening
 * started, then pauses itself for [WAKE_COOLDOWN_MILLIS] so the same
 * utterance does not re-trigger it.
 */
@AndroidEntryPoint
class WakeWordService : Service() {

    @Inject lateinit var speechInput: SpeechInput

    @Inject lateinit var settingsRepository: SettingsRepository

    @Inject lateinit var voiceStateStore: VoiceStateStore

    private val scope = CoroutineScope(Dispatchers.Main.immediate + Job())
    private var listenJob: Job? = null
    private var restartDelayMillis: Long = RESTART_DELAY_START_MILLIS
    private var coolingDownUntilMillis: Long = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            // Permission revoked while running: stop, don't loop errors.
            stopSelf()
            return START_NOT_STICKY
        }
        if (listenJob == null) {
            listenJob = scope.launch { listenLoop() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        listenJob?.cancel()
        listenJob = null
        speechInput.cancel()
        scope.coroutineContext[Job]?.cancel()
        super.onDestroy()
    }

    private suspend fun listenLoop() {
        val languageTag = settingsRepository.settings.first().language.localeTag
        speechInput.state.collect { inputState ->
            when (inputState) {
                is SpeechInputState.Listening -> {
                    restartDelayMillis = RESTART_DELAY_START_MILLIS
                    if (System.currentTimeMillis() >= coolingDownUntilMillis &&
                        WakeWordMatcher.matches(inputState.partialTranscript)
                    ) {
                        onWakeWordHeard()
                    }
                }
                is SpeechInputState.Final -> {
                    if (System.currentTimeMillis() >= coolingDownUntilMillis &&
                        WakeWordMatcher.matches(inputState.text)
                    ) {
                        onWakeWordHeard()
                    } else {
                        restartListening(languageTag)
                    }
                }
                is SpeechInputState.Error -> {
                    // Silence / no-match is normal: restart quietly.
                    // Real errors (network, busy) back off before retrying.
                    restartListening(languageTag)
                }
                is SpeechInputState.Idle -> {
                    restartListening(languageTag)
                }
            }
        }
    }

    private fun onWakeWordHeard() {
        coolingDownUntilMillis = System.currentTimeMillis() + WAKE_COOLDOWN_MILLIS
        speechInput.cancel()
        voiceStateStore.requestVoiceStart()
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MainActivity.EXTRA_START_VOICE, true)
            putExtra(MainActivity.EXTRA_DESTINATION, MainActivity.DESTINATION_CHAT)
        }
        startActivity(intent)
        scope.launch {
            delay(WAKE_COOLDOWN_MILLIS)
            val languageTag = settingsRepository.settings.first().language.localeTag
            restartListening(languageTag)
        }
    }

    private fun restartListening(languageTag: String) {
        scope.launch {
            delay(restartDelayMillis)
            restartDelayMillis =
                (restartDelayMillis * 2).coerceAtMost(RESTART_DELAY_MAX_MILLIS)
            if (System.currentTimeMillis() < coolingDownUntilMillis) return@launch
            speechInput.start(languageTag)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "Wake word listening",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Jarvis is listening for “Hey Jarvis”. " +
                    "Turn it off in Settings → Voice."
            },
        )
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Jarvis is listening for “Hey Jarvis”")
            .setContentText("Say “Hey Jarvis” to talk. Uses the microphone and battery.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val CHANNEL_ID: String = "jarvis_wake_word"
        private const val NOTIFICATION_ID: Int = 1001
        private const val RESTART_DELAY_START_MILLIS: Long = 500L
        private const val RESTART_DELAY_MAX_MILLIS: Long = 5_000L
        private const val WAKE_COOLDOWN_MILLIS: Long = 10_000L
    }
}
