package com.zaid.jarvis.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zaid.jarvis.accessibility.MacroRecorder
import com.zaid.jarvis.core.automation.Macro
import com.zaid.jarvis.viewmodel.MacrosViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Macros screen (Phase 6): Zaid's recorded automation sequences.
 *
 * Record: tap "Start recording", use another app normally (taps,
 * typing, scrolling are captured), come back here and tap "Stop &
 * save". Password entries are never recorded. Run: one approval card
 * lists every step, then the macro plays — the kill switch stops it
 * at any time.
 */
@Composable
fun MacrosScreen(
    viewModel: MacrosViewModel = hiltViewModel(),
) {
    val macros by viewModel.macros.collectAsState()
    val recordingState by viewModel.recordingState.collectAsState()
    val automationEnabled by viewModel.automationEnabled.collectAsState()
    val accessibilityConnected by viewModel.accessibilityConnected.collectAsState()
    val message by viewModel.message.collectAsState()

    var renaming by remember { mutableStateOf<Macro?>(null) }
    var savingRecording by remember { mutableStateOf(false) }

    val recording = recordingState as? MacroRecorder.RecordingState.Recording
    val canRecord = automationEnabled && accessibilityConnected && recording == null

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Macros", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Recorded sequences of taps, typing, and scrolling. Run one and " +
                "Jarvis replays it — after you approve the full step list. " +
                "Automation is fragile by nature: if an app changes its layout, " +
                "a macro stops at the step it can no longer find.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        if (recording != null) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("● Recording…", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "${recording.steps.size} step(s) recorded." +
                            if (recording.skippedPasswordEntries > 0) {
                                " ${recording.skippedPasswordEntries} password entr" +
                                    (if (recording.skippedPasswordEntries == 1) "y" else "ies") +
                                    " skipped (never recorded)."
                            } else {
                                ""
                            },
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        "Use another app normally, then come back here to stop. " +
                            "Taps inside Jarvis itself are not recorded.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { savingRecording = true }) { Text("Stop & save") }
                        OutlinedButton(onClick = viewModel::cancelRecording) { Text("Cancel") }
                    }
                }
            }
        } else {
            Button(onClick = viewModel::startRecording, enabled = canRecord) {
                Text("Start recording")
            }
            if (!canRecord) {
                Text(
                    when {
                        !accessibilityConnected -> "Recording needs the Accessibility service: " +
                            "enable “Zaid Jarvis automation” in Android Settings → Accessibility."
                        !automationEnabled -> "Recording needs Automation turned on in Settings → Automation."
                        else -> ""
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (macros.isEmpty()) {
                item {
                    Text(
                        "No macros yet. Record one — for example, opening your news app " +
                            "and tapping the top story — then run it from here or by asking Jarvis.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            items(macros) { macro ->
                MacroCard(
                    macro = macro,
                    onRun = { viewModel.runMacro(macro.name) },
                    onRename = { renaming = macro },
                    onDelete = { viewModel.deleteMacro(macro.id) },
                )
            }
        }
    }

    renaming?.let { macro ->
        var newName by remember(macro) { mutableStateOf(macro.name) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Rename macro") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.renameMacro(macro, newName)
                        renaming = null
                    },
                    enabled = newName.isNotBlank(),
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { renaming = null }) { Text("Cancel") }
            },
        )
    }

    if (savingRecording) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { savingRecording = false },
            title = { Text("Save recording") },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Macro name") },
                    placeholder = { Text("e.g. Morning news") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.stopRecordingAndSave(name)
                        savingRecording = false
                    },
                    enabled = name.isNotBlank(),
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { savingRecording = false }) { Text("Keep recording") }
            },
        )
    }

    message?.let { text ->
        AlertDialog(
            onDismissRequest = viewModel::clearMessage,
            title = { Text("Macros") },
            text = { Text(text) },
            confirmButton = {
                Button(onClick = viewModel::clearMessage) { Text("OK") }
            },
        )
    }
}

@Composable
private fun MacroCard(
    macro: Macro,
    onRun: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    val dateFormat = remember { SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault()) }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(macro.name, style = MaterialTheme.typography.titleSmall)
            Text(
                "${macro.steps.size} step(s) · created " +
                    dateFormat.format(Date(macro.createdAtMillis)) +
                    (macro.lastRunAtMillis?.let { " · last run " + dateFormat.format(Date(it)) } ?: ""),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (expanded) {
                Text(
                    macro.describeSteps(),
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onRun) { Text("Run") }
                OutlinedButton(onClick = { expanded = !expanded }) {
                    Text(if (expanded) "Hide steps" else "Show steps")
                }
                OutlinedButton(onClick = onRename) { Text("Rename") }
                OutlinedButton(onClick = onDelete) { Text("Delete") }
            }
        }
    }
}
