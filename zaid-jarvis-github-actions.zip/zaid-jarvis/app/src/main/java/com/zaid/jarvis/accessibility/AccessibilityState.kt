package com.zaid.jarvis.accessibility

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Where the app learns whether the Accessibility service is running
 * (Phase 6). Two sources, used together:
 *
 * - [isConnected] — a live flow the service itself updates in
 *   `onServiceConnected` / `onUnbind`. True while the system has the
 *   service bound.
 * - [isServiceEnabled] — a on-demand check against the system's list
 *   of enabled services. The Settings screen re-reads this on resume,
 *   because the user enables the service in system Settings and then
 *   comes back — the flow alone would not refresh until the service
 *   actually connects.
 *
 * Jarvis never enables the service itself: Android requires the user
 * to do it by hand in Settings → Accessibility. The app only deep-links
 * there ([openAccessibilitySettingsIntent]).
 */
object AccessibilityState {

    private val _isConnected = MutableStateFlow(false)

    /** True while the system has JarvisAccessibilityService bound. */
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    internal fun setConnected(connected: Boolean) {
        _isConnected.value = connected
    }

    /** True when Jarvis's service is in the system's enabled list. */
    fun isServiceEnabled(context: Context): Boolean {
        val manager =
            context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
                ?: return false
        return manager
            .getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { info ->
                info.resolveInfo.serviceInfo.packageName == context.packageName &&
                    info.resolveInfo.serviceInfo.name ==
                    JarvisAccessibilityService::class.java.name
            }
    }

    /** Intent for the system Accessibility settings screen. */
    fun openAccessibilitySettingsIntent(): Intent =
        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
}

/**
 * The currently bound service instance, if any. The system owns the
 * service's lifecycle, so Hilt cannot inject it — the service registers
 * itself here in `onServiceConnected` and clears itself in `onUnbind`.
 * The automation device reads this to reach the service; a null value
 * means "not connected" and every action fails clearly.
 */
object AccessibilityServiceHolder {
    @Volatile
    var service: JarvisAccessibilityService? = null
        internal set
}
