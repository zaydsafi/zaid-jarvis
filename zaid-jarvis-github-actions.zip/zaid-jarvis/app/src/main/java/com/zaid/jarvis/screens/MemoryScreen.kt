package com.zaid.jarvis.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zaid.jarvis.data.db.MemoryItem
import com.zaid.jarvis.viewmodel.MemoryViewModel

/**
 * Memory screen (Master Prompt §4): everything Jarvis remembers about
 * Zaid — preferences, nicknames, routines, writing style. Zaid can view,
 * edit, and delete any item; deleted memory is gone for good.
 */
@Composable
fun MemoryScreen(
    viewModel: MemoryViewModel = hiltViewModel(),
) {
    val memories by viewModel.memories.collectAsState()
    var editing by remember { mutableStateOf<MemoryItem?>(null) }
    var adding by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Memory", style = MaterialTheme.typography.headlineMedium)
        Text(
            "What Jarvis remembers about you. It uses this to answer in your " +
                "style and remember your preferences — nothing here is shared.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { adding = true }) { Text("Add memory") }
            if (memories.isNotEmpty()) {
                OutlinedButton(onClick = viewModel::deleteAll) { Text("Delete all") }
            }
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (memories.isEmpty()) {
                item {
                    Text(
                        "No memories yet. Add one — for example, kind \"preference\", " +
                            "key \"coffee\", value \"black, no sugar\".",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            items(memories) { item ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            "${item.kind} / ${item.key}",
                            style = MaterialTheme.typography.titleSmall,
                        )
                        Text(item.value, style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { editing = item }) { Text("Edit") }
                            OutlinedButton(onClick = { viewModel.deleteMemory(item.id) }) {
                                Text("Delete")
                            }
                        }
                    }
                }
            }
        }
    }

    if (adding) {
        MemoryEditorDialog(
            title = "Add memory",
            onDismiss = { adding = false },
            onSave = { kind, key, value ->
                viewModel.addMemory(kind, key, value)
                adding = false
            },
        )
    }
    editing?.let { item ->
        MemoryEditorDialog(
            title = "Edit memory",
            initialKind = item.kind,
            initialKey = item.key,
            initialValue = item.value,
            onDismiss = { editing = null },
            onSave = { kind, key, value ->
                viewModel.updateMemory(item, kind, key, value)
                editing = null
            },
        )
    }
}

@Composable
private fun MemoryEditorDialog(
    title: String,
    initialKind: String = "",
    initialKey: String = "",
    initialValue: String = "",
    onDismiss: () -> Unit,
    onSave: (kind: String, key: String, value: String) -> Unit,
) {
    var kind by remember { mutableStateOf(initialKind) }
    var key by remember { mutableStateOf(initialKey) }
    var value by remember { mutableStateOf(initialValue) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = kind,
                    onValueChange = { kind = it },
                    label = { Text("Kind (e.g. preference)") },
                    singleLine = true,
                )
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it },
                    label = { Text("Key (e.g. coffee)") },
                    singleLine = true,
                )
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it },
                    label = { Text("Value (e.g. black, no sugar)") },
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(kind, key, value) },
                enabled = key.isNotBlank() && value.isNotBlank(),
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}
