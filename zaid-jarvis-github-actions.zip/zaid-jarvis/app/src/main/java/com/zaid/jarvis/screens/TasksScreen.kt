package com.zaid.jarvis.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zaid.jarvis.core.productivity.DueDateParser
import com.zaid.jarvis.core.productivity.Task
import com.zaid.jarvis.core.productivity.TaskPriority
import com.zaid.jarvis.core.productivity.TaskStatus
import com.zaid.jarvis.viewmodel.TasksViewModel
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

/**
 * Tasks list (Phase 9): Zaid's to-do list, with due dates, priorities,
 * and reminders.
 *
 * Due dates and reminders are typed in plain words ("tomorrow",
 * "Friday at 5pm", "in 3 days") and parsed by [DueDateParser] — the
 * editor shows the resolved date live, and anything unparseable is
 * flagged instead of guessed. Overdue tasks are highlighted in red.
 * Asking Jarvis in chat works too ("remind me to buy milk tomorrow
 * at 9am") — the same tools, gated by the Confirmation Engine.
 */
@Composable
fun TasksScreen(
    viewModel: TasksViewModel = hiltViewModel(),
) {
    val tasks by viewModel.tasks.collectAsState()
    val filter by viewModel.filter.collectAsState()
    val openCount by viewModel.openCount.collectAsState()
    val message by viewModel.message.collectAsState()
    var editingTask by remember { mutableStateOf<Task?>(null) }
    var showEditor by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Tasks", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Your to-do list. Due dates and reminders are typed in plain words — " +
                "“tomorrow”, “Friday at 5pm”, “in 3 days”. Overdue tasks get one gentle " +
                "nudge a day (turn it off in Settings → Productivity & wellness).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Button(
            onClick = {
                editingTask = null
                showEditor = true
            },
        ) {
            Text("New task")
        }

        // Filter chips.
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            TasksViewModel.TaskFilter.entries.forEach { taskFilter ->
                val label = when (taskFilter) {
                    TasksViewModel.TaskFilter.OPEN -> "Open ($openCount)"
                    TasksViewModel.TaskFilter.DONE -> "Done"
                    TasksViewModel.TaskFilter.OVERDUE -> "Overdue"
                    TasksViewModel.TaskFilter.ALL -> "All"
                }
                FilterChip(
                    selected = filter == taskFilter,
                    onClick = { viewModel.setFilter(taskFilter) },
                    label = { Text(label) },
                )
            }
        }

        if (tasks.isEmpty()) {
            Text(
                when (filter) {
                    TasksViewModel.TaskFilter.OVERDUE -> "Nothing overdue — all clear."
                    TasksViewModel.TaskFilter.DONE -> "No completed tasks yet."
                    else -> "No tasks yet. Add one above, or ask Jarvis: “remind me to " +
                        "buy milk tomorrow at 9am”."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(tasks, key = { it.id }) { task ->
                TaskCard(
                    task = task,
                    onEdit = {
                        editingTask = task
                        showEditor = true
                    },
                    onComplete = { viewModel.completeTask(task.id) },
                    onDelete = { viewModel.deleteTask(task.id) },
                )
            }
        }
    }

    if (showEditor) {
        TaskEditorDialog(
            task = editingTask,
            onDismiss = { showEditor = false },
            onSave = { edited ->
                viewModel.saveTask(edited)
                showEditor = false
            },
        )
    }

    message?.let {
        AlertDialog(
            onDismissRequest = viewModel::clearMessage,
            confirmButton = {
                TextButton(onClick = viewModel::clearMessage) { Text("OK") }
            },
            text = { Text(it) },
        )
    }
}

@Composable
private fun TaskCard(
    task: Task,
    onEdit: () -> Unit,
    onComplete: () -> Unit,
    onDelete: () -> Unit,
) {
    val now = System.currentTimeMillis()
    val overdue = task.isOverdue(now)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onEdit),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(task.title, style = MaterialTheme.typography.titleMedium)
                Text(
                    task.priority.displayName,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (task.priority == TaskPriority.HIGH) {
                        MaterialTheme.colorScheme.error
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                )
            }
            if (task.notes.isNotBlank()) {
                Text(
                    task.notes,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 2,
                )
            }
            task.dueAtMillis?.let { due ->
                Text(
                    "Due ${formatDateTime(due)}" + if (overdue) " — OVERDUE" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (overdue) {
                        MaterialTheme.colorScheme.error
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                )
            }
            task.reminderAtMillis?.let { reminder ->
                Text(
                    "Reminder at ${formatDateTime(reminder)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (task.status == TaskStatus.OPEN) {
                    OutlinedButton(onClick = onComplete) { Text("Done") }
                }
                OutlinedButton(onClick = onEdit) { Text("Edit") }
                OutlinedButton(onClick = onDelete) { Text("Delete") }
            }
        }
    }
}

/**
 * The task editor: title, notes, due date and reminder as plain
 * words, priority chips. The parsed date is previewed live under
 * each field; unparseable input shows a hint instead of a date, and
 * Save refuses to store a due date it could not understand.
 */
@Composable
private fun TaskEditorDialog(
    task: Task?,
    onDismiss: () -> Unit,
    onSave: (Task) -> Unit,
) {
    var title by remember(task) { mutableStateOf(task?.title ?: "") }
    var notes by remember(task) { mutableStateOf(task?.notes ?: "") }
    var duePhrase by remember(task) { mutableStateOf("") }
    var reminderPhrase by remember(task) { mutableStateOf("") }
    var priority by remember(task) { mutableStateOf(task?.priority ?: TaskPriority.MEDIUM) }
    var dueCleared by remember(task) { mutableStateOf(false) }
    var reminderCleared by remember(task) { mutableStateOf(false) }
    var dueError by remember { mutableStateOf<String?>(null) }
    var reminderError by remember { mutableStateOf<String?>(null) }

    val parsedDue = duePhrase.takeIf { it.isNotBlank() }?.let { DueDateParser.parse(it) }
    val parsedReminder = reminderPhrase.takeIf { it.isNotBlank() }?.let { DueDateParser.parse(it) }
    // Locals (not cross-module property reads) so smart casts work.
    val currentDue = task?.dueAtMillis
    val currentReminder = task?.reminderAtMillis

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (task == null) "New task" else "Edit task") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (optional)") },
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = duePhrase,
                    onValueChange = {
                        duePhrase = it
                        dueError = null
                        dueCleared = false
                    },
                    label = { Text("Due — e.g. tomorrow, Friday at 5pm") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                when {
                    dueCleared -> Text(
                        "Due date will be removed.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    duePhrase.isBlank() && currentDue != null -> Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(
                            "Currently due ${formatDateTime(currentDue)}.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = { dueCleared = true }) { Text("Remove") }
                    }
                    duePhrase.isNotBlank() && parsedDue != null -> Text(
                        "Due ${formatDateTime(parsedDue)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    duePhrase.isNotBlank() -> Text(
                        "I couldn't understand that date — try “tomorrow” or “Friday at 5pm”.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                dueError?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
                OutlinedTextField(
                    value = reminderPhrase,
                    onValueChange = {
                        reminderPhrase = it
                        reminderError = null
                        reminderCleared = false
                    },
                    label = { Text("Remind me — e.g. tomorrow at 9am") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                when {
                    reminderCleared -> Text(
                        "Reminder will be removed.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    reminderPhrase.isBlank() && currentReminder != null -> Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(
                            "Reminder set for ${formatDateTime(currentReminder)}.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = { reminderCleared = true }) { Text("Remove") }
                    }
                    reminderPhrase.isNotBlank() && parsedReminder != null -> Text(
                        "Reminder at ${formatDateTime(parsedReminder)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    reminderPhrase.isNotBlank() -> Text(
                        "I couldn't understand that time — try “tomorrow at 9am” or “in 2 hours”.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                reminderError?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TaskPriority.entries.forEach { option ->
                        FilterChip(
                            selected = priority == option,
                            onClick = { priority = option },
                            label = { Text(option.displayName) },
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (title.isBlank()) return@TextButton
                    if (duePhrase.isNotBlank() && parsedDue == null) {
                        dueError = "Please fix the due date (or clear it)."
                        return@TextButton
                    }
                    if (reminderPhrase.isNotBlank() && parsedReminder == null) {
                        reminderError = "Please fix the reminder time (or clear it)."
                        return@TextButton
                    }
                    if (parsedReminder != null && parsedReminder <= System.currentTimeMillis()) {
                        reminderError = "That reminder time is in the past."
                        return@TextButton
                    }
                    val edited = (task ?: Task(title = title)).copy(
                        title = title.trim(),
                        notes = notes.trim(),
                        dueAtMillis = when {
                            dueCleared -> null
                            parsedDue != null -> parsedDue
                            else -> task?.dueAtMillis
                        },
                        // Reminder: a new phrase replaces the old
                        // one; "Remove" clears it; blank keeps it.
                        reminderAtMillis = when {
                            reminderCleared -> null
                            parsedReminder != null -> parsedReminder
                            else -> task?.reminderAtMillis
                        },
                        priority = priority,
                    )
                    onSave(edited)
                },
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

private fun formatDateTime(epochMillis: Long): String {
    val dateTime = Instant.ofEpochMilli(epochMillis).atZone(ZoneId.systemDefault())
    return dateTime.format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.SHORT))
}
