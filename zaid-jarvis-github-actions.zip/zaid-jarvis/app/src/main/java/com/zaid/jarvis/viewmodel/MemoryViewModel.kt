package com.zaid.jarvis.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zaid.jarvis.data.db.MemoryItem
import com.zaid.jarvis.data.repository.MemoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Memory screen state (Master Prompt §4): Zaid can view, edit, and delete
 * any long-term memory item. Memory is what Jarvis remembers about Zaid —
 * preferences, nicknames, routines, writing style — and Zaid owns it.
 */
@HiltViewModel
class MemoryViewModel @Inject constructor(
    private val memoryRepository: MemoryRepository,
) : ViewModel() {

    val memories: StateFlow<List<MemoryItem>> = memoryRepository.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Adds a new memory item. */
    fun addMemory(kind: String, key: String, value: String) {
        if (key.isBlank() || value.isBlank()) return
        viewModelScope.launch {
            memoryRepository.save(
                MemoryItem(
                    kind = kind.ifBlank { "note" },
                    key = key.trim(),
                    value = value.trim(),
                ),
            )
        }
    }

    /** Edits an existing item in place. */
    fun updateMemory(item: MemoryItem, kind: String, key: String, value: String) {
        if (key.isBlank() || value.isBlank()) return
        viewModelScope.launch {
            memoryRepository.save(
                item.copy(
                    kind = kind.ifBlank { "note" },
                    key = key.trim(),
                    value = value.trim(),
                ),
            )
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch { memoryRepository.delete(id) }
    }

    fun deleteAll() {
        viewModelScope.launch { memoryRepository.deleteAll() }
    }
}
