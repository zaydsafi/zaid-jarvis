package com.zaid.jarvis.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zaid.jarvis.accessibility.AccessibilityState
import com.zaid.jarvis.accessibility.MacroRecorder
import com.zaid.jarvis.core.automation.Macro
import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.datastore.SettingsRepository
import com.zaid.jarvis.data.repository.MacroRepository
import com.zaid.jarvis.tools.GatedToolExecutor
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import javax.inject.Inject

/**
 * Macros screen state (Phase 6): Zaid's saved automation sequences.
 *
 * Running a macro goes through the [GatedToolExecutor] like any tool
 * call — the whole macro is approved once, on a card listing every
 * step — and the run job is registered with the kill switch so "Stop
 * Jarvis" cancels playback mid-macro. Recording is driven here but
 * owned by [MacroRecorder], which the AccessibilityService feeds.
 */
@HiltViewModel
class MacrosViewModel @Inject constructor(
    private val macroRepository: MacroRepository,
    private val gatedToolExecutor: GatedToolExecutor,
    private val macroRecorder: MacroRecorder,
    private val killSwitch: KillSwitch,
    settingsRepository: SettingsRepository,
) : ViewModel() {

    val macros: StateFlow<List<Macro>> = macroRepository.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val recordingState: StateFlow<MacroRecorder.RecordingState> = macroRecorder.state
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5_000),
            MacroRecorder.RecordingState.Idle,
        )

    /** The automation toggle (Settings → Automation). */
    val automationEnabled: StateFlow<Boolean> = settingsRepository.settings
        .map { it.automationEnabled }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    /** True while the system has the Accessibility service bound. */
    val accessibilityConnected: StateFlow<Boolean> = AccessibilityState.isConnected
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    private val _message = MutableStateFlow<String?>(null)

    /** One-shot result message (run result, save result, error), shown as a dialog. */
    val message: StateFlow<String?> = _message.asStateFlow()

    fun clearMessage() {
        _message.value = null
    }

    /** Runs a macro by name — approval card first, kill switch registered. */
    fun runMacro(name: String) {
        viewModelScope.launch {
            val job = launch {
                val params = buildJsonObject { put("name", name) }
                val result = gatedToolExecutor.execute("run_macro", params)
                _message.value = when (result) {
                    is JarvisResult.Success -> result.value
                    is JarvisResult.Failure -> result.message
                }
            }
            killSwitch.register(job)
        }
    }

    fun startRecording() {
        macroRecorder.start()
    }

    fun cancelRecording() {
        macroRecorder.cancel()
    }

    /**
     * Stops the recording and saves it under [name]. Refuses empty
     * recordings and invalid names; reports skipped password entries
     * so Zaid knows they were left out on purpose.
     */
    fun stopRecordingAndSave(name: String) {
        val skippedPasswords = macroRecorder.skippedPasswordEntries()
        val steps = macroRecorder.stop()
        if (steps.isEmpty()) {
            _message.value = if (skippedPasswords > 0) {
                "Nothing was recorded — $skippedPasswords password entr" +
                    (if (skippedPasswords == 1) "y was" else "ies were") +
                    " skipped (passwords are never recorded)."
            } else {
                "Nothing was recorded — no taps, typing, or scrolling happened " +
                    "while recording."
            }
            return
        }
        viewModelScope.launch {
            when (val result = macroRepository.save(Macro(name = name, steps = steps))) {
                is JarvisResult.Success -> {
                    _message.value = buildString {
                        append("Saved macro “${name.trim()}” (${steps.size} step(s)).")
                        if (skippedPasswords > 0) {
                            append(
                                " $skippedPasswords password entr" +
                                    (if (skippedPasswords == 1) "y was" else "ies were") +
                                    " not recorded.",
                            )
                        }
                    }
                }
                is JarvisResult.Failure -> {
                    _message.value = "Couldn't save the macro: ${result.message}"
                }
            }
        }
    }

    fun renameMacro(macro: Macro, newName: String) {
        viewModelScope.launch {
            when (val result = macroRepository.rename(macro.id, newName)) {
                is JarvisResult.Success -> Unit // List updates via the Flow.
                is JarvisResult.Failure -> _message.value = result.message
            }
        }
    }

    fun deleteMacro(id: Long) {
        viewModelScope.launch { macroRepository.delete(id) }
    }
}
