package com.zaid.jarvis.backup

import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.repository.NoteRepository
import com.zaid.jarvis.plugins.notes.Note
import com.zaid.jarvis.plugins.notes.NoteStore
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Adapts :data's NoteRepository to the NoteStore interface the Notes
 * plugin tools program against (Phase 10) — the same seam pattern as
 * RoomTaskStore (Phase 9).
 */
@Singleton
class RoomNoteStore @Inject constructor(
    private val repository: NoteRepository,
) : NoteStore {
    override suspend fun save(note: Note): JarvisResult<Long> = repository.save(note)
    override suspend fun getById(id: Long): Note? = repository.getById(id)
    override suspend fun listAll(): List<Note> = repository.getAll()
    override suspend fun search(query: String): List<Note> = repository.search(query)
    override suspend fun delete(id: Long) = repository.deleteById(id)
}
