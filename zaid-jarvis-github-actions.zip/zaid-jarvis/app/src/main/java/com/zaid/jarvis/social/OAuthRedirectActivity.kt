package com.zaid.jarvis.social

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.zaid.jarvis.core.util.JarvisResult
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * OAuth redirect target (Phase 8): `com.zaid.jarvis://oauth2redirect`.
 *
 * The platform's authorization page redirects here after Zaid signs
 * in. This activity shows a brief spinner while [OAuthFlowManager]
 * validates the redirect, exchanges the code, and fetches the
 * profile — then it finishes. The Connected accounts screen observes
 * the accounts Flow, so it updates itself; no result needs to be
 * passed back. If the flow failed, the message is shown as a
 * transient state on the Connected accounts screen via
 * [OAuthFlowManager.lastError] (read when the screen resumes).
 */
@AndroidEntryPoint
class OAuthRedirectActivity : ComponentActivity() {

    @Inject
    lateinit var oAuthFlowManager: OAuthFlowManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RedirectSpinner() }
        val uri = intent?.data
        if (uri == null) {
            finish()
            return
        }
        lifecycleScope.launch {
            val result = oAuthFlowManager.handleRedirect(uri)
            if (result is JarvisResult.Failure) {
                OAuthFlowManager.lastError = result.message
            } else {
                OAuthFlowManager.lastError = null
            }
            finish()
        }
    }

    @Composable
    private fun RedirectSpinner() {
        Column(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            CircularProgressIndicator()
            Text(
                text = "Finishing sign-in…",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 16.dp),
            )
        }
    }
}
