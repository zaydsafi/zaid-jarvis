package com.zaid.jarvis.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zaid.jarvis.viewmodel.PluginsViewModel

/**
 * Plugins screen (Phase 10): the plugins Jarvis ships with, each
 * with an enable/disable toggle and a per-plugin trust toggle.
 *
 * Trust is opt-in and defaults to off: a trusted plugin's Tier 0/1
 * tools may auto-allow like built-in tools; an untrusted plugin's
 * tools always ask. Disabling a plugin unregisters its tools from
 * the planner immediately.
 *
 * Plugins are built-in compiled code only — Jarvis never downloads
 * or loads plugin code (see PHASE10.md).
 */
@Composable
fun PluginsScreen(
    viewModel: PluginsViewModel = hiltViewModel(),
) {
    val plugins by viewModel.plugins.collectAsState()
    val message by viewModel.message.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Plugins", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Plugins add tools Jarvis can use — Notes, unit conversion, " +
                "and more later. Plugin tools are gated like any other " +
                "tool: they need your approval, and disabling a plugin " +
                "removes its tools from the planner at once. Plugins are " +
                "built into the app — Jarvis never downloads plugin code.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        if (message != null) {
            Text(
                message ?: "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
            )
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(plugins, key = { it.plugin.id }) { row ->
                val plugin = row.plugin
                val state = row.state
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    plugin.displayName,
                                    style = MaterialTheme.typography.titleMedium,
                                )
                                Text(
                                    "v${plugin.version}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Switch(
                                checked = state.enabled,
                                onCheckedChange = { viewModel.setEnabled(plugin.id, it) },
                            )
                        }
                        Text(
                            plugin.description,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        val tools = plugin.tools()
                        Text(
                            "Tools: " + tools.joinToString(", ") { it.name },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        if (plugin.declaredPermissions.isEmpty()) {
                            Text(
                                "Needs no permissions.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        } else {
                            Text(
                                "Needs: " + plugin.declaredPermissions.joinToString(", ") {
                                    "${it.displayName} — ${it.description}"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        if (row.hasSkippedTools) {
                            Text(
                                "One of this plugin's tools has the same name as a " +
                                    "built-in tool, so it was not registered.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error,
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    "Trust this plugin",
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                                Text(
                                    "Its low-risk tools may run without asking, " +
                                        "like built-in tools. Off by default.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Switch(
                                checked = state.trusted,
                                onCheckedChange = { viewModel.setTrusted(plugin.id, it) },
                                enabled = state.enabled,
                            )
                        }
                    }
                }
            }
        }
    }
}
