package com.zaid.jarvis.viewmodel

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zaid.jarvis.core.social.OAuthClientCredentials
import com.zaid.jarvis.core.social.SocialAccount
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.repository.SocialAccountRepository
import com.zaid.jarvis.social.OAuthFlowManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Connected accounts screen state (Phase 8): per-platform connection
 * status, OAuth client credentials, and connect/disconnect.
 *
 * Client credentials are presence-only in the UI (the screen never
 * reads a stored secret back — it only learns whether one is saved).
 * Connecting opens the platform's sign-in page in a Custom Tab; the
 * redirect comes back through [OAuthRedirectActivity], and the
 * accounts Flow updates itself when the profile is saved.
 */
@HiltViewModel
class SocialAccountsViewModel @Inject constructor(
    private val socialAccountRepository: SocialAccountRepository,
    private val oAuthFlowManager: OAuthFlowManager,
) : ViewModel() {

    /** Connected accounts (metadata only — no tokens reach the UI). */
    val accounts: StateFlow<List<SocialAccount>> = socialAccountRepository.accounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Whether OAuth client credentials are stored per platform (presence only). */
    private val _credentialsPresence = MutableStateFlow<Map<SocialPlatform, Boolean>>(emptyMap())
    val credentialsPresence: StateFlow<Map<SocialPlatform, Boolean>> =
        _credentialsPresence.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)

    /** One-shot result message (connect result, save result, error). */
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        refreshCredentialsPresence()
    }

    fun clearMessage() {
        _message.value = null
    }

    /** Surfaces a connect-flow error left by the redirect activity (if any). */
    fun surfaceRedirectError() {
        OAuthFlowManager.lastError?.let { error ->
            OAuthFlowManager.lastError = null
            _message.value = error
        }
    }

    /** Saves the OAuth client id/secret for a platform (Keystore-encrypted). */
    fun saveClientCredentials(platform: SocialPlatform, clientId: String, clientSecret: String) {
        if (clientId.isBlank()) {
            _message.value = "Enter the client ID first."
            return
        }
        viewModelScope.launch {
            socialAccountRepository.saveClientCredentials(
                platform,
                OAuthClientCredentials(
                    clientId = clientId.trim(),
                    clientSecret = clientSecret.trim().ifEmpty { null },
                ),
            )
            refreshCredentialsPresence()
            _message.value = "${platform.displayName} credentials saved. Tap Connect to sign in."
        }
    }

    /** Opens the platform's sign-in page (Custom Tab). */
    fun connect(platform: SocialPlatform, activity: Activity) {
        when (val result = oAuthFlowManager.startConnect(activity, platform)) {
            is JarvisResult.Success -> Unit // The redirect finishes the flow.
            is JarvisResult.Failure -> _message.value = result.message
        }
    }

    /** Disconnects a platform (removes its metadata and tokens). */
    fun disconnect(platform: SocialPlatform) {
        viewModelScope.launch {
            socialAccountRepository.deleteAccount(platform)
            _message.value = "${platform.displayName} disconnected."
        }
    }

    private fun refreshCredentialsPresence() {
        _credentialsPresence.value = SocialPlatform.entries.associateWith { platform ->
            socialAccountRepository.hasClientCredentials(platform)
        }
    }
}
