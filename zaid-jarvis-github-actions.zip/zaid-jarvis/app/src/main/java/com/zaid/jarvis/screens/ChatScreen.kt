package com.zaid.jarvis.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import com.zaid.jarvis.chat.ChatUiMessage
import com.zaid.jarvis.core.voice.VoiceState
import com.zaid.jarvis.ui.components.JarvisOrb
import com.zaid.jarvis.viewmodel.ChatViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Chat view (Master Prompt §5.1). Phase 3 wired typed input to the agent
 * loop; Phase 4 adds voice input (mic button, live partial transcript,
 * listening indicator), message timestamps, tool-progress lines, a
 * per-message speak button, and suggested prompts.
 *
 * @param voiceStartNonce bumped by widget / tile / wake word / Home orb
 * — each new value starts a voice session (after the mic permission
 * check). 0 means "no request yet".
 */
@Composable
fun ChatScreen(
    viewModel: ChatViewModel = hiltViewModel(),
    voiceStartNonce: Int = 0,
) {
    val messages by viewModel.messages.collectAsState()
    val isThinking by viewModel.isThinking.collectAsState()
    val statusText by viewModel.statusText.collectAsState()
    val voiceState by viewModel.voiceState.collectAsState()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val context = LocalContext.current

    // Microphone permission is requested only when the user first taps
    // the mic (least privilege — never at app start).
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) viewModel.startVoiceInput() else viewModel.onMicPermissionDenied()
    }
    val tryStartVoice: () -> Unit = {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            viewModel.startVoiceInput()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    // Widget / tile / wake word / Home orb asked for a voice session.
    LaunchedEffect(voiceStartNonce) {
        if (voiceStartNonce > 0) tryStartVoice()
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Chat", style = MaterialTheme.typography.headlineMedium)
            OutlinedButton(onClick = viewModel::clearChat) {
                Text("Clear")
            }
        }
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (messages.isEmpty()) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            "Ask Jarvis anything — type or tap the mic. " +
                                "Tool calls always ask your approval first.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            "Try one of these:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        SUGGESTED_PROMPTS.forEach { prompt ->
                            SuggestionChip(
                                onClick = { viewModel.send(prompt) },
                                label = { Text(prompt) },
                            )
                        }
                    }
                }
            }
            items(messages, key = { it.id }) { message ->
                MessageBubble(
                    message = message,
                    onSpeak = if (message.role == "assistant") {
                        { viewModel.speakMessage(message.text) }
                    } else {
                        null
                    },
                )
            }
            if (isThinking) {
                item {
                    Text(
                        statusText ?: "Thinking…",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        // Voice status row: listening indicator, partial transcript, errors.
        when (val state = voiceState) {
            is VoiceState.Listening -> {
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    JarvisOrb(size = 48.dp, isActive = true)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Listening…",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        if (state.partialTranscript.isNotBlank()) {
                            Text(
                                state.partialTranscript,
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                        Text(
                            "Say “Jarvis stop” to cancel.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = viewModel::stopVoice) {
                        Icon(Icons.Filled.MicOff, contentDescription = "Stop listening")
                    }
                }
            }
            is VoiceState.Speaking -> {
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Speaking…",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f),
                    )
                    IconButton(onClick = viewModel::stopVoice) {
                        Icon(Icons.Filled.Stop, contentDescription = "Stop speaking")
                    }
                }
            }
            is VoiceState.Error -> {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    state.message,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }
            else -> Unit
        }

        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text("Type a message") },
                singleLine = true,
                modifier = Modifier.weight(1f),
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    if (voiceState is VoiceState.Listening) {
                        viewModel.stopVoice()
                    } else {
                        tryStartVoice()
                    }
                },
            ) {
                Icon(
                    if (voiceState is VoiceState.Listening) Icons.Filled.MicOff else Icons.Filled.Mic,
                    contentDescription = if (voiceState is VoiceState.Listening) {
                        "Stop listening"
                    } else {
                        "Voice input"
                    },
                    tint = if (voiceState is VoiceState.Listening) {
                        MaterialTheme.colorScheme.error
                    } else {
                        MaterialTheme.colorScheme.primary
                    },
                )
            }
            Button(
                onClick = {
                    viewModel.send(input)
                    input = ""
                },
                enabled = input.isNotBlank() && !isThinking,
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
            }
        }
    }
}

private val SUGGESTED_PROMPTS: List<String> = listOf(
    "What time is it?",
    "Calculate 12 × 8",
    "What can you do?",
)

private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

@Composable
private fun MessageBubble(
    message: ChatUiMessage,
    onSpeak: (() -> Unit)?,
) {
    // System lines (tool progress, errors) are quiet, full-width notes;
    // user and Jarvis messages are bubbles.
    if (message.role == "system") {
        Text(
            message.text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth(),
        )
        return
    }
    val colors = when (message.role) {
        "user" -> CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
        )
        else -> CardDefaults.cardColors()
    }
    Card(colors = colors, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    if (message.role == "user") "You" else "Jarvis",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        timeFormat.format(Date(message.timestampMillis)),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (onSpeak != null) {
                        IconButton(onClick = onSpeak) {
                            Icon(
                                Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "Read aloud",
                            )
                        }
                    }
                }
            }
            Text(message.text, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
