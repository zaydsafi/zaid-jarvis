package com.zaid.jarvis.chat

import android.content.Context
import com.zaid.jarvis.agent.AgentPlanner
import com.zaid.jarvis.agent.ConversationContext
import com.zaid.jarvis.agent.LlmClientFactory
import com.zaid.jarvis.agent.isSimpleRequest
import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.datastore.SettingsRepository
import com.zaid.jarvis.data.device.DeviceContextProvider
import com.zaid.jarvis.data.repository.LastAnswerRepository
import com.zaid.jarvis.data.repository.MemoryRepository
import com.zaid.jarvis.widget.WidgetUpdater
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** One row in the chat UI (and in the overlay mini chat). */
data class ChatUiMessage(
    val id: Long,
    val role: String, // "user" | "assistant" | "system"
    val text: String,
    val timestampMillis: Long,
)

/**
 * The single conversation session (Phase 4). The chat screen and the
 * overlay bubble share this object, so a request started from the
 * bubble continues in the chat screen and vice versa — one planner run,
 * one message list, one kill switch.
 *
 * Owns the planner run (previously in ChatViewModel): typed or voice
 * input → planner loop → reply. The running job is registered with the
 * kill switch, so "Stop Jarvis" cancels a run mid-thought as well as
 * mid-tool-call. The latest assistant answer is saved for the
 * home-screen widget ([LastAnswerRepository]) and the widget is
 * refreshed.
 *
 * Voice (mic, TTS, "Jarvis stop") lives in ChatViewModel / VoiceEngine,
 * not here — this session only knows about text in and text out.
 */
@Singleton
class ChatSession @Inject constructor(
    private val planner: AgentPlanner,
    private val clientFactory: LlmClientFactory,
    private val settingsRepository: SettingsRepository,
    private val memoryRepository: MemoryRepository,
    private val deviceContextProvider: DeviceContextProvider,
    private val killSwitch: KillSwitch,
    private val lastAnswerRepository: LastAnswerRepository,
    @ApplicationContext private val appContext: Context,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val messageIds = AtomicLong(0L)
    private val history = ConversationContext()

    private val _messages = MutableStateFlow<List<ChatUiMessage>>(emptyList())
    val messages: StateFlow<List<ChatUiMessage>> = _messages.asStateFlow()

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    private val _statusText = MutableStateFlow<String?>(null)
    val statusText: StateFlow<String?> = _statusText.asStateFlow()

    fun send(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || _isThinking.value) return
        addMessage("user", trimmed)
        _isThinking.value = true
        _statusText.value = "Thinking…"

        val job = scope.launch {
            runCatching { runPlanner(trimmed) }
                .onFailure { error ->
                    addMessage(
                        "system",
                        "Something went wrong: ${error.message ?: "unknown error"}",
                    )
                }
            _isThinking.value = false
            _statusText.value = null
        }
        killSwitch.register(job)
    }

    /** Appends a system line (e.g. "Stopped.") from the voice layer. */
    fun addSystemMessage(text: String) {
        addMessage("system", text)
    }

    private suspend fun runPlanner(userRequest: String) {
        val settings = settingsRepository.settings.first()
        val client = when (val result = clientFactory.clientFor(settings)) {
            is JarvisResult.Success -> result.value
            is JarvisResult.Failure -> {
                addMessage("system", result.message)
                return
            }
        }
        val modelApiId = clientFactory.modelApiIdFor(
            settings,
            simpleIntent = isSimpleRequest(userRequest),
        )
        if (modelApiId.isBlank()) {
            addMessage(
                "system",
                "No model is configured for the selected provider. " +
                    "Check Settings → AI provider.",
            )
            return
        }
        val config = AgentPlanner.RunConfig(
            client = client,
            modelApiId = modelApiId,
            settings = settings,
            history = history,
            context = deviceContextProvider.snapshot(),
            memorySummary = memoryRepository.summaryForPrompt(),
        )
        planner.run(userRequest, config).collect { event ->
            when (event) {
                is AgentPlanner.AgentEvent.Thinking ->
                    _statusText.value = event.detail
                is AgentPlanner.AgentEvent.ToolCallStarted -> {
                    _statusText.value = "Using ${event.toolName}…"
                    addMessage("system", "Running ${event.toolName}…")
                }
                is AgentPlanner.AgentEvent.ToolCallFinished -> {
                    _statusText.value = "Thinking…"
                    addMessage(
                        "system",
                        if (event.success) {
                            "${event.toolName} finished."
                        } else {
                            "${event.toolName} failed."
                        },
                    )
                }
                is AgentPlanner.AgentEvent.InjectionFlagged ->
                    addMessage(
                        "system",
                        "I spotted something suspicious in the result from " +
                            "'${event.toolName}' and stopped before acting on it.",
                    )
                is AgentPlanner.AgentEvent.FinalAnswer -> {
                    addMessage("assistant", event.text)
                    saveLastAnswer(event.text)
                }
                is AgentPlanner.AgentEvent.NeedsInput ->
                    addMessage("assistant", event.question)
                is AgentPlanner.AgentEvent.Failed ->
                    addMessage("system", event.message)
            }
        }
    }

    private fun saveLastAnswer(text: String) {
        scope.launch(Dispatchers.IO) {
            lastAnswerRepository.save(text)
            WidgetUpdater.updateAll(appContext)
        }
    }

    private fun addMessage(role: String, text: String) {
        _messages.update {
            it + ChatUiMessage(
                id = messageIds.incrementAndGet(),
                role = role,
                text = text,
                timestampMillis = System.currentTimeMillis(),
            )
        }
    }

    /** Clears the chat and the planner's short-term context. */
    fun clearChat() {
        history.clear()
        _messages.value = emptyList()
    }
}
