package com.zaid.jarvis.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zaid.jarvis.core.analytics.AnalyticsEvents
import com.zaid.jarvis.core.productivity.FocusSessionStatus
import com.zaid.jarvis.core.productivity.TaskStatus
import com.zaid.jarvis.core.social.ScheduledPostStatus
import com.zaid.jarvis.data.datastore.SettingsRepository
import com.zaid.jarvis.data.repository.AnalyticsRepository
import com.zaid.jarvis.data.repository.FocusSessionRepository
import com.zaid.jarvis.data.repository.ScheduledPostRepository
import com.zaid.jarvis.data.repository.TaskRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Insights screen state (Phase 10): local aggregates over the last
 * 7 or 30 days, computed on-device from the local tables.
 *
 * - Most-used tools come from analytics events (recorded only while
 *   insights are on — turning insights off leaves this empty, by
 *   design).
 * - Tasks created/completed and focus minutes come from the tasks
 *   and focus tables (not from events — they are derivable).
 * - Posts published per platform come from the scheduled-posts table
 *   (a post counts in the range where it was published).
 * - LLM usage is a lifetime total from Settings (the Phase 3 usage
 *   tracker accumulates totals, not per-day figures — labelled as
 *   lifetime on the screen, not as a range figure).
 *
 * Nothing here leaves the device.
 */
@HiltViewModel
class InsightsViewModel @Inject constructor(
    private val analyticsRepository: AnalyticsRepository,
    private val taskRepository: TaskRepository,
    private val focusSessionRepository: FocusSessionRepository,
    private val scheduledPostRepository: ScheduledPostRepository,
    private val settingsRepository: SettingsRepository,
) : ViewModel() {

    enum class Range(val days: Int, val label: String) {
        WEEK(7, "Last 7 days"),
        MONTH(30, "Last 30 days"),
    }

    /** One aggregate row on the Insights screen. */
    data class Insights(
        val range: Range,
        /** Tool name → executions, most-used first (top 5). */
        val topTools: List<Pair<String, Int>>,
        val tasksCreated: Int,
        val tasksCompleted: Int,
        val focusMinutes: Int,
        val focusSessions: Int,
        /** Platform display name → posts published. */
        val postsByPlatform: List<Pair<String, Int>>,
        val totalTokensUsed: Long,
        val estimatedCostUsd: Double,
        val eventsRecorded: Int,
    )

    private val _range = MutableStateFlow(Range.WEEK)
    val range: StateFlow<Range> = _range.asStateFlow()

    private val _insights = MutableStateFlow<Insights?>(null)

    /** The current aggregates (null until the first load). */
    val insights: StateFlow<Insights?> = _insights.asStateFlow()

    /** Whether insights recording is on (Settings toggle). */
    val analyticsEnabled: StateFlow<Boolean> = settingsRepository.settings
        .combine(_range) { settings, _ -> settings.analyticsEnabled }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)

    private val _message = MutableStateFlow<String?>(null)

    /** One-shot result message (clear-data result). */
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        refresh()
    }

    fun clearMessage() {
        _message.value = null
    }

    fun setRange(range: Range) {
        if (_range.value == range) return
        _range.value = range
        refresh()
    }

    /** Recomputes the aggregates for the current range. */
    fun refresh() {
        viewModelScope.launch {
            val range = _range.value
            val since = System.currentTimeMillis() - range.days * 24L * 60L * 60L * 1000L

            val events = analyticsRepository.eventsSince(since)
            val topTools = events
                .filter { it.eventName == AnalyticsEvents.TOOL_EXECUTED }
                .mapNotNull { it.payload["tool"] }
                .groupingBy { it }
                .eachCount()
                .entries
                .sortedByDescending { it.value }
                .take(5)
                .map { it.key to it.value }

            val tasks = runCatching { taskRepository.getAll() }.getOrDefault(emptyList())
            val tasksCreated = tasks.count { it.createdAtMillis >= since }
            // Completion updates updatedAtMillis (TaskRepository.complete),
            // so a DONE task updated in the range counts as completed here.
            val tasksCompleted = tasks.count {
                it.status == TaskStatus.DONE && it.updatedAtMillis >= since
            }

            val sessions = runCatching { focusSessionRepository.getAll() }.getOrDefault(emptyList())
            val endedInRange = sessions.filter {
                it.status != FocusSessionStatus.RUNNING &&
                    (it.endedAtMillis ?: 0L) >= since
            }
            val focusMinutes = endedInRange.sumOf { session ->
                val ended = session.endedAtMillis ?: session.startedAtMillis
                ((ended - session.startedAtMillis) / 60_000L).toInt().coerceAtLeast(0)
            }

            val posts = runCatching { scheduledPostRepository.getAll() }.getOrDefault(emptyList())
            val postsByPlatform = posts
                .filter {
                    it.status == ScheduledPostStatus.PUBLISHED && it.updatedAtMillis >= since
                }
                .groupingBy { it.platform.displayName }
                .eachCount()
                .entries
                .sortedByDescending { it.value }
                .map { it.key to it.value }

            val settings = settingsRepository.settings.first()
            _insights.value = Insights(
                range = range,
                topTools = topTools,
                tasksCreated = tasksCreated,
                tasksCompleted = tasksCompleted,
                focusMinutes = focusMinutes,
                focusSessions = endedInRange.size,
                postsByPlatform = postsByPlatform,
                totalTokensUsed = settings.totalTokensUsed,
                estimatedCostUsd = settings.estimatedCostUsd,
                eventsRecorded = events.size,
            )
        }
    }

    /** Wipes all recorded analytics events (tasks/focus/posts data is untouched). */
    fun clearAnalyticsData() {
        viewModelScope.launch {
            analyticsRepository.clearAll()
            _message.value = "Analytics data cleared."
            refresh()
        }
    }
}
