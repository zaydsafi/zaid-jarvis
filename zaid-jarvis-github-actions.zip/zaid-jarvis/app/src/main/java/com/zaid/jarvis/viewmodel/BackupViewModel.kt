package com.zaid.jarvis.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zaid.jarvis.backup.AutoBackupFiles
import com.zaid.jarvis.backup.appVersionName
import com.zaid.jarvis.core.backup.BackupData
import com.zaid.jarvis.core.backup.BackupFormat
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.repository.BackupService
import com.zaid.jarvis.tools.productivity.ReminderScheduler
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

/**
 * Backup screen state (Phase 10): manual export/import via the
 * Storage Access Framework pickers, and the automatic local backups.
 *
 * Export builds the JSON here and hands it to the screen, which
 * writes it through the create-document picker the user chose.
 * Import reads the picked file, validates it (format version +
 * SHA-256 checksum, 10 MB cap), and shows a preview — nothing is
 * written until the user confirms on the Tier 2-style confirmation
 * dialog. Import merges by id: existing rows are never overwritten.
 */
@HiltViewModel
class BackupViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val backupService: BackupService,
    private val reminderScheduler: ReminderScheduler,
) : ViewModel() {

    /** A validated backup file waiting for the user to confirm the import. */
    data class PendingImport(
        val data: BackupData,
        val preview: BackupService.ImportPreview,
        val appVersion: String,
        val exportedAtMillis: Long,
        /** Where the file came from ("Backup file" or an auto-backup name). */
        val sourceLabel: String,
    )

    private val _pendingImport = MutableStateFlow<PendingImport?>(null)

    /** The import waiting for confirmation (null = none). */
    val pendingImport: StateFlow<PendingImport?> = _pendingImport.asStateFlow()

    private val _autoBackups = MutableStateFlow<List<File>>(emptyList())

    /** Automatic local backups, newest first. */
    val autoBackups: StateFlow<List<File>> = _autoBackups.asStateFlow()

    private val _busy = MutableStateFlow(false)

    /** True while an export or import is running. */
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)

    /** One-shot result message (export/import result, error). */
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        refreshAutoBackups()
    }

    fun clearMessage() {
        _message.value = null
    }

    fun refreshAutoBackups() {
        _autoBackups.value = AutoBackupFiles.list(context)
    }

    /**
     * Builds the export JSON ([onReady] receives it) so the screen
     * can write it through the create-document picker.
     */
    fun prepareExport(onReady: (String) -> Unit) {
        viewModelScope.launch {
            _busy.value = true
            try {
                val json = withContext(Dispatchers.Default) {
                    BackupFormat.encode(
                        data = backupService.export(),
                        appVersion = appVersionName(context),
                        exportedAtMillis = System.currentTimeMillis(),
                    )
                }
                onReady(json)
            } catch (e: Exception) {
                _message.value = "Couldn't build the backup: ${e.message ?: e::class.simpleName}"
            } finally {
                _busy.value = false
            }
        }
    }

    /** Writes already-built export JSON to the picked document. */
    fun writeExport(uri: Uri, json: String) {
        viewModelScope.launch {
            val written = withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openOutputStream(uri, "wt")?.use { out ->
                        out.write(json.toByteArray(Charsets.UTF_8))
                    } ?: throw IllegalStateException("The document could not be opened for writing.")
                }
            }
            written.onSuccess { _message.value = "Backup exported." }
                .onFailure { _message.value = "Couldn't write the backup: ${it.message}" }
        }
    }

    /**
     * Reads a picked backup file, validates it, and shows the import
     * preview. Nothing is written until [confirmImport].
     */
    fun loadImport(uri: Uri) {
        viewModelScope.launch {
            _busy.value = true
            try {
                val text = withContext(Dispatchers.IO) { readCapped(uri) }
                loadFromText(text, sourceLabel = "Backup file")
            } finally {
                _busy.value = false
            }
        }
    }

    /**
     * Loads an automatic local backup into the import preview (same
     * validation and confirmation as a picked file).
     */
    fun loadAutoBackup(file: File) {
        viewModelScope.launch {
            _busy.value = true
            try {
                val text = withContext(Dispatchers.IO) {
                    runCatching { file.readText(Charsets.UTF_8) }.getOrElse {
                        _message.value = "Couldn't read “${file.name}”: ${it.message}"
                        return@withContext null
                    }
                }
                loadFromText(text, sourceLabel = file.name)
            } finally {
                _busy.value = false
            }
        }
    }

    /** Deletes one automatic local backup. */
    fun deleteAutoBackup(file: File) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { AutoBackupFiles.delete(file) }
            refreshAutoBackups()
        }
    }

    /** Validates backup text and, when valid, builds the import preview. */
    private suspend fun loadFromText(text: String?, sourceLabel: String): PendingImport? {
        if (text == null) return null
        return when (val decoded = BackupFormat.decode(text)) {
            is JarvisResult.Success -> {
                val envelope = decoded.value
                val preview = backupService.preview(envelope.data)
                val pending = PendingImport(
                    data = envelope.data,
                    preview = preview,
                    appVersion = envelope.appVersion,
                    exportedAtMillis = envelope.exportedAtMillis,
                    sourceLabel = sourceLabel,
                )
                _pendingImport.value = pending
                pending
            }
            is JarvisResult.Failure -> {
                _message.value = decoded.message
                null
            }
        }
    }

    /** Discards the pending import without writing anything. */
    fun cancelImport() {
        _pendingImport.value = null
    }

    /**
     * Writes the pending import (merge by id — existing rows are
     * never overwritten), then re-enqueues reminders on imported
     * tasks whose reminder is still in the future.
     */
    fun confirmImport() {
        val pending = _pendingImport.value ?: return
        viewModelScope.launch {
            _busy.value = true
            try {
                when (val result = backupService.import(pending.data)) {
                    is JarvisResult.Success -> {
                        val report = result.value
                        var remindersFailed = 0
                        for (task in report.remindersToReschedule) {
                            val reminderAt = task.reminderAtMillis ?: continue
                            if (reminderScheduler.schedule(task.id, reminderAt) is JarvisResult.Failure) {
                                remindersFailed++
                            }
                        }
                        val totalImported = report.imported.values.sum()
                        val totalSkipped = report.skipped.values.sum()
                        _message.value = buildString {
                            append("Imported $totalImported items")
                            if (totalSkipped > 0) append(" ($totalSkipped already existed and were kept)")
                            append(".")
                            if (report.cancelledScheduledPosts > 0) {
                                append(" ${report.cancelledScheduledPosts} scheduled post(s) were restored as cancelled — re-schedule them from Drafts if you still want them published.")
                            }
                            if (remindersFailed > 0) {
                                append(" $remindersFailed reminder(s) could not be re-scheduled.")
                            }
                        }
                        _pendingImport.value = null
                    }
                    is JarvisResult.Failure -> {
                        _message.value = result.message
                        _pendingImport.value = null
                    }
                }
            } finally {
                _busy.value = false
            }
        }
    }

    /** Reads a document, refusing files over the 10 MB cap. Returns null on error. */
    private fun readCapped(uri: Uri): String? {
        val cap = BackupFormat.MAX_BACKUP_BYTES
        return runCatching {
            context.contentResolver.openInputStream(uri)?.use { input ->
                val bytes = ByteArray((cap + 1).toInt())
                var total = 0
                while (total <= cap) {
                    val read = input.read(bytes, total, bytes.size - total)
                    if (read == -1) break
                    total += read
                }
                if (total > cap) {
                    throw IllegalStateException(
                        "The file is over ${cap / 1_000_000} MB — " +
                            "backups are capped at ${cap / 1_000_000} MB.",
                    )
                }
                String(bytes, 0, total, Charsets.UTF_8)
            } ?: throw IllegalStateException("The file could not be opened.")
        }.onFailure { _message.value = it.message }.getOrNull()
    }
}
