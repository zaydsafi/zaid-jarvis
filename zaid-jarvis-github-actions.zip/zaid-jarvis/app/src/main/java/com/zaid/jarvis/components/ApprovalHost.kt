package com.zaid.jarvis.components

import android.content.Context
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.fragment.app.FragmentActivity
import androidx.hilt.navigation.compose.hiltViewModel
import com.zaid.jarvis.core.confirmation.ApprovalState
import com.zaid.jarvis.ui.components.ApprovalCard
import com.zaid.jarvis.viewmodel.ConfirmationViewModel

/**
 * Hosts the approval UI on top of every screen (Master Prompt §6):
 * - [ApprovalState.AWAITING_DECISION] → the approval card dialog.
 * - [ApprovalState.AWAITING_SECOND_CONFIRMATION] → a second confirm dialog.
 * - [ApprovalState.AWAITING_BIOMETRIC] → the system biometric prompt
 *   (launched once per request; the dialog stays up behind it).
 *
 * Mounted once in [com.zaid.jarvis.navigation.JarvisNavGraph] so an
 * approval can arrive while Zaid is on any screen.
 */
@Composable
fun ApprovalHost(viewModel: ConfirmationViewModel = hiltViewModel()) {
    val request by viewModel.pendingRequest.collectAsState()
    val nowMillis by viewModel.nowMillis.collectAsState()
    val context = LocalContext.current

    // Launch the biometric prompt exactly once per Tier 3 request.
    LaunchedEffect(request?.id, request?.state) {
        if (request?.state == ApprovalState.AWAITING_BIOMETRIC) {
            val activity = context.findActivity()
            if (activity != null) {
                viewModel.authenticateBiometric(activity)
            } else {
                // No FragmentActivity (should not happen in-app): fail closed.
                viewModel.deny()
            }
        }
    }

    val current = request ?: return
    when (current.state) {
        ApprovalState.AWAITING_DECISION -> {
            Dialog(
                onDismissRequest = { /* Dismissing is not deciding; use Deny. */ },
                properties = DialogProperties(
                    dismissOnBackPress = false,
                    dismissOnClickOutside = false,
                ),
            ) {
                ApprovalCard(
                    request = current,
                    remainingSeconds = current.remainingMillis(nowMillis) / 1_000,
                    onAllow = viewModel::allow,
                    onDeny = viewModel::deny,
                    onEdit = viewModel::edit,
                    onTrust = if (current.tier.canBeTrusted) viewModel::trustPending else null,
                )
            }
        }
        ApprovalState.AWAITING_SECOND_CONFIRMATION -> {
            AlertDialog(
                onDismissRequest = { /* Must confirm or cancel explicitly. */ },
                title = { Text("Confirm — this leaves the device") },
                text = {
                    Text(
                        "You allowed “${current.action}” (${current.toolName}).\n\n" +
                            "Target: ${current.target}\n\n" +
                            "Content:\n${current.exactContent}\n\n" +
                            "Are you sure you want to go ahead?",
                    )
                },
                confirmButton = {
                    Button(onClick = { viewModel.confirmSecond(true) }) {
                        Text("Yes, do it")
                    }
                },
                dismissButton = {
                    OutlinedButton(onClick = { viewModel.confirmSecond(false) }) {
                        Text("Cancel")
                    }
                },
            )
        }
        ApprovalState.AWAITING_BIOMETRIC -> {
            // The system biometric prompt is showing; keep a waiting dialog
            // behind it so Zaid can still cancel from here.
            AlertDialog(
                onDismissRequest = { /* Biometric prompt owns dismissal. */ },
                title = { Text("Biometric check") },
                text = {
                    Text(
                        "Approve “${current.action}” with your fingerprint, " +
                            "face, or device PIN.",
                    )
                },
                confirmButton = {},
                dismissButton = {
                    OutlinedButton(onClick = viewModel::deny) {
                        Text("Cancel")
                    }
                },
            )
        }
        else -> { /* Terminal states clear the pending request immediately. */ }
    }
}

/** Walks up Context wrappers to find the hosting FragmentActivity. */
private fun Context.findActivity(): FragmentActivity? {
    var ctx: Context? = this
    while (ctx != null) {
        if (ctx is FragmentActivity) return ctx
        ctx = if (ctx is android.content.ContextWrapper) ctx.baseContext else null
    }
    return null
}
