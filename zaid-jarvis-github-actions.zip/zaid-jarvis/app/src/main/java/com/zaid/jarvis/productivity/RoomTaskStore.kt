package com.zaid.jarvis.productivity

import com.zaid.jarvis.core.productivity.Task
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.repository.TaskRepository
import com.zaid.jarvis.tools.productivity.TaskStore
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The [TaskStore] implementation (Phase 9): adapts :data's
 * [TaskRepository] to the interface the planner tools program against.
 * Same pattern as RoomMacroStore (Phase 6).
 */
@Singleton
class RoomTaskStore @Inject constructor(
    private val repository: TaskRepository,
) : TaskStore {

    override suspend fun create(task: Task): JarvisResult<Long> = repository.save(task)

    override suspend fun getById(id: Long): Task? = repository.getById(id)

    override suspend fun listAll(): List<Task> = repository.getAll()

    override suspend fun update(task: Task): JarvisResult<Unit> {
        return when (val saved = repository.save(task)) {
            is JarvisResult.Success -> JarvisResult.Success(Unit)
            is JarvisResult.Failure -> saved
        }
    }

    override suspend fun complete(id: Long): JarvisResult<Task> = repository.complete(id)

    override suspend fun delete(id: Long): JarvisResult<Unit> {
        repository.deleteById(id)
        return JarvisResult.Success(Unit)
    }

    override suspend fun setReminder(
        id: Long,
        reminderAtMillis: Long,
        workId: String?,
    ): JarvisResult<Task> = repository.setReminder(id, reminderAtMillis, workId)

    override suspend fun clearReminder(id: Long): JarvisResult<Unit> {
        repository.clearReminder(id)
        return JarvisResult.Success(Unit)
    }

    override suspend fun markOverdueNotified(id: Long, epochDay: Long) {
        repository.markOverdueNotified(id, epochDay)
    }
}
