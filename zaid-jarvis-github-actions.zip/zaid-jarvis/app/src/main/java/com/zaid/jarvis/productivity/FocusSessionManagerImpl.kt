package com.zaid.jarvis.productivity

import android.content.Context
import android.content.Intent
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.zaid.jarvis.core.analytics.AnalyticsSink
import com.zaid.jarvis.core.analytics.NoOpAnalyticsSink
import com.zaid.jarvis.core.productivity.FocusSession
import com.zaid.jarvis.core.productivity.FocusSessionStatus
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.repository.FocusSessionRepository
import com.zaid.jarvis.tools.phone.DndMode
import com.zaid.jarvis.tools.phone.PhoneDevice
import com.zaid.jarvis.tools.productivity.FocusSessionManager
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Focus sessions (Phase 9): timed Do Not Disturb sessions.
 *
 * Starting a session sets DND to **Alarms only** (alarms still ring;
 * total silence would mute them too) and restores the previous mode
 * when the session ends — on time or stopped early. The session is
 * logged in Room and shown in the Wellness history list.
 *
 * Ending is idempotent: the foreground service ([FocusSessionService],
 * which ticks the timer notification) and the WorkManager end worker
 * ([FocusEndWorker], the reliable backstop if the service is killed)
 * can both try to end the same session — [FocusSessionRepository.finish]
 * only lets the first one through, so DND is restored exactly once
 * and the "session complete" notification fires exactly once.
 *
 * Starting requires Do Not Disturb access (system Settings); without
 * it the start fails plainly instead of pretending to focus.
 *
 * Analytics (Phase 10): each finished session records one local,
 * on-device event (duration bucket + completed/stopped-early — no
 * exact times). Only the first finisher records (finish is
 * idempotent), so a session is never counted twice.
 */
@Singleton
class FocusSessionManagerImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: FocusSessionRepository,
    private val phoneDevice: PhoneDevice,
    private val wellnessNotifier: WellnessNotifier,
    private val analyticsSink: AnalyticsSink = NoOpAnalyticsSink,
) : FocusSessionManager {

    override suspend fun currentSession(): FocusSession? = repository.getRunning()

    override suspend fun start(durationMinutes: Int): JarvisResult<FocusSession> {
        if (durationMinutes !in MIN_MINUTES..MAX_MINUTES) {
            return JarvisResult.Failure(
                "Focus sessions are $MIN_MINUTES–$MAX_MINUTES minutes — $durationMinutes is out of range.",
            )
        }
        if (repository.getRunning() != null) {
            return JarvisResult.Failure(
                "A focus session is already running — stop it first with stop_focus.",
            )
        }
        val currentMode = when (val result = phoneDevice.dndMode()) {
            is JarvisResult.Success -> result.value
            is JarvisResult.Failure -> return JarvisResult.Failure(
                "Couldn't start the focus session: ${result.message} " +
                    "Focus needs Do Not Disturb access (Settings → App permissions).",
            )
        }
        // DND to Alarms only — unless it is already there (nothing to restore then).
        var previousDndMode: String? = null
        if (currentMode != FOCUS_DND_MODE) {
            when (val set = phoneDevice.setDndMode(FOCUS_DND_MODE)) {
                is JarvisResult.Success -> previousDndMode = currentMode.name
                is JarvisResult.Failure -> return JarvisResult.Failure(
                    "Couldn't start the focus session: ${set.message} " +
                        "Focus needs Do Not Disturb access (Settings → App permissions).",
                )
            }
        }
        val session = FocusSession(
            startedAtMillis = System.currentTimeMillis(),
            durationMinutes = durationMinutes,
            previousDndMode = previousDndMode,
        )
        val rowId = when (val saved = repository.save(session)) {
            is JarvisResult.Success -> saved.value
            is JarvisResult.Failure -> {
                // Roll back the DND change — the session never started.
                previousDndMode?.let { restoreDnd(it) }
                return saved
            }
        }
        val saved = session.copy(id = rowId)
        try {
            val delayMillis = saved.endsAtMillis() - System.currentTimeMillis()
            val request = OneTimeWorkRequestBuilder<FocusEndWorker>()
                .setInitialDelay(delayMillis.coerceAtLeast(0L), TimeUnit.MILLISECONDS)
                .setInputData(
                    Data.Builder()
                        .putLong(FocusEndWorker.KEY_SESSION_ID, rowId)
                        .build(),
                )
                .addTag(FocusEndWorker.WORK_TAG)
                .build()
            WorkManager.getInstance(context).enqueue(request)
            repository.setEndWorkId(rowId, request.id.toString())
        } catch (e: Exception) {
            // The session is saved and DND is set; the foreground
            // service still ends it on time — the worker is only a
            // backstop, so a failed enqueue is not fatal.
        }
        startService(rowId)
        return JarvisResult.Success(saved)
    }

    override suspend fun stop(): JarvisResult<FocusSession?> {
        val running = repository.getRunning() ?: return JarvisResult.Success(null)
        val finished = repository.finish(
            running.id,
            FocusSessionStatus.CANCELLED,
            System.currentTimeMillis(),
        )
        if (!finished) {
            // The end worker or service already finished it (DND
            // already restored) — nothing left to do.
            return JarvisResult.Success(running)
        }
        cancelEndWork(running)
        stopService()
        running.previousDndMode?.let { restoreDnd(it) }
        recordFocusSession(running.durationMinutes, completed = false)
        return JarvisResult.Success(running.copy(status = FocusSessionStatus.CANCELLED))
    }

    override suspend fun endSession(sessionId: Long): JarvisResult<Unit> {
        val session = repository.getById(sessionId) ?: return JarvisResult.Success(Unit)
        val finished = repository.finish(
            sessionId,
            FocusSessionStatus.COMPLETED,
            System.currentTimeMillis(),
        )
        if (!finished) return JarvisResult.Success(Unit) // Already ended — idempotent.
        stopService()
        val dndRestored = session.previousDndMode?.let { restoreDnd(it) } ?: true
        wellnessNotifier.notifyFocusEnded(session.durationMinutes, dndRestored)
        recordFocusSession(session.durationMinutes, completed = true)
        return JarvisResult.Success(Unit)
    }

    override suspend fun history(limit: Int): List<FocusSession> = repository.getRecent(limit)

    /** One analytics event per finished session (duration bucket + outcome only). Never throws. */
    private suspend fun recordFocusSession(durationMinutes: Int, completed: Boolean) {
        runCatching { analyticsSink.recordFocusSession(durationMinutes, completed) }
    }

    /** Restores a DND mode by name. Returns false when the restore failed. */
    private suspend fun restoreDnd(modeName: String): Boolean {
        val mode = runCatching { DndMode.valueOf(modeName) }.getOrNull() ?: return false
        return phoneDevice.setDndMode(mode) is JarvisResult.Success
    }

    private fun cancelEndWork(session: FocusSession) {
        session.endWorkId?.let { workId ->
            runCatching { WorkManager.getInstance(context).cancelWorkById(UUID.fromString(workId)) }
        }
    }

    private fun startService(sessionId: Long) {
        val intent = Intent(context, FocusSessionService::class.java).apply {
            putExtra(FocusSessionService.EXTRA_SESSION_ID, sessionId)
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    private fun stopService() {
        context.stopService(Intent(context, FocusSessionService::class.java))
    }

    companion object {
        /** DND mode during a focus session: alarms still ring. */
        val FOCUS_DND_MODE: DndMode = DndMode.ALARMS_ONLY

        /** Focus sessions are 5–240 minutes. */
        const val MIN_MINUTES: Int = 5
        const val MAX_MINUTES: Int = 240
    }
}
