package com.zaid.jarvis.di

import com.zaid.jarvis.backup.RoomNoteStore
import com.zaid.jarvis.core.confirmation.TrustedActionStore
import com.zaid.jarvis.data.repository.NoteRepository
import com.zaid.jarvis.plugins.BuiltInPlugins
import com.zaid.jarvis.plugins.JarvisPlugin
import com.zaid.jarvis.plugins.PluginRegistry
import com.zaid.jarvis.plugins.PluginStateStore
import com.zaid.jarvis.plugins.notes.NoteStore
import com.zaid.jarvis.tools.ToolRegistry
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Plugin bindings (Phase 10).
 *
 * The built-in plugins are constructed here (the Notes plugin needs
 * its NoteStore) and handed to the [PluginRegistry], which syncs
 * their tools into the planner's [ToolRegistry] at app start
 * (JarvisApplication) and whenever a plugin is enabled or disabled.
 * Plugin tools are gated by the Confirmation Engine exactly like
 * built-in tools — registration alone grants nothing.
 */
@Module
@InstallIn(SingletonComponent::class)
object PluginsModule {

    /** The note storage the Notes plugin tools read and write. */
    @Provides
    @Singleton
    fun provideNoteStore(
        repository: NoteRepository,
    ): NoteStore = RoomNoteStore(repository)

    /** The plugins Jarvis ships with (Notes + Unit converter). */
    @Provides
    @Singleton
    fun providePlugins(
        noteStore: NoteStore,
    ): List<JarvisPlugin> = BuiltInPlugins.all(noteStore)

    @Provides
    @Singleton
    fun providePluginRegistry(
        toolRegistry: ToolRegistry,
        stateStore: PluginStateStore,
        trustedStore: TrustedActionStore,
        plugins: List<JarvisPlugin>,
    ): PluginRegistry = PluginRegistry(toolRegistry, stateStore, trustedStore, plugins)
}
