package com.zaid.jarvis.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.zaid.jarvis.core.automation.BlockedApps
import com.zaid.jarvis.core.automation.NodeBounds
import com.zaid.jarvis.core.automation.NodeSelector
import com.zaid.jarvis.core.automation.ObservedEventKind
import com.zaid.jarvis.core.automation.ObservedUiEvent
import com.zaid.jarvis.core.automation.ScreenNode
import com.zaid.jarvis.core.automation.ScreenSnapshot
import com.zaid.jarvis.core.automation.SnapshotSanitizer
import com.zaid.jarvis.core.util.JarvisResult
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * Jarvis's AccessibilityService (Phase 6): the only component that
 * touches other apps' UIs. It reads the current screen, taps, types,
 * scrolls, and dispatches gestures — and it observes the user's own
 * actions while a macro recording is active.
 *
 * **Safety rules — these are the backstop behind the Confirmation
 * Engine, enforced here for every caller:**
 * - The service **never acts on its own**. It only runs what the tools
 *   ask for, and tools only run after Zaid approves them (Phase 2 gate).
 * - **No passwords, ever.** Password nodes are skipped entirely when a
 *   snapshot is built (their text is never read, stored, or logged),
 *   typing into a password field is refused, and no tap/type/scroll
 *   runs on a screen that contains a password field. Back/Home are
 *   still allowed there — they only navigate away.
 * - **No banking / payment apps.** Actions and snapshots are refused
 *   when the foreground app matches the [BlockedApps] list. The list
 *   is best-effort; the password-field rule is the real backstop.
 * - **No logging of screen content.** This file logs nothing about
 *   what is on screen — no node text, no snapshots, no typed text.
 * - **No persistence.** Snapshots live for one call and are discarded.
 *
 * Capabilities requested (see `res/xml/accessibility_service_config.xml`):
 * `canRetrieveWindowContent` (read the screen), `canPerformGestures`
 * (tap at coordinates), `FLAG_REPORT_VIEW_IDS` (stable selectors for
 * macros), `FLAG_RETRIEVE_INTERACTIVE_WINDOWS` (multi-window devices).
 * Touch-exploration mode is NOT requested — Jarvis is not a screen
 * reader and does not need it.
 *
 * Every public operation runs on the main thread (Accessibility APIs
 * require it) and returns a [JarvisResult] — never throws for an
 * expected failure.
 *
 * Note on deprecations: `AccessibilityNodeInfo.recycle()` and
 * `obtain(AccessibilityNodeInfo)` are deprecated on API 36 (no-ops
 * there — the framework manages node pooling itself), but they are
 * still the correct node-lifecycle calls on older APIs, and this app
 * supports API 26+. They are kept deliberately and the deprecation is
 * suppressed at the class level.
 */
@Suppress("DEPRECATION")
@AndroidEntryPoint
class JarvisAccessibilityService : AccessibilityService() {

    @Inject
    lateinit var macroRecorder: MacroRecorder

    override fun onServiceConnected() {
        super.onServiceConnected()
        AccessibilityServiceHolder.service = this
        AccessibilityState.setConnected(true)
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        AccessibilityServiceHolder.service = null
        AccessibilityState.setConnected(false)
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {
        // Nothing to interrupt: the service holds no long-running state
        // of its own (playback is driven by the tools, one step at a time).
    }

    /**
     * Observes the user's own actions — **only while a macro recording
     * is active**. All other events are ignored. Password text is
     * dropped at this mapping site, before the recorder ever sees it.
     */
    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (!macroRecorder.isRecording) return
        val packageName = event.packageName?.toString() ?: return
        if (packageName == applicationContext.packageName) return // Never record Jarvis itself.
        if (BlockedApps.isBlocked(packageName)) return // Never record in banking apps.

        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                val node = event.source ?: return
                try {
                    if (!node.isPassword) {
                        macroRecorder.observe(
                            ObservedUiEvent(
                                kind = ObservedEventKind.CLICKED,
                                packageName = packageName,
                                selector = selectorFrom(node),
                            ),
                        )
                    }
                } finally {
                    node.recycle()
                }
            }
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
                val node = event.source ?: return
                try {
                    if (node.isPassword) {
                        // Counted, never recorded (see MacroRecorder).
                        macroRecorder.observe(
                            ObservedUiEvent(
                                kind = ObservedEventKind.TEXT_CHANGED,
                                packageName = packageName,
                                text = null,
                                isPassword = true,
                            ),
                        )
                    } else {
                        val text = event.text.joinToString("").ifBlank { node.text?.toString() ?: "" }
                        macroRecorder.observe(
                            ObservedUiEvent(
                                kind = ObservedEventKind.TEXT_CHANGED,
                                packageName = packageName,
                                selector = selectorFrom(node),
                                text = text,
                            ),
                        )
                    }
                } finally {
                    node.recycle()
                }
            }
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                // fromIndex/toIndex move with the scroll direction on every API level.
                val kind = when {
                    event.toIndex > event.fromIndex -> ObservedEventKind.SCROLLED_FORWARD
                    event.toIndex < event.fromIndex -> ObservedEventKind.SCROLLED_BACK
                    else -> return
                }
                macroRecorder.observe(
                    ObservedUiEvent(kind = kind, packageName = packageName),
                )
            }
        }
    }

    // ── Screen reading ────────────────────────────────────────────────

    /** Sanitized snapshot of the current screen (password fields excluded). */
    suspend fun snapshot(): JarvisResult<ScreenSnapshot> = withContext(Dispatchers.Main.immediate) {
        val root = rootInActiveWindow
            ?: return@withContext JarvisResult.Failure(
                "I can't see the current screen — no active window.",
            )
        try {
            val packageName = root.packageName?.toString().orEmpty()
            BlockedApps.blockReason(packageName)?.let {
                return@withContext JarvisResult.Failure(it)
            }
            JarvisResult.Success(buildSnapshot(root, packageName))
        } finally {
            root.recycle()
        }
    }

    // ── Actions ───────────────────────────────────────────────────────

    /** Taps the first node matching [selector] (preferring clickable matches). */
    suspend fun tap(selector: NodeSelector): JarvisResult<String> =
        withContext(Dispatchers.Main.immediate) {
            when (val guard = actionGuard()) {
                is JarvisResult.Failure -> return@withContext guard
                is JarvisResult.Success -> Unit
            }
            val root = rootInActiveWindow
                ?: return@withContext JarvisResult.Failure("I can't see the current screen.")
            try {
                val match = findNode(root, selector)
                    ?: return@withContext JarvisResult.Failure(
                        "I couldn't find ${selector.describe()} on the current screen.",
                    )
                try {
                    val clicked = clickNodeOrAncestor(match)
                    if (clicked) {
                        JarvisResult.Success("Tapped ${describeMatch(match)}.")
                    } else {
                        JarvisResult.Failure(
                            "I found ${describeMatch(match)} but couldn't tap it.",
                        )
                    }
                } finally {
                    match.recycle()
                }
            } finally {
                root.recycle()
            }
        }

    /** Taps at screen coordinates via a dispatched gesture. */
    suspend fun tapAt(x: Int, y: Int): JarvisResult<String> =
        withContext(Dispatchers.Main.immediate) {
            when (val guard = actionGuard()) {
                is JarvisResult.Failure -> return@withContext guard
                is JarvisResult.Success -> Unit
            }
            val done = withTimeoutOrNull(GESTURE_TIMEOUT_MILLIS) {
                suspendCancellableCoroutine { cont ->
                    val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
                    val gesture = GestureDescription.Builder()
                        .addStroke(
                            GestureDescription.StrokeDescription(
                                path, 0L, TAP_DURATION_MILLIS,
                            ),
                        )
                        .build()
                    val started = dispatchGesture(
                        gesture,
                        object : GestureResultCallback() {
                            override fun onCompleted(gestureDescription: GestureDescription?) {
                                if (cont.isActive) cont.resume(true)
                            }

                            override fun onCancelled(gestureDescription: GestureDescription?) {
                                if (cont.isActive) cont.resume(false)
                            }
                        },
                        null,
                    )
                    if (!started && cont.isActive) cont.resume(false)
                }
            }
            if (done == true) {
                JarvisResult.Success("Tapped the point ($x, $y).")
            } else {
                JarvisResult.Failure("The tap at ($x, $y) didn't go through.")
            }
        }

    /**
     * Types [text] into the field matching [selector] — or the focused
     * field when [selector] is null. Refuses password fields outright.
     */
    suspend fun typeText(selector: NodeSelector?, text: String): JarvisResult<String> =
        withContext(Dispatchers.Main.immediate) {
            when (val guard = actionGuard()) {
                is JarvisResult.Failure -> return@withContext guard
                is JarvisResult.Success -> Unit
            }
            val root = rootInActiveWindow
                ?: return@withContext JarvisResult.Failure("I can't see the current screen.")
            try {
                val target = if (selector == null) {
                    root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                } else {
                    findNode(root, selector)
                } ?: return@withContext JarvisResult.Failure(
                    if (selector == null) {
                        "No text field is focused — tap a field first, then type."
                    } else {
                        "I couldn't find ${selector.describe()} to type into."
                    },
                )
                try {
                    if (target.isPassword) {
                        return@withContext JarvisResult.Failure(
                            "That field is a password field — Jarvis never types into password fields.",
                        )
                    }
                    if (!target.isEditable) {
                        return@withContext JarvisResult.Failure(
                            "“${target.text ?: target.contentDescription ?: "That element"}” " +
                                "isn't an editable text field.",
                        )
                    }
                    val args = Bundle().apply {
                        putCharSequence(
                            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                            text,
                        )
                    }
                    if (target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                        JarvisResult.Success("Typed into ${describeMatch(target)}.")
                    } else {
                        JarvisResult.Failure("Typing into that field didn't work.")
                    }
                } finally {
                    target.recycle()
                }
            } finally {
                root.recycle()
            }
        }

    /** Scrolls the first scrollable node on screen, forward (down) or back (up). */
    suspend fun scroll(forward: Boolean): JarvisResult<String> =
        withContext(Dispatchers.Main.immediate) {
            when (val guard = actionGuard()) {
                is JarvisResult.Failure -> return@withContext guard
                is JarvisResult.Success -> Unit
            }
            val root = rootInActiveWindow
                ?: return@withContext JarvisResult.Failure("I can't see the current screen.")
            try {
                val scrollable = findScrollable(root)
                    ?: return@withContext JarvisResult.Failure(
                        "Nothing on this screen can scroll " +
                            if (forward) "down." else "up.",
                    )
                try {
                    val action = if (forward) {
                        AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                    } else {
                        AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                    }
                    if (scrollable.performAction(action)) {
                        JarvisResult.Success(
                            "Scrolled ${if (forward) "down" else "up"}.",
                        )
                    } else {
                        JarvisResult.Failure(
                            "This screen can't scroll any further " +
                                if (forward) "down." else "up.",
                        )
                    }
                } finally {
                    scrollable.recycle()
                }
            } finally {
                root.recycle()
            }
        }

    /**
     * Global Back. Allowed on password screens and in blocked apps:
     * it only navigates away from the screen, never acts on it.
     */
    fun pressBack(): JarvisResult<String> =
        if (performGlobalAction(GLOBAL_ACTION_BACK)) {
            JarvisResult.Success("Pressed Back.")
        } else {
            JarvisResult.Failure("Back didn't do anything.")
        }

    /** Global Home. Allowed anywhere — it only leaves the current app. */
    fun pressHome(): JarvisResult<String> =
        if (performGlobalAction(GLOBAL_ACTION_HOME)) {
            JarvisResult.Success("Pressed Home.")
        } else {
            JarvisResult.Failure("Home didn't do anything.")
        }

    // ── Guards ────────────────────────────────────────────────────────

    /**
     * The guard every tap/type/scroll/gesture passes: the foreground
     * app must not be blocked, and the screen must not contain a
     * password field. Back/Home skip this (see above).
     */
    private fun actionGuard(): JarvisResult<Unit> {
        val root = rootInActiveWindow
            ?: return JarvisResult.Failure("I can't see the current screen.")
        try {
            val packageName = root.packageName?.toString().orEmpty()
            BlockedApps.blockReason(packageName)?.let {
                return JarvisResult.Failure(it)
            }
            val snapshot = buildSnapshot(root, packageName)
            if (snapshot.hasPasswordField) {
                return JarvisResult.Failure(
                    "This screen has a password field — Jarvis never acts on " +
                        "screens with password fields.",
                )
            }
            return JarvisResult.Success(Unit)
        } finally {
            root.recycle()
        }
    }

    // ── Node traversal ────────────────────────────────────────────────

    /**
     * Walks the node tree into a sanitized snapshot. Password nodes are
     * skipped entirely (their text is never read); [ScreenSnapshot.hasPasswordField]
     * records that one existed. Nodes are capped so a huge view tree
     * cannot flood memory or the LLM context.
     */
    private fun buildSnapshot(root: AccessibilityNodeInfo, packageName: String): ScreenSnapshot {
        val nodes = mutableListOf<ScreenNode>()
        var hasPasswordField = false

        fun walk(node: AccessibilityNodeInfo, depth: Int) {
            if (nodes.size >= MAX_SNAPSHOT_NODES || depth > MAX_SNAPSHOT_DEPTH) return
            if (node.isPassword) {
                hasPasswordField = true
                return // Skip the node and its subtree entirely.
            }
            val rect = Rect()
            node.getBoundsInScreen(rect)
            val text = node.text?.toString()?.take(MAX_NODE_TEXT_CHARS)
            val description = node.contentDescription?.toString()?.take(MAX_NODE_TEXT_CHARS)
            val clickable = node.isClickable
            val editable = node.isEditable
            if ((clickable || editable || !text.isNullOrBlank() || !description.isNullOrBlank()) &&
                rect.width() > 0 && rect.height() > 0
            ) {
                nodes += ScreenNode(
                    text = text,
                    contentDescription = description,
                    viewId = node.viewIdResourceName,
                    className = node.className?.toString()?.substringAfterLast('.').orEmpty(),
                    clickable = clickable,
                    editable = editable,
                    isPassword = false,
                    bounds = NodeBounds(rect.left, rect.top, rect.right, rect.bottom),
                )
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                try {
                    walk(child, depth + 1)
                } finally {
                    child.recycle()
                }
            }
        }

        walk(root, 0)
        return ScreenSnapshot(
            packageName = packageName,
            nodes = nodes,
            hasPasswordField = hasPasswordField,
            capturedAtMillis = System.currentTimeMillis(),
        )
    }

    /**
     * Finds a node matching [selector]. Returns an independent copy
     * (via [AccessibilityNodeInfo.obtain]) that the caller must recycle,
     * or null. Prefers interactive matches — a tappable button labelled
     * "Search" beats a static label with the same text.
     */
    private fun findNode(
        root: AccessibilityNodeInfo,
        selector: NodeSelector,
    ): AccessibilityNodeInfo? {
        var found: AccessibilityNodeInfo? = null
        var fallback: AccessibilityNodeInfo? = null

        fun walk(node: AccessibilityNodeInfo) {
            if (found != null) return
            if (!node.isPassword && selector.matches(toScreenNode(node))) {
                if (node.isClickable || node.isEditable) {
                    found = AccessibilityNodeInfo.obtain(node)
                    return
                } else if (fallback == null) {
                    fallback = AccessibilityNodeInfo.obtain(node)
                }
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                try {
                    walk(child)
                } finally {
                    child.recycle()
                }
                if (found != null) return
            }
        }

        walk(root)
        return found ?: fallback
    }

    /** First scrollable node in the tree (an obtain() copy the caller recycles), or null. */
    private fun findScrollable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var found: AccessibilityNodeInfo? = null

        fun walk(node: AccessibilityNodeInfo) {
            if (found != null) return
            if (node.isScrollable) {
                found = AccessibilityNodeInfo.obtain(node)
                return
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                try {
                    walk(child)
                } finally {
                    child.recycle()
                }
                if (found != null) return
            }
        }

        walk(root)
        return found
    }

    /** Clicks [node], or the nearest clickable ancestor when the node itself is not clickable. */
    private fun clickNodeOrAncestor(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) {
                val clicked = current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                if (current !== node) current.recycle()
                return clicked
            }
            val parent = current.parent
            if (current !== node) current.recycle()
            current = parent
        }
        return false
    }

    /** Lightweight ScreenNode view of a live node, for selector matching only. */
    private fun toScreenNode(node: AccessibilityNodeInfo): ScreenNode {
        val rect = Rect()
        node.getBoundsInScreen(rect)
        return ScreenNode(
            text = node.text?.toString(),
            contentDescription = node.contentDescription?.toString(),
            viewId = node.viewIdResourceName,
            className = node.className?.toString()?.substringAfterLast('.').orEmpty(),
            clickable = node.isClickable,
            editable = node.isEditable,
            isPassword = node.isPassword,
            bounds = NodeBounds(rect.left, rect.top, rect.right, rect.bottom),
        )
    }

    /** Short description of a matched node for result messages ("Button “Search”"). */
    private fun describeMatch(node: AccessibilityNodeInfo): String =
        SnapshotSanitizer.describeNode(toScreenNode(node))

    /** Selector for a node, for macro recording (text/description/id/class). */
    private fun selectorFrom(node: AccessibilityNodeInfo): NodeSelector? {
        val selector = NodeSelector(
            text = node.text?.toString()?.take(MAX_NODE_TEXT_CHARS)?.takeIf { it.isNotBlank() },
            contentDescription = node.contentDescription?.toString()
                ?.take(MAX_NODE_TEXT_CHARS)?.takeIf { it.isNotBlank() },
            viewId = node.viewIdResourceName,
            className = node.className?.toString()?.substringAfterLast('.'),
        )
        return selector.takeUnless { it.isEmpty }
    }

    private companion object {
        /** Most nodes kept in one snapshot. */
        const val MAX_SNAPSHOT_NODES: Int = 200

        /** Deepest tree level traversed for a snapshot. */
        const val MAX_SNAPSHOT_DEPTH: Int = 12

        /** Longest node text kept (longer text is truncated). */
        const val MAX_NODE_TEXT_CHARS: Int = 100

        /** How long a tap gesture lasts. */
        const val TAP_DURATION_MILLIS: Long = 100L

        /** A gesture that takes longer than this is treated as failed. */
        const val GESTURE_TIMEOUT_MILLIS: Long = 5_000L
    }
}
