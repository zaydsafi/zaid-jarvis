package com.zaid.jarvis.productivity

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import com.zaid.jarvis.core.productivity.ScreenTime
import com.zaid.jarvis.core.productivity.ScreenTimeSummary
import com.zaid.jarvis.core.productivity.UsageEntry
import com.zaid.jarvis.core.productivity.UsageEvent
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.permissions.PermissionHelper
import com.zaid.jarvis.tools.productivity.ScreenTimeReader
import dagger.hilt.android.qualifiers.ApplicationContext
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * On-device screen-time data (Phase 9) via UsageStats.
 *
 * PACKAGE_USAGE_STATS is a special access: the user grants it in
 * system Settings (Settings → Productivity & wellness → Usage access
 * opens the usage-access screen). Until then, every read fails with
 * a plain message — the feature is disabled, not broken.
 *
 * All data stays on-device: it is aggregated in memory for the
 * Wellness screen, the get_screen_time tool, and the break-reminder
 * check, and never stored, uploaded, or logged.
 *
 * Honest limits: UsageStats is the system's own record — it can lag
 * a few minutes behind real usage, and the "continuous session"
 * length is computed from UsageEvents (see [ScreenTime]), which the
 * system may coalesce. Break reminders therefore only ever fire
 * late, never early.
 */
@Singleton
class UsageStatsScreenTimeReader @Inject constructor(
    @ApplicationContext private val context: Context,
) : ScreenTimeReader {

    private val usageStatsManager: UsageStatsManager? =
        context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager

    override fun hasUsageAccess(): Boolean = PermissionHelper.hasUsageAccess(context)

    override suspend fun todaySummary(): JarvisResult<ScreenTimeSummary> {
        if (!hasUsageAccess()) return noAccess()
        val manager = usageStatsManager ?: return noAccess()
        return withContext(Dispatchers.IO) {
            runCatching {
                val zone = ZoneId.systemDefault()
                val now = System.currentTimeMillis()
                val dayStart = LocalDate.ofInstant(Instant.ofEpochMilli(now), zone)
                    .atStartOfDay(zone).toInstant().toEpochMilli()
                val stats = manager.queryUsageStats(
                    UsageStatsManager.INTERVAL_DAILY,
                    dayStart,
                    now,
                ).orEmpty()
                val entries = stats.map { stat ->
                    UsageEntry(
                        packageName = stat.packageName,
                        totalTimeInForegroundMillis = stat.totalTimeInForeground,
                    )
                }
                JarvisResult.Success(ScreenTime.aggregate(entries))
            }.getOrElse { e ->
                JarvisResult.Failure(
                    "Couldn't read screen time: ${e.message ?: e::class.simpleName}.",
                )
            }
        }
    }

    @Suppress("DEPRECATION")
    // MOVE_TO_FOREGROUND / MOVE_TO_BACKGROUND are deprecated on API 34+
    // in favour of ACTIVITY_RESUMED / ACTIVITY_PAUSED, but those only
    // exist on API 29+ — the MOVE_TO_* events are the only ones on API
    // 26–28 (minSdk 26) and are still delivered on API 36.
    override suspend fun currentContinuousMillis(nowMillis: Long): JarvisResult<Long> {
        if (!hasUsageAccess()) return noAccess()
        val manager = usageStatsManager ?: return noAccess()
        return withContext(Dispatchers.IO) {
            runCatching {
                // Events from the last 12 hours are plenty: a
                // continuous session longer than that is not a
                // session, it is a forgotten phone.
                val from = nowMillis - 12 * 3_600_000L
                val events = mutableListOf<UsageEvent>()
                val usageEvents = manager.queryEvents(from, nowMillis)
                val event = UsageEvents.Event()
                while (usageEvents.hasNextEvent()) {
                    usageEvents.getNextEvent(event)
                    when (event.eventType) {
                        UsageEvents.Event.MOVE_TO_FOREGROUND ->
                            events += UsageEvent(event.timeStamp, isForeground = true)
                        UsageEvents.Event.MOVE_TO_BACKGROUND ->
                            events += UsageEvent(event.timeStamp, isForeground = false)
                    }
                }
                JarvisResult.Success(ScreenTime.currentContinuousMillis(events, nowMillis))
            }.getOrElse { e ->
                JarvisResult.Failure(
                    "Couldn't read screen time: ${e.message ?: e::class.simpleName}.",
                )
            }
        }
    }

    private fun <T> noAccess(): JarvisResult<T> =
        JarvisResult.Failure(
            "Screen time needs usage access. Grant it in " +
                "Settings → Productivity & wellness → Usage access.",
        )
}
