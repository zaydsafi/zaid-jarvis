package com.zaid.jarvis.social

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.zaid.jarvis.core.social.ScheduledPostStatus
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.repository.ScheduledPostRepository
import com.zaid.jarvis.tools.social.PublishService
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent

/**
 * The scheduled-publish worker (Phase 8).
 *
 * Runs at the scheduled time (one-time work, network constraint — see
 * [WorkManagerSocialScheduler]). It delegates everything to
 * [PublishService.publishScheduled], which re-checks the gate (draft
 * still APPROVED, body unchanged) and either publishes or cancels the
 * post; this worker only notifies Zaid of the outcome.
 *
 * The worker always returns [Result.success] after handling the post:
 * the outcome is recorded in the database (PUBLISHED / FAILED /
 * CANCELLED) and notified, and a failed post is retried by Zaid from
 * the Scheduled screen with a fresh approval card — never silently
 * retried by WorkManager, which could publish long after Zaid
 * changed his mind.
 *
 * Dependencies come from a Hilt entry point ([PublishWorkerEntryPoint])
 * rather than @HiltWorker, so no `androidx.hilt:hilt-work` dependency
 * is needed — WorkManager instantiates the worker itself, and the
 * entry point pulls the singletons out of the application graph.
 */
class PublishPostWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    private val entryPoint: PublishWorkerEntryPoint =
        EntryPointAccessors.fromApplication(
            appContext,
            PublishWorkerEntryPoint::class.java,
        )

    override suspend fun doWork(): Result {
        val scheduledPostId = inputData.getLong(KEY_SCHEDULED_POST_ID, 0L)
        if (scheduledPostId == 0L) return Result.failure()

        val scheduledPostRepository = entryPoint.scheduledPostRepository()
        val publishService = entryPoint.publishService()
        val publishNotifier = entryPoint.publishNotifier()

        val postBefore = scheduledPostRepository.getById(scheduledPostId)
            ?: return Result.success() // Row deleted while waiting — nothing to do.
        val draft = publishService.getDraft(postBefore.draftId)
        val draftTitle = draft?.title ?: "Scheduled post"

        when (val result = publishService.publishScheduled(scheduledPostId)) {
            is JarvisResult.Success -> {
                publishNotifier.notifyPublished(
                    platform = postBefore.platform,
                    draftTitle = draftTitle,
                    postUrl = result.value.postUrl,
                )
            }
            is JarvisResult.Failure -> {
                // The publish path recorded the outcome; read the row
                // back to tell a cancellation from a failure.
                val postAfter = scheduledPostRepository.getById(scheduledPostId)
                val reason = postAfter?.failureReason ?: result.message
                when (postAfter?.status) {
                    ScheduledPostStatus.CANCELLED -> publishNotifier.notifyCancelled(
                        platform = postBefore.platform,
                        draftTitle = draftTitle,
                        reason = reason,
                    )
                    else -> publishNotifier.notifyFailed(
                        platform = postBefore.platform,
                        draftTitle = draftTitle,
                        reason = reason,
                    )
                }
            }
        }
        return Result.success()
    }

    companion object {
        /** Input-data key for the scheduled-post row id. */
        const val KEY_SCHEDULED_POST_ID: String = "scheduled_post_id"

        /** Tag on every publish job (for debugging / bulk cancellation). */
        const val WORK_TAG: String = "jarvis_publish"
    }
}

/** Hilt entry point for [PublishPostWorker] (WorkManager creates the worker, not Hilt). */
@EntryPoint
@InstallIn(SingletonComponent::class)
interface PublishWorkerEntryPoint {
    fun publishService(): PublishService
    fun scheduledPostRepository(): ScheduledPostRepository
    fun publishNotifier(): PublishNotifier
}
