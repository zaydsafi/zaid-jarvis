package com.zaid.jarvis.social

import com.zaid.jarvis.core.social.OAuthClientCredentials
import com.zaid.jarvis.core.social.OAuthTokens
import com.zaid.jarvis.core.social.SocialAccount
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.data.repository.SocialAccountRepository
import com.zaid.jarvis.tools.social.SocialAccountStore
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Thin adapter: the [SocialAccountStore] interface (:tools) over the
 * [SocialAccountRepository] (:data). Same pattern as RoomMacroStore
 * (Phase 6) — :data does not depend on :tools, so the adapter lives
 * in :app. Provided by AppModule.
 */
@Singleton
class SocialAccountStoreImpl @Inject constructor(
    private val repository: SocialAccountRepository,
) : SocialAccountStore {
    override suspend fun getAccount(platform: SocialPlatform): SocialAccount? =
        repository.getAccount(platform)

    override suspend fun allAccounts(): List<SocialAccount> = repository.allAccounts()

    override suspend fun saveAccount(account: SocialAccount) = repository.saveAccount(account)

    override suspend fun deleteAccount(platform: SocialPlatform) = repository.deleteAccount(platform)

    override suspend fun getTokens(platform: SocialPlatform): OAuthTokens? =
        repository.getTokens(platform)

    override suspend fun saveTokens(platform: SocialPlatform, tokens: OAuthTokens) =
        repository.saveTokens(platform, tokens)

    override suspend fun clearTokens(platform: SocialPlatform) = repository.clearTokens(platform)

    override suspend fun getClientCredentials(platform: SocialPlatform): OAuthClientCredentials? =
        repository.getClientCredentials(platform)

    override suspend fun saveClientCredentials(
        platform: SocialPlatform,
        credentials: OAuthClientCredentials,
    ) = repository.saveClientCredentials(platform, credentials)

    override suspend fun clearClientCredentials(platform: SocialPlatform) =
        repository.clearClientCredentials(platform)

    override suspend fun clearAllSocialSecrets() = repository.clearAllSocialSecrets()
}
