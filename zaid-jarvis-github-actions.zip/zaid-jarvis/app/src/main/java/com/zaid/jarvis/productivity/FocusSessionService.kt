package com.zaid.jarvis.productivity

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.zaid.jarvis.MainActivity
import com.zaid.jarvis.core.productivity.formatDuration
import com.zaid.jarvis.tools.productivity.FocusSessionManager
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * The focus-session foreground service (Phase 9).
 *
 * Shows the persistent timer notification ("Focus session — 12m
 * left") and ticks it every 30 seconds. When the timer runs out it
 * ends the session through [FocusSessionManager.endSession] (which
 * restores DND and notifies) and stops itself.
 *
 * The service is the live timer; [FocusEndWorker] is the reliable
 * backstop — if the system kills this service, the worker still ends
 * the session on time. Ending is idempotent, so both paths are safe.
 *
 * Foreground service type: specialUse (the timer notification has no
 * dedicated type). The service stops itself when the session is
 * gone (stopped early from elsewhere) or the timer runs out.
 */
@AndroidEntryPoint
class FocusSessionService : Service() {

    @Inject lateinit var focusSessionManager: FocusSessionManager

    private val scope = CoroutineScope(Dispatchers.Main.immediate + Job())
    private var tickJob: Job? = null
    private var sessionId: Long = 0L

    private val notificationManager: NotificationManager by lazy {
        getSystemService(NotificationManager::class.java)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Focus session starting…"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        sessionId = intent?.getLongExtra(EXTRA_SESSION_ID, 0L) ?: 0L
        if (sessionId == 0L) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (tickJob == null) {
            tickJob = scope.launch { tickLoop() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        tickJob?.cancel()
        scope.coroutineContext[Job]?.cancel()
        super.onDestroy()
    }

    private suspend fun tickLoop() {
        while (true) {
            val session = focusSessionManager.currentSession()
            if (session == null || session.id != sessionId) {
                // Stopped early from elsewhere — nothing to time.
                stopSelf()
                return
            }
            if (session.isDueToEnd()) {
                focusSessionManager.endSession(sessionId)
                stopSelf()
                return
            }
            val remaining = formatDuration(session.remainingMillis())
            notificationManager.notify(
                NOTIFICATION_ID,
                buildNotification("Focus session — $remaining left"),
            )
            delay(TICK_MILLIS)
        }
    }

    private fun buildNotification(text: String): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            putExtra(MainActivity.EXTRA_DESTINATION, MainActivity.DESTINATION_WELLNESS)
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            NOTIFICATION_ID,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Focus session")
            .setContentText(text)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        if (notificationManager.getNotificationChannel(CHANNEL_ID) != null) return
        notificationManager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "Focus sessions",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "The running focus-session timer."
            },
        )
    }

    companion object {
        /** Session id extra (the session this service is timing). */
        const val EXTRA_SESSION_ID: String = "com.zaid.jarvis.focus.SESSION_ID"

        /** Notification refresh interval: 30 seconds. */
        const val TICK_MILLIS: Long = 30_000L

        private const val CHANNEL_ID: String = "jarvis_focus"
        private const val NOTIFICATION_ID: Int = 9200
    }
}
