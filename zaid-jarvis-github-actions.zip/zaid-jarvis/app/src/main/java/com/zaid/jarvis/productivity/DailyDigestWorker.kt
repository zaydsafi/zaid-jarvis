package com.zaid.jarvis.productivity

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.datastore.SettingsRepository
import com.zaid.jarvis.tools.productivity.BriefingProvider
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.first

/**
 * The daily-digest worker (Phase 9).
 *
 * A 24-hour periodic worker (see [WellnessScheduler]) that posts the
 * morning briefing as a notification — but only when the digest is
 * enabled in Settings (off by default). The briefing itself never
 * fails (BriefingService falls back to the plain template), so a
 * failure here means the notification path broke, and the worker
 * stays silent rather than posting an error.
 *
 * Quiet hours are respected inside [WellnessNotifier]: if the
 * configured digest time falls inside quiet hours, that day's
 * digest is skipped.
 *
 * Timing is best-effort (WorkManager + Doze/battery optimization):
 * the digest may arrive a few minutes late, never early.
 */
class DailyDigestWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    private val entryPoint: DailyDigestWorkerEntryPoint =
        EntryPointAccessors.fromApplication(
            appContext,
            DailyDigestWorkerEntryPoint::class.java,
        )

    override suspend fun doWork(): Result {
        // A failure anywhere here stays silent (no error notification,
        // no retry): tomorrow's digest is a fresh run. In particular
        // an unreadable Settings store must not throw — WorkManager
        // retries a throwing worker, and a digest must never post twice.
        return runCatching {
            val settings = entryPoint.settingsRepository().settings.first()
            if (settings.dailyDigestEnabled) {
                when (val result = entryPoint.briefingProvider().briefing()) {
                    is JarvisResult.Success ->
                        entryPoint.wellnessNotifier().notifyDigest(result.value)
                    is JarvisResult.Failure -> Unit // Stay silent on error.
                }
            }
            Result.success()
        }.getOrDefault(Result.success())
    }

    companion object {
        /** Tag on the digest job (for debugging). */
        const val WORK_TAG: String = "jarvis_daily_digest"
    }
}

/** Hilt entry point for [DailyDigestWorker] (WorkManager creates the worker, not Hilt). */
@EntryPoint
@InstallIn(SingletonComponent::class)
interface DailyDigestWorkerEntryPoint {
    fun settingsRepository(): SettingsRepository
    fun briefingProvider(): BriefingProvider
    fun wellnessNotifier(): WellnessNotifier
}
