package com.zaid.jarvis.backup

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Keeps the data-maintenance job enqueued (Phase 11 hardening).
 *
 * One unique periodic job ([MaintenanceWorker], every 7 days):
 * analytics pruning (90 days) and the audit-log retention cap
 * (10,000 entries). Unlike the auto-backup job, this one is NOT
 * gated on a setting — retention is hygiene, not a feature, and the
 * tables it prunes grow without Zaid doing anything.
 *
 * Called from [com.zaid.jarvis.JarvisApplication] on every app start
 * (WorkManager survives app restarts, but a force-stop or an update
 * can drop jobs — re-syncing is cheap and idempotent). KEEP policy:
 * the job's weekly cadence is not tied to any setting, so there is
 * never a reason to replace an existing schedule.
 */
@Singleton
class MaintenanceScheduler @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    /** Enqueues the weekly maintenance job if it is not already scheduled. */
    fun syncMaintenance() {
        val workManager = WorkManager.getInstance(context)
        val request = PeriodicWorkRequestBuilder<MaintenanceWorker>(
            MAINTENANCE_INTERVAL_DAYS,
            TimeUnit.DAYS,
        )
            .addTag(MaintenanceWorker.WORK_TAG)
            .build()
        workManager.enqueueUniquePeriodicWork(
            UNIQUE_MAINTENANCE_WORK,
            ExistingPeriodicWorkPolicy.KEEP,
            request,
        )
    }

    companion object {
        const val UNIQUE_MAINTENANCE_WORK: String = "jarvis_maintenance"
        const val MAINTENANCE_INTERVAL_DAYS: Long = 7
    }
}
