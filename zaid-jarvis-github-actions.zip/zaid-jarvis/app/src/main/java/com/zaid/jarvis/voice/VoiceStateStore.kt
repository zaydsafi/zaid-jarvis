package com.zaid.jarvis.voice

import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Voice state shared across entry points that cannot share a ViewModel:
 * the chat screen, the overlay bubble, the home-screen widget, and the
 * Quick Settings tile.
 *
 * - [isListening] is set by [VoiceEngine] so the tile can show the
 *   listening state even when the app UI is not visible.
 * - [voiceStartRequests] is a counter bumped by MainActivity (widget /
 *   tile / wake word deep-links) and by the Home orb; the chat screen
 *   observes it and starts listening on each new value.
 */
@Singleton
class VoiceStateStore @Inject constructor() {

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _voiceStartRequests = MutableStateFlow(0)
    val voiceStartRequests: StateFlow<Int> = _voiceStartRequests.asStateFlow()

    private val _openChatRequests = MutableStateFlow(0)
    /** Bumped when a deep-link asks for the Chat screen (with or without voice). */
    val openChatRequests: StateFlow<Int> = _openChatRequests.asStateFlow()

    private val _openTasksRequests = MutableStateFlow(0)
    /** Bumped when a deep-link asks for the Tasks screen (Phase 9 notifications). */
    val openTasksRequests: StateFlow<Int> = _openTasksRequests.asStateFlow()

    private val _openWellnessRequests = MutableStateFlow(0)
    /** Bumped when a deep-link asks for the Wellness screen (Phase 9 notifications). */
    val openWellnessRequests: StateFlow<Int> = _openWellnessRequests.asStateFlow()

    fun setListening(listening: Boolean) {
        _isListening.value = listening
    }

    /** Asks the chat screen to start listening (once, on the next value). */
    fun requestVoiceStart() {
        _voiceStartRequests.value = _voiceStartRequests.value + 1
    }

    /** Asks the nav graph to show the Chat screen. */
    fun requestOpenChat() {
        _openChatRequests.value = _openChatRequests.value + 1
    }

    /** Asks the nav graph to show the Tasks screen. */
    fun requestOpenTasks() {
        _openTasksRequests.value = _openTasksRequests.value + 1
    }

    /** Asks the nav graph to show the Wellness screen. */
    fun requestOpenWellness() {
        _openWellnessRequests.value = _openWellnessRequests.value + 1
    }
}
