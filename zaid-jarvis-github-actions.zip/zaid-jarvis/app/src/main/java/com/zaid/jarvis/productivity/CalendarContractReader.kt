package com.zaid.jarvis.productivity

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import com.zaid.jarvis.core.productivity.CalendarEvent
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.productivity.CalendarReader
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Read-only device calendar access (Phase 9) via CalendarContract.
 *
 * READ_CALENDAR is requested only when the calendar is first used
 * (the list_events tool, the briefing, or Home's schedule) — never
 * at app start. Without it, every read fails with a plain message
 * pointing at Settings → App permissions. No event creation in
 * Phase 9 (documented as a future addition).
 *
 * Only the primary calendar's visible events are returned, earliest
 * first. Event data is used for the briefing and the schedule
 * display only — it is never stored, never uploaded, never logged.
 */
@Singleton
class CalendarContractReader @Inject constructor(
    @ApplicationContext private val context: Context,
) : CalendarReader {

    override fun hasCalendarAccess(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) ==
            PackageManager.PERMISSION_GRANTED

    override suspend fun eventsBetween(
        startMillis: Long,
        endMillis: Long,
    ): JarvisResult<List<CalendarEvent>> {
        if (!hasCalendarAccess()) {
            return JarvisResult.Failure(
                "Jarvis can't see your calendar. Grant calendar access in " +
                    "Settings → App permissions.",
            )
        }
        return withContext(Dispatchers.IO) {
            runCatching {
                val projection = arrayOf(
                    CalendarContract.Events._ID,
                    CalendarContract.Events.TITLE,
                    CalendarContract.Events.DTSTART,
                    CalendarContract.Events.DTEND,
                    CalendarContract.Events.EVENT_LOCATION,
                    CalendarContract.Events.ALL_DAY,
                )
                // Overlapping events: starts before the window ends and
                // ends after the window starts (or has no end).
                val selection =
                    "${CalendarContract.Events.DTSTART} < ? AND " +
                        "(${CalendarContract.Events.DTEND} > ? OR ${CalendarContract.Events.DTEND} IS NULL)"
                val selectionArgs = arrayOf(endMillis.toString(), startMillis.toString())
                val sortOrder = "${CalendarContract.Events.DTSTART} ASC"
                val events = mutableListOf<CalendarEvent>()
                context.contentResolver.query(
                    CalendarContract.Events.CONTENT_URI,
                    projection,
                    selection,
                    selectionArgs,
                    sortOrder,
                )?.use { cursor ->
                    val idIndex = cursor.getColumnIndexOrThrow(CalendarContract.Events._ID)
                    val titleIndex = cursor.getColumnIndexOrThrow(CalendarContract.Events.TITLE)
                    val startIndex = cursor.getColumnIndexOrThrow(CalendarContract.Events.DTSTART)
                    val endIndex = cursor.getColumnIndexOrThrow(CalendarContract.Events.DTEND)
                    val locationIndex =
                        cursor.getColumnIndexOrThrow(CalendarContract.Events.EVENT_LOCATION)
                    val allDayIndex = cursor.getColumnIndexOrThrow(CalendarContract.Events.ALL_DAY)
                    while (cursor.moveToNext()) {
                        val start = cursor.getLong(startIndex)
                        val end = if (cursor.isNull(endIndex)) start else cursor.getLong(endIndex)
                        events += CalendarEvent(
                            id = cursor.getLong(idIndex),
                            title = cursor.getString(titleIndex) ?: "(No title)",
                            startMillis = start,
                            endMillis = end,
                            location = cursor.getString(locationIndex) ?: "",
                            allDay = cursor.getInt(allDayIndex) == 1,
                        )
                    }
                }
                JarvisResult.Success(events)
            }.getOrElse { e ->
                JarvisResult.Failure(
                    "Couldn't read the calendar: ${e.message ?: e::class.simpleName}.",
                )
            }
        }
    }
}
