package com.zaid.jarvis.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.zaid.jarvis.core.voice.SpeechInputState
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Locale
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Speech-to-text (Master Prompt §5.2). Thin wrapper around Android's
 * [SpeechRecognizer] with streaming partial results.
 *
 * Callers must hold RECORD_AUDIO before [start] — the UI requests it
 * when the user first taps the mic (least privilege; never at app
 * start). [SpeechRecognizer] must be created and used on the main
 * thread; all entry points here (chat, overlay, wake-word service)
 * run on the main thread.
 */
interface SpeechInput {
    /** Current recognizer state (idle / listening / final / error). */
    val state: StateFlow<SpeechInputState>

    /** False on devices with no recognizer installed (e.g. no Google app). */
    val isAvailable: Boolean

    /** Starts listening in [languageTag] (BCP 47, e.g. "en", "ur", "ar"). */
    fun start(languageTag: String)

    /** Stops listening and returns the final result, if any. */
    fun stop()

    /** Cancels listening without a result. */
    fun cancel()

    /** Releases the recognizer; the instance must not be used afterwards. */
    fun release()
}

class AndroidSpeechInput @Inject constructor(
    @ApplicationContext private val context: Context,
) : SpeechInput {

    private val _state = MutableStateFlow<SpeechInputState>(SpeechInputState.Idle)
    override val state: StateFlow<SpeechInputState> = _state.asStateFlow()

    override val isAvailable: Boolean
        get() = SpeechRecognizer.isRecognitionAvailable(context)

    private var recognizer: SpeechRecognizer? = null

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            _state.value = SpeechInputState.Listening("")
        }

        override fun onBeginningOfSpeech() = Unit
        override fun onRmsChanged(rmsdB: Float) = Unit
        override fun onBufferReceived(buffer: ByteArray?) = Unit
        override fun onEndOfSpeech() = Unit

        override fun onError(error: Int) {
            // ERROR_NO_MATCH / ERROR_SPEECH_TIMEOUT are ordinary silence,
            // not failures — report them gently so the UI can just stop.
            _state.value = SpeechInputState.Error(errorMessage(error))
            recognizer = null
        }

        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
            _state.value = if (text.isBlank()) {
                SpeechInputState.Error("I didn't catch that. Try again?")
            } else {
                SpeechInputState.Final(text)
            }
            recognizer = null
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val text = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
            if (text.isNotBlank()) {
                _state.value = SpeechInputState.Listening(text)
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }

    override fun start(languageTag: String) {
        if (!isAvailable) {
            _state.value = SpeechInputState.Error(
                "Speech recognition isn't available on this device. " +
                    "Install the Google app (or another recognizer) to use voice input.",
            )
            return
        }
        cancel()
        val recognizer = SpeechRecognizer.createSpeechRecognizer(context).also {
            this.recognizer = it
            it.setRecognitionListener(listener)
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.forLanguageTag(languageTag))
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        _state.value = SpeechInputState.Listening("")
        recognizer.startListening(intent)
    }

    override fun stop() {
        recognizer?.stopListening()
    }

    override fun cancel() {
        runCatching { recognizer?.cancel() }
        recognizer?.destroy()
        recognizer = null
        if (_state.value !is SpeechInputState.Final) {
            _state.value = SpeechInputState.Idle
        }
    }

    override fun release() {
        cancel()
    }

    companion object {
        /** Plain-language message for a SpeechRecognizer error code. */
        fun errorMessage(error: Int): String = when (error) {
            SpeechRecognizer.ERROR_AUDIO -> "Microphone error — is another app using the mic?"
            SpeechRecognizer.ERROR_CLIENT -> "Voice input was interrupted."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                "Jarvis needs microphone permission to listen."
            SpeechRecognizer.ERROR_NETWORK ->
                "Speech recognition needs a network connection right now."
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech recognition timed out — try again."
            SpeechRecognizer.ERROR_NO_MATCH -> "I didn't catch that. Try again?"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "The recognizer is busy — try again in a moment."
            SpeechRecognizer.ERROR_SERVER -> "The speech service had a problem — try again."
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't hear anything."
            else -> "Voice input failed (error $error)."
        }
    }
}
