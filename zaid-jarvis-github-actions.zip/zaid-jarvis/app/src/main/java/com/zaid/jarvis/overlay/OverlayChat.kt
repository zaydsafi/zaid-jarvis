package com.zaid.jarvis.overlay

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.zaid.jarvis.chat.ChatSession
import com.zaid.jarvis.core.confirmation.ApprovalDecision
import com.zaid.jarvis.core.confirmation.ApprovalState
import com.zaid.jarvis.core.confirmation.ConfirmationEngine
import com.zaid.jarvis.ui.components.ApprovalCard
import com.zaid.jarvis.ui.theme.JarvisTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * The expanded bubble: a compact overlay chat (Master Prompt §5.3).
 * Shares the [ChatSession] with the main chat screen, so a request
 * started here continues there.
 *
 * Approvals work from the overlay: the same [ApprovalCard] as in-app
 * appears when a tool call awaits a decision. Second confirmations and
 * biometric checks need the app (the biometric prompt requires a
 * FragmentActivity), so those states offer an "Open app" button
 * instead of silently failing.
 *
 * The mic button opens the app to Chat with voice listening started —
 * the overlay does not hold the recognizer itself, so the chat screen
 * stays the single owner of voice transcripts.
 */
@Composable
fun OverlayChatContent(
    chatSession: ChatSession,
    engine: ConfirmationEngine,
    onClose: () -> Unit,
    onOpenApp: () -> Unit,
    onMicTap: () -> Unit,
) {
    val messages by chatSession.messages.collectAsState()
    val isThinking by chatSession.isThinking.collectAsState()
    val statusText by chatSession.statusText.collectAsState()
    val pendingRequest by engine.pendingRequest.collectAsState()
    var input by remember { mutableStateOf("") }
    var nowMillis by remember { mutableStateOf(System.currentTimeMillis()) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    // Countdown ticker for the approval card's expiry display.
    LaunchedEffect(pendingRequest?.id) {
        while (pendingRequest != null) {
            delay(1_000)
            nowMillis = System.currentTimeMillis()
            engine.expireStaleRequests()
        }
    }
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    JarvisTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Jarvis", style = MaterialTheme.typography.titleMedium)
                    Row {
                        IconButton(onClick = onMicTap) {
                            Icon(Icons.Filled.Mic, contentDescription = "Voice input (opens app)")
                        }
                        IconButton(onClick = onOpenApp) {
                            Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = "Open full app")
                        }
                        IconButton(onClick = onClose) {
                            Icon(Icons.Filled.Close, contentDescription = "Collapse bubble")
                        }
                    }
                }

                // Approval card (reused from :ui) when a decision is pending.
                val request = pendingRequest
                if (request != null) {
                    when (request.state) {
                        ApprovalState.AWAITING_DECISION -> {
                            ApprovalCard(
                                request = request,
                                remainingSeconds = request.remainingMillis(nowMillis) / 1_000,
                                onAllow = {
                                    engine.resolve(request.id, ApprovalDecision.Allow)
                                },
                                onDeny = {
                                    engine.resolve(request.id, ApprovalDecision.Deny)
                                },
                                onEdit = { edited ->
                                    engine.resolve(request.id, ApprovalDecision.Edit(edited))
                                },
                                onTrust = if (request.tier.canBeTrusted) {
                                    {
                                        scope.launch {
                                            engine.trust(request.toolName)
                                            engine.resolve(request.id, ApprovalDecision.Allow)
                                        }
                                    }
                                } else {
                                    null
                                },
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                        ApprovalState.AWAITING_SECOND_CONFIRMATION,
                        ApprovalState.AWAITING_BIOMETRIC -> {
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                                ),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Text(
                                        "“${request.action}” needs one more confirmation in the app.",
                                        style = MaterialTheme.typography.bodyMedium,
                                    )
                                    Button(onClick = onOpenApp) {
                                        Text("Open app to confirm")
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                        else -> Unit
                    }
                }

                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    if (messages.isEmpty()) {
                        item {
                            Text(
                                "Ask Jarvis anything. Approvals appear here too.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    items(messages, key = { it.id }) { message ->
                        if (message.role == "system") {
                            Text(
                                message.text,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        } else {
                            Card(
                                colors = if (message.role == "user") {
                                    CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                                    )
                                } else {
                                    CardDefaults.cardColors()
                                },
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Text(
                                    message.text,
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.padding(10.dp),
                                )
                            }
                        }
                    }
                    if (isThinking) {
                        item {
                            Text(
                                statusText ?: "Thinking…",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        label = { Text("Message Jarvis") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            chatSession.send(input)
                            input = ""
                        },
                        enabled = input.isNotBlank() && !isThinking,
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
                    }
                }
            }
        }
    }
}
