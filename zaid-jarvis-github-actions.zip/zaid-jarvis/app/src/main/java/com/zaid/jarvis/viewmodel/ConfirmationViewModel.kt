package com.zaid.jarvis.viewmodel

import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zaid.jarvis.core.confirmation.ApprovalDecision
import com.zaid.jarvis.core.confirmation.ApprovalRequest
import com.zaid.jarvis.core.confirmation.ConfirmationEngine
import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.security.BiometricAuth
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Drives the approval card, the second-confirmation dialog, the Tier 3
 * biometric prompt, and the kill switch (Master Prompt §2.4, §6).
 *
 * A 1-second ticker keeps the approval countdown fresh and expires
 * stale requests, so a card left open past its 2-minute window can
 * never be approved afterwards.
 */
@HiltViewModel
class ConfirmationViewModel @Inject constructor(
    private val engine: ConfirmationEngine,
    private val killSwitch: KillSwitch,
    private val biometricAuth: BiometricAuth,
) : ViewModel() {

    val pendingRequest: StateFlow<ApprovalRequest?> = engine.pendingRequest

    /** Kill-switch generation; the UI shows feedback when it changes. */
    val killGeneration: StateFlow<Int> = killSwitch.generation
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    private val _nowMillis = MutableStateFlow(System.currentTimeMillis())
    val nowMillis: StateFlow<Long> = _nowMillis.asStateFlow()

    init {
        viewModelScope.launch {
            while (true) {
                delay(1_000)
                _nowMillis.value = System.currentTimeMillis()
                engine.expireStaleRequests()
            }
        }
    }

    fun allow() {
        pendingRequest.value?.let { engine.resolve(it.id, ApprovalDecision.Allow) }
    }

    fun deny() {
        pendingRequest.value?.let { engine.resolve(it.id, ApprovalDecision.Deny) }
    }

    fun edit(newContent: String) {
        pendingRequest.value?.let { engine.resolve(it.id, ApprovalDecision.Edit(newContent)) }
    }

    fun confirmSecond(confirmed: Boolean) {
        pendingRequest.value?.let {
            engine.resolve(
                it.id,
                if (confirmed) ApprovalDecision.ConfirmSecond else ApprovalDecision.CancelSecond,
            )
        }
    }

    /** Launches the system biometric / device-credential prompt for Tier 3. */
    fun authenticateBiometric(activity: FragmentActivity) {
        val request = pendingRequest.value ?: return
        biometricAuth.authenticate(
            activity = activity,
            title = "Approve sensitive action",
            subtitle = "${request.action} — ${request.toolName}",
        ) { result ->
            when (result) {
                is BiometricAuth.Result.Success ->
                    engine.resolve(request.id, ApprovalDecision.BiometricOk)
                else ->
                    engine.resolve(request.id, ApprovalDecision.BiometricFailed)
            }
        }
    }

    /** Trusts the pending action (tiers 0–1 only; the engine enforces it). */
    fun trustPending() {
        val request = pendingRequest.value ?: return
        viewModelScope.launch {
            engine.trust(request.toolName)
            engine.resolve(request.id, ApprovalDecision.Allow)
        }
    }

    /** The kill switch: cancels all running and queued automation. */
    fun stopAll() {
        killSwitch.cancelAll()
    }
}
