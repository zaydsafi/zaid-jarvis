package com.zaid.jarvis.backup

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.zaid.jarvis.data.datastore.SettingsRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.first

/**
 * Keeps the automatic-backup job in sync with Settings (Phase 10).
 *
 * One unique periodic job ([AutoBackupWorker], every 7 days):
 * enqueued only when automatic backup is enabled (off by default),
 * cancelled when it is off.
 *
 * Called from [com.zaid.jarvis.JarvisApplication] on every app start
 * (WorkManager survives app restarts, but a force-stop or an update
 * can drop jobs — re-syncing is cheap and idempotent) and from
 * [com.zaid.jarvis.viewmodel.SettingsViewModel] whenever the
 * auto-backup toggle changes.
 */
@Singleton
class BackupScheduler @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settingsRepository: SettingsRepository,
) {
    /** Re-syncs the auto-backup job from the current settings. */
    suspend fun syncAutoBackup() {
        val settings = settingsRepository.settings.first()
        val workManager = WorkManager.getInstance(context)
        if (!settings.autoBackupEnabled) {
            workManager.cancelUniqueWork(UNIQUE_AUTO_BACKUP_WORK)
            return
        }
        val request = PeriodicWorkRequestBuilder<AutoBackupWorker>(
            AUTO_BACKUP_INTERVAL_DAYS,
            TimeUnit.DAYS,
        )
            .addTag(AutoBackupWorker.WORK_TAG)
            .build()
        workManager.enqueueUniquePeriodicWork(
            UNIQUE_AUTO_BACKUP_WORK,
            ExistingPeriodicWorkPolicy.KEEP,
            request,
        )
    }

    companion object {
        const val UNIQUE_AUTO_BACKUP_WORK: String = "jarvis_auto_backup"
        const val AUTO_BACKUP_INTERVAL_DAYS: Long = 7
    }
}
