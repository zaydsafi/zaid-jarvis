package com.zaid.jarvis.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.core.model.JarvisSettings
import com.zaid.jarvis.core.productivity.FocusSession
import com.zaid.jarvis.core.productivity.ScreenTimeSummary
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.datastore.SettingsRepository
import com.zaid.jarvis.productivity.WellnessScheduler
import com.zaid.jarvis.tools.GatedToolExecutor
import com.zaid.jarvis.tools.productivity.FocusSessionManager
import com.zaid.jarvis.tools.productivity.ScreenTimeReader
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import javax.inject.Inject

/**
 * Wellness screen state (Phase 9): today's screen time, the running
 * focus session + history, and the break / wind-down / quiet-hours
 * toggles.
 *
 * Focus start/stop and the "Wind down now" action go through the
 * [GatedToolExecutor] like any tool call — `start_focus` /
 * `stop_focus` are Tier 1, and wind-down runs `set_do_not_disturb`
 * + `set_brightness` (Tier 1 each), so Zaid sees an approval card
 * for each change before it happens. The wind-down notification
 * itself never changes a setting.
 *
 * Toggle changes re-sync the periodic work via [WellnessScheduler]
 * so the workers follow Settings immediately.
 */
@HiltViewModel
class WellnessViewModel @Inject constructor(
    private val screenTimeReader: ScreenTimeReader,
    private val focusSessionManager: FocusSessionManager,
    private val settingsRepository: SettingsRepository,
    private val wellnessScheduler: WellnessScheduler,
    private val gatedToolExecutor: GatedToolExecutor,
    private val killSwitch: KillSwitch,
) : ViewModel() {

    val settings: StateFlow<JarvisSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), JarvisSettings())

    private val _screenTime = MutableStateFlow<ScreenTimeSummary?>(null)

    /** Today's screen-time summary (null until loaded / when unavailable). */
    val screenTime: StateFlow<ScreenTimeSummary?> = _screenTime.asStateFlow()

    private val _screenTimeError = MutableStateFlow<String?>(null)
    val screenTimeError: StateFlow<String?> = _screenTimeError.asStateFlow()

    private val _currentSession = MutableStateFlow<FocusSession?>(null)
    val currentSession: StateFlow<FocusSession?> = _currentSession.asStateFlow()

    private val _focusHistory = MutableStateFlow<List<FocusSession>>(emptyList())
    val focusHistory: StateFlow<List<FocusSession>> = _focusHistory.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        refresh()
    }

    fun clearMessage() {
        _message.value = null
    }

    /** Whether usage access is granted (re-read on every refresh — the user may grant it in Settings). */
    fun hasUsageAccess(): Boolean = screenTimeReader.hasUsageAccess()

    /** Reloads screen time + focus state (call on resume). */
    fun refresh() {
        viewModelScope.launch {
            _currentSession.value = focusSessionManager.currentSession()
            _focusHistory.value = focusSessionManager.history(20)
        }
        viewModelScope.launch {
            if (!screenTimeReader.hasUsageAccess()) {
                _screenTime.value = null
                _screenTimeError.value = null
                return@launch
            }
            when (val result = screenTimeReader.todaySummary()) {
                is JarvisResult.Success -> {
                    _screenTime.value = result.value
                    _screenTimeError.value = null
                }
                is JarvisResult.Failure -> {
                    _screenTime.value = null
                    _screenTimeError.value = result.message
                }
            }
        }
    }

    /** Starts a focus session — Tier 1 approval card first. */
    fun startFocus(durationMinutes: Int) {
        viewModelScope.launch {
            val job = launch {
                val params = buildJsonObject { put("duration_minutes", durationMinutes) }
                when (val result = gatedToolExecutor.execute("start_focus", params)) {
                    is JarvisResult.Success -> {
                        _message.value = result.value
                        refresh()
                    }
                    is JarvisResult.Failure -> _message.value = result.message
                }
            }
            killSwitch.register(job)
        }
    }

    /** Stops the running focus session early — Tier 1 approval card first. */
    fun stopFocus() {
        viewModelScope.launch {
            val job = launch {
                when (val result = gatedToolExecutor.execute("stop_focus", buildJsonObject {})) {
                    is JarvisResult.Success -> {
                        _message.value = result.value
                        refresh()
                    }
                    is JarvisResult.Failure -> _message.value = result.message
                }
            }
            killSwitch.register(job)
        }
    }

    /**
     * Wind down now: DND to Alarms only, then brightness to 20% —
     * each through its own Tier 1 approval card (the second only runs
     * when the first is approved). The wind-down notification offers
     * this; it never changes a setting by itself.
     */
    fun windDownNow() {
        viewModelScope.launch {
            val job = launch {
                val dndParams = buildJsonObject { put("mode", "alarms_only") }
                when (val dnd = gatedToolExecutor.execute("set_do_not_disturb", dndParams)) {
                    is JarvisResult.Success -> {
                        val brightnessParams = buildJsonObject { put("percent", 20) }
                        when (val brightness =
                            gatedToolExecutor.execute("set_brightness", brightnessParams)) {
                            is JarvisResult.Success -> _message.value =
                                "Winding down: Do Not Disturb on (alarms only), screen dimmed to 20%."
                            is JarvisResult.Failure -> _message.value =
                                "Do Not Disturb is on. Brightness: ${brightness.message}"
                        }
                    }
                    is JarvisResult.Failure -> _message.value = dnd.message
                }
            }
            killSwitch.register(job)
        }
    }

    // ── Settings (Phase 9 toggles; each re-syncs the periodic work) ──

    fun setBreakRemindersEnabled(enabled: Boolean) = updateSettings {
        it.copy(breakRemindersEnabled = enabled)
    }

    fun setBreakReminderIntervalMinutes(minutes: Int) = updateSettings {
        it.copy(breakReminderIntervalMinutes = minutes.coerceIn(15, 240))
    }

    fun setWindDownEnabled(enabled: Boolean) = updateSettings {
        it.copy(windDownEnabled = enabled)
    }

    fun setWindDownTime(hour: Int, minute: Int) = updateSettings {
        it.copy(windDownHour = hour.coerceIn(0, 23), windDownMinute = minute.coerceIn(0, 59))
    }

    fun setQuietHours(startMinute: Int, endMinute: Int) = updateSettings {
        it.copy(
            quietHoursStartMinute = startMinute.coerceIn(0, 1439),
            quietHoursEndMinute = endMinute.coerceIn(0, 1439),
        )
    }

    private fun updateSettings(transform: (JarvisSettings) -> JarvisSettings) {
        viewModelScope.launch {
            settingsRepository.updateSettings(transform)
            wellnessScheduler.syncPeriodicWork()
        }
    }
}
