package com.zaid.jarvis.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zaid.jarvis.core.confirmation.AuditEntry
import com.zaid.jarvis.core.confirmation.AuditLog
import com.zaid.jarvis.core.confirmation.AuditLogExporter
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.GatedToolExecutor
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Audit Log screen state (Master Prompt §6): list, search, detail,
 * export (CSV), delete, and undo.
 *
 * Search (Phase 11) runs against the database ([AuditLog.search]),
 * not against the in-memory list: the list flow is capped at the most
 * recent 1,000 entries, so an in-memory filter could never find older
 * entries. The search re-runs whenever the log changes.
 *
 * Undo (Phase 5) is real: [undo] runs the tool's inverse operation
 * through the same [GatedToolExecutor] as any other action, so undoing
 * a Tier 1 action shows its own approval card first. The entry is only
 * marked undone after the inverse succeeds — a denied or failed undo
 * leaves the entry untouched, and Jarvis never claims an undo it did
 * not perform.
 */
@HiltViewModel
class AuditLogViewModel @Inject constructor(
    private val auditLog: AuditLog,
    private val gatedExecutor: GatedToolExecutor,
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    /** Result of the last undo, shown in a dialog; null when none. */
    private val _undoMessage = MutableStateFlow<String?>(null)
    val undoMessage: StateFlow<String?> = _undoMessage.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val entries: StateFlow<List<AuditEntry>> = _searchQuery
        .flatMapLatest { query ->
            val q = query.trim()
            if (q.isEmpty()) {
                auditLog.observeAll()
            } else {
                // Re-run the SQL search whenever the log changes.
                auditLog.observeAll().map { auditLog.search(q) }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    /** CSV text for the share/export action. */
    fun exportCsv(): String = AuditLogExporter.toCsv(entries.value)

    fun deleteEntry(id: Long) {
        viewModelScope.launch { auditLog.delete(id) }
    }

    fun clearAll() {
        viewModelScope.launch { auditLog.clear() }
    }

    /**
     * Undoes [entry] through the gated executor. The result appears in
     * [undoMessage] when the undo finishes (or is denied / fails).
     * The entry is marked undone only after the inverse succeeds.
     */
    fun undo(entry: AuditEntry) {
        if (!entry.undoable) {
            _undoMessage.value = "This action cannot be undone."
            return
        }
        if (entry.undone) {
            _undoMessage.value = "This action was already undone."
            return
        }
        viewModelScope.launch {
            when (val result = gatedExecutor.executeUndo(entry)) {
                is JarvisResult.Success -> {
                    auditLog.markUndone(entry.id)
                    _undoMessage.value = result.value
                }
                is JarvisResult.Failure -> {
                    _undoMessage.value = result.message
                }
            }
        }
    }

    fun clearUndoMessage() {
        _undoMessage.value = null
    }
}
