package com.zaid.jarvis.backup

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.zaid.jarvis.data.repository.MaintenanceService
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent

/**
 * The data-maintenance worker (Phase 11 hardening).
 *
 * A weekly periodic worker (see [MaintenanceScheduler]) that enforces
 * the retention policy: analytics events older than 90 days are
 * pruned, and the audit log is trimmed to its most recent 10,000
 * entries. Nothing Zaid created by hand is ever touched (see
 * [MaintenanceService]).
 *
 * Approvals need no maintenance step: they are in-memory only (the
 * Confirmation Engine keeps the pending request and the awaiting map
 * in the process; expiry is checked at use), so there is nothing
 * persisted to prune.
 *
 * Always returns success: maintenance is best-effort hygiene, and a
 * failure here just means the next weekly run retries — the tables
 * only grow by one week of rows in the meantime. Silent on failure,
 * like the auto-backup worker.
 */
class MaintenanceWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    private val entryPoint: MaintenanceWorkerEntryPoint =
        EntryPointAccessors.fromApplication(
            appContext,
            MaintenanceWorkerEntryPoint::class.java,
        )

    override suspend fun doWork(): Result {
        runCatching { entryPoint.maintenanceService().prune() }
        return Result.success()
    }

    companion object {
        /** Tag on the maintenance job (for debugging). */
        const val WORK_TAG: String = "jarvis_maintenance"
    }
}

/** Hilt entry point for [MaintenanceWorker] (WorkManager creates the worker, not Hilt). */
@EntryPoint
@InstallIn(SingletonComponent::class)
interface MaintenanceWorkerEntryPoint {
    fun maintenanceService(): MaintenanceService
}
