package com.zaid.jarvis.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.core.research.ContentDraft
import com.zaid.jarvis.core.research.DraftStatus
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.repository.DraftRepository
import com.zaid.jarvis.tools.GatedToolExecutor
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import javax.inject.Inject

/**
 * Drafts screen state (Phase 7): the list, filters, and the editor.
 *
 * Approving a draft is a deliberate user action (the "Approve for
 * publishing" button) — it calls [DraftRepository.approve] directly,
 * not a tool, because the user is pressing the button themselves.
 *
 * Publishing and scheduling (Phase 8) go through the
 * [GatedToolExecutor] like any tool call — `publish_draft` and
 * `schedule_post` are Tier 2, so Zaid sees a card (plus a second
 * confirmation) with the exact text, platform, account, and time
 * before anything leaves the device.
 */
@HiltViewModel
class DraftsViewModel @Inject constructor(
    private val draftRepository: DraftRepository,
    private val gatedToolExecutor: GatedToolExecutor,
    private val killSwitch: KillSwitch,
) : ViewModel() {

    /** Status filter (null = all statuses). */
    private val _statusFilter = MutableStateFlow<DraftStatus?>(null)
    val statusFilter: StateFlow<DraftStatus?> = _statusFilter.asStateFlow()

    /** Platform filter (null = all platforms). */
    private val _platformFilter = MutableStateFlow<String?>(null)
    val platformFilter: StateFlow<String?> = _platformFilter.asStateFlow()

    /** Drafts matching the current filters, most recently updated first. */
    val drafts: StateFlow<List<ContentDraft>> = combine(
        draftRepository.observeAll(),
        _statusFilter,
        _platformFilter,
    ) { all, status, platform ->
        all.filter { draft ->
            (status == null || draft.status == status) &&
                (platform == null || draft.platform.equals(platform, ignoreCase = true))
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Platforms present in the draft list (for the filter chips). */
    val platforms: StateFlow<List<String>> = draftRepository.observeAll()
        .map { all -> all.map { it.platform }.distinct().sorted() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** The draft open in the editor (null = new draft / none loaded). */
    private val _selectedDraft = MutableStateFlow<ContentDraft?>(null)
    val selectedDraft: StateFlow<ContentDraft?> = _selectedDraft.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)

    /** One-shot result message (save / approve result, error). */
    val message: StateFlow<String?> = _message.asStateFlow()

    fun clearMessage() {
        _message.value = null
    }

    fun setStatusFilter(status: DraftStatus?) {
        _statusFilter.value = status
    }

    fun setPlatformFilter(platform: String?) {
        _platformFilter.value = platform
    }

    /** Loads a draft into the editor (id 0 = a new blank draft). */
    fun loadDraft(id: Long) {
        if (id == 0L) {
            _selectedDraft.value = null
            return
        }
        viewModelScope.launch {
            _selectedDraft.value = draftRepository.getById(id)
        }
    }

    /**
     * Saves the editor's draft (new or existing). Returns the row id
     * on success, or null with a message on failure.
     */
    fun saveDraft(draft: ContentDraft, onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch {
            when (val result = draftRepository.save(draft)) {
                is JarvisResult.Success -> {
                    // Re-read so the editor sees the stored approval
                    // hash (an edit keeps APPROVED but invalidates the
                    // hash — the screen must show that).
                    _selectedDraft.value = draftRepository.getById(result.value)
                    onSaved(result.value)
                }
                is JarvisResult.Failure -> _message.value = result.message
            }
        }
    }

    /** Marks a draft APPROVED for publishing (DRAFT only; deliberate user action). */
    fun approveDraft(id: Long) {
        viewModelScope.launch {
            when (val result = draftRepository.approve(id)) {
                is JarvisResult.Success -> {
                    _selectedDraft.value = _selectedDraft.value?.copy(status = DraftStatus.APPROVED)
                    _message.value = "Draft approved for publishing. Publish it now or " +
                        "schedule it from this screen — or ask Jarvis to publish it."
                }
                is JarvisResult.Failure -> _message.value = result.message
            }
        }
    }

    /**
     * Publishes an APPROVED draft right now — Tier 2 approval card
     * first (exact text, platform, account). [imageUrl] is required
     * for Instagram posts (a public image URL).
     */
    fun publishDraft(id: Long, imageUrl: String? = null) {
        viewModelScope.launch {
            val job = launch {
                val params = buildJsonObject {
                    put("draft_id", id.toInt())
                    imageUrl?.takeIf { it.isNotBlank() }?.let { put("image_url", it) }
                }
                val result = gatedToolExecutor.execute("publish_draft", params)
                _message.value = when (result) {
                    is JarvisResult.Success -> {
                        _selectedDraft.value = _selectedDraft.value?.copy(status = DraftStatus.PUBLISHED)
                        result.value
                    }
                    is JarvisResult.Failure -> result.message
                }
            }
            killSwitch.register(job)
        }
    }

    /**
     * Schedules an APPROVED draft for [delayMinutes] from now — Tier 2
     * approval card first (exact text, platform, account, time).
     */
    fun scheduleDraft(id: Long, delayMinutes: Long, imageUrl: String? = null) {
        viewModelScope.launch {
            val job = launch {
                val params = buildJsonObject {
                    put("draft_id", id.toInt())
                    put("delay_minutes", delayMinutes.toInt())
                    imageUrl?.takeIf { it.isNotBlank() }?.let { put("image_url", it) }
                }
                val result = gatedToolExecutor.execute("schedule_post", params)
                _message.value = when (result) {
                    is JarvisResult.Success -> result.value
                    is JarvisResult.Failure -> result.message
                }
            }
            killSwitch.register(job)
        }
    }

    fun deleteDraft(id: Long) {
        viewModelScope.launch { draftRepository.delete(id) }
    }
}
