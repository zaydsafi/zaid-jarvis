package com.zaid.jarvis.overlay

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

/**
 * "Display over other apps" permission (Master Prompt §5.3). Android
 * grants this only from the system settings screen — there is no
 * runtime-permission dialog for it — so the Settings toggle sends Zaid
 * there and stays greyed out until the permission is granted.
 */
object OverlayPermission {

    /** True when the bubble may draw over other apps. */
    fun canDrawOverlays(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)

    /** Intent for the system "Display over other apps" screen for this app. */
    fun manageOverlayIntent(context: Context): Intent =
        Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}"),
        )
}
