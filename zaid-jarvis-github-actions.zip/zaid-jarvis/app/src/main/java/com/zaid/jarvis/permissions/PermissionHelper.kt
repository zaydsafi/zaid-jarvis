package com.zaid.jarvis.permissions

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.core.content.ContextCompat

/**
 * What Jarvis needs from Android, in one place (Phase 5).
 *
 * Least privilege (Master Prompt §2.5): every permission is requested
 * only when its feature is first used — never at app start. When a tool
 * finds a permission missing, it fails with a clear message pointing
 * here (Settings → App permissions), where Zaid can grant it.
 *
 * Two kinds of access live here:
 * - **Runtime permissions** (Contacts, Camera, Bluetooth, Microphone):
 *   granted through the system permission dialog.
 * - **Special accesses** (Modify system settings for brightness, Do Not
 *   Disturb access, Display over other apps for the bubble): granted
 *   only in system Settings — the helper builds the right intent.
 */
object PermissionHelper {

    /** One runtime permission, with the plain-language reason Jarvis needs it. */
    data class ToolPermission(
        val permission: String,
        val displayName: String,
        val rationale: String,
    )

    /** Runtime permissions the phone tools (and voice) use. */
    val TOOL_PERMISSIONS: List<ToolPermission> = listOf(
        ToolPermission(
            permission = Manifest.permission.READ_CONTACTS,
            displayName = "Contacts",
            rationale = "Look up contacts by name, for calls and messages.",
        ),
        ToolPermission(
            permission = Manifest.permission.CAMERA,
            displayName = "Camera",
            rationale = "Switch the flashlight (torch) on and off.",
        ),
        ToolPermission(
            permission = Manifest.permission.BLUETOOTH_CONNECT,
            displayName = "Bluetooth",
            rationale = "Turn Bluetooth on and off.",
        ),
        ToolPermission(
            permission = Manifest.permission.RECORD_AUDIO,
            displayName = "Microphone",
            rationale = "Voice input and the “Hey Jarvis” wake word.",
        ),
        ToolPermission(
            permission = Manifest.permission.READ_CALENDAR,
            displayName = "Calendar",
            rationale = "Read today's schedule (read-only — Jarvis never creates or changes events).",
        ),
    )

    fun isGranted(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun rationaleFor(permission: String): String =
        TOOL_PERMISSIONS.firstOrNull { it.permission == permission }?.rationale
            ?: "Jarvis needs this permission for one of its features."

    // ── Special accesses (granted in system Settings) ─────────────────

    /** "Modify system settings" — needed to change screen brightness. */
    fun canWriteSettings(context: Context): Boolean = Settings.System.canWrite(context)

    /** Intent for the "Modify system settings" screen for this app. */
    fun writeSettingsIntent(context: Context): Intent =
        Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
            data = Uri.parse("package:${context.packageName}")
        }

    /** Do Not Disturb policy access — needed to change DND mode. */
    fun hasDndAccess(context: Context): Boolean {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        return manager?.isNotificationPolicyAccessGranted == true
    }

    /** Intent for the Do Not Disturb access screen for this app. */
    fun dndAccessIntent(context: Context): Intent =
        Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
            data = Uri.parse("package:${context.packageName}")
        }

    /** Usage access (PACKAGE_USAGE_STATS, Phase 9) — granted only in system Settings. */
    fun hasUsageAccess(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? android.app.AppOpsManager
            ?: return false
        val mode = appOps.checkOpNoThrow(
            android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            context.packageName,
        )
        return mode == android.app.AppOpsManager.MODE_ALLOWED
    }

    /** Intent for the usage-access screen (the user picks Zaid Jarvis and allows access). */
    fun usageAccessSettingsIntent(): Intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)

    /** Intent for this app's page in system Settings. */
    fun appSettingsIntent(context: Context): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:${context.packageName}")
        }
}
