package com.zaid.jarvis.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.core.social.ScheduledPost
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.repository.ScheduledPostRepository
import com.zaid.jarvis.tools.GatedToolExecutor
import com.zaid.jarvis.tools.social.SocialScheduler
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import javax.inject.Inject

/**
 * Scheduled posts screen state (Phase 8): upcoming, published,
 * failed, and cancelled posts.
 *
 * Cancelling and retrying both go through the [GatedToolExecutor]
 * like any tool call, so they get their approval cards (cancel is
 * Tier 1; retry re-schedules through `schedule_post`, Tier 2, with
 * the exact text and new time on the card). A successful retry
 * deletes the old FAILED row so the list doesn't fill with stale
 * failures.
 */
@HiltViewModel
class ScheduledPostsViewModel @Inject constructor(
    private val scheduledPostRepository: ScheduledPostRepository,
    private val scheduler: SocialScheduler,
    private val gatedToolExecutor: GatedToolExecutor,
    private val killSwitch: KillSwitch,
) : ViewModel() {

    val posts: StateFlow<List<ScheduledPost>> = scheduledPostRepository.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _message = MutableStateFlow<String?>(null)

    /** One-shot result message (cancel / retry result, error). */
    val message: StateFlow<String?> = _message.asStateFlow()

    fun clearMessage() {
        _message.value = null
    }

    /** Cancels a scheduled post — approval card first. */
    fun cancelPost(id: Long) {
        viewModelScope.launch {
            val job = launch {
                val params = buildJsonObject { put("scheduled_post_id", id.toInt()) }
                val result = gatedToolExecutor.execute("cancel_scheduled_post", params)
                _message.value = when (result) {
                    is JarvisResult.Success -> result.value
                    is JarvisResult.Failure -> result.message
                }
            }
            killSwitch.register(job)
        }
    }

    /**
     * Retries a FAILED post: re-schedules the same draft for 5 minutes
     * from now, through `schedule_post` (fresh Tier 2 approval card
     * with the exact text and new time), then deletes the old FAILED
     * row on success.
     */
    fun retryPost(post: ScheduledPost) {
        viewModelScope.launch {
            val job = launch {
                val params = buildJsonObject {
                    put("draft_id", post.draftId.toInt())
                    put("delay_minutes", 5)
                    post.imageUrl?.let { put("image_url", it) }
                }
                val result = gatedToolExecutor.execute("schedule_post", params)
                _message.value = when (result) {
                    is JarvisResult.Success -> {
                        scheduler.delete(post.id)
                        result.value
                    }
                    is JarvisResult.Failure -> result.message
                }
            }
            killSwitch.register(job)
        }
    }
}
