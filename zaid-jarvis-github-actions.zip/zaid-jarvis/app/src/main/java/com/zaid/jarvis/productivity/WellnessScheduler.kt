package com.zaid.jarvis.productivity

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.zaid.jarvis.core.model.JarvisSettings
import com.zaid.jarvis.core.productivity.ProactiveRules
import com.zaid.jarvis.data.datastore.SettingsRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.first

/**
 * Keeps the Phase 9 periodic work in sync with Settings (Phase 9).
 *
 * Two unique periodic jobs:
 * - **Proactive check** ([ProactiveCheckWorker], every 15 minutes —
 *   WorkManager's minimum): overdue nudges, break reminders, and
 *   wind-down. Enqueued only when at least one of the three features
 *   is enabled; cancelled when all three are off.
 * - **Daily digest** ([DailyDigestWorker], every 24 hours, first run
 *   at the next configured digest time): enqueued only when the
 *   digest is enabled. Re-synced with UPDATE so a changed digest
 *   time re-aligns the next run (the initial delay is always
 *   recomputed to the next occurrence of the configured time).
 *
 * Called from [com.zaid.jarvis.JarvisApplication] on every app
 * start (WorkManager survives app restarts, but a force-stop or an
 * update can drop jobs — re-syncing is cheap and idempotent) and
 * from [com.zaid.jarvis.viewmodel.SettingsViewModel] whenever a
 * Phase 9 toggle or time changes.
 */
@Singleton
class WellnessScheduler @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settingsRepository: SettingsRepository,
) {

    /** Re-syncs both periodic jobs from the current settings. */
    suspend fun syncPeriodicWork() {
        val settings = settingsRepository.settings.first()
        syncProactiveCheck(settings)
        syncDigest(settings)
    }

    private fun syncProactiveCheck(settings: JarvisSettings) {
        val workManager = WorkManager.getInstance(context)
        val anyEnabled = settings.overdueRemindersEnabled ||
            settings.breakRemindersEnabled ||
            settings.windDownEnabled
        if (!anyEnabled) {
            workManager.cancelUniqueWork(UNIQUE_PROACTIVE_WORK)
            return
        }
        val request = PeriodicWorkRequestBuilder<ProactiveCheckWorker>(
            PROACTIVE_INTERVAL_MINUTES,
            TimeUnit.MINUTES,
        )
            .addTag(ProactiveCheckWorker.WORK_TAG)
            .build()
        workManager.enqueueUniquePeriodicWork(
            UNIQUE_PROACTIVE_WORK,
            ExistingPeriodicWorkPolicy.KEEP,
            request,
        )
    }

    private fun syncDigest(settings: JarvisSettings) {
        val workManager = WorkManager.getInstance(context)
        if (!settings.dailyDigestEnabled) {
            workManager.cancelUniqueWork(UNIQUE_DIGEST_WORK)
            return
        }
        val now = System.currentTimeMillis()
        val nextDigest = ProactiveRules.nextDailyTimeMillis(
            hour = settings.dailyDigestHour,
            minute = settings.dailyDigestMinute,
            nowMillis = now,
        )
        val request = PeriodicWorkRequestBuilder<DailyDigestWorker>(
            DIGEST_INTERVAL_HOURS,
            TimeUnit.HOURS,
        )
            .setInitialDelay(nextDigest - now, TimeUnit.MILLISECONDS)
            .addTag(DailyDigestWorker.WORK_TAG)
            .build()
        // UPDATE: a changed digest time re-aligns the next run (the
        // initial delay is always recomputed to the next occurrence).
        workManager.enqueueUniquePeriodicWork(
            UNIQUE_DIGEST_WORK,
            ExistingPeriodicWorkPolicy.UPDATE,
            request,
        )
    }

    companion object {
        const val UNIQUE_PROACTIVE_WORK: String = "jarvis_proactive_check"
        const val UNIQUE_DIGEST_WORK: String = "jarvis_daily_digest"
        const val PROACTIVE_INTERVAL_MINUTES: Long = 15
        const val DIGEST_INTERVAL_HOURS: Long = 24
    }
}
