package com.zaid.jarvis.productivity

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.zaid.jarvis.tools.productivity.FocusSessionManager
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent

/**
 * The focus-session end worker (Phase 9).
 *
 * A one-time worker enqueued for the session's end time (see
 * [FocusSessionManagerImpl]). It is the reliable backstop for the
 * foreground service: if the system kills [FocusSessionService],
 * this worker still ends the session on time (restoring DND and
 * notifying). Ending is idempotent, so it is safe for both the
 * service and the worker to try.
 *
 * Always returns success after handling the session — a finished
 * session is never retried.
 */
class FocusEndWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    private val entryPoint: FocusEndWorkerEntryPoint =
        EntryPointAccessors.fromApplication(
            appContext,
            FocusEndWorkerEntryPoint::class.java,
        )

    override suspend fun doWork(): Result {
        val sessionId = inputData.getLong(KEY_SESSION_ID, 0L)
        if (sessionId == 0L) return Result.failure()
        // endSession is idempotent and handles a missing session — but
        // a database failure would throw, and WorkManager retries a
        // throwing worker. A finished session is never retried, so a
        // failure here stays silent instead (the session row keeps
        // its RUNNING status and the user can stop it from Wellness).
        runCatching { entryPoint.focusSessionManager().endSession(sessionId) }
        return Result.success()
    }

    companion object {
        /** Input-data key for the focus-session row id. */
        const val KEY_SESSION_ID: String = "focus_session_id"

        /** Tag on every focus-end job (for debugging / bulk cancellation). */
        const val WORK_TAG: String = "jarvis_focus_end"
    }
}

/** Hilt entry point for [FocusEndWorker] (WorkManager creates the worker, not Hilt). */
@EntryPoint
@InstallIn(SingletonComponent::class)
interface FocusEndWorkerEntryPoint {
    fun focusSessionManager(): FocusSessionManager
}
