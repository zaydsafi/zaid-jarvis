package com.zaid.jarvis.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.core.research.ResearchEvent
import com.zaid.jarvis.core.research.ResearchRecord
import com.zaid.jarvis.data.repository.ResearchRepository
import com.zaid.jarvis.tools.research.ResearchRunner
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Research screen state (Phase 7): past research jobs and running new ones.
 *
 * Running research collects the [ResearchRunner] flow directly (not via a
 * tool call — the user pressed the button, so no approval card is needed)
 * and registers the job with the kill switch, so "Stop Jarvis" cancels a
 * research job mid-run. Progress lines are shown live; the finished brief
 * lands in the history list via the repository Flow.
 */
@HiltViewModel
class ResearchViewModel @Inject constructor(
    private val researchRepository: ResearchRepository,
    private val researchRunner: ResearchRunner,
    private val killSwitch: KillSwitch,
) : ViewModel() {

    val records: StateFlow<List<ResearchRecord>> = researchRepository.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _running = MutableStateFlow(false)

    /** True while a research job is running. */
    val running: StateFlow<Boolean> = _running.asStateFlow()

    private val _progress = MutableStateFlow<List<String>>(emptyList())

    /** Live progress lines for the current (or last) job. */
    val progress: StateFlow<List<String>> = _progress.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)

    /** One-shot result message, shown as a dialog. */
    val message: StateFlow<String?> = _message.asStateFlow()

    fun clearMessage() {
        _message.value = null
    }

    /** Starts a research job for [topic]. Ignored while one is already running. */
    fun runResearch(topic: String) {
        val trimmed = topic.trim()
        if (trimmed.isEmpty() || _running.value) return
        _running.value = true
        _progress.value = emptyList()
        viewModelScope.launch {
            val job = launch {
                researchRunner.research(trimmed).collect { event ->
                    when (event) {
                        is ResearchEvent.Searching ->
                            appendProgress("Searching: “${event.query}”…")
                        is ResearchEvent.Fetching ->
                            appendProgress("Reading ${event.index}/${event.total}: ${event.url}")
                        ResearchEvent.Synthesizing ->
                            appendProgress("Writing the brief…")
                        is ResearchEvent.Done -> {
                            appendProgress("Done — brief saved.")
                            _message.value = "Research on “${event.brief.topic}” is saved " +
                                "(${event.brief.sources.size} sources)."
                        }
                        is ResearchEvent.Failed -> {
                            _message.value = event.message
                        }
                    }
                }
            }
            killSwitch.register(job)
            job.join()
            _running.value = false
        }
    }

    fun deleteRecord(id: Long) {
        viewModelScope.launch { researchRepository.delete(id) }
    }

    fun deleteAllRecords() {
        viewModelScope.launch { researchRepository.deleteAll() }
    }

    private fun appendProgress(line: String) {
        _progress.value = _progress.value + line
    }
}
