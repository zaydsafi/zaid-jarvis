package com.zaid.jarvis.viewmodel

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.WorkManager
import com.zaid.jarvis.MainActivity
import com.zaid.jarvis.accessibility.AccessibilityState
import com.zaid.jarvis.backup.BackupScheduler
import com.zaid.jarvis.core.confirmation.TrustedActionStore
import com.zaid.jarvis.core.model.AppLanguage
import com.zaid.jarvis.core.model.CustomProviderConfig
import com.zaid.jarvis.core.model.JarvisSettings
import com.zaid.jarvis.core.model.LlmModel
import com.zaid.jarvis.core.model.LlmProvider
import com.zaid.jarvis.core.model.Personality
import com.zaid.jarvis.core.model.ThemeMode
import com.zaid.jarvis.core.research.SearchBackend
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.datastore.SettingsRepository
import com.zaid.jarvis.data.repository.AnalyticsRepository
import com.zaid.jarvis.data.repository.ApiKeyRepository
import com.zaid.jarvis.data.repository.DataWipeService
import com.zaid.jarvis.data.repository.MacroRepository
import com.zaid.jarvis.data.repository.SocialAccountRepository
import com.zaid.jarvis.overlay.BubbleService
import com.zaid.jarvis.productivity.FocusSessionService
import com.zaid.jarvis.productivity.WellnessScheduler
import com.zaid.jarvis.security.BiometricAuth
import com.zaid.jarvis.voice.WakeWordService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Settings screen state. All writes go through the repositories —
 * DataStore for preferences, EncryptedSharedPreferences for API keys,
 * and the trusted-action store for "always allow" actions (Phase 2).
 */
@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val apiKeyRepository: ApiKeyRepository,
    private val trustedActionStore: TrustedActionStore,
    private val macroRepository: MacroRepository,
    private val socialAccountRepository: SocialAccountRepository,
    private val wellnessScheduler: WellnessScheduler,
    private val backupScheduler: BackupScheduler,
    private val analyticsRepository: AnalyticsRepository,
    private val dataWipeService: DataWipeService,
    private val biometricAuth: BiometricAuth,
    @ApplicationContext private val appContext: Context,
) : ViewModel() {

    /** Delete-all-data state, for the Danger zone dialog. */
    sealed interface DeleteAllDataState {
        data object Idle : DeleteAllDataState
        data object Wiping : DeleteAllDataState
        /** The wipe failed partway — the message names what could not be deleted. */
        data class Failed(val message: String) : DeleteAllDataState
    }

    val settings: StateFlow<JarvisSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), JarvisSettings())

    /** True while the system has the Accessibility service bound (Phase 6). */
    val accessibilityConnected: StateFlow<Boolean> = AccessibilityState.isConnected
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    /** Number of saved macros, for the Automation section (Phase 6). A SQL COUNT — no rows loaded. */
    val macroCount: StateFlow<Int> = macroRepository.observeCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    private val _deleteAllDataState = MutableStateFlow<DeleteAllDataState>(DeleteAllDataState.Idle)
    val deleteAllDataState: StateFlow<DeleteAllDataState> = _deleteAllDataState.asStateFlow()

    val apiKeyPresence: StateFlow<Map<LlmProvider, Boolean>> = apiKeyRepository.keyPresence
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyMap())

    /** Ids of custom providers that have a key stored. */
    val customKeyPresence: StateFlow<Set<String>> = apiKeyRepository.customKeyPresence
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

    /** Whether a Tavily search API key is stored (Phase 7). */
    val tavilyKeyPresence: StateFlow<Boolean> = apiKeyRepository.tavilyKeyPresence
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    val trustedActions: StateFlow<Set<String>> = trustedActionStore.observeTrusted()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

    fun setTheme(mode: ThemeMode) = update { it.copy(themeMode = mode) }
    fun setLanguage(language: AppLanguage) = update { it.copy(language = language) }
    fun setVoiceSpeed(speed: Float) = update { it.copy(voiceSpeed = speed.coerceIn(0.5f, 2.0f)) }
    fun setPersonality(personality: Personality) = update { it.copy(personality = personality) }
    fun setProvider(provider: LlmProvider) = update { it.withProvider(provider) }
    fun setModel(model: LlmModel) = update { it.withModel(model) }
    fun setUseCheapModel(useCheap: Boolean) = update { it.copy(useCheapModelForSimpleIntents = useCheap) }
    fun setAlwaysAskReadOnly(alwaysAsk: Boolean) = update { it.copy(alwaysAskReadOnly = alwaysAsk) }
    fun setVoiceRepliesEnabled(enabled: Boolean) = update { it.copy(voiceRepliesEnabled = enabled) }

    /**
     * Screen automation on/off (Phase 6). Enabling only takes effect
     * when the Accessibility service is enabled in system Settings —
     * the UI greys the toggle out until then, and the device layer
     * refuses to act without the service regardless of this flag.
     */
    fun setAutomationEnabled(enabled: Boolean) = update { it.copy(automationEnabled = enabled) }

    /** True when the Accessibility service is in the system's enabled list. */
    fun isAccessibilityServiceEnabled(): Boolean =
        AccessibilityState.isServiceEnabled(appContext)

    /**
     * Wake word on/off (Phase 4). Enabling starts the foreground
     * wake-word service; the UI asks for microphone permission first,
     * and this refuses to start without it.
     */
    fun setWakeWordEnabled(enabled: Boolean) {
        update { it.copy(wakeWordEnabled = enabled) }
        val intent = Intent(appContext, WakeWordService::class.java)
        if (enabled) {
            if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
            ) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    appContext.startForegroundService(intent)
                } else {
                    appContext.startService(intent)
                }
            }
        } else {
            appContext.stopService(intent)
        }
    }

    /**
     * Floating bubble on/off (Phase 4). Enabling starts the overlay
     * service; the UI greys the toggle out until "Display over other
     * apps" is granted, and the service stops itself without it.
     */
    fun setFloatingBubbleEnabled(enabled: Boolean) {
        update { it.copy(floatingBubbleEnabled = enabled) }
        val intent = Intent(appContext, BubbleService::class.java)
        if (enabled) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appContext.startForegroundService(intent)
            } else {
                appContext.startService(intent)
            }
        } else {
            appContext.stopService(intent)
        }
    }

    /** Free-text model override for OpenRouter (blank = use the preset). */
    fun setCustomModelId(modelId: String) = update { it.copy(customModelId = modelId.trim()) }

    /** Adds a custom provider and selects it. Returns its id. */
    fun addCustomProvider(name: String, baseUrl: String, modelId: String): String {
        val config = CustomProviderConfig(
            id = UUID.randomUUID().toString(),
            name = name.trim(),
            baseUrl = baseUrl.trim(),
            modelId = modelId.trim(),
        )
        update {
            it.copy(
                customProviders = it.customProviders + config,
                selectedCustomProviderId = config.id,
            )
        }
        return config.id
    }

    fun updateCustomProvider(config: CustomProviderConfig) = update { settings ->
        settings.copy(
            customProviders = settings.customProviders.map {
                if (it.id == config.id) config else it
            },
        )
    }

    /** Deletes a custom provider and its stored API key. */
    fun deleteCustomProvider(id: String) {
        apiKeyRepository.clearCustomApiKey(id)
        update { settings ->
            val remaining = settings.customProviders.filterNot { it.id == id }
            settings.copy(
                customProviders = remaining,
                selectedCustomProviderId = settings.selectedCustomProviderId
                    ?.takeIf { selected -> remaining.any { it.id == selected } }
                    ?: remaining.firstOrNull()?.id,
            )
        }
    }

    fun setSelectedCustomProvider(id: String) =
        update { it.copy(selectedCustomProviderId = id) }

    /** Stores a custom provider's key (encrypted). Blank input clears it. */
    fun setCustomApiKey(customProviderId: String, apiKey: String) {
        apiKeyRepository.setCustomApiKey(customProviderId, apiKey)
    }

    /** Revokes trust for one action; the next call asks again. */
    fun revokeTrusted(toolName: String) {
        viewModelScope.launch { trustedActionStore.revoke(toolName) }
    }

    /** Revokes all trusted actions. */
    fun revokeAllTrusted() {
        viewModelScope.launch { trustedActionStore.revokeAll() }
    }

    /** Stores the key (encrypted). Blank input clears the stored key. */
    fun setApiKey(provider: LlmProvider, apiKey: String) {
        apiKeyRepository.setApiKey(provider, apiKey)
    }

    /** Web-search backend for `search_web` / `research_topic` (Phase 7). */
    fun setSearchBackend(backend: SearchBackend) =
        update { it.copy(searchBackend = backend) }

    /** Max search results per query (1–10). */
    fun setMaxSearchResults(maxResults: Int) =
        update { it.copy(maxSearchResults = maxResults.coerceIn(1, 10)) }

    /** Stores the Tavily search API key (encrypted). Blank input clears it. */
    fun setTavilyApiKey(apiKey: String) {
        apiKeyRepository.setTavilyApiKey(apiKey)
    }

    /** Deletes every stored secret and resets usage counters. */
    fun deleteAllSecrets() {
        apiKeyRepository.clearAllApiKeys()
        viewModelScope.launch { socialAccountRepository.clearAllSocialSecrets() }
    }

    // ── Delete all data (Phase 11) ────────────────────────────────────

    /** Whether the biometric / device-credential prompt can run on this device. */
    fun biometricAvailability(): BiometricAuth.Result = biometricAuth.availability(appContext)

    /**
     * Shows the system biometric / device-credential prompt for the
     * delete-all-data confirmation. [onResult] receives the outcome;
     * the caller wipes only on [BiometricAuth.Result.Success].
     */
    fun authenticateForDeleteAllData(
        activity: FragmentActivity,
        onResult: (BiometricAuth.Result) -> Unit,
    ) {
        biometricAuth.authenticate(
            activity = activity,
            title = "Delete all Jarvis data?",
            subtitle = "Confirm with your fingerprint, face, or device PIN — " +
                "this erases everything Jarvis stored and cannot be undone.",
            onResult = onResult,
        )
    }

    /** Resets the delete-all-data dialog state (after a failed wipe). */
    fun clearDeleteAllDataState() {
        _deleteAllDataState.value = DeleteAllDataState.Idle
    }

    /**
     * Deletes ALL of Jarvis's data — the database, every DataStore
     * file, all secrets, and Jarvis's files (see [DataWipeService])
     * — then restarts the app so every singleton rebuilds fresh.
     *
     * Runs on IO: the database wipe does file I/O. Before wiping, all
     * WorkManager work is cancelled (no reminder, digest, publish, or
     * backup job may fire against a wiped database) and the
     * foreground services are stopped. On success the app restarts
     * immediately, so there is no success state to show — a failure
     * leaves the app running with [DeleteAllDataState.Failed].
     */
    fun deleteAllData() {
        if (_deleteAllDataState.value is DeleteAllDataState.Wiping) return
        _deleteAllDataState.value = DeleteAllDataState.Wiping
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { WorkManager.getInstance(appContext).cancelAllWork() }
            stopForegroundServices()
            when (val result = dataWipeService.wipeAll()) {
                is JarvisResult.Success -> restartApp()
                is JarvisResult.Failure -> {
                    _deleteAllDataState.value = DeleteAllDataState.Failed(result.message)
                }
            }
        }
    }

    /** Stops the services that hold Jarvis state (wake word, bubble, focus timer). */
    private fun stopForegroundServices() {
        runCatching { appContext.stopService(Intent(appContext, WakeWordService::class.java)) }
        runCatching { appContext.stopService(Intent(appContext, BubbleService::class.java)) }
        runCatching { appContext.stopService(Intent(appContext, FocusSessionService::class.java)) }
    }

    /**
     * Restarts the app into a fresh process: the launch intent is
     * handed to the system first, then this process is killed — the
     * system starts the app again to serve the intent, with every
     * Hilt singleton, the Room database, and the DataStores rebuilt
     * from the wiped state.
     */
    private fun restartApp() {
        val intent = Intent(appContext, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        }
        runCatching { appContext.startActivity(intent) }
        Process.killProcess(Process.myPid())
    }

    // ── Productivity & wellness (Phase 9) ─────────────────────────────
    // Each of these re-syncs the periodic work so the digest and
    // proactive workers follow Settings immediately.

    /** Daily digest on/off (opt-in, off by default). */
    fun setDailyDigestEnabled(enabled: Boolean) =
        updateProactive { it.copy(dailyDigestEnabled = enabled) }

    /** Daily digest time (hour/minute, 24-hour). */
    fun setDailyDigestTime(hour: Int, minute: Int) = updateProactive {
        it.copy(
            dailyDigestHour = hour.coerceIn(0, 23),
            dailyDigestMinute = minute.coerceIn(0, 59),
        )
    }

    /** Overdue-task nudges on/off (on by default, but quiet by design). */
    fun setOverdueRemindersEnabled(enabled: Boolean) =
        updateProactive { it.copy(overdueRemindersEnabled = enabled) }

    /** Quiet hours start/end (minutes since midnight; equal = off). */
    fun setQuietHours(startMinute: Int, endMinute: Int) = updateProactive {
        it.copy(
            quietHoursStartMinute = startMinute.coerceIn(0, 1439),
            quietHoursEndMinute = endMinute.coerceIn(0, 1439),
        )
    }

    /** Break reminders on/off (opt-in, off by default). */
    fun setBreakRemindersEnabled(enabled: Boolean) =
        updateProactive { it.copy(breakRemindersEnabled = enabled) }

    /** Break-reminder interval in minutes of continuous screen time (15–240). */
    fun setBreakReminderIntervalMinutes(minutes: Int) = updateProactive {
        it.copy(breakReminderIntervalMinutes = minutes.coerceIn(15, 240))
    }

    /** Sleep wind-down on/off (opt-in, off by default). */
    fun setWindDownEnabled(enabled: Boolean) =
        updateProactive { it.copy(windDownEnabled = enabled) }

    /** Bedtime for the wind-down reminder (hour/minute, 24-hour). */
    fun setWindDownTime(hour: Int, minute: Int) = updateProactive {
        it.copy(
            windDownHour = hour.coerceIn(0, 23),
            windDownMinute = minute.coerceIn(0, 59),
        )
    }

    // ── Plugins, backup & insights (Phase 10) ─────────────────────────

    /**
     * Usage insights on/off (default ON — everything is local and
     * non-personal). Turning it off stops event recording
     * immediately; the screen offers to clear existing events.
     */
    fun setAnalyticsEnabled(enabled: Boolean) =
        update { it.copy(analyticsEnabled = enabled) }

    /** Wipes all recorded analytics events. */
    fun clearAnalyticsData() {
        viewModelScope.launch { analyticsRepository.clearAll() }
    }

    /** Automatic weekly backup on/off (opt-in, off by default). */
    fun setAutoBackupEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.updateSettings { it.copy(autoBackupEnabled = enabled) }
            backupScheduler.syncAutoBackup()
        }
    }

    private fun update(transform: (JarvisSettings) -> JarvisSettings) {
        viewModelScope.launch { settingsRepository.updateSettings(transform) }
    }

    /** Like [update], then re-syncs the Phase 9 periodic work. */
    private fun updateProactive(transform: (JarvisSettings) -> JarvisSettings) {
        viewModelScope.launch {
            settingsRepository.updateSettings(transform)
            wellnessScheduler.syncPeriodicWork()
        }
    }
}
