package com.zaid.jarvis.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zaid.jarvis.backup.AutoBackupFiles
import com.zaid.jarvis.core.backup.BackupFormat
import com.zaid.jarvis.viewmodel.BackupViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Backup screen (Phase 10): export and import Jarvis's data, and
 * the automatic local backups.
 *
 * Export writes one JSON file (you choose where) with settings,
 * tasks, notes, macros, drafts, research records, memory, scheduled
 * posts, focus history, trusted actions, and the audit log — never
 * API keys, OAuth tokens, client secrets, or the database
 * passphrase. Import validates the file (format version + SHA-256
 * checksum, 10 MB cap), shows a preview, and only writes after you
 * confirm. Import merges by id: rows that already exist are kept,
 * never overwritten.
 */
@Composable
fun BackupScreen(
    viewModel: BackupViewModel = hiltViewModel(),
) {
    val pendingImport by viewModel.pendingImport.collectAsState()
    val autoBackups by viewModel.autoBackups.collectAsState()
    val busy by viewModel.busy.collectAsState()
    val message by viewModel.message.collectAsState()

    var pendingExportJson by remember { mutableStateOf<String?>(null) }
    var deletingAutoBackup by remember { mutableStateOf<File?>(null) }

    val createDocumentLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri ->
        val json = pendingExportJson
        pendingExportJson = null
        if (uri != null && json != null) viewModel.writeExport(uri, json)
    }
    val openDocumentLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) viewModel.loadImport(uri)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Backup", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Export everything Jarvis knows — settings, tasks, notes, " +
                "macros, drafts, research, memory, scheduled posts, focus " +
                "history, trusted actions, and the audit log — as one JSON " +
                "file. API keys, OAuth tokens, and the database passphrase " +
                "are never included, so a backup file is safe to keep " +
                "wherever you like.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    viewModel.prepareExport { json ->
                        pendingExportJson = json
                        createDocumentLauncher.launch(
                            AutoBackupFiles.fileName(System.currentTimeMillis()),
                        )
                    }
                },
                enabled = !busy,
            ) { Text("Export backup") }
            OutlinedButton(
                onClick = { openDocumentLauncher.launch(arrayOf("application/json")) },
                enabled = !busy,
            ) { Text("Import backup") }
        }
        Text(
            "Importing merges by id: items already on this device are " +
                "kept, never overwritten. Scheduled posts come back as " +
                "cancelled — re-schedule them from Drafts if you still " +
                "want them published. Reminders on imported tasks are " +
                "re-scheduled automatically.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        if (message != null) {
            Text(
                message ?: "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
            )
        }

        Text("Automatic backups", style = MaterialTheme.typography.titleMedium)
        Text(
            "When automatic backup is on (Settings → Backup), Jarvis " +
                "writes a backup to its private storage every week and " +
                "keeps the newest ${AutoBackupFiles.MAX_FILES}. " +
                "Restoring one works exactly like importing a file.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (autoBackups.isEmpty()) {
            Text(
                "No automatic backups yet.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(autoBackups, key = { it.absolutePath }) { file ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Text(file.name, style = MaterialTheme.typography.titleSmall)
                        Text(
                            formatBackupDate(file.lastModified()) +
                                " · ${file.length() / 1024} KB",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(
                                onClick = { viewModel.loadAutoBackup(file) },
                                enabled = !busy,
                            ) { Text("Restore") }
                            TextButton(onClick = { deletingAutoBackup = file }) {
                                Text("Delete")
                            }
                        }
                    }
                }
            }
        }
    }

    // The import preview + Tier 2-style confirmation: nothing is
    // written until the user taps "Import" here.
    pendingImport?.let { pending ->
        AlertDialog(
            onDismissRequest = viewModel::cancelImport,
            title = { Text("Import backup?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "From ${pending.sourceLabel} — app version " +
                            "${pending.appVersion}, exported " +
                            formatBackupDate(pending.exportedAtMillis) +
                            " (format v${BackupFormat.CURRENT_FORMAT_VERSION}).",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    pending.preview.sections.forEach { section ->
                        Text(
                            "${section.section}: ${section.toImport} new, " +
                                "${section.skipped} already here (kept)",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                    if (pending.preview.trustedNew > 0 || pending.preview.trustedAlready > 0) {
                        Text(
                            "Trusted actions: ${pending.preview.trustedNew} new, " +
                                "${pending.preview.trustedAlready} already trusted",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                    Text(
                        "Your settings will be replaced with the backup's " +
                            "settings. Existing items are never overwritten.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            },
            confirmButton = {
                Button(onClick = viewModel::confirmImport, enabled = !busy) {
                    Text("Import")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = viewModel::cancelImport) { Text("Cancel") }
            },
        )
    }

    deletingAutoBackup?.let { file ->
        AlertDialog(
            onDismissRequest = { deletingAutoBackup = null },
            title = { Text("Delete automatic backup?") },
            text = { Text("“${file.name}” will be deleted. This cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteAutoBackup(file)
                        deletingAutoBackup = null
                    },
                ) { Text("Delete") }
            },
            dismissButton = {
                OutlinedButton(onClick = { deletingAutoBackup = null }) { Text("Cancel") }
            },
        )
    }
}

private fun formatBackupDate(millis: Long): String =
    SimpleDateFormat("MMM d, yyyy HH:mm", Locale.US).format(Date(millis))
