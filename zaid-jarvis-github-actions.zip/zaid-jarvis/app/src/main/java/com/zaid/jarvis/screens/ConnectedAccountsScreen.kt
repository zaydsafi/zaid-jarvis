package com.zaid.jarvis.screens

import android.app.Activity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zaid.jarvis.core.social.SocialAccount
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.viewmodel.SocialAccountsViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Connected accounts (Phase 8): one card per platform — connection
 * status, the connected handle, token expiry, OAuth client
 * credentials, and Connect / Disconnect.
 *
 * Setup (see PHASE8.md for the full step-by-step): create a developer
 * app on the platform, paste its client ID (and secret, where the
 * platform needs one) here, then tap Connect and sign in on the
 * platform's own page. Jarvis never sees your platform password —
 * sign-in happens in the browser, and only OAuth tokens come back.
 * Tokens are stored Keystore-encrypted and are never shown here.
 */
@Composable
fun ConnectedAccountsScreen(
    viewModel: SocialAccountsViewModel = hiltViewModel(),
) {
    val accounts by viewModel.accounts.collectAsState()
    val credentialsPresence by viewModel.credentialsPresence.collectAsState()
    val message by viewModel.message.collectAsState()
    val context = LocalContext.current

    // A connect flow that just finished in the browser may have left
    // an error (or a success) to show.
    LaunchedEffect(Unit) { viewModel.surfaceRedirectError() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Connected accounts", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Connect a social account to publish to it. Publishing only ever " +
                "happens after you approve the exact post on a card — connecting " +
                "an account grants nothing by itself.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        SocialPlatform.entries.forEach { platform ->
            val account = accounts.find { it.platform == platform }
            val hasCredentials = credentialsPresence[platform] == true
            PlatformAccountCard(
                platform = platform,
                account = account,
                hasCredentials = hasCredentials,
                onSaveCredentials = { clientId, clientSecret ->
                    viewModel.saveClientCredentials(platform, clientId, clientSecret)
                },
                onConnect = {
                    (context as? Activity)?.let { activity ->
                        viewModel.connect(platform, activity)
                    }
                },
                onDisconnect = { viewModel.disconnect(platform) },
            )
        }
    }

    message?.let {
        AlertDialog(
            onDismissRequest = viewModel::clearMessage,
            confirmButton = {
                TextButton(onClick = viewModel::clearMessage) { Text("OK") }
            },
            text = { Text(it) },
        )
    }
}

@Composable
private fun PlatformAccountCard(
    platform: SocialPlatform,
    account: SocialAccount?,
    hasCredentials: Boolean,
    onSaveCredentials: (clientId: String, clientSecret: String) -> Unit,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
) {
    var clientId by remember { mutableStateOf("") }
    var clientSecret by remember { mutableStateOf("") }
    var showCredentials by remember { mutableStateOf(false) }
    val connected = account != null

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(platform.displayName, style = MaterialTheme.typography.titleMedium)
            Text(
                platform.accountRequirement,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (connected) {
                Text(
                    "Connected as @${account.handle}" +
                        (account.displayName.takeIf { it != account.handle }
                            ?.let { " ($it)" } ?: ""),
                    style = MaterialTheme.typography.bodyMedium,
                )
                if (account.tokenExpiresAtMillis > 0) {
                    val expiry = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault())
                        .format(Date(account.tokenExpiresAtMillis))
                    Text(
                        "Token expires: $expiry (Jarvis refreshes it automatically; " +
                            "if a refresh fails you'll be asked to reconnect.)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                Text(
                    "Not connected.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (connected) {
                    OutlinedButton(onClick = onDisconnect) { Text("Disconnect") }
                } else {
                    Button(onClick = onConnect, enabled = hasCredentials) {
                        Text("Connect")
                    }
                    if (!hasCredentials) {
                        Text(
                            "Add your client ID below first.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 12.dp),
                        )
                    }
                }
                OutlinedButton(onClick = { showCredentials = !showCredentials }) {
                    Text(
                        if (hasCredentials) "Change credentials" else "Add credentials",
                    )
                }
            }
            if (showCredentials) {
                OutlinedTextField(
                    value = clientId,
                    onValueChange = { clientId = it },
                    label = { Text("Client ID") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = clientSecret,
                    onValueChange = { clientSecret = it },
                    label = {
                        Text(
                            "Client secret" +
                                if (platform == SocialPlatform.X) " (optional for X)" else "",
                        )
                    },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    "Stored Keystore-encrypted on this device. The redirect URI to " +
                        "register in the developer portal is " +
                        "com.zaid.jarvis://oauth2redirect — see PHASE8.md for the " +
                        "step-by-step setup for ${platform.displayName}.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Button(
                    onClick = {
                        onSaveCredentials(clientId, clientSecret)
                        clientId = ""
                        clientSecret = ""
                        showCredentials = false
                    },
                    enabled = clientId.isNotBlank(),
                ) {
                    Text("Save credentials")
                }
            }
        }
    }
}
