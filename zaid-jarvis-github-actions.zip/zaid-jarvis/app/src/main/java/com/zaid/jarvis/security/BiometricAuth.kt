package com.zaid.jarvis.security

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Biometric authentication for Tier 3 approvals (Master Prompt §6).
 *
 * Uses [BiometricManager.Authenticators.BIOMETRIC_STRONG] combined with
 * [BiometricManager.Authenticators.DEVICE_CREDENTIAL], so on devices
 * without enrolled biometrics the system falls back to the device PIN /
 * pattern / password. That is the documented graceful degradation:
 * - Biometric hardware + enrolled biometrics → fingerprint / face prompt.
 * - No biometrics enrolled, but a lock screen is set → PIN / pattern prompt.
 * - No lock screen at all, or no biometric hardware and no credential →
 *   [Result.Unavailable]; the Tier 3 action cannot proceed and Jarvis
 *   only assists (it never completes a sensitive action silently).
 *
 * Note: when DEVICE_CREDENTIAL is allowed, no negative button may be set
 * (the system provides its own cancel path) — that is why no
 * `setNegativeButtonText` call appears here.
 */
@Singleton
class BiometricAuth @Inject constructor() {

    sealed interface Result {
        data object Success : Result
        data class Failed(val message: String) : Result
        data class Unavailable(val message: String) : Result
    }

    private val authenticators: Int =
        BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL

    /** Whether a Tier 3 check can run at all on this device. */
    fun availability(context: Context): Result {
        return when (BiometricManager.from(context).canAuthenticate(authenticators)) {
            BiometricManager.BIOMETRIC_SUCCESS -> Result.Success
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE ->
                Result.Unavailable("This device has no biometric hardware and no lock screen is set.")
            BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE ->
                Result.Unavailable("Biometric hardware is temporarily unavailable.")
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED ->
                Result.Unavailable(
                    "No biometrics enrolled and no lock screen set. " +
                        "Set a PIN, pattern, or password (or enroll a fingerprint) to approve sensitive actions.",
                )
            BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED ->
                Result.Unavailable("A security update is required before biometrics can be used.")
            BiometricManager.BIOMETRIC_ERROR_UNSUPPORTED ->
                Result.Unavailable("Biometric authentication is not supported on this device.")
            BiometricManager.BIOMETRIC_STATUS_UNKNOWN ->
                Result.Unavailable("Biometric status is unknown on this device.")
            else -> Result.Unavailable("Biometric authentication is unavailable.")
        }
    }

    /** Shows the system biometric / device-credential prompt. */
    fun authenticate(
        activity: FragmentActivity,
        title: String,
        subtitle: String,
        onResult: (Result) -> Unit,
    ) {
        when (val available = availability(activity)) {
            is Result.Unavailable -> {
                onResult(available)
                return
            }
            else -> { /* Proceed to the prompt. */ }
        }

        val prompt = BiometricPrompt(
            activity,
            ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onResult(Result.Success)
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onResult(Result.Failed(errString.toString()))
                }

                override fun onAuthenticationFailed() {
                    // A single failed attempt (e.g. wrong finger); the
                    // prompt stays open, so this is not yet terminal.
                }
            },
        )

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setAllowedAuthenticators(authenticators)
            .build()

        prompt.authenticate(promptInfo)
    }
}
