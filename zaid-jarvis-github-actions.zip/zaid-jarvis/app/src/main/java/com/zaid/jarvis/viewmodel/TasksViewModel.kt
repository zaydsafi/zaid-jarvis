package com.zaid.jarvis.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zaid.jarvis.core.productivity.Task
import com.zaid.jarvis.core.productivity.TaskStatus
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.repository.TaskRepository
import com.zaid.jarvis.tools.productivity.ReminderScheduler
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Tasks screen state (Phase 9): the list, filters, and the editor.
 *
 * Saving / completing / deleting from the UI calls the repository
 * directly — the user is pressing the button themselves (same as
 * approving a draft in DraftsViewModel). The planner tools
 * (create_task etc.) are the gated path for chat/voice requests.
 * Setting a reminder goes through the [ReminderScheduler] so the
 * WorkManager job is enqueued with the reminder time.
 */
@HiltViewModel
class TasksViewModel @Inject constructor(
    private val taskRepository: TaskRepository,
    private val reminderScheduler: ReminderScheduler,
) : ViewModel() {

    /** Which tasks the list shows. */
    enum class TaskFilter {
        OPEN,
        DONE,
        OVERDUE,
        ALL,
    }

    private val _filter = MutableStateFlow(TaskFilter.OPEN)
    val filter: StateFlow<TaskFilter> = _filter.asStateFlow()

    /** Tasks matching the current filter, earliest due first (undated last). */
    val tasks: StateFlow<List<Task>> = combine(
        taskRepository.observeAll(),
        _filter,
    ) { all, filter ->
        val now = System.currentTimeMillis()
        val filtered = when (filter) {
            TaskFilter.OPEN -> all.filter { it.status == TaskStatus.OPEN }
            TaskFilter.DONE -> all.filter { it.status == TaskStatus.DONE }
            TaskFilter.OVERDUE -> all.filter { it.isOverdue(now) }
            TaskFilter.ALL -> all
        }
        filtered.sortedWith(
            compareBy<Task> { it.dueAtMillis ?: Long.MAX_VALUE }.thenBy { it.updatedAtMillis },
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Open-task count, for the filter chips. */
    val openCount: StateFlow<Int> = taskRepository.observeAll()
        .map { all -> all.count { it.status == TaskStatus.OPEN } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    /** The task open in the editor (null = new task / none loaded). */
    private val _selectedTask = MutableStateFlow<Task?>(null)
    val selectedTask: StateFlow<Task?> = _selectedTask.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)

    /** One-shot result message (save / reminder result, error). */
    val message: StateFlow<String?> = _message.asStateFlow()

    fun clearMessage() {
        _message.value = null
    }

    fun setFilter(filter: TaskFilter) {
        _filter.value = filter
    }

    /** Loads a task into the editor (id 0 = a new blank task). */
    fun loadTask(id: Long) {
        if (id == 0L) {
            _selectedTask.value = null
            return
        }
        viewModelScope.launch {
            _selectedTask.value = taskRepository.getById(id)
        }
    }

    /**
     * Saves the editor's task (new or existing) and reconciles its
     * reminder: a changed reminder is re-scheduled, a removed one is
     * cancelled, an unchanged one is left alone. [onSaved] receives
     * the row id.
     */
    fun saveTask(task: Task, onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val previous = if (task.id != 0L) taskRepository.getById(task.id) else null
            when (val result = taskRepository.save(task)) {
                is JarvisResult.Success -> {
                    val oldReminder = previous?.reminderAtMillis
                    val newReminder = task.reminderAtMillis
                    when {
                        newReminder != null && newReminder != oldReminder -> {
                            when (val scheduled = reminderScheduler.schedule(result.value, newReminder)) {
                                is JarvisResult.Success -> Unit
                                is JarvisResult.Failure -> _message.value = scheduled.message
                            }
                        }
                        newReminder == null && oldReminder != null -> {
                            reminderScheduler.cancel(result.value)
                        }
                    }
                    _selectedTask.value = taskRepository.getById(result.value)
                    onSaved(result.value)
                }
                is JarvisResult.Failure -> _message.value = result.message
            }
        }
    }

    /** Marks a task done. */
    fun completeTask(id: Long) {
        viewModelScope.launch {
            when (val result = taskRepository.complete(id)) {
                is JarvisResult.Success -> Unit
                is JarvisResult.Failure -> _message.value = result.message
            }
        }
    }

    /** Deletes a task (cancelling its reminder first, if any). */
    fun deleteTask(id: Long) {
        viewModelScope.launch {
            val task = taskRepository.getById(id)
            if (task?.reminderAtMillis != null) {
                reminderScheduler.cancel(id)
            }
            taskRepository.deleteById(id)
        }
    }

    /** Sets a reminder on a task (must be in the future). */
    fun setReminder(id: Long, reminderAtMillis: Long) {
        viewModelScope.launch {
            when (val result = reminderScheduler.schedule(id, reminderAtMillis)) {
                is JarvisResult.Success -> {
                    _selectedTask.value = result.value
                    _message.value = "Reminder set."
                }
                is JarvisResult.Failure -> _message.value = result.message
            }
        }
    }

    /** Cancels a task's reminder. */
    fun clearReminder(id: Long) {
        viewModelScope.launch {
            when (val result = reminderScheduler.cancel(id)) {
                is JarvisResult.Success -> {
                    _selectedTask.value = taskRepository.getById(id)
                }
                is JarvisResult.Failure -> _message.value = result.message
            }
        }
    }
}
