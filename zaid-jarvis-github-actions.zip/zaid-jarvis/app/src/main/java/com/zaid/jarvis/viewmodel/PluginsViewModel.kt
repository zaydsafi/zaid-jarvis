package com.zaid.jarvis.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.plugins.JarvisPlugin
import com.zaid.jarvis.plugins.PluginRegistry
import com.zaid.jarvis.plugins.PluginState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Plugins screen state (Phase 10): the installed plugins, their
 * enable/disable toggles, and their per-plugin trust state.
 *
 * Trust is opt-in per plugin and defaults to off: a trusted plugin's
 * Tier 0/1 tools may auto-allow like built-in tools; an untrusted
 * plugin's tools always ask. Disabling a plugin unregisters its
 * tools from the planner immediately.
 */
@HiltViewModel
class PluginsViewModel @Inject constructor(
    private val pluginRegistry: PluginRegistry,
) : ViewModel() {

    /** One row in the Plugins screen: the plugin + its current state. */
    data class PluginRow(
        val plugin: JarvisPlugin,
        val state: PluginState,
        /** True when one of this plugin's tools collided with a built-in and was skipped. */
        val hasSkippedTools: Boolean,
    )

    val plugins: StateFlow<List<PluginRow>> = combine(
        pluginRegistry.observeStates(),
        pluginRegistry.skippedToolNames,
    ) { states, skipped ->
        pluginRegistry.installed().map { plugin ->
            PluginRow(
                plugin = plugin,
                state = states[plugin.id] ?: PluginState(),
                hasSkippedTools = plugin.tools().any { it.name in skipped },
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _message = MutableStateFlow<String?>(null)

    /** One-shot result message (error only — toggles are quiet). */
    val message: StateFlow<String?> = _message.asStateFlow()

    fun clearMessage() {
        _message.value = null
    }

    /** Enables or disables a plugin (disabling unregisters its tools immediately). */
    fun setEnabled(pluginId: String, enabled: Boolean) {
        viewModelScope.launch {
            when (val result = pluginRegistry.setEnabled(pluginId, enabled)) {
                is JarvisResult.Success -> Unit
                is JarvisResult.Failure -> _message.value = result.message
            }
        }
    }

    /**
     * Enables or disables trust for a plugin (its Tier 0/1 tools may
     * auto-allow only when trusted — default: not trusted).
     */
    fun setTrusted(pluginId: String, trusted: Boolean) {
        viewModelScope.launch {
            when (val result = pluginRegistry.setTrusted(pluginId, trusted)) {
                is JarvisResult.Success -> Unit
                is JarvisResult.Failure -> _message.value = result.message
            }
        }
    }
}
