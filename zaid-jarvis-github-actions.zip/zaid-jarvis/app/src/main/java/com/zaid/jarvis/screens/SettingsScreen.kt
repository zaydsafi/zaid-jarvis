package com.zaid.jarvis.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuAnchorType
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.zaid.jarvis.components.TimePickerDialog
import com.zaid.jarvis.core.model.AppLanguage
import com.zaid.jarvis.core.model.CustomProviderConfig
import com.zaid.jarvis.core.model.LlmModel
import com.zaid.jarvis.core.model.LlmProvider
import com.zaid.jarvis.core.model.Personality
import com.zaid.jarvis.core.model.ThemeMode
import com.zaid.jarvis.core.productivity.QuietHours
import com.zaid.jarvis.core.research.SearchBackend
import com.zaid.jarvis.overlay.OverlayPermission
import com.zaid.jarvis.permissions.PermissionHelper
import com.zaid.jarvis.security.BiometricAuth
import com.zaid.jarvis.viewmodel.SettingsViewModel

/**
 * Settings (Master Prompt §3, §5.1): theme, language, voice, personality,
 * LLM provider + model (Claude, OpenAI, Gemini, OpenRouter, custom
 * providers), API keys (masked, Keystore-encrypted), custom providers,
 * and the token/cost counter (real usage reporting since Phase 3).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = hiltViewModel(),
    onNavigateToAuditLog: () -> Unit = {},
    onNavigateToMemory: () -> Unit = {},
    onNavigateToMacros: () -> Unit = {},
    onNavigateToResearch: () -> Unit = {},
    onNavigateToDrafts: () -> Unit = {},
    onNavigateToConnectedAccounts: () -> Unit = {},
    onNavigateToScheduledPosts: () -> Unit = {},
    onNavigateToTasks: () -> Unit = {},
    onNavigateToWellness: () -> Unit = {},
    onNavigateToPlugins: () -> Unit = {},
    onNavigateToNotes: () -> Unit = {},
    onNavigateToBackup: () -> Unit = {},
    onNavigateToInsights: () -> Unit = {},
) {
    val settings by viewModel.settings.collectAsState()
    val keyPresence by viewModel.apiKeyPresence.collectAsState()
    val customKeyPresence by viewModel.customKeyPresence.collectAsState()
    val tavilyKeyPresence by viewModel.tavilyKeyPresence.collectAsState()
    val trustedActions by viewModel.trustedActions.collectAsState()
    val accessibilityConnected by viewModel.accessibilityConnected.collectAsState()
    val macroCount by viewModel.macroCount.collectAsState()
    val deleteAllDataState by viewModel.deleteAllDataState.collectAsState()
    val context = LocalContext.current

    // Mic permission for the wake word: asked only when Zaid turns it on.
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) viewModel.setWakeWordEnabled(true)
    }
    // Generic permission launcher for the App permissions section (Phase 5).
    // The rows re-read their grant status on resume (see the observer below).
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { /* status refreshes on resume */ }
    // Generic launcher for system settings screens (special accesses).
    val settingsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
    ) { /* status refreshes on resume */ }
    // Overlay permission is granted in system settings; refresh the
    // toggle state when returning to this screen.
    var canDrawOverlay by remember {
        mutableStateOf(OverlayPermission.canDrawOverlays(context))
    }
    val overlayPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
    ) {
        canDrawOverlay = OverlayPermission.canDrawOverlays(context)
    }
    val lifecycleOwner = LocalLifecycleOwner.current
    // Bump this on resume so the permission rows re-read their status.
    var permissionRefreshTick by remember { mutableStateOf(0) }
    // Time pickers for the Productivity & wellness section (Phase 9).
    var showDigestTimePicker by remember { mutableStateOf(false) }
    // Offered when usage insights are turned off (Phase 10): clear the
    // events recorded so far, or keep them.
    var showClearAnalyticsDialog by remember { mutableStateOf(false) }
    // Delete-all-data confirmation (Phase 11, Danger zone).
    var showDeleteAllDataDialog by remember { mutableStateOf(false) }
    var showQuietStartPicker by remember { mutableStateOf(false) }
    var showQuietEndPicker by remember { mutableStateOf(false) }
    var showBedtimePicker by remember { mutableStateOf(false) }
    // Accessibility service status (Phase 6): the user enables it in
    // system Settings, so re-read it every time this screen resumes.
    var accessibilityServiceEnabled by remember {
        mutableStateOf(viewModel.isAccessibilityServiceEnabled())
    }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                canDrawOverlay = OverlayPermission.canDrawOverlays(context)
                accessibilityServiceEnabled = viewModel.isAccessibilityServiceEnabled()
                permissionRefreshTick++
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)

        // ── Appearance ──────────────────────────────────────────────────
        SettingsSection("Appearance") {
            EnumDropdown(
                label = "Theme",
                options = ThemeMode.entries,
                selected = settings.themeMode,
                displayName = { it.displayName },
                onSelect = viewModel::setTheme,
            )
            EnumDropdown(
                label = "Language",
                options = AppLanguage.entries,
                selected = settings.language,
                displayName = { it.displayName },
                onSelect = viewModel::setLanguage,
            )
        }

        // ── Voice & personality ─────────────────────────────────────────
        SettingsSection("Voice & personality") {
            EnumDropdown(
                label = "Personality",
                options = Personality.entries,
                selected = settings.personality,
                displayName = { it.displayName },
                onSelect = viewModel::setPersonality,
            )
            Text("Voice speed: ${"%.1f".format(settings.voiceSpeed)}x")
            Slider(
                value = settings.voiceSpeed,
                onValueChange = viewModel::setVoiceSpeed,
                valueRange = 0.5f..2.0f,
                steps = 5,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "Speak answers aloud after voice requests",
                    modifier = Modifier.weight(1f),
                )
                Switch(
                    checked = settings.voiceRepliesEnabled,
                    onCheckedChange = viewModel::setVoiceRepliesEnabled,
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "Wake word — “Hey Jarvis”",
                    modifier = Modifier.weight(1f),
                )
                Switch(
                    checked = settings.wakeWordEnabled,
                    onCheckedChange = { enabled ->
                        if (!enabled) {
                            viewModel.setWakeWordEnabled(false)
                        } else if (ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO,
                            ) == PackageManager.PERMISSION_GRANTED
                        ) {
                            viewModel.setWakeWordEnabled(true)
                        } else {
                            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                )
            }
            Text(
                "Listens for “Hey Jarvis” in the background and opens Chat. " +
                    "Uses the microphone continuously and more battery — this is " +
                    "the platform recognizer in a loop, not a true always-on hotword.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "Floating bubble",
                    modifier = Modifier.weight(1f),
                )
                Switch(
                    checked = settings.floatingBubbleEnabled,
                    onCheckedChange = viewModel::setFloatingBubbleEnabled,
                    enabled = canDrawOverlay,
                )
            }
            if (!canDrawOverlay) {
                Text(
                    "The bubble needs “Display over other apps” permission, " +
                        "granted in Android Settings.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedButton(
                    onClick = {
                        overlayPermissionLauncher.launch(
                            OverlayPermission.manageOverlayIntent(context),
                        )
                    },
                ) {
                    Text("Grant “Display over other apps”")
                }
            } else {
                Text(
                    "A floating orb over other apps — tap to chat, drag to move, " +
                        "long-press to dismiss.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        // ── Automation (Phase 6) ──────────────────────────────────────
        SettingsSection("Automation") {
            Text(
                "Let Jarvis see the screen and tap, type, and scroll in other apps — " +
                    "every action still needs your approval first. Jarvis never reads " +
                    "passwords, never acts on screens with password fields, and never " +
                    "automates banking or payment apps.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "Accessibility service: " + when {
                    accessibilityConnected -> "Connected"
                    accessibilityServiceEnabled -> "Enabled (connecting…)"
                    else -> "Not enabled"
                },
                style = MaterialTheme.typography.bodyMedium,
            )
            if (!accessibilityServiceEnabled) {
                Text(
                    "Turn on “Zaid Jarvis automation” in Android Settings → Accessibility. " +
                        "Jarvis cannot enable it itself — Android requires you to do it by hand.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedButton(
                    onClick = {
                        settingsLauncher.launch(
                            com.zaid.jarvis.accessibility.AccessibilityState
                                .openAccessibilitySettingsIntent(),
                        )
                    },
                ) {
                    Text("Open Accessibility settings")
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "Automation tools",
                    modifier = Modifier.weight(1f),
                )
                Switch(
                    checked = settings.automationEnabled,
                    onCheckedChange = viewModel::setAutomationEnabled,
                    enabled = accessibilityServiceEnabled,
                )
            }
            Text(
                "Off by default. When on, Jarvis can find things on screen, tap, type, " +
                    "scroll, and run your saved macros — always with your approval first.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "Saved macros: $macroCount",
                style = MaterialTheme.typography.bodyMedium,
            )
            OutlinedButton(onClick = onNavigateToMacros) {
                Text("View macros")
            }
        }

        // ── Research (Phase 7) ────────────────────────────────────────
        SettingsSection("Research") {
            Text(
                "How Jarvis searches the web for `search_web` and `research_topic`. " +
                    "Web content is treated as untrusted data: pages with instruction-like " +
                    "text are excluded from research briefs, and every claim in a brief " +
                    "cites its source.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            EnumDropdown(
                label = "Search backend",
                options = SearchBackend.entries,
                selected = settings.searchBackend,
                displayName = { it.displayName },
                onSelect = viewModel::setSearchBackend,
            )
            if (settings.searchBackend == SearchBackend.TAVILY) {
                Text(
                    "Tavily is a research search API (tavily.com — free tier available). " +
                        "Get a key at app.tavily.com and paste it below.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                GenericApiKeyField(
                    label = "Tavily",
                    hasKey = tavilyKeyPresence,
                    onSave = viewModel::setTavilyApiKey,
                )
            } else {
                Text(
                    "DuckDuckGo is free and needs no key. Search quality depends on " +
                        "DuckDuckGo — if results look thin, try Tavily.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text("Max search results per query: ${settings.maxSearchResults}")
            Slider(
                value = settings.maxSearchResults.toFloat(),
                onValueChange = { viewModel.setMaxSearchResults(it.toInt()) },
                valueRange = 1f..10f,
                steps = 8,
            )
            OutlinedButton(onClick = onNavigateToResearch) {
                Text("View research history")
            }
            OutlinedButton(onClick = onNavigateToDrafts) {
                Text("View drafts")
            }
        }

        // ── Social publishing (Phase 8) ───────────────────────────────
        SettingsSection("Social publishing") {
            Text(
                "Publish APPROVED drafts to X, Threads, LinkedIn, and Instagram " +
                    "through their official APIs. Connecting an account grants " +
                    "nothing by itself — every publish or schedule shows the exact " +
                    "text on an approval card first.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedButton(onClick = onNavigateToConnectedAccounts) {
                Text("Connected accounts")
            }
            OutlinedButton(onClick = onNavigateToScheduledPosts) {
                Text("Scheduled posts")
            }
        }

        // ── Productivity & wellness (Phase 9) ─────────────────────────
        SettingsSection("Productivity & wellness") {
            Text(
                "Tasks, reminders, and gentle nudges — never nagging. Every proactive " +
                    "feature is off by default or quiet by default, and quiet hours " +
                    "silence them all (except your own reminders and publish results).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Daily digest", modifier = Modifier.weight(1f))
                Switch(
                    checked = settings.dailyDigestEnabled,
                    onCheckedChange = viewModel::setDailyDigestEnabled,
                )
            }
            Text(
                "A morning briefing notification — today's events, tasks due today, " +
                    "and overdue tasks. Off by default.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "Digest time: ${formatTimeOfDay(settings.dailyDigestHour, settings.dailyDigestMinute)}",
                    style = MaterialTheme.typography.bodyMedium,
                )
                OutlinedButton(onClick = { showDigestTimePicker = true }) { Text("Change") }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Overdue task reminders", modifier = Modifier.weight(1f))
                Switch(
                    checked = settings.overdueRemindersEnabled,
                    onCheckedChange = viewModel::setOverdueRemindersEnabled,
                )
            }
            Text(
                "One gentle nudge per overdue task per day — never repeated.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "Quiet hours: ${
                    QuietHours(
                        settings.quietHoursStartMinute,
                        settings.quietHoursEndMinute,
                    ).displayLabel()
                }",
                style = MaterialTheme.typography.bodyMedium,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { showQuietStartPicker = true }) {
                    Text(
                        "Start ${formatTimeOfDay(
                            settings.quietHoursStartMinute / 60,
                            settings.quietHoursStartMinute % 60,
                        )}",
                    )
                }
                OutlinedButton(onClick = { showQuietEndPicker = true }) {
                    Text(
                        "End ${formatTimeOfDay(
                            settings.quietHoursEndMinute / 60,
                            settings.quietHoursEndMinute % 60,
                        )}",
                    )
                }
            }
            Text(
                "Set start and end to the same time to turn quiet hours off.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Break reminders", modifier = Modifier.weight(1f))
                Switch(
                    checked = settings.breakRemindersEnabled,
                    onCheckedChange = viewModel::setBreakRemindersEnabled,
                )
            }
            Text(
                "After ${settings.breakReminderIntervalMinutes} minutes of continuous screen " +
                    "time — at most once an hour, never during quiet hours or focus.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(30, 60, 90, 120).forEach { minutes ->
                    FilterChip(
                        selected = settings.breakReminderIntervalMinutes == minutes,
                        onClick = { viewModel.setBreakReminderIntervalMinutes(minutes) },
                        label = { Text("$minutes min") },
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Sleep wind-down", modifier = Modifier.weight(1f))
                Switch(
                    checked = settings.windDownEnabled,
                    onCheckedChange = viewModel::setWindDownEnabled,
                )
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "Bedtime: ${formatTimeOfDay(settings.windDownHour, settings.windDownMinute)}",
                    style = MaterialTheme.typography.bodyMedium,
                )
                OutlinedButton(onClick = { showBedtimePicker = true }) { Text("Change") }
            }
            Text(
                "At bedtime Jarvis suggests winding down and offers to turn on Do Not " +
                    "Disturb and dim the screen — only after you approve.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            PermissionRow(
                displayName = "Usage access",
                rationale = "Read today's screen time and top apps (on-device only).",
                granted = PermissionHelper.hasUsageAccess(context),
                onGrant = {
                    settingsLauncher.launch(PermissionHelper.usageAccessSettingsIntent())
                },
            )
            PermissionRow(
                displayName = "Calendar",
                rationale = "Read today's schedule (read-only — Jarvis never creates or changes events).",
                granted = PermissionHelper.isGranted(context, Manifest.permission.READ_CALENDAR),
                onGrant = { permissionLauncher.launch(Manifest.permission.READ_CALENDAR) },
            )
            OutlinedButton(onClick = onNavigateToTasks) {
                Text("View tasks")
            }
            OutlinedButton(onClick = onNavigateToWellness) {
                Text("View wellness")
            }
        }

        // ── Plugins, backup & insights (Phase 10) ─────────────────────────
        SettingsSection("Plugins, backup & insights") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Usage insights", modifier = Modifier.weight(1f))
                Switch(
                    checked = settings.analyticsEnabled,
                    onCheckedChange = { enabled ->
                        viewModel.setAnalyticsEnabled(enabled)
                        if (!enabled) showClearAnalyticsDialog = true
                    },
                )
            }
            Text(
                "Local usage stats for the Insights screen — which tools " +
                    "ran, publish results, focus time. Everything stays on " +
                    "this phone; no message text, note text, or searches are " +
                    "ever recorded. Turning it off stops recording at once.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Automatic backup", modifier = Modifier.weight(1f))
                Switch(
                    checked = settings.autoBackupEnabled,
                    onCheckedChange = viewModel::setAutoBackupEnabled,
                )
            }
            Text(
                "A weekly backup to Jarvis's private storage (the newest " +
                    "3 are kept). Restorable from the Backup screen. " +
                    "Off by default.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedButton(onClick = onNavigateToPlugins) {
                Text("Plugins")
            }
            OutlinedButton(onClick = onNavigateToNotes) {
                Text("Notes")
            }
            OutlinedButton(onClick = onNavigateToBackup) {
                Text("Backup")
            }
            OutlinedButton(onClick = onNavigateToInsights) {
                Text("Insights")
            }
        }

        // ── AI provider ─────────────────────────────────────────────────
        SettingsSection("AI provider") {
            EnumDropdown(
                label = "Provider",
                options = LlmProvider.entries,
                selected = settings.llmProvider,
                displayName = { it.displayName },
                onSelect = viewModel::setProvider,
            )
            EnumDropdown(
                label = "Model",
                options = LlmModel.forProvider(settings.llmProvider),
                selected = settings.llmModel,
                displayName = { it.displayName },
                onSelect = viewModel::setModel,
            )
            if (settings.llmProvider == LlmProvider.OPENROUTER) {
                var customModel by remember(settings.customModelId) {
                    mutableStateOf(settings.customModelId)
                }
                OutlinedTextField(
                    value = customModel,
                    onValueChange = {
                        customModel = it
                        viewModel.setCustomModelId(it)
                    },
                    label = { Text("OpenRouter model ID (optional)") },
                    placeholder = { Text("e.g. anthropic/claude-opus-4.5") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    "Leave blank to use the preset above. Any OpenRouter model ID works.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (settings.llmProvider == LlmProvider.CUSTOM) {
                val providers = settings.customProviders
                if (providers.isEmpty()) {
                    Text(
                        "No custom providers yet — add one in the Custom providers section below.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    var expanded by remember { mutableStateOf(false) }
                    val selected = settings.selectedCustomProvider()
                        ?: providers.first()
                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = it },
                    ) {
                        OutlinedTextField(
                            value = selected.name,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Custom provider") },
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                            },
                            modifier = Modifier
                                .menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable, enabled = true)
                                .fillMaxWidth(),
                        )
                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false },
                        ) {
                            providers.forEach { provider ->
                                DropdownMenuItem(
                                    text = { Text(provider.name) },
                                    onClick = {
                                        viewModel.setSelectedCustomProvider(provider.id)
                                        expanded = false
                                    },
                                )
                            }
                        }
                    }
                    Text(
                        "Model: ${selected.modelId}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "Use cheap model for simple intents",
                    modifier = Modifier.weight(1f),
                )
                Switch(
                    checked = settings.useCheapModelForSimpleIntents,
                    onCheckedChange = viewModel::setUseCheapModel,
                )
            }
        }

        // ── API keys ────────────────────────────────────────────────────
        SettingsSection("API keys") {
            Text(
                "Keys are stored encrypted in the Android Keystore and never leave " +
                    "this device except in requests to the provider you choose.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            LlmProvider.entries
                .filter { it != LlmProvider.CUSTOM }
                .forEach { provider ->
                    ApiKeyField(
                        provider = provider,
                        hasKey = keyPresence[provider] == true,
                        onSave = { viewModel.setApiKey(provider, it) },
                    )
                }
            OutlinedButton(onClick = viewModel::deleteAllSecrets) {
                Text("Delete all stored keys")
            }
        }

        // ── Custom providers (Phase 3) ──────────────────────────────────
        SettingsSection("Custom providers") {
            Text(
                "Any OpenAI-compatible API: a local server (Ollama, llama.cpp, vLLM), " +
                    "another vendor, or a corporate proxy. The server must speak the " +
                    "OpenAI Chat Completions API at [base URL]/chat/completions.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            settings.customProviders.forEach { provider ->
                CustomProviderCard(
                    provider = provider,
                    hasKey = customKeyPresence.contains(provider.id),
                    onSaveKey = { viewModel.setCustomApiKey(provider.id, it) },
                    onSave = viewModel::updateCustomProvider,
                    onDelete = { viewModel.deleteCustomProvider(provider.id) },
                )
            }
            AddCustomProviderForm(onAdd = viewModel::addCustomProvider)
        }

        // ── Permissions & trust (Phase 2) ───────────────────────────────
        SettingsSection("Permissions & trust") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "Always ask, even for read-only actions",
                    modifier = Modifier.weight(1f),
                )
                Switch(
                    checked = settings.alwaysAskReadOnly,
                    onCheckedChange = viewModel::setAlwaysAskReadOnly,
                )
            }
            Text(
                "Read-only actions (time, weather, search) normally ask once per session. " +
                    "Turn this on to be asked every time.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "Trusted actions",
                style = MaterialTheme.typography.titleSmall,
            )
            if (trustedActions.isEmpty()) {
                Text(
                    "No trusted actions. You can mark a low-risk action as trusted from its " +
                        "approval card; tiers 2–3 can never be trusted.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                trustedActions.sorted().forEach { toolName ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(toolName, modifier = Modifier.weight(1f))
                        OutlinedButton(onClick = { viewModel.revokeTrusted(toolName) }) {
                            Text("Revoke")
                        }
                    }
                }
                OutlinedButton(onClick = viewModel::revokeAllTrusted) {
                    Text("Revoke all")
                }
            }
            OutlinedButton(onClick = onNavigateToAuditLog) {
                Text("View audit log")
            }
            OutlinedButton(onClick = onNavigateToMemory) {
                Text("View memory")
            }
        }

        // ── App permissions (Phase 5) ───────────────────────────────────
        // key() forces the section to re-read grant status on resume.
        key(permissionRefreshTick) {
            SettingsSection("App permissions") {
            Text(
                "Jarvis asks for each permission only when its feature is first used. " +
                    "Grant them here any time — or wait until a tool asks for one.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            PermissionHelper.TOOL_PERMISSIONS.forEach { toolPermission ->
                PermissionRow(
                    displayName = toolPermission.displayName,
                    rationale = toolPermission.rationale,
                    granted = PermissionHelper.isGranted(context, toolPermission.permission),
                    onGrant = { permissionLauncher.launch(toolPermission.permission) },
                )
            }
            PermissionRow(
                displayName = "Modify system settings",
                rationale = "Change the screen brightness.",
                granted = PermissionHelper.canWriteSettings(context),
                onGrant = { settingsLauncher.launch(PermissionHelper.writeSettingsIntent(context)) },
            )
            PermissionRow(
                displayName = "Do Not Disturb access",
                rationale = "Change Do Not Disturb mode.",
                granted = PermissionHelper.hasDndAccess(context),
                onGrant = { settingsLauncher.launch(PermissionHelper.dndAccessIntent(context)) },
            )
            PermissionRow(
                displayName = "Display over other apps",
                rationale = "Show the floating bubble.",
                granted = canDrawOverlay,
                onGrant = { overlayPermissionLauncher.launch(OverlayPermission.manageOverlayIntent(context)) },
            )
            }
        }

        // ── Usage (real reporting since Phase 3) ────────────────────────
        SettingsSection("Usage") {
            Text("Tokens used: ${settings.totalTokensUsed}")
            Text("Estimated cost: $${"%.4f".format(settings.estimatedCostUsd)}")
            Text(
                "Cost is an estimate from approximate per-model rates — not a bill. " +
                    "Unknown and custom models use a fallback rate.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        // ── Danger zone (Phase 11) ────────────────────────────────────
        SettingsSection("Danger zone") {
            Text(
                "Delete all data erases everything Jarvis stored on this phone — " +
                    "tasks, notes, macros, drafts, research, memory, scheduled posts, " +
                    "focus history, the audit log, usage insights, settings, trusted " +
                    "actions, connected accounts, API keys, and the automatic backups. " +
                    "It cannot be undone. Export a backup first if you want to keep anything.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
            )
            Button(
                onClick = { showDeleteAllDataDialog = true },
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                ),
            ) {
                Text("Delete all data")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }

    // Time pickers (Phase 9).
    if (showDigestTimePicker) {
        TimePickerDialog(
            title = "Digest time",
            initialHour = settings.dailyDigestHour,
            initialMinute = settings.dailyDigestMinute,
            onDismiss = { showDigestTimePicker = false },
            onTimeSelected = { hour, minute ->
                viewModel.setDailyDigestTime(hour, minute)
                showDigestTimePicker = false
            },
        )
    }
    if (showQuietStartPicker) {
        TimePickerDialog(
            title = "Quiet hours start",
            initialHour = settings.quietHoursStartMinute / 60,
            initialMinute = settings.quietHoursStartMinute % 60,
            onDismiss = { showQuietStartPicker = false },
            onTimeSelected = { hour, minute ->
                viewModel.setQuietHours(hour * 60 + minute, settings.quietHoursEndMinute)
                showQuietStartPicker = false
            },
        )
    }
    if (showQuietEndPicker) {
        TimePickerDialog(
            title = "Quiet hours end",
            initialHour = settings.quietHoursEndMinute / 60,
            initialMinute = settings.quietHoursEndMinute % 60,
            onDismiss = { showQuietEndPicker = false },
            onTimeSelected = { hour, minute ->
                viewModel.setQuietHours(settings.quietHoursStartMinute, hour * 60 + minute)
                showQuietEndPicker = false
            },
        )
    }
    if (showBedtimePicker) {
        TimePickerDialog(
            title = "Bedtime",
            initialHour = settings.windDownHour,
            initialMinute = settings.windDownMinute,
            onDismiss = { showBedtimePicker = false },
            onTimeSelected = { hour, minute ->
                viewModel.setWindDownTime(hour, minute)
                showBedtimePicker = false
            },
        )
    }

    // Offered when usage insights are turned off (Phase 10).
    if (showClearAnalyticsDialog) {
        AlertDialog(
            onDismissRequest = { showClearAnalyticsDialog = false },
            title = { Text("Clear recorded insights?") },
            text = {
                Text(
                    "Usage insights are off — nothing new will be recorded. " +
                        "The usage events recorded so far are still on this " +
                        "phone. Clear them now, or keep them for the Insights " +
                        "screen?",
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAnalyticsData()
                        showClearAnalyticsDialog = false
                    },
                ) { Text("Clear data") }
            },
            dismissButton = {
                OutlinedButton(onClick = { showClearAnalyticsDialog = false }) {
                    Text("Keep data")
                }
            },
        )
    }

    // Delete-all-data confirmation (Phase 11, Danger zone).
    if (showDeleteAllDataDialog) {
        DeleteAllDataDialog(
            viewModel = viewModel,
            state = deleteAllDataState,
            onDismiss = {
                showDeleteAllDataDialog = false
                viewModel.clearDeleteAllDataState()
            },
        )
    }
}

private fun formatTimeOfDay(hour: Int, minute: Int): String =
    "%02d:%02d".format(hour, minute)

/** What the user must type to confirm delete-all-data when biometrics are unavailable. */
private const val DELETE_CONFIRMATION_TEXT: String = "DELETE"

/**
 * Delete-all-data confirmation (Phase 11, Danger zone): a Tier 2-style
 * dialog that shows exactly what will be erased, then requires a second
 * factor before anything is deleted —
 * - biometrics (or the device PIN / pattern / password) when the device
 *   supports them, via the same [BiometricAuth] as Tier 3 approvals;
 * - typing DELETE when biometrics are unavailable (no lock screen set,
 *   no biometric hardware).
 *
 * On success the app restarts immediately, so this dialog never shows
 * a success state — only the wiping state and a failure message.
 */
@Composable
private fun DeleteAllDataDialog(
    viewModel: SettingsViewModel,
    state: SettingsViewModel.DeleteAllDataState,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val activity = context as? FragmentActivity
    // Checked once per dialog open: whether the biometric / credential prompt can run.
    val biometricAvailable = remember {
        activity != null &&
            viewModel.biometricAvailability() is BiometricAuth.Result.Success
    }
    var typedConfirmation by remember { mutableStateOf("") }
    var biometricMessage by remember { mutableStateOf<String?>(null) }
    val wiping = state is SettingsViewModel.DeleteAllDataState.Wiping
    val failureMessage = (state as? SettingsViewModel.DeleteAllDataState.Failed)?.message

    AlertDialog(
        onDismissRequest = { if (!wiping) onDismiss() },
        title = { Text("Delete all data?") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "This erases everything Jarvis stored on this phone: tasks, notes, " +
                        "macros, drafts, research, memory, scheduled posts, focus history, " +
                        "the audit log, usage insights, settings, trusted actions, connected " +
                        "accounts, API keys, and the automatic backups. It cannot be undone. " +
                        "Export a backup first (Settings → Backup) if you want to keep anything.",
                )
                if (failureMessage != null) {
                    Text(
                        failureMessage,
                        color = MaterialTheme.colorScheme.error,
                    )
                } else if (wiping) {
                    Text("Deleting… The app will restart when it is done.")
                } else if (biometricAvailable) {
                    Text(
                        "Confirm with your fingerprint, face, or device PIN to delete everything.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    biometricMessage?.let { message ->
                        Text(message, color = MaterialTheme.colorScheme.error)
                    }
                } else {
                    Text(
                        "This device has no biometric or lock-screen check available, " +
                            "so type DELETE below to confirm.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    OutlinedTextField(
                        value = typedConfirmation,
                        onValueChange = { typedConfirmation = it },
                        label = { Text("Type DELETE to confirm") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        },
        confirmButton = {
            if (failureMessage != null) {
                Button(onClick = onDismiss) { Text("Close") }
            } else if (wiping) {
                Button(onClick = {}, enabled = false) { Text("Deleting…") }
            } else if (biometricAvailable) {
                Button(
                    onClick = {
                        val currentActivity = activity ?: return@Button
                        viewModel.authenticateForDeleteAllData(currentActivity) { result ->
                            when (result) {
                                is BiometricAuth.Result.Success -> viewModel.deleteAllData()
                                is BiometricAuth.Result.Failed ->
                                    biometricMessage = result.message
                                is BiometricAuth.Result.Unavailable ->
                                    biometricMessage = result.message
                            }
                        }
                    },
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                    ),
                ) { Text("Confirm with biometrics") }
            } else {
                Button(
                    onClick = { viewModel.deleteAllData() },
                    enabled = typedConfirmation == DELETE_CONFIRMATION_TEXT,
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                    ),
                ) { Text("Delete everything") }
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss, enabled = !wiping) {
                Text("Cancel")
            }
        },
    )
}

@Composable
private fun SettingsSection(
    title: String,
    content: @Composable () -> Unit,
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

/** One row in the App permissions section (Phase 5): name, why, status, Grant button. */
@Composable
private fun PermissionRow(
    displayName: String,
    rationale: String,
    granted: Boolean,
    onGrant: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(displayName, style = MaterialTheme.typography.titleSmall)
            Text(
                rationale,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (granted) {
            Text(
                "Granted",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
            )
        } else {
            OutlinedButton(onClick = onGrant) {
                Text("Grant")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun <T : Enum<T>> EnumDropdown(
    label: String,
    options: List<T>,
    selected: T,
    displayName: (T) -> String,
    onSelect: (T) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it },
    ) {
        OutlinedTextField(
            value = displayName(selected),
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth(),
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(displayName(option)) },
                    onClick = {
                        onSelect(option)
                        expanded = false
                    },
                )
            }
        }
    }
}

@Composable
private fun ApiKeyField(
    provider: LlmProvider,
    hasKey: Boolean,
    onSave: (String) -> Unit,
) {
    GenericApiKeyField(
        label = provider.displayName,
        hasKey = hasKey,
        onSave = onSave,
    )
}

/** Masked key field for a non-LLM service (Phase 7: Tavily). Same rules as ApiKeyField. */
@Composable
private fun GenericApiKeyField(
    label: String,
    hasKey: Boolean,
    onSave: (String) -> Unit,
) {
    var text by remember(label) { mutableStateOf("") }
    var visible by remember { mutableStateOf(false) }
    var saved by remember(label) { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.width(8.dp))
            if (hasKey) {
                Icon(
                    Icons.Filled.Check,
                    contentDescription = "Key stored",
                    tint = MaterialTheme.colorScheme.primary,
                )
                Text("Key stored", style = MaterialTheme.typography.bodySmall)
            } else {
                Text("No key stored", style = MaterialTheme.typography.bodySmall)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it; saved = false },
                label = { Text("Paste $label API key") },
                singleLine = true,
                visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    IconButton(onClick = { visible = !visible }) {
                        Icon(
                            if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            contentDescription = if (visible) "Hide key" else "Show key",
                        )
                    }
                },
                modifier = Modifier.weight(1f),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = {
                    onSave(text)
                    text = ""
                    saved = true
                },
            ) {
                Text(if (saved) "Saved" else "Save")
            }
        }
    }
}

@Composable
private fun CustomProviderCard(
    provider: CustomProviderConfig,
    hasKey: Boolean,
    onSaveKey: (String) -> Unit,
    onSave: (CustomProviderConfig) -> Unit,
    onDelete: () -> Unit,
) {
    var editing by remember { mutableStateOf(false) }
    var name by remember(provider) { mutableStateOf(provider.name) }
    var baseUrl by remember(provider) { mutableStateOf(provider.baseUrl) }
    var modelId by remember(provider) { mutableStateOf(provider.modelId) }
    var keyText by remember(provider) { mutableStateOf("") }
    var keyVisible by remember { mutableStateOf(false) }
    var keySaved by remember(provider) { mutableStateOf(false) }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(provider.name, style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.width(8.dp))
                if (hasKey) {
                    Icon(
                        Icons.Filled.Check,
                        contentDescription = "Key stored",
                        tint = MaterialTheme.colorScheme.primary,
                    )
                    Text("Key stored", style = MaterialTheme.typography.bodySmall)
                } else {
                    Text("No key stored", style = MaterialTheme.typography.bodySmall)
                }
            }
            if (!editing) {
                Text(provider.baseUrl, style = MaterialTheme.typography.bodySmall)
                Text("Model: ${provider.modelId}", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { editing = true }) { Text("Edit") }
                    OutlinedButton(onClick = onDelete) { Text("Delete") }
                }
            } else {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = baseUrl,
                    onValueChange = { baseUrl = it },
                    label = { Text("Base URL") },
                    placeholder = { Text("https://api.example.com/v1") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = modelId,
                    onValueChange = { modelId = it },
                    label = { Text("Model ID") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                val errors = provider.copy(name = name, baseUrl = baseUrl, modelId = modelId)
                    .validationErrors()
                if (errors.isNotEmpty()) {
                    Text(
                        errors.joinToString(" "),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            onSave(provider.copy(name = name, baseUrl = baseUrl, modelId = modelId))
                            editing = false
                        },
                        enabled = errors.isEmpty(),
                    ) {
                        Text("Save")
                    }
                    OutlinedButton(onClick = { editing = false }) { Text("Cancel") }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = keyText,
                    onValueChange = { keyText = it; keySaved = false },
                    label = { Text("Paste API key") },
                    singleLine = true,
                    visualTransformation = if (keyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        IconButton(onClick = { keyVisible = !keyVisible }) {
                            Icon(
                                if (keyVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                contentDescription = if (keyVisible) "Hide key" else "Show key",
                            )
                        }
                    },
                    modifier = Modifier.weight(1f),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        onSaveKey(keyText)
                        keyText = ""
                        keySaved = true
                    },
                ) {
                    Text(if (keySaved) "Saved" else "Save")
                }
            }
        }
    }
}

@Composable
private fun AddCustomProviderForm(
    onAdd: (name: String, baseUrl: String, modelId: String) -> String,
) {
    var name by remember { mutableStateOf("") }
    var baseUrl by remember { mutableStateOf("") }
    var modelId by remember { mutableStateOf("") }
    var added by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Add a provider", style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(
            value = name,
            onValueChange = { name = it; added = false },
            label = { Text("Name") },
            placeholder = { Text("My local server") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = baseUrl,
            onValueChange = { baseUrl = it; added = false },
            label = { Text("Base URL") },
            placeholder = { Text("https://api.example.com/v1") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = modelId,
            onValueChange = { modelId = it; added = false },
            label = { Text("Model ID") },
            placeholder = { Text("llama-3.3-70b-instruct") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        val errors = CustomProviderConfig(id = "", name = name, baseUrl = baseUrl, modelId = modelId)
            .validationErrors()
        if (name.isNotBlank() || baseUrl.isNotBlank() || modelId.isNotBlank()) {
            if (errors.isNotEmpty()) {
                Text(
                    errors.joinToString(" "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }
        }
        Button(
            onClick = {
                onAdd(name, baseUrl, modelId)
                name = ""
                baseUrl = ""
                modelId = ""
                added = true
            },
            enabled = errors.isEmpty(),
        ) {
            Text(if (added) "Added" else "Add provider")
        }
    }
}
