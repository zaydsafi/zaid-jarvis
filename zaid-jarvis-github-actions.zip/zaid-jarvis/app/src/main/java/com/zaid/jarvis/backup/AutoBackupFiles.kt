package com.zaid.jarvis.backup

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Automatic local backups (Phase 10): the same export JSON as a
 * manual backup, written to the app's private files directory (never
 * shared storage — no other app can read it), and restorable from the
 * Backup screen.
 *
 * At most [MAX_FILES] auto-backups are kept; writing a new one
 * deletes the oldest. File names carry the export date so the Backup
 * screen can show when each one was made.
 */
object AutoBackupFiles {

    /** Subdirectory of the app's private files dir. */
    const val DIRECTORY: String = "auto_backups"

    /** Maximum auto-backups kept (oldest deleted first). */
    const val MAX_FILES: Int = 3

    fun directory(context: Context): File = File(context.filesDir, DIRECTORY)

    /** Auto-backup files, newest first. */
    fun list(context: Context): List<File> {
        val dir = directory(context)
        if (!dir.exists()) return emptyList()
        return dir.listFiles()
            ?.filter { it.isFile && it.name.startsWith(FILE_PREFIX) && it.name.endsWith(".json") }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
    }

    /**
     * Writes [json] as a new auto-backup and prunes older files to
     * [MAX_FILES]. Returns the written file, or null on failure.
     */
    fun write(context: Context, json: String, timestampMillis: Long): File? {
        return runCatching {
            val dir = directory(context).also { it.mkdirs() }
            val name = fileName(timestampMillis)
            val file = File(dir, name)
            file.writeText(json, Charsets.UTF_8)
            prune(context)
            file
        }.getOrNull()
    }

    fun delete(file: File): Boolean = runCatching { file.delete() }.getOrDefault(false)

    /** Deletes all but the newest [MAX_FILES] auto-backups. */
    fun prune(context: Context) {
        val files = list(context)
        files.drop(MAX_FILES).forEach { delete(it) }
    }

    fun fileName(timestampMillis: Long): String {
        val stamp = SimpleDateFormat("yyyy-MM-dd-HHmm", Locale.US).format(Date(timestampMillis))
        return "$FILE_PREFIX$stamp.json"
    }

    private const val FILE_PREFIX: String = "zaid-jarvis-backup-"
}
