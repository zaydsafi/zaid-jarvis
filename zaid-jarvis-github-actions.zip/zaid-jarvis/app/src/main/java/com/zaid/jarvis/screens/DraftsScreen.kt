package com.zaid.jarvis.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zaid.jarvis.core.research.ContentDraft
import com.zaid.jarvis.core.research.DraftLimits
import com.zaid.jarvis.core.research.DraftStatus
import com.zaid.jarvis.viewmodel.DraftsViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Drafts list (Phase 7): every post Jarvis drafted, with its status.
 *
 * DRAFT = waiting for review. APPROVED = Zaid approved it for publishing.
 * PUBLISHED = published (Phase 8). Tap a draft to open the editor;
 * filter by status or platform.
 */
@Composable
fun DraftsScreen(
    viewModel: DraftsViewModel = hiltViewModel(),
    onOpenDraft: (Long) -> Unit = {},
    onNavigateToScheduledPosts: () -> Unit = {},
) {
    val drafts by viewModel.drafts.collectAsState()
    val statusFilter by viewModel.statusFilter.collectAsState()
    val platformFilter by viewModel.platformFilter.collectAsState()
    val platforms by viewModel.platforms.collectAsState()
    val message by viewModel.message.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Drafts", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Posts Jarvis drafted for you. Review, edit, and approve them here — " +
                "only APPROVED drafts can be published, and every publish shows " +
                "the exact text on an approval card first.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onOpenDraft(0L) }) {
                Text("New draft")
            }
            OutlinedButton(onClick = onNavigateToScheduledPosts) {
                Text("Scheduled posts")
            }
        }

        // Status filter.
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilterChip(
                selected = statusFilter == null,
                onClick = { viewModel.setStatusFilter(null) },
                label = { Text("All") },
            )
            DraftStatus.entries.forEach { status ->
                FilterChip(
                    selected = statusFilter == status,
                    onClick = { viewModel.setStatusFilter(status) },
                    label = { Text(statusLabel(status)) },
                )
            }
        }
        // Platform filter (only when drafts exist on more than one platform).
        if (platforms.size > 1) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FilterChip(
                    selected = platformFilter == null,
                    onClick = { viewModel.setPlatformFilter(null) },
                    label = { Text("All platforms") },
                )
                platforms.forEach { platform ->
                    FilterChip(
                        selected = platformFilter == platform,
                        onClick = { viewModel.setPlatformFilter(platform) },
                        label = { Text(platform) },
                    )
                }
            }
        }

        if (drafts.isEmpty()) {
            Text(
                "No drafts yet. Ask Jarvis in chat: “draft a post about my new collection " +
                    "for Instagram” — or start a blank one above.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(drafts, key = { it.id }) { draft ->
                DraftCard(
                    draft = draft,
                    onOpen = { onOpenDraft(draft.id) },
                    onDelete = { viewModel.deleteDraft(draft.id) },
                )
            }
        }
    }

    message?.let {
        AlertDialog(
            onDismissRequest = viewModel::clearMessage,
            confirmButton = {
                TextButton(onClick = viewModel::clearMessage) { Text("OK") }
            },
            text = { Text(it) },
        )
    }
}

private fun statusLabel(status: DraftStatus): String = when (status) {
    DraftStatus.DRAFT -> "Draft"
    DraftStatus.APPROVED -> "Approved"
    DraftStatus.PUBLISHED -> "Published"
}

@Composable
private fun DraftCard(
    draft: ContentDraft,
    onOpen: () -> Unit,
    onDelete: () -> Unit,
) {
    val dateFormat = rememberDateFormat()
    val limit = DraftLimits.limitFor(draft.platform)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(draft.title, style = MaterialTheme.typography.titleMedium)
                Text(
                    statusLabel(draft.status),
                    style = MaterialTheme.typography.bodySmall,
                    color = when (draft.status) {
                        DraftStatus.APPROVED -> MaterialTheme.colorScheme.primary
                        DraftStatus.PUBLISHED -> MaterialTheme.colorScheme.primary
                        DraftStatus.DRAFT -> MaterialTheme.colorScheme.onSurfaceVariant
                    },
                )
            }
            Text(
                "${draft.platform} · ${draft.body.length}/$limit characters · " +
                    dateFormat.format(Date(draft.updatedAtMillis)),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                draft.body,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 3,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onOpen) { Text("Edit") }
                OutlinedButton(onClick = onDelete) { Text("Delete") }
            }
        }
    }
}

@Composable
private fun rememberDateFormat(): SimpleDateFormat {
    return androidx.compose.runtime.remember {
        SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault())
    }
}
