package com.zaid.jarvis.backup

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.zaid.jarvis.core.backup.BackupFormat
import com.zaid.jarvis.data.datastore.SettingsRepository
import com.zaid.jarvis.data.repository.BackupService
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.first

/**
 * The automatic-backup worker (Phase 10).
 *
 * A weekly periodic worker (see [BackupScheduler]) that writes the
 * same export JSON as a manual backup to the app's private files
 * directory — but only when automatic backup is enabled in Settings
 * (off by default). At most 3 auto-backups are kept (see
 * [AutoBackupFiles]); the Backup screen lists them and can restore
 * any of them.
 *
 * Timing is best-effort (WorkManager + Doze/battery optimization):
 * a weekly backup may run a little late, never early. A failure here
 * is silent — the next weekly run retries, and the Backup screen
 * always shows the newest auto-backup that actually exists.
 */
class AutoBackupWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    private val entryPoint: AutoBackupWorkerEntryPoint =
        EntryPointAccessors.fromApplication(
            appContext,
            AutoBackupWorkerEntryPoint::class.java,
        )

    override suspend fun doWork(): Result {
        // An unreadable Settings store must not throw — WorkManager
        // retries a throwing worker, and a backup must never run
        // twice for one schedule. Stay silent; the next weekly run retries.
        val settings = runCatching {
            entryPoint.settingsRepository().settings.first()
        }.getOrNull() ?: return Result.success()
        if (!settings.autoBackupEnabled) return Result.success()
        runCatching {
            val data = entryPoint.backupService().export()
            val json = BackupFormat.encode(
                data = data,
                appVersion = appVersionName(applicationContext),
                exportedAtMillis = System.currentTimeMillis(),
            )
            AutoBackupFiles.write(applicationContext, json, System.currentTimeMillis())
        }
        return Result.success() // Silent on failure — the next run retries.
    }

    companion object {
        /** Tag on the auto-backup job (for debugging). */
        const val WORK_TAG: String = "jarvis_auto_backup"
    }
}

/** Hilt entry point for [AutoBackupWorker] (WorkManager creates the worker, not Hilt). */
@EntryPoint
@InstallIn(SingletonComponent::class)
interface AutoBackupWorkerEntryPoint {
    fun settingsRepository(): SettingsRepository
    fun backupService(): BackupService
}

/**
 * The app's version name (e.g. "0.10.0-phase10"), for the backup
 * header. Read from the package — never hard-coded, so the label
 * always matches the build that wrote the file.
 */
@Suppress("DEPRECATION")
fun appVersionName(context: Context): String {
    return runCatching {
        val packageManager: PackageManager = context.packageManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.getPackageInfo(
                context.packageName,
                PackageManager.PackageInfoFlags.of(0),
            ).versionName
        } else {
            packageManager.getPackageInfo(context.packageName, 0).versionName
        }
    }.getOrNull() ?: "unknown"
}
