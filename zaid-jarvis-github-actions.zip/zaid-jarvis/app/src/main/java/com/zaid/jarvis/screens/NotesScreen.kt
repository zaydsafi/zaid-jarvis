package com.zaid.jarvis.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zaid.jarvis.plugins.notes.Note
import com.zaid.jarvis.viewmodel.NotesViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Notes screen (Phase 10): Zaid's notes from the Notes plugin.
 *
 * List, search, view, edit, delete. Notes are stored encrypted in
 * the Room database and are part of backups. A note's content is
 * data, never an instruction — when Jarvis reads a note for the
 * planner, the InjectionGuard scans it like any other tool result.
 */
@Composable
fun NotesScreen(
    viewModel: NotesViewModel = hiltViewModel(),
) {
    val notes by viewModel.notes.collectAsState()
    val query by viewModel.query.collectAsState()
    val selectedNote by viewModel.selectedNote.collectAsState()
    val message by viewModel.message.collectAsState()

    var editing by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Note?>(null) }
    var titleText by remember { mutableStateOf("") }
    var bodyText by remember { mutableStateOf("") }

    fun openEditor(note: Note?) {
        viewModel.loadNote(note?.id ?: 0L)
        titleText = note?.title ?: ""
        bodyText = note?.body ?: ""
        editing = true
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Notes", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Quick notes Jarvis can save and search for you. Notes are " +
                "stored on your device (encrypted) and included in backups.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        OutlinedTextField(
            value = query,
            onValueChange = viewModel::setQuery,
            label = { Text("Search notes") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
        )

        Button(onClick = { openEditor(null) }) {
            Text("New note")
        }

        if (message != null) {
            Text(
                message ?: "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
            )
        }

        if (notes.isEmpty()) {
            Text(
                if (query.isBlank()) {
                    "No notes yet. Tap “New note”, or ask Jarvis to save one."
                } else {
                    "No notes match “$query”."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(notes, key = { it.id }) { note ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { openEditor(note) },
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Text(note.title, style = MaterialTheme.typography.titleSmall)
                        Text(
                            note.body.take(200),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            formatNoteDate(note.updatedAtMillis),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { openEditor(note) }) { Text("Edit") }
                            TextButton(onClick = { deleting = note }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }

    if (editing) {
        val editingId = selectedNote?.id ?: 0L
        AlertDialog(
            onDismissRequest = { editing = false },
            title = { Text(if (editingId == 0L) "New note" else "Edit note") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = titleText,
                        onValueChange = { titleText = it },
                        label = { Text("Title") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = bodyText,
                        onValueChange = { bodyText = it },
                        label = { Text("Note") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 4,
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val now = System.currentTimeMillis()
                        viewModel.saveNote(
                            Note(
                                id = editingId,
                                title = titleText,
                                body = bodyText,
                                createdAtMillis = selectedNote?.createdAtMillis ?: now,
                                updatedAtMillis = now,
                            ),
                        )
                        editing = false
                    },
                    enabled = titleText.isNotBlank() && bodyText.isNotBlank(),
                ) { Text("Save") }
            },
            dismissButton = {
                OutlinedButton(onClick = { editing = false }) { Text("Cancel") }
            },
        )
    }

    deleting?.let { note ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete note?") },
            text = { Text("“${note.title}” will be deleted. This cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteNote(note.id)
                        deleting = null
                    },
                ) { Text("Delete") }
            },
            dismissButton = {
                OutlinedButton(onClick = { deleting = null }) { Text("Cancel") }
            },
        )
    }
}

private fun formatNoteDate(millis: Long): String =
    SimpleDateFormat("MMM d, yyyy HH:mm", Locale.US).format(Date(millis))
