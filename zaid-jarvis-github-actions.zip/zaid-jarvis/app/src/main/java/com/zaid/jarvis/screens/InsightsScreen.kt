package com.zaid.jarvis.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zaid.jarvis.viewmodel.InsightsViewModel

/**
 * Insights screen (Phase 10): local usage aggregates over the last
 * 7 or 30 days — most-used tools, tasks, focus time, posts
 * published, and LLM usage.
 *
 * Everything is computed on-device from local tables; nothing
 * leaves the device. Tool usage comes from analytics events, which
 * are recorded only while "Usage insights" is on in Settings — with
 * it off, that section stays empty by design.
 */
@Composable
fun InsightsScreen(
    viewModel: InsightsViewModel = hiltViewModel(),
) {
    val insights by viewModel.insights.collectAsState()
    val range by viewModel.range.collectAsState()
    val analyticsEnabled by viewModel.analyticsEnabled.collectAsState()
    val message by viewModel.message.collectAsState()

    var confirmingClear by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Insights", style = MaterialTheme.typography.headlineMedium)
        Text(
            "What Jarvis has been doing — computed on your device, from " +
                "your data. Nothing here leaves the phone.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            InsightsViewModel.Range.entries.forEach { option ->
                FilterChip(
                    selected = range == option,
                    onClick = { viewModel.setRange(option) },
                    label = { Text(option.label) },
                )
            }
        }

        if (!analyticsEnabled) {
            Text(
                "Usage insights are off in Settings, so tool usage is not " +
                    "being recorded. Tasks, focus time, and posts still show " +
                    "below — they come from your lists, not from analytics.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        if (message != null) {
            Text(
                message ?: "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
            )
        }

        val data = insights
        if (data == null) {
            Text(
                "Loading…",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            InsightCard("Most-used tools") {
                if (data.topTools.isEmpty()) {
                    Text(
                        "No tool usage recorded in this period.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    data.topTools.forEach { (tool, count) ->
                        Text("$tool — $count time${if (count == 1) "" else "s"}")
                    }
                }
            }
            InsightCard("Tasks") {
                Text("${data.tasksCreated} created · ${data.tasksCompleted} completed")
            }
            InsightCard("Focus") {
                Text(
                    "${data.focusMinutes} minutes across ${data.focusSessions} " +
                        "session${if (data.focusSessions == 1) "" else "s"}",
                )
            }
            InsightCard("Posts published") {
                if (data.postsByPlatform.isEmpty()) {
                    Text(
                        "No posts published in this period.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    data.postsByPlatform.forEach { (platform, count) ->
                        Text("$platform — $count")
                    }
                }
            }
            InsightCard("LLM usage (lifetime)") {
                Text("${data.totalTokensUsed} tokens · about \$${"%.2f".format(data.estimatedCostUsd)}")
                Text(
                    "Lifetime totals — the usage tracker keeps running " +
                        "totals, not per-day figures. Cost is an estimate.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            OutlinedButton(onClick = { confirmingClear = true }) {
                Text("Clear analytics data")
            }
            Text(
                "Clearing wipes the recorded usage events only. Your " +
                    "tasks, notes, focus history, and posts are untouched.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    if (confirmingClear) {
        AlertDialog(
            onDismissRequest = { confirmingClear = false },
            title = { Text("Clear analytics data?") },
            text = {
                Text(
                    "All recorded usage events will be deleted. Your tasks, " +
                        "focus history, and posts are not affected.",
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAnalyticsData()
                        confirmingClear = false
                    },
                ) { Text("Clear") }
            },
            dismissButton = {
                OutlinedButton(onClick = { confirmingClear = false }) { Text("Cancel") }
            },
        )
    }
}

@Composable
private fun InsightCard(title: String, content: @Composable () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}
