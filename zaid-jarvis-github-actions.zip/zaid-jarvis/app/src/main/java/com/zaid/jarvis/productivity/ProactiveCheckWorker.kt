package com.zaid.jarvis.productivity

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.zaid.jarvis.core.productivity.ProactiveRules
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.datastore.ProactiveStateRepository
import com.zaid.jarvis.data.datastore.SettingsRepository
import com.zaid.jarvis.data.repository.TaskRepository
import com.zaid.jarvis.tools.productivity.FocusSessionManager
import com.zaid.jarvis.tools.productivity.ScreenTimeReader
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.first

/**
 * The proactive-check worker (Phase 9).
 *
 * A 15-minute periodic worker (see [WellnessScheduler]) that runs
 * the three quiet proactive checks — smart overdue reminders, break
 * reminders, and wind-down — each guarded by its own toggle, its own
 * dedupe/throttle rule ([ProactiveRules]), and quiet hours.
 *
 * The worker only runs at all when at least one of the three
 * features is enabled; every check re-reads Settings, so toggling a
 * feature off takes effect on the next run at the latest.
 *
 * All three checks are best-effort and fail silent: a missing
 * permission or an unreadable data source just skips that check —
 * the worker never posts an error notification.
 */
class ProactiveCheckWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    private val entryPoint: ProactiveCheckWorkerEntryPoint =
        EntryPointAccessors.fromApplication(
            appContext,
            ProactiveCheckWorkerEntryPoint::class.java,
        )

    override suspend fun doWork(): Result {
        // The three checks below are each wrapped in runCatching, but
        // the Settings read itself was not — an unreadable Settings
        // store would throw and WorkManager would retry the whole
        // run. Stay silent instead; the next 15-minute run retries.
        val settings = runCatching {
            entryPoint.settingsRepository().settings.first()
        }.getOrNull() ?: return Result.success()
        val notifier = entryPoint.wellnessNotifier()
        val now = System.currentTimeMillis()
        val quiet = runCatching { notifier.isQuietNow(now) }.getOrDefault(false)

        // ── 1. Smart overdue reminders (once per task per day) ──────
        if (settings.overdueRemindersEnabled && !quiet) {
            runCatching {
                val repository = entryPoint.taskRepository()
                val due = repository.getOverdue(now)
                    .filter { ProactiveRules.shouldNotifyOverdue(it, now) }
                if (due.isNotEmpty()) {
                    notifier.notifyOverdue(due)
                    val day = ProactiveRules.epochDay(now)
                    due.forEach { repository.markOverdueNotified(it.id, day) }
                }
            }
        }

        // ── 2. Break reminders (interval + once-per-hour throttle) ───
        if (settings.breakRemindersEnabled && !quiet) {
            runCatching {
                val focusRunning = entryPoint.focusSessionManager().currentSession() != null
                val screenTimeReader = entryPoint.screenTimeReader()
                if (!focusRunning && screenTimeReader.hasUsageAccess()) {
                    val continuous = (screenTimeReader.currentContinuousMillis(now)
                        as? JarvisResult.Success)?.value
                    if (continuous != null) {
                        val state = entryPoint.proactiveStateRepository()
                        val lastBreak = state.lastBreakNotifiedMillisNow()
                        if (
                            ProactiveRules.shouldNotifyBreak(
                                continuousScreenMillis = continuous,
                                intervalMinutes = settings.breakReminderIntervalMinutes,
                                lastBreakNotifiedMillis = lastBreak,
                                nowMillis = now,
                            )
                        ) {
                            notifier.notifyBreak(continuous)
                            state.recordBreakNotified(now)
                        }
                    }
                }
            }
        }

        // ── 3. Wind-down (once per day; exempt from quiet hours — ────
        // bedtime is normally inside quiet hours, the user opted in
        // and chose the time).
        if (settings.windDownEnabled) {
            runCatching {
                val state = entryPoint.proactiveStateRepository()
                val lastDay = state.lastWindDownDayNow()
                if (
                    ProactiveRules.shouldNotifyWindDown(
                        bedtimeHour = settings.windDownHour,
                        bedtimeMinute = settings.windDownMinute,
                        lastWindDownDay = lastDay,
                        nowMillis = now,
                    )
                ) {
                    notifier.notifyWindDown()
                    state.recordWindDownNotified(ProactiveRules.epochDay(now))
                }
            }
        }
        return Result.success()
    }

    companion object {
        /** Tag on the proactive-check job (for debugging). */
        const val WORK_TAG: String = "jarvis_proactive_check"
    }
}

/** Hilt entry point for [ProactiveCheckWorker] (WorkManager creates the worker, not Hilt). */
@EntryPoint
@InstallIn(SingletonComponent::class)
interface ProactiveCheckWorkerEntryPoint {
    fun settingsRepository(): SettingsRepository
    fun taskRepository(): TaskRepository
    fun focusSessionManager(): FocusSessionManager
    fun screenTimeReader(): ScreenTimeReader
    fun proactiveStateRepository(): ProactiveStateRepository
    fun wellnessNotifier(): WellnessNotifier
}
