package com.zaid.jarvis.phone

import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.ActivityNotFoundException
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.provider.Settings.SettingNotFoundException
import androidx.core.content.ContextCompat
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.device.DeviceContextProvider
import com.zaid.jarvis.tools.phone.AppInfo
import com.zaid.jarvis.tools.phone.BatteryInfo
import com.zaid.jarvis.tools.phone.BluetoothToggleResult
import com.zaid.jarvis.tools.phone.BrightnessChange
import com.zaid.jarvis.tools.phone.Contact
import com.zaid.jarvis.tools.phone.DndMode
import com.zaid.jarvis.tools.phone.NetworkInfo
import com.zaid.jarvis.tools.phone.PhoneDevice
import com.zaid.jarvis.tools.phone.SystemAction
import com.zaid.jarvis.tools.phone.VolumeInfo
import com.zaid.jarvis.tools.phone.VolumeStream
import com.zaid.jarvis.tools.phone.WifiToggleResult
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The Android implementation of [PhoneDevice] (Phase 5).
 *
 * Every method returns a [JarvisResult] — missing permissions, missing
 * hardware, and Android version restrictions all come back as failures
 * with plain-language messages, never as crashes. Blocking work runs on
 * Dispatchers.IO.
 *
 * Honest limitations (also documented in PHASE5.md):
 * - **Wi-Fi**: Android 10+ does not let apps toggle Wi-Fi directly, so
 *   [setWifi] opens the system Wi-Fi panel on API 29+ instead.
 * - **Bluetooth**: on Android 13+, turning Bluetooth on shows the
 *   system's own confirmation dialog.
 * - **Brightness**: needs "Modify system settings" (WRITE_SETTINGS);
 *   when auto-brightness is on, a manual value may not be visible.
 * - **Do Not Disturb**: needs Notification Policy access.
 * - **Alarms/timers**: created through the Clock app; Android has no
 *   API to cancel them programmatically (see SetAlarmTool/SetTimerTool).
 */
@Singleton
class AndroidPhoneDevice @Inject constructor(
    @ApplicationContext private val context: Context,
    private val deviceContextProvider: DeviceContextProvider,
) : PhoneDevice {

    private val audioManager: AudioManager? by lazy {
        context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }
    private val cameraManager: CameraManager? by lazy {
        context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    }
    private val wifiManager: WifiManager? by lazy {
        context.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    }
    private val bluetoothAdapter: BluetoothAdapter? by lazy {
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    }
    private val notificationManager: NotificationManager? by lazy {
        context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
    }

    /** Last-known torch state (CameraManager has no getter; kept in sync via a callback). */
    @Volatile
    private var torchOn: Boolean = false

    init {
        // Keep the torch state in sync even when another app toggles it.
        runCatching {
            cameraManager?.registerTorchCallback(
                object : CameraManager.TorchCallback() {
                    override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                        torchOn = enabled
                    }
                },
                Handler(Looper.getMainLooper()),
            )
        }
    }

    // ── Tier 0 reads ──────────────────────────────────────────────────

    override suspend fun battery(): JarvisResult<BatteryInfo> = io {
        val snapshot = deviceContextProvider.snapshot()
        JarvisResult.Success(BatteryInfo(snapshot.batteryPercent, snapshot.isCharging))
    }

    override suspend fun network(): JarvisResult<NetworkInfo> = io {
        JarvisResult.Success(
            NetworkInfo(
                isOnline = deviceContextProvider.isOnline(),
                type = deviceContextProvider.networkType(),
            ),
        )
    }

    override suspend fun searchContacts(query: String): JarvisResult<List<Contact>> = io {
        if (!hasPermission(android.Manifest.permission.READ_CONTACTS)) {
            return@io JarvisResult.Failure(
                "Jarvis doesn't have permission to read contacts. " +
                    "Grant it in Settings → App permissions → Contacts, then try again.",
            )
        }
        runCatchingJarvisResult {
            val resolver: ContentResolver = context.contentResolver
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone._ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
            )
            val contacts = mutableListOf<Contact>()
            resolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$query%"),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC",
            )?.use { cursor ->
                val idIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone._ID)
                val nameIndex =
                    cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numberIndex =
                    cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext() && contacts.size < 20) {
                    val name = if (nameIndex >= 0) cursor.getString(nameIndex) else null
                    val number = if (numberIndex >= 0) cursor.getString(numberIndex) else null
                    if (!name.isNullOrBlank() && !number.isNullOrBlank()) {
                        contacts += Contact(
                            id = if (idIndex >= 0) cursor.getLong(idIndex) else 0L,
                            name = name,
                            phoneNumber = number,
                        )
                    }
                }
            }
            contacts
        }
    }

    override suspend fun listApps(query: String?): JarvisResult<List<AppInfo>> = io {
        runCatchingJarvisResult {
            // Launcher apps only (ACTION_MAIN + CATEGORY_LAUNCHER): these
            // are exactly the apps open_app can open, and listing them
            // needs no QUERY_ALL_PACKAGES permission.
            val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val packageManager = context.packageManager
            val apps = packageManager.queryIntentActivities(launcherIntent, 0)
                .mapNotNull { resolveInfo ->
                    val activityInfo = resolveInfo.activityInfo ?: return@mapNotNull null
                    // loadLabel is declared non-null, but a missing label
                    // must never crash the listing — fall back to the package.
                    val label = resolveInfo.loadLabel(packageManager) as CharSequence?
                    val name = label?.toString()?.ifBlank { null } ?: activityInfo.packageName
                    AppInfo(name = name, packageName = activityInfo.packageName)
                }
                .distinctBy { it.packageName }
                .sortedBy { it.name.lowercase() }
            val q = query?.trim()?.lowercase()
            val filtered = if (q.isNullOrEmpty()) {
                apps
            } else {
                apps.filter {
                    it.name.lowercase().contains(q) || it.packageName.lowercase().contains(q)
                }
            }
            filtered.take(100)
        }
    }

    // ── Tier 1 state ──────────────────────────────────────────────────

    override suspend fun isFlashlightOn(): JarvisResult<Boolean> = io {
        if (findFlashCameraId() == null) {
            JarvisResult.Failure("This device doesn't have a flashlight.")
        } else {
            JarvisResult.Success(torchOn)
        }
    }

    override suspend fun setFlashlight(on: Boolean): JarvisResult<Boolean> = io {
        if (!hasPermission(android.Manifest.permission.CAMERA)) {
            return@io JarvisResult.Failure(
                "Jarvis needs camera permission to use the flashlight. " +
                    "Grant it in Settings → App permissions → Camera, then try again.",
            )
        }
        val cameraId = findFlashCameraId()
            ?: return@io JarvisResult.Failure("This device doesn't have a flashlight.")
        val previous = torchOn
        runCatchingJarvisResult {
            cameraManager?.setTorchMode(cameraId, on)
                ?: throw IllegalStateException("Camera service is unavailable.")
            torchOn = on
            previous
        }.mapFailure { "Could not change the flashlight: ${it.message}" }
    }

    override suspend fun volumeInfo(stream: VolumeStream): JarvisResult<VolumeInfo> = io {
        val manager = audioManager
            ?: return@io JarvisResult.Failure("Audio service is unavailable.")
        runCatchingJarvisResult {
            VolumeInfo(
                stream = stream,
                level = manager.getStreamVolume(stream.toAndroidStream()),
                maxLevel = manager.getStreamMaxVolume(stream.toAndroidStream()),
            )
        }
    }

    override suspend fun setVolume(stream: VolumeStream, level: Int): JarvisResult<VolumeInfo> = io {
        val manager = audioManager
            ?: return@io JarvisResult.Failure("Audio service is unavailable.")
        runCatchingJarvisResult {
            val androidStream = stream.toAndroidStream()
            val previous = VolumeInfo(
                stream = stream,
                level = manager.getStreamVolume(androidStream),
                maxLevel = manager.getStreamMaxVolume(androidStream),
            )
            manager.setStreamVolume(androidStream, level, AudioManager.FLAG_SHOW_UI)
            previous
        }.mapFailure { "Could not change the volume: ${it.message}" }
    }

    override suspend fun brightnessPercent(): JarvisResult<Int> = io {
        runCatchingJarvisResult {
            val raw = Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS)
            (raw * 100 / 255).coerceIn(0, 100)
        }.mapFailure { "Could not read the screen brightness." }
    }

    override suspend fun setBrightnessPercent(percent: Int): JarvisResult<BrightnessChange> = io {
        if (!Settings.System.canWrite(context)) {
            return@io JarvisResult.Failure(
                "Jarvis can't change the brightness until you grant “Modify system settings”. " +
                    "Open Settings → App permissions → Modify system settings and allow it for Zaid Jarvis.",
            )
        }
        runCatchingJarvisResult {
            val resolver = context.contentResolver
            val previousRaw = try {
                Settings.System.getInt(resolver, Settings.System.SCREEN_BRIGHTNESS)
            } catch (e: SettingNotFoundException) {
                128
            }
            val autoOn = try {
                Settings.System.getInt(resolver, Settings.System.SCREEN_BRIGHTNESS_MODE) ==
                    Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
            } catch (e: SettingNotFoundException) {
                false
            }
            Settings.System.putInt(
                resolver,
                Settings.System.SCREEN_BRIGHTNESS,
                (percent * 255 / 100).coerceIn(0, 255),
            )
            BrightnessChange(
                previousPercent = (previousRaw * 100 / 255).coerceIn(0, 100),
                autoBrightnessOn = autoOn,
            )
        }.mapFailure { "Could not change the brightness: ${it.message}" }
    }

    override suspend fun isWifiEnabled(): JarvisResult<Boolean> = io {
        val manager = wifiManager
            ?: return@io JarvisResult.Failure("Wi-Fi service is unavailable.")
        runCatchingJarvisResult { manager.isWifiEnabled }
    }

    @Suppress("DEPRECATION") // setWifiEnabled is the only direct toggle; deprecated on API 29+.
    override suspend fun setWifi(enabled: Boolean): JarvisResult<WifiToggleResult> = io {
        val manager = wifiManager
            ?: return@io JarvisResult.Failure("Wi-Fi service is unavailable.")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+: apps cannot toggle Wi-Fi directly. Open the
            // system panel and let Zaid toggle it there.
            return@io when (val launched = launch(SystemAction.OpenWifiPanel)) {
                is JarvisResult.Success -> JarvisResult.Success(WifiToggleResult.PanelOpened)
                is JarvisResult.Failure -> launched
            }
        }
        runCatchingJarvisResult {
            val previous = manager.isWifiEnabled
            if (!manager.setWifiEnabled(enabled)) {
                throw IllegalStateException(
                    "Android refused to turn Wi-Fi ${if (enabled) "on" else "off"}.",
                )
            }
            WifiToggleResult.Changed(previous)
        }.mapFailure { "Could not change Wi-Fi: ${it.message}" }
    }

    override suspend fun isBluetoothEnabled(): JarvisResult<Boolean> = io {
        val adapter = bluetoothAdapter
            ?: return@io JarvisResult.Failure("This device doesn't have Bluetooth.")
        if (!hasBluetoothPermission()) {
            return@io bluetoothPermissionFailure()
        }
        runCatchingJarvisResult { adapter.isEnabled }
    }

    @Suppress("DEPRECATION") // enable()/disable() are deprecated on API 33+ but still functional.
    override suspend fun setBluetooth(enabled: Boolean): JarvisResult<BluetoothToggleResult> = io {
        val adapter = bluetoothAdapter
            ?: return@io JarvisResult.Failure("This device doesn't have Bluetooth.")
        if (!hasBluetoothPermission()) {
            return@io bluetoothPermissionFailure()
        }
        if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+: turning Bluetooth on shows the system's own
            // confirmation dialog — Jarvis cannot switch it on silently.
            return@io when (val launched = launch(SystemAction.RequestBluetoothEnable)) {
                is JarvisResult.Success ->
                    JarvisResult.Success(BluetoothToggleResult.EnableDialogOpened)
                is JarvisResult.Failure -> launched
            }
        }
        runCatchingJarvisResult {
            val previous = adapter.isEnabled
            val changed = if (enabled) adapter.enable() else adapter.disable()
            if (!changed) {
                throw IllegalStateException(
                    "Android refused to turn Bluetooth ${if (enabled) "on" else "off"}.",
                )
            }
            BluetoothToggleResult.Changed(previous)
        }.mapFailure { "Could not change Bluetooth: ${it.message}" }
    }

    override suspend fun dndMode(): JarvisResult<DndMode> = io {
        val manager = notificationManager
            ?: return@io JarvisResult.Failure("Notification service is unavailable.")
        runCatchingJarvisResult { manager.currentInterruptionFilter.toDndMode() }
    }

    override suspend fun setDndMode(mode: DndMode): JarvisResult<DndMode> = io {
        val manager = notificationManager
            ?: return@io JarvisResult.Failure("Notification service is unavailable.")
        if (!manager.isNotificationPolicyAccessGranted) {
            return@io JarvisResult.Failure(
                "Jarvis can't change Do Not Disturb until you grant Do Not Disturb access. " +
                    "Open Settings → App permissions → Do Not Disturb access and allow it for Zaid Jarvis.",
            )
        }
        runCatchingJarvisResult {
            val previous = manager.currentInterruptionFilter.toDndMode()
            manager.setInterruptionFilter(mode.toInterruptionFilter())
            previous
        }.mapFailure { "Could not change Do Not Disturb: ${it.message}" }
    }

    // ── Permissions ───────────────────────────────────────────────────

    override fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    /** BLUETOOTH_CONNECT (API 31+); older Android needs no runtime permission for this. */
    private fun hasBluetoothPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            hasPermission(android.Manifest.permission.BLUETOOTH_CONNECT)

    private fun bluetoothPermissionFailure(): JarvisResult.Failure =
        JarvisResult.Failure(
            "Jarvis needs Bluetooth permission to switch Bluetooth. " +
                "Grant it in Settings → App permissions → Bluetooth, then try again.",
        )

    // ── System actions (intents) ──────────────────────────────────────

    /**
     * Starts the system app for [action]. Every action only *opens* the
     * owning app with the content pre-filled — the user always completes
     * the action there. In particular, [SystemAction.Dial] opens the
     * dialer (ACTION_DIAL), never places the call (ACTION_CALL).
     */
    override suspend fun launch(action: SystemAction): JarvisResult<String> = io {
        val intent = when (action) {
            is SystemAction.Dial -> Intent(Intent.ACTION_DIAL).apply {
                data = android.net.Uri.parse("tel:${sanitizePhoneNumber(action.phoneNumber)}")
            }
            is SystemAction.SendSms -> Intent(Intent.ACTION_SENDTO).apply {
                data = android.net.Uri.parse("smsto:${sanitizePhoneNumber(action.phoneNumber)}")
                putExtra("sms_body", action.body)
            }
            is SystemAction.SendEmail -> Intent(Intent.ACTION_SENDTO).apply {
                data = android.net.Uri.parse("mailto:")
                putExtra(Intent.EXTRA_EMAIL, action.to.toTypedArray())
                putExtra(Intent.EXTRA_SUBJECT, action.subject)
                putExtra(Intent.EXTRA_TEXT, action.body)
            }
            is SystemAction.ShareText -> Intent.createChooser(
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, action.text)
                },
                action.title,
            )
            is SystemAction.OpenApp -> context.packageManager
                .getLaunchIntentForPackage(action.packageName)
                ?: return@io JarvisResult.Failure(
                    "“${action.packageName}” has no launchable activity.",
                )
            is SystemAction.SetAlarm -> Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, action.hour)
                putExtra(AlarmClock.EXTRA_MINUTES, action.minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, action.label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            }
            is SystemAction.SetTimer -> Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, action.seconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, action.label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            }
            SystemAction.OpenWifiPanel -> Intent(Settings.Panel.ACTION_WIFI)
            SystemAction.RequestBluetoothEnable ->
                Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            SystemAction.OpenClockApp -> Intent(AlarmClock.ACTION_SHOW_ALARMS)
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
            JarvisResult.Success("Opened.")
        } catch (e: ActivityNotFoundException) {
            JarvisResult.Failure(
                "No app on this phone can handle that (${actionDescription(action)}).",
            )
        } catch (e: SecurityException) {
            JarvisResult.Failure(
                "Android refused to open that (${actionDescription(action)}): ${e.message}",
            )
        } catch (e: Exception) {
            JarvisResult.Failure(
                "Could not open that (${actionDescription(action)}): ${e.message}",
            )
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────

    /** The camera id of a camera with a flash, or null when there is none. */
    private fun findFlashCameraId(): String? {
        val manager = cameraManager ?: return null
        return try {
            manager.cameraIdList.firstOrNull { id ->
                val characteristics = manager.getCameraCharacteristics(id)
                characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Keeps only digits and a leading '+' so tel:/smsto: URIs are valid. */
    private fun sanitizePhoneNumber(number: String): String {
        val digits = number.filter { it.isDigit() }
        return if (number.trim().startsWith("+")) "+$digits" else digits
    }

    private fun actionDescription(action: SystemAction): String = when (action) {
        is SystemAction.Dial -> "dialer"
        is SystemAction.SendSms -> "messaging app"
        is SystemAction.SendEmail -> "email app"
        is SystemAction.ShareText -> "share sheet"
        is SystemAction.OpenApp -> "app ${action.packageName}"
        is SystemAction.SetAlarm -> "Clock app (alarm)"
        is SystemAction.SetTimer -> "Clock app (timer)"
        SystemAction.OpenWifiPanel -> "Wi-Fi settings panel"
        SystemAction.RequestBluetoothEnable -> "Bluetooth enable dialog"
        SystemAction.OpenClockApp -> "Clock app"
    }

    private fun VolumeStream.toAndroidStream(): Int = when (this) {
        VolumeStream.MUSIC -> AudioManager.STREAM_MUSIC
        VolumeStream.ALARM -> AudioManager.STREAM_ALARM
        VolumeStream.RING -> AudioManager.STREAM_RING
        VolumeStream.NOTIFICATION -> AudioManager.STREAM_NOTIFICATION
        VolumeStream.CALL -> AudioManager.STREAM_VOICE_CALL
        VolumeStream.SYSTEM -> AudioManager.STREAM_SYSTEM
    }

    private fun Int.toDndMode(): DndMode = when (this) {
        NotificationManager.INTERRUPTION_FILTER_ALL -> DndMode.OFF
        NotificationManager.INTERRUPTION_FILTER_ALARMS -> DndMode.ALARMS_ONLY
        NotificationManager.INTERRUPTION_FILTER_PRIORITY -> DndMode.PRIORITY_ONLY
        NotificationManager.INTERRUPTION_FILTER_NONE -> DndMode.TOTAL_SILENCE
        else -> DndMode.OFF
    }

    private fun DndMode.toInterruptionFilter(): Int = when (this) {
        DndMode.OFF -> NotificationManager.INTERRUPTION_FILTER_ALL
        DndMode.ALARMS_ONLY -> NotificationManager.INTERRUPTION_FILTER_ALARMS
        DndMode.PRIORITY_ONLY -> NotificationManager.INTERRUPTION_FILTER_PRIORITY
        DndMode.TOTAL_SILENCE -> NotificationManager.INTERRUPTION_FILTER_NONE
    }

    private suspend fun <T> io(block: suspend () -> JarvisResult<T>): JarvisResult<T> =
        withContext(Dispatchers.IO) { block() }

    private fun <T> runCatchingJarvisResult(block: () -> T): JarvisResult<T> =
        try {
            JarvisResult.Success(block())
        } catch (e: Exception) {
            JarvisResult.Failure(e.message ?: e::class.simpleName ?: "Unknown error", e)
        }

    private fun <T> JarvisResult<T>.mapFailure(
        transform: (JarvisResult.Failure) -> String,
    ): JarvisResult<T> = when (this) {
        is JarvisResult.Success -> this
        is JarvisResult.Failure -> JarvisResult.Failure(transform(this), cause)
    }
}
