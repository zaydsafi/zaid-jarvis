package com.zaid.jarvis.voice

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.zaid.jarvis.core.voice.SpeechTextSanitizer
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Locale
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Text-to-speech (Master Prompt §5.2). Thin wrapper around Android's
 * [TextToSpeech]: speaks the planner's final answer when in voice mode,
 * at the speed from Settings.
 *
 * Text is sanitized ([SpeechTextSanitizer]) before speaking so markdown
 * and URLs are not read out literally. Init is asynchronous — a speak
 * request that arrives before init completes is queued and spoken once
 * the engine is ready. [stop] is called by the kill switch and by any
 * new request, so Jarvis never talks over Zaid.
 */
interface SpeechOutput {
    /** True while an utterance is playing. */
    val isSpeaking: StateFlow<Boolean>

    /** Speaks [text] at [speechRate] in [languageTag]; stops any current speech. */
    fun speak(text: String, speechRate: Float, languageTag: String)

    /** Stops speaking immediately. */
    fun stop()

    /** Releases the engine; the instance must not be used afterwards. */
    fun shutdown()
}

class AndroidSpeechOutput @Inject constructor(
    @ApplicationContext private val context: Context,
) : SpeechOutput, TextToSpeech.OnInitListener {

    private val _isSpeaking = MutableStateFlow(false)
    override val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val tts: TextToSpeech = TextToSpeech(context, this)

    /** Speak request that arrived before init finished. */
    private var pending: PendingSpeak? = null
    private var initialized = false

    private data class PendingSpeak(
        val text: String,
        val speechRate: Float,
        val languageTag: String,
    )

    init {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                _isSpeaking.value = true
            }

            override fun onDone(utteranceId: String?) {
                _isSpeaking.value = false
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                _isSpeaking.value = false
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                _isSpeaking.value = false
            }
        })
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        initialized = true
        pending?.let { request ->
            pending = null
            speakNow(request)
        }
    }

    override fun speak(text: String, speechRate: Float, languageTag: String) {
        val clean = SpeechTextSanitizer.sanitize(text)
        if (clean.isBlank()) return
        val request = PendingSpeak(clean, speechRate, languageTag)
        if (!initialized) {
            pending = request
            return
        }
        speakNow(request)
    }

    private fun speakNow(request: PendingSpeak) {
        tts.stop()
        val locale = Locale.forLanguageTag(request.languageTag)
        val availability = tts.isLanguageAvailable(locale)
        val languageResult = if (availability >= TextToSpeech.LANG_AVAILABLE) {
            tts.setLanguage(locale)
        } else {
            // Fall back to the device default voice rather than failing.
            tts.setLanguage(Locale.getDefault())
        }
        if (languageResult == TextToSpeech.LANG_MISSING_DATA ||
            languageResult == TextToSpeech.LANG_NOT_SUPPORTED
        ) {
            return
        }
        tts.setSpeechRate(request.speechRate.coerceIn(0.5f, 2.0f))
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, UUID.randomUUID().toString())
        }
        tts.speak(request.text, TextToSpeech.QUEUE_FLUSH, params, UUID.randomUUID().toString())
    }

    override fun stop() {
        pending = null
        tts.stop()
        _isSpeaking.value = false
    }

    override fun shutdown() {
        stop()
        tts.shutdown()
    }
}
