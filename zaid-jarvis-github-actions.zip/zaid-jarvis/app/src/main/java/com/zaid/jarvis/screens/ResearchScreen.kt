package com.zaid.jarvis.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zaid.jarvis.core.research.ResearchRecord
import com.zaid.jarvis.core.research.formatBrief
import com.zaid.jarvis.viewmodel.ResearchViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Research history (Phase 7): run a new research job and browse past briefs.
 *
 * A job searches the web, reads the top pages, and writes a structured
 * brief with sources — every factual claim cites its source. Web content
 * is untrusted data: pages with instruction-like text are excluded from
 * the brief, and the brief says so.
 */
@Composable
fun ResearchScreen(
    viewModel: ResearchViewModel = hiltViewModel(),
) {
    val records by viewModel.records.collectAsState()
    val running by viewModel.running.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val message by viewModel.message.collectAsState()
    var topic by remember { mutableStateOf("") }
    var confirmClearAll by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Research", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Ask about any topic — Jarvis searches the web, reads the top pages, " +
                "and writes a brief with sources for every claim.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedTextField(
            value = topic,
            onValueChange = { topic = it },
            label = { Text("Topic to research") },
            placeholder = { Text("e.g. quantum computing breakthroughs") },
            singleLine = true,
            enabled = !running,
            modifier = Modifier.fillMaxWidth(),
        )
        Button(
            onClick = {
                viewModel.runResearch(topic)
                topic = ""
            },
            enabled = !running && topic.isNotBlank(),
        ) {
            Text(if (running) "Researching…" else "Research")
        }
        if (running) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CircularProgressIndicator()
                Column {
                    progress.forEach { line ->
                        Text(line, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        } else if (progress.isNotEmpty()) {
            Column {
                progress.forEach { line ->
                    Text(line, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("History", style = MaterialTheme.typography.titleMedium)
            if (records.isNotEmpty()) {
                OutlinedButton(onClick = { confirmClearAll = true }) {
                    Text("Clear all")
                }
            }
        }
        if (records.isEmpty()) {
            Text(
                "No research yet. Run your first topic above — or ask Jarvis in chat: " +
                    "“research quantum computing”.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(records, key = { it.id }) { record ->
                ResearchRecordCard(
                    record = record,
                    onDelete = { viewModel.deleteRecord(record.id) },
                )
            }
        }
    }

    message?.let {
        AlertDialog(
            onDismissRequest = viewModel::clearMessage,
            confirmButton = {
                TextButton(onClick = viewModel::clearMessage) { Text("OK") }
            },
            text = { Text(it) },
        )
    }
    if (confirmClearAll) {
        AlertDialog(
            onDismissRequest = { confirmClearAll = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteAllRecords()
                        confirmClearAll = false
                    },
                ) { Text("Clear all") }
            },
            dismissButton = {
                TextButton(onClick = { confirmClearAll = false }) { Text("Cancel") }
            },
            text = { Text("Delete all saved research? This cannot be undone.") },
        )
    }
}

@Composable
private fun ResearchRecordCard(
    record: ResearchRecord,
    onDelete: () -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    val dateFormat = remember { SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault()) }
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(record.topic, style = MaterialTheme.typography.titleMedium)
            Text(
                "${dateFormat.format(Date(record.createdAtMillis))} · " +
                    "${record.brief.sources.size} source(s) · " +
                    "${record.brief.keyFacts.size} cited fact(s)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                record.brief.summary,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = if (expanded) Int.MAX_VALUE else 3,
            )
            if (expanded) {
                Text(
                    formatBrief(record.brief),
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { expanded = !expanded }) {
                    Text(if (expanded) "Show less" else "Read full brief")
                }
                OutlinedButton(onClick = onDelete) {
                    Text("Delete")
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
        }
    }
}
