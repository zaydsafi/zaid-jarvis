package com.zaid.jarvis.social

import android.content.Context
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.zaid.jarvis.core.social.ScheduleValidation
import com.zaid.jarvis.core.social.ScheduledPost
import com.zaid.jarvis.core.social.ScheduledPostStatus
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.repository.ScheduledPostRepository
import com.zaid.jarvis.tools.social.SocialScheduler
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The [SocialScheduler] implementation (Phase 8): stores the schedule
 * in Room and enqueues a one-time WorkManager job for the publish time.
 *
 * The job has a network constraint (no point waking up offline) and
 * carries only the scheduled-post row id — the worker re-reads the
 * draft and re-checks the gate at run time, so nothing stale can be
 * published. Cancelling removes both the row's SCHEDULED status and
 * the WorkManager job.
 */
@Singleton
class WorkManagerSocialScheduler @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: ScheduledPostRepository,
) : SocialScheduler {

    override suspend fun schedule(
        draftId: Long,
        platform: SocialPlatform,
        accountHandle: String,
        scheduledAtMillis: Long,
        contentHash: String,
        imageUrl: String?,
    ): JarvisResult<ScheduledPost> {
        val now = System.currentTimeMillis()
        when (val valid = ScheduleValidation.validateScheduledTime(scheduledAtMillis, now)) {
            is JarvisResult.Failure -> return valid
            is JarvisResult.Success -> Unit
        }
        val post = ScheduledPost(
            draftId = draftId,
            platform = platform,
            accountHandle = accountHandle,
            scheduledAtMillis = scheduledAtMillis,
            contentHash = contentHash,
            imageUrl = imageUrl,
            status = ScheduledPostStatus.SCHEDULED,
        )
        val rowId = when (val saved = repository.save(post)) {
            is JarvisResult.Success -> saved.value
            is JarvisResult.Failure -> return saved
        }
        return try {
            val delayMillis = scheduledAtMillis - System.currentTimeMillis()
            val request = OneTimeWorkRequestBuilder<PublishPostWorker>()
                .setInitialDelay(delayMillis.coerceAtLeast(0L), TimeUnit.MILLISECONDS)
                .setInputData(
                    Data.Builder()
                        .putLong(PublishPostWorker.KEY_SCHEDULED_POST_ID, rowId)
                        .build(),
                )
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build(),
                )
                .addTag(PublishPostWorker.WORK_TAG)
                .build()
            WorkManager.getInstance(context).enqueue(request)
            repository.setWorkRequestId(rowId, request.id.toString())
            JarvisResult.Success(post.copy(id = rowId))
        } catch (e: Exception) {
            // Enqueueing failed — remove the row so a post that will
            // never run doesn't sit in the list looking scheduled.
            repository.deleteById(rowId)
            JarvisResult.Failure(
                "Could not schedule the post: ${e.message ?: e::class.simpleName}. " +
                    "Try again in a moment.",
            )
        }
    }

    override suspend fun cancel(scheduledPostId: Long): JarvisResult<Unit> {
        val post = repository.getById(scheduledPostId)
            ?: return JarvisResult.Failure("No scheduled post with id $scheduledPostId.")
        if (post.status != ScheduledPostStatus.SCHEDULED) {
            return JarvisResult.Failure(
                "Scheduled post #$scheduledPostId is already ${post.status.name.lowercase()} — " +
                    "there is nothing to cancel.",
            )
        }
        repository.workRequestIdFor(scheduledPostId)?.let { workId ->
            runCatching { WorkManager.getInstance(context).cancelWorkById(UUID.fromString(workId)) }
        }
        return repository.updateStatus(
            scheduledPostId,
            ScheduledPostStatus.CANCELLED,
            failureReason = "Cancelled by Zaid.",
        )
    }

    override suspend fun listAll(): List<ScheduledPost> = repository.getAll()

    override suspend fun getById(scheduledPostId: Long): ScheduledPost? =
        repository.getById(scheduledPostId)

    override suspend fun delete(scheduledPostId: Long) {
        repository.workRequestIdFor(scheduledPostId)?.let { workId ->
            runCatching { WorkManager.getInstance(context).cancelWorkById(UUID.fromString(workId)) }
        }
        repository.deleteById(scheduledPostId)
    }
}
