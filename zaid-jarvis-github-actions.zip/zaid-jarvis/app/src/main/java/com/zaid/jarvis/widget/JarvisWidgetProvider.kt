package com.zaid.jarvis.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent

/**
 * Home-screen widget (Master Prompt §5.4): orb + last-answer line +
 * mic button. See [WidgetUpdater] for the RemoteViews construction
 * and update logic; this provider only forwards lifecycle events.
 */
class JarvisWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray,
    ) {
        WidgetUpdater.updateAll(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            WidgetUpdater.updateAll(context)
        }
    }

    companion object {
        /** Broadcast action that forces a widget refresh. */
        const val ACTION_REFRESH: String = "com.zaid.jarvis.widget.ACTION_REFRESH"
    }
}
