package com.zaid.jarvis.productivity

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.zaid.jarvis.MainActivity
import com.zaid.jarvis.core.productivity.QuietHours
import com.zaid.jarvis.core.productivity.Task
import com.zaid.jarvis.core.productivity.formatDuration
import com.zaid.jarvis.data.datastore.SettingsRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.first

/**
 * Productivity & wellness notifications (Phase 9).
 *
 * One channel ("Productivity"). The quiet-hours rule lives here, in
 * one place: every proactive notification checks it before posting —
 * EXCEPT user-set task reminders and focus-session results, which
 * are explicit user requests (like an alarm), and the wind-down
 * nudge, which is exempt by design (bedtime, default 23:00, is
 * normally *inside* quiet hours, default 22:00–07:00 — the user
 * opted in and chose the time).
 *
 * Skipped silently when the notification permission isn't granted —
 * every outcome is also visible in-app (Tasks / Wellness screens),
 * so a missing permission never hides anything.
 */
@Singleton
class WellnessNotifier @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settingsRepository: SettingsRepository,
) {
    private val notificationManager: NotificationManager =
        context.getSystemService(NotificationManager::class.java)

    /**
     * A user-set task reminder. EXEMPT from quiet hours (the user
     * asked for this exact time). Tap opens the Tasks screen.
     */
    fun notifyTaskReminder(taskId: Long, title: String) {
        notify(
            id = NOTIFICATION_ID_BASE + (taskId % 1000).toInt(),
            title = "Reminder",
            text = title,
            contentIntent = openDestinationIntent(
                MainActivity.DESTINATION_TASKS,
                NOTIFICATION_ID_BASE + (taskId % 1000).toInt(),
            ),
        )
    }

    /**
     * Smart overdue nudge: one summary notification for the tasks
     * that became due for a nudge. Respects quiet hours (skipped
     * inside them — the worker retries on its next run).
     */
    suspend fun notifyOverdue(tasks: List<Task>) {
        if (tasks.isEmpty()) return
        if (isQuietNow()) return
        val text = if (tasks.size == 1) {
            "“${tasks.first().title}” is overdue."
        } else {
            val named = tasks.take(3).joinToString(", ") { "“${it.title}”" }
            val more = if (tasks.size > 3) " and ${tasks.size - 3} more" else ""
            "$named$more ${if (tasks.size == 1) "is" else "are"} overdue."
        }
        notify(
            id = NOTIFICATION_ID_OVERDUE,
            title = "Overdue task${if (tasks.size == 1) "" else "s"}",
            text = text,
            contentIntent = openDestinationIntent(
                MainActivity.DESTINATION_TASKS,
                NOTIFICATION_ID_OVERDUE,
            ),
        )
    }

    /**
     * The daily digest (morning briefing summary). Respects quiet
     * hours — if the configured digest time falls inside quiet
     * hours, that day's digest is skipped.
     */
    suspend fun notifyDigest(briefingText: String) {
        if (isQuietNow()) return
        notify(
            id = NOTIFICATION_ID_DIGEST,
            title = "Your morning briefing",
            text = briefingText,
            contentIntent = openDestinationIntent(
                MainActivity.DESTINATION_TASKS,
                NOTIFICATION_ID_DIGEST,
            ),
        )
    }

    /** A break reminder. Respects quiet hours. Tap opens Wellness. */
    suspend fun notifyBreak(continuousMillis: Long) {
        if (isQuietNow()) return
        notify(
            id = NOTIFICATION_ID_BREAK,
            title = "Time for a break?",
            text = "You've been on your phone for ${formatDuration(continuousMillis)} " +
                "without a break — stretch?",
            contentIntent = openDestinationIntent(
                MainActivity.DESTINATION_WELLNESS,
                NOTIFICATION_ID_BREAK,
            ),
        )
    }

    /**
     * The wind-down nudge. EXEMPT from quiet hours by design (see the
     * class doc). The notification alone never changes any setting:
     * "Wind down now" opens the Wellness screen, where the DND +
     * dimming action goes through the normal gated approval path.
     */
    fun notifyWindDown() {
        val intent = openDestinationIntent(
            MainActivity.DESTINATION_WELLNESS,
            NOTIFICATION_ID_WIND_DOWN,
        )
        if (!canPost()) return
        ensureChannel()
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Time to wind down")
            .setContentText("It's bedtime — want me to enable Do Not Disturb and dim the screen?")
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "It's bedtime — want me to enable Do Not Disturb and dim the screen? " +
                        "Tap to open Wellness and confirm.",
                ),
            )
            .setContentIntent(intent)
            .addAction(
                android.R.drawable.ic_dialog_info,
                "Wind down now",
                intent,
            )
            .setAutoCancel(true)
            .build()
        notificationManager.notify(NOTIFICATION_ID_WIND_DOWN, notification)
    }

    /**
     * A focus session ended on time. EXEMPT from quiet hours (the
     * user started the timer; like an alarm, it reports back).
     * [dndRestored] is false when the DND restore failed — the
     * notification says so honestly instead of claiming success.
     */
    fun notifyFocusEnded(durationMinutes: Int, dndRestored: Boolean = true) {
        val text = if (dndRestored) {
            "$durationMinutes minutes of focus — done. Do Not Disturb is back to normal."
        } else {
            "$durationMinutes minutes of focus — done. I couldn't restore Do Not Disturb " +
                "automatically; please check it in Settings."
        }
        notify(
            id = NOTIFICATION_ID_FOCUS,
            title = "Focus session complete",
            text = text,
            contentIntent = openDestinationIntent(
                MainActivity.DESTINATION_WELLNESS,
                NOTIFICATION_ID_FOCUS,
            ),
        )
    }

    /** True when the current time is inside the user's quiet hours. */
    suspend fun isQuietNow(nowMillis: Long = System.currentTimeMillis()): Boolean {
        val settings = settingsRepository.settings.first()
        val quiet = QuietHours(
            startMinute = settings.quietHoursStartMinute,
            endMinute = settings.quietHoursEndMinute,
        )
        return quiet.isQuietAt(nowMillis)
    }

    private fun openDestinationIntent(destination: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            putExtra(MainActivity.EXTRA_DESTINATION, destination)
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun canPost(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return false
        }
        return true
    }

    private fun notify(id: Int, title: String, text: String, contentIntent: PendingIntent) {
        if (!canPost()) return
        ensureChannel()
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(contentIntent)
            .setAutoCancel(true)
            .build()
        notificationManager.notify(id, notification)
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        if (notificationManager.getNotificationChannel(CHANNEL_ID) != null) return
        notificationManager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "Productivity",
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = "Task reminders, overdue nudges, the daily digest, " +
                    "break reminders, wind-down, and focus sessions."
            },
        )
    }

    private companion object {
        const val CHANNEL_ID: String = "jarvis_productivity"
        const val NOTIFICATION_ID_BASE: Int = 9000
        const val NOTIFICATION_ID_OVERDUE: Int = 9100
        const val NOTIFICATION_ID_DIGEST: Int = 9101
        const val NOTIFICATION_ID_BREAK: Int = 9102
        const val NOTIFICATION_ID_WIND_DOWN: Int = 9103
        const val NOTIFICATION_ID_FOCUS: Int = 9104
    }
}
