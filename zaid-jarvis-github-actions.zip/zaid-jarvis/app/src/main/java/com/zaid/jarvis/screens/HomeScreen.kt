package com.zaid.jarvis.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.zaid.jarvis.ui.components.JarvisOrb
import com.zaid.jarvis.viewmodel.ConfirmationViewModel
import com.zaid.jarvis.viewmodel.HomeViewModel
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

/**
 * Voice-first home screen (Master Prompt §5.1).
 * Phase 1: orb + greeting + quick-action chips (chips are decorative until
 * the voice engine lands in Phase 4 and the agent in Phase 3).
 * Phase 2: the kill switch button and a link to the audit log.
 * Phase 4: tapping the orb opens Chat and starts voice listening.
 * Phase 9: today's schedule (read-only calendar) + tasks due today,
 * "Daily briefing" and "Set a reminder" chips wired up.
 */
@Composable
fun HomeScreen(
    confirmationViewModel: ConfirmationViewModel = hiltViewModel(),
    homeViewModel: HomeViewModel = hiltViewModel(),
    onNavigateToAuditLog: () -> Unit = {},
    onNavigateToMacros: () -> Unit = {},
    onNavigateToResearch: () -> Unit = {},
    onNavigateToDrafts: () -> Unit = {},
    onNavigateToScheduledPosts: () -> Unit = {},
    onNavigateToTasks: () -> Unit = {},
    onNavigateToWellness: () -> Unit = {},
    onNavigateToNotes: () -> Unit = {},
    onNavigateToChat: () -> Unit = {},
    onOrbTap: () -> Unit = {},
) {
    var stoppedMessage by remember { mutableStateOf<String?>(null) }
    val tasksDueTodayCount by homeViewModel.tasksDueTodayCount.collectAsState()
    val overdueCount by homeViewModel.overdueCount.collectAsState()
    val todayEvents by homeViewModel.todayEvents.collectAsState()
    val calendarAvailable by homeViewModel.calendarAvailable.collectAsState()

    // Refresh every time Home is shown (tasks/events change over the day).
    LaunchedEffect(Unit) { homeViewModel.refresh() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        JarvisOrb(modifier = Modifier.clickable(onClick = onOrbTap))
        Spacer(modifier = Modifier.height(32.dp))
        Text(
            text = "Hello, Zaid.",
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Tap the orb and speak — or type below.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )

        // ── Phase 9: today at a glance ──────────────────────────────
        Spacer(modifier = Modifier.height(16.dp))
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onNavigateToTasks),
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text("Today", style = MaterialTheme.typography.titleMedium)
                Text(
                    when {
                        tasksDueTodayCount == 0 && overdueCount == 0 ->
                            "No tasks due today."
                        tasksDueTodayCount == 0 ->
                            "$overdueCount overdue task${if (overdueCount == 1) "" else "s"}."
                        overdueCount == 0 ->
                            "$tasksDueTodayCount task${if (tasksDueTodayCount == 1) "" else "s"} due today."
                        else ->
                            "$tasksDueTodayCount task${if (tasksDueTodayCount == 1) "" else "s"} due today, " +
                                "$overdueCount overdue."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (overdueCount > 0) {
                        MaterialTheme.colorScheme.error
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                )
                if (calendarAvailable) {
                    if (todayEvents.isEmpty()) {
                        Text(
                            "No events on your calendar today.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    } else {
                        todayEvents.take(3).forEach { event ->
                            Text(
                                "${formatTime(event.startMillis)}  ${event.title}" +
                                    (if (event.location.isNotBlank()) " · ${event.location}" else ""),
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                        if (todayEvents.size > 3) {
                            Text(
                                "…and ${todayEvents.size - 3} more",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                } else {
                    Text(
                        "Calendar not connected — grant calendar access in Settings to see " +
                            "today's schedule here.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        // Quick-action chips (Phase 1: visual only).
        SuggestionChip(onClick = onNavigateToChat, label = { Text("Daily briefing") })
        SuggestionChip(onClick = onNavigateToResearch, label = { Text("Trending topics") })
        SuggestionChip(onClick = onNavigateToTasks, label = { Text("Set a reminder") })
        SuggestionChip(onClick = onNavigateToTasks, label = { Text("Tasks") })
        SuggestionChip(onClick = onNavigateToNotes, label = { Text("Notes") })
        SuggestionChip(onClick = onNavigateToWellness, label = { Text("Wellness") })
        SuggestionChip(onClick = onNavigateToAuditLog, label = { Text("Audit log") })
        SuggestionChip(onClick = onNavigateToMacros, label = { Text("Macros") })
        SuggestionChip(onClick = onNavigateToResearch, label = { Text("Research") })
        SuggestionChip(onClick = onNavigateToDrafts, label = { Text("Drafts") })
        SuggestionChip(onClick = onNavigateToScheduledPosts, label = { Text("Scheduled posts") })
        Spacer(modifier = Modifier.height(24.dp))
        // Kill switch (Master Prompt §2.4): one tap cancels everything.
        OutlinedButton(
            onClick = {
                confirmationViewModel.stopAll()
                stoppedMessage = "All automation stopped."
            },
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = MaterialTheme.colorScheme.error,
            ),
        ) {
            Icon(Icons.Filled.Stop, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Stop Jarvis")
        }
        stoppedMessage?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = it,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                textAlign = TextAlign.Center,
            )
        }
    }
}

private fun formatTime(epochMillis: Long): String {
    val time = Instant.ofEpochMilli(epochMillis).atZone(ZoneId.systemDefault())
    return time.format(DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT))
}
