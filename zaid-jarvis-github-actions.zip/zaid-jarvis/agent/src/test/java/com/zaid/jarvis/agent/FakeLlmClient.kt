package com.zaid.jarvis.agent

import com.zaid.jarvis.core.model.LlmProvider
import com.zaid.jarvis.core.util.JarvisResult

/**
 * Deterministic fake LLM client (Master Prompt §8: "Fake-LLM test harness
 * for deterministic agent tests").
 *
 * Script responses in order with [thenRespond]; the client returns them one
 * at a time and records every request it received. Use [thenFail] to script
 * failures. When the script runs out, the last response repeats — tests
 * never hang waiting for a response that was never scripted.
 *
 * Test-only: never used in production.
 */
class FakeLlmClient(
    override val provider: LlmProvider = LlmProvider.CLAUDE,
) : LlmProviderClient {

    private val script = ArrayDeque<JarvisResult<LlmResponse>>()
    private var last: JarvisResult<LlmResponse>? = null

    /** Every request the planner sent, in order. */
    val requestsReceived = mutableListOf<LlmRequest>()

    /** Number of times [chat] was called. */
    val callCount: Int get() = requestsReceived.size

    fun thenRespond(response: LlmResponse): FakeLlmClient {
        script.addLast(JarvisResult.Success(response))
        return this
    }

    fun thenRespondText(text: String, usage: LlmUsage = LlmUsage(10, 5)): FakeLlmClient =
        thenRespond(LlmResponse(text = text, usage = usage))

    fun thenFail(message: String): FakeLlmClient {
        script.addLast(JarvisResult.Failure(message))
        return this
    }

    override suspend fun chat(request: LlmRequest): JarvisResult<LlmResponse> {
        requestsReceived += request
        val next = script.removeFirstOrNull() ?: last
            ?: return JarvisResult.Failure("FakeLlmClient has no scripted response.")
        last = next
        return next
    }
}

/** A fake tool executor for planner tests (no Confirmation Engine involved). */
class FakeToolExecutor(
    private val handler: (String, kotlinx.serialization.json.JsonObject) -> JarvisResult<String>,
) : ToolExecutor {
    val calls = mutableListOf<Pair<String, kotlinx.serialization.json.JsonObject>>()

    override suspend fun execute(
        toolName: String,
        params: kotlinx.serialization.json.JsonObject,
    ): JarvisResult<String> {
        calls += toolName to params
        return handler(toolName, params)
    }
}
