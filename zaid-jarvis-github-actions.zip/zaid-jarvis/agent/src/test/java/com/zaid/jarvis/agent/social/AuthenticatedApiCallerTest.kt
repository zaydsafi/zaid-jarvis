package com.zaid.jarvis.agent.social

import com.zaid.jarvis.core.social.OAuthClientCredentials
import com.zaid.jarvis.core.social.OAuthTokens
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.social.NoOpSocialAccountStore
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Token refresh logic (Phase 8) with an OkHttp interceptor standing in
 * for the network — no real HTTP. Covers: 401 → refresh → retry once,
 * proactive refresh of an expired token, refresh failure → disconnected
 * (tokens cleared), and a second 401 after refresh → disconnected.
 */
class AuthenticatedApiCallerTest {

    /**
     * A scripted fake server: [tweetResponses] is the sequence of HTTP
     * codes the API endpoint returns; [tokenResponse] is what the token
     * endpoint returns (null = 400 invalid_grant).
     */
    private class FakeServer(
        private val tweetResponses: ArrayDeque<Int>,
        private val tokenResponse: String?,
    ) : Interceptor {
        var tweetCalls = 0
        var tokenCalls = 0

        private val jsonMediaType = "application/json".toMediaType()

        override fun intercept(chain: Interceptor.Chain): Response {
            val request = chain.request()
            val url = request.url.toString()
            return if (url.contains("oauth2/token")) {
                tokenCalls++
                if (tokenResponse != null) {
                    response(request, 200, tokenResponse)
                } else {
                    response(request, 400, """{"error":"invalid_grant","error_description":"Token expired"}""")
                }
            } else {
                tweetCalls++
                val code = if (tweetResponses.isEmpty()) 200 else tweetResponses.removeFirst()
                val body = if (code in 200..299) {
                    """{"data":{"id":"1","text":"Hello"}}"""
                } else {
                    """{"title":"Unauthorized","detail":"Unauthorized"}"""
                }
                response(request, code, body)
            }
        }

        private fun response(request: Request, code: Int, body: String): Response =
            Response.Builder()
                .request(request)
                .protocol(Protocol.HTTP_1_1)
                .code(code)
                .message("Fake")
                .body(body.toResponseBody(jsonMediaType))
                .build()
    }

    private fun callerFor(server: FakeServer, store: NoOpSocialAccountStore): AuthenticatedApiCaller {
        val client = OkHttpClient.Builder().addInterceptor(server).build()
        return AuthenticatedApiCaller(client, store, OAuthClient(client))
    }

    private fun tweetRequest(token: String): Request =
        Request.Builder()
            .url("https://api.x.com/2/tweets")
            .header("Authorization", "Bearer $token")
            .get()
            .build()

    private val parseOk: (Int, String, Response) -> JarvisResult<String> =
        { status, _, _ ->
            if (status in 200..299) JarvisResult.Success("ok") else JarvisResult.Failure("HTTP $status")
        }

    private val newTokensJson =
        """{"access_token":"new-token","refresh_token":"new-refresh","expires_in":7200,"token_type":"bearer"}"""

    @Test
    fun `a 401 refreshes the token once and retries the call`() = runBlocking {
        val store = NoOpSocialAccountStore()
        store.saveTokens(
            SocialPlatform.X,
            OAuthTokens("old-token", "refresh-token", System.currentTimeMillis() + 3_600_000L),
        )
        store.saveClientCredentials(SocialPlatform.X, OAuthClientCredentials("cid"))
        val server = FakeServer(ArrayDeque(listOf(401, 200)), newTokensJson)
        val caller = callerFor(server, store)

        val result = caller.call(SocialPlatform.X, ::tweetRequest, parseOk)

        assertTrue(result is JarvisResult.Success)
        assertEquals("ok", (result as JarvisResult.Success).value)
        assertEquals(2, server.tweetCalls)
        assertEquals(1, server.tokenCalls)
        assertEquals("new-token", store.getTokens(SocialPlatform.X)?.accessToken)
        assertEquals("new-refresh", store.getTokens(SocialPlatform.X)?.refreshToken)
    }

    @Test
    fun `an expired token is refreshed before the call, not after a 401`() = runBlocking {
        val store = NoOpSocialAccountStore()
        store.saveTokens(
            SocialPlatform.X,
            OAuthTokens("old-token", "refresh-token", System.currentTimeMillis() - 1_000L),
        )
        store.saveClientCredentials(SocialPlatform.X, OAuthClientCredentials("cid"))
        val server = FakeServer(ArrayDeque(listOf(200)), newTokensJson)
        val caller = callerFor(server, store)

        val result = caller.call(SocialPlatform.X, ::tweetRequest, parseOk)

        assertTrue(result is JarvisResult.Success)
        assertEquals(1, server.tweetCalls) // No wasted 401 round-trip.
        assertEquals(1, server.tokenCalls)
        assertEquals("new-token", store.getTokens(SocialPlatform.X)?.accessToken)
    }

    @Test
    fun `a failed refresh disconnects the account and clears its tokens`() = runBlocking {
        val store = NoOpSocialAccountStore()
        store.saveTokens(
            SocialPlatform.X,
            OAuthTokens("old-token", "refresh-token", System.currentTimeMillis() + 3_600_000L),
        )
        store.saveClientCredentials(SocialPlatform.X, OAuthClientCredentials("cid"))
        val server = FakeServer(ArrayDeque(listOf(401)), tokenResponse = null)
        val caller = callerFor(server, store)

        val result = caller.call(SocialPlatform.X, ::tweetRequest, parseOk)

        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("reconnect"))
        assertNull(store.getTokens(SocialPlatform.X))
    }

    @Test
    fun `a second 401 after refresh disconnects the account`() = runBlocking {
        val store = NoOpSocialAccountStore()
        store.saveTokens(
            SocialPlatform.X,
            OAuthTokens("old-token", "refresh-token", System.currentTimeMillis() + 3_600_000L),
        )
        store.saveClientCredentials(SocialPlatform.X, OAuthClientCredentials("cid"))
        val server = FakeServer(ArrayDeque(listOf(401, 401)), newTokensJson)
        val caller = callerFor(server, store)

        val result = caller.call(SocialPlatform.X, ::tweetRequest, parseOk)

        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("revoked"))
        assertNull(store.getTokens(SocialPlatform.X))
        assertEquals(1, server.tokenCalls) // Exactly one refresh attempt.
    }

    @Test
    fun `no stored tokens fails without touching the network`() = runBlocking {
        val store = NoOpSocialAccountStore()
        val server = FakeServer(ArrayDeque(listOf(200)), newTokensJson)
        val caller = callerFor(server, store)

        val result = caller.call(SocialPlatform.X, ::tweetRequest, parseOk)

        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("No X / Twitter account connected"))
        assertEquals(0, server.tweetCalls)
        assertEquals(0, server.tokenCalls)
    }
}
