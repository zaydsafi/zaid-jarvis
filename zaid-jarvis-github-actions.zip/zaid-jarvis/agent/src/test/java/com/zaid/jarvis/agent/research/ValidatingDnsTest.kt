package com.zaid.jarvis.agent.research

import java.net.InetAddress
import java.net.UnknownHostException
import okhttp3.Dns
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/**
 * DNS-rebinding guard (Phase 11) with a fake delegate Dns — no real
 * resolution, no network. The delegate returns scripted addresses;
 * the guard must refuse the lookup when ANY of them is non-public.
 */
class ValidatingDnsTest {

    private class FakeDns(private val addresses: List<InetAddress>) : Dns {
        override fun lookup(hostname: String): List<InetAddress> = addresses
    }

    private class FailingDns(private val message: String = "no such host") : Dns {
        override fun lookup(hostname: String): List<InetAddress> =
            throw UnknownHostException(message)
    }

    private fun address(host: String): InetAddress = InetAddress.getByName(host)

    /** A genuine 16-byte IPv4-mapped address (::ffff:a.b.c.d). */
    private fun mappedAddress(a: Int, b: Int, c: Int, d: Int): InetAddress =
        InetAddress.getByAddress(
            byteArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xFF.toByte(), 0xFF.toByte(), a.toByte(), b.toByte(), c.toByte(), d.toByte()),
        )

    private fun assertRefused(dns: Dns, hostname: String): UnknownHostException {
        return try {
            dns.lookup(hostname)
            fail("Expected lookup($hostname) to throw UnknownHostException")
            throw AssertionError("unreachable")
        } catch (e: UnknownHostException) {
            e
        }
    }

    @Test
    fun `a hostname resolving to a public ip is allowed`() {
        val dns = ValidatingDns(FakeDns(listOf(address("93.184.216.34"), address("2606:2800:220:1:248:1893:25c8:1946"))))
        val resolved = dns.lookup("example.com")
        assertEquals(2, resolved.size)
    }

    @Test
    fun `a hostname resolving to a private ip is refused`() {
        val dns = ValidatingDns(FakeDns(listOf(address("192.168.1.1"))))
        val error = assertRefused(dns, "evil.example.com")
        assertTrue(error.message!!.contains("evil.example.com"))
        assertTrue(error.message!!.contains("private"))
    }

    @Test
    fun `a hostname resolving to public and private ips is refused`() {
        // Mixed answers fail closed: one private address poisons the
        // whole lookup, even when a public address is also present.
        val dns = ValidatingDns(
            FakeDns(listOf(address("93.184.216.34"), address("10.0.0.5"))),
        )
        assertRefused(dns, "mixed.example.com")
    }

    @Test
    fun `loopback and link-local addresses are refused`() {
        val loopback = ValidatingDns(FakeDns(listOf(address("127.0.0.1"))))
        assertRefused(loopback, "localhost.example.com")
        val linkLocal = ValidatingDns(FakeDns(listOf(address("169.254.169.254"))))
        assertRefused(linkLocal, "metadata.example.com")
        val ipv6Loopback = ValidatingDns(FakeDns(listOf(address("::1"))))
        assertRefused(ipv6Loopback, "v6.example.com")
        val ipv6LinkLocal = ValidatingDns(FakeDns(listOf(address("fe80::1"))))
        assertRefused(ipv6LinkLocal, "v6ll.example.com")
    }

    @Test
    fun `a hostname that fails to resolve gives a clear error, no crash`() {
        val dns = ValidatingDns(FailingDns("nonexistent.invalid: Name or service not known"))
        val error = assertRefused(dns, "nonexistent.invalid")
        assertTrue(error.message!!.contains("nonexistent.invalid"))
    }

    @Test
    fun `an empty answer is refused with a clear error`() {
        val dns = ValidatingDns(FakeDns(emptyList()))
        val error = assertRefused(dns, "empty.example.com")
        assertTrue(error.message!!.contains("empty.example.com"))
    }

    @Test
    fun `ipv4-mapped addresses embedding private ips are refused`() {
        val loopback = ValidatingDns(FakeDns(listOf(mappedAddress(127, 0, 0, 1))))
        assertRefused(loopback, "mapped.example.com")
        val private = ValidatingDns(FakeDns(listOf(mappedAddress(192, 168, 0, 5))))
        assertRefused(private, "mapped2.example.com")
    }

    @Test
    fun `ipv4-mapped addresses embedding public ips are allowed`() {
        val dns = ValidatingDns(FakeDns(listOf(mappedAddress(8, 8, 8, 8))))
        assertEquals(1, dns.lookup("mapped-public.example.com").size)
    }

    @Test
    fun `ipv4-compatible addresses embedding private ips are refused`() {
        val dns = ValidatingDns(FakeDns(listOf(address("::127.0.0.1"))))
        assertRefused(dns, "compat.example.com")
    }

    @Test
    fun `integer-form ip spellings are caught at resolution`() {
        // "2130706433" looks like a hostname to the literal check, but
        // resolution normalizes it to 127.0.0.1 — the guard sees the
        // real address.
        val dns = ValidatingDns(FakeDns(listOf(address("2130706433"))))
        assertRefused(dns, "2130706433")
    }
}
