package com.zaid.jarvis.agent

import com.zaid.jarvis.core.model.LlmProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ResponseCacheTest {

    private fun request(text: String) = LlmRequest(
        provider = LlmProvider.CLAUDE,
        modelApiId = "m",
        messages = listOf(ChatMessage(role = "user", content = text)),
        tools = emptyList(),
    )

    @Test
    fun `put then get returns the response`() {
        val cache = ResponseCache()
        val response = LlmResponse(text = "answer")
        cache.put(request("hello"), response)
        assertEquals(response, cache.get(request("hello")))
    }

    @Test
    fun `different prompt misses`() {
        val cache = ResponseCache()
        cache.put(request("hello"), LlmResponse(text = "answer"))
        assertNull(cache.get(request("goodbye")))
    }

    @Test
    fun `tool-calling responses are never cached`() {
        val cache = ResponseCache()
        val response = LlmResponse(
            text = "",
            toolCalls = listOf(LlmToolCall("c1", "echo", "{}")),
        )
        cache.put(request("hello"), response)
        assertNull(cache.get(request("hello")))
    }

    @Test
    fun `entries expire after the ttl`() {
        var now = 1_000_000L
        val cache = ResponseCache(clock = { now })
        cache.put(request("hello"), LlmResponse(text = "answer"))
        assertEquals(LlmResponse(text = "answer"), cache.get(request("hello")))
        now += 16 * 60 * 1000L // 16 minutes > 15-minute TTL.
        assertNull(cache.get(request("hello")))
    }

    @Test
    fun `oldest entry is evicted past capacity`() {
        val cache = ResponseCache(maxEntries = 2)
        cache.put(request("a"), LlmResponse(text = "1"))
        cache.put(request("b"), LlmResponse(text = "2"))
        cache.put(request("c"), LlmResponse(text = "3"))
        assertNull(cache.get(request("a")))
        assertEquals(LlmResponse(text = "2"), cache.get(request("b")))
        assertEquals(LlmResponse(text = "3"), cache.get(request("c")))
    }
}
