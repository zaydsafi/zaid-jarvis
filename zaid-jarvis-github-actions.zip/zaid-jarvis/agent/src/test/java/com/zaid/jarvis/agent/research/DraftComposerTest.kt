package com.zaid.jarvis.agent.research

import com.zaid.jarvis.agent.FakeLlmClient
import com.zaid.jarvis.agent.UsageRecorder
import com.zaid.jarvis.agent.UsageTracker
import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.core.model.JarvisSettings
import com.zaid.jarvis.core.research.DraftStatus
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.db.ContentDraftDao
import com.zaid.jarvis.data.db.ContentDraftEntity
import com.zaid.jarvis.data.repository.DraftRepository
import com.zaid.jarvis.tools.research.DraftRequest
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Draft generation (Phase 7) with a fake LLM — no real API calls.
 * Length limits are enforced in code, never trusted to the model.
 */
class DraftComposerTest {

    private class FakeDraftDao : ContentDraftDao {
        private val rows = mutableListOf<ContentDraftEntity>()
        private var nextId = 1L

        override fun observeAll(limit: Int): Flow<List<ContentDraftEntity>> =
            flowOf(rows.take(limit))
        override suspend fun getAll(): List<ContentDraftEntity> = rows.toList()
        override suspend fun getAllIds(): List<Long> = rows.map { it.id }
        override suspend fun getById(id: Long): ContentDraftEntity? = rows.find { it.id == id }
        override suspend fun upsert(entity: ContentDraftEntity): Long {
            return if (entity.id == 0L) {
                val id = nextId++
                rows += entity.copy(id = id)
                id
            } else {
                rows.removeAll { it.id == entity.id }
                rows += entity
                entity.id
            }
        }

        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
        }

        override suspend fun deleteAll() = rows.clear()
        override suspend fun count(): Int = rows.size
    }

    private fun composer(
        llm: FakeLlmClient,
        dao: FakeDraftDao = FakeDraftDao(),
    ): Pair<DraftComposer, DraftRepository> {
        val repository = DraftRepository(dao)
        val composer = DraftComposer(
            clientResolver = { JarvisResult.Success(llm) },
            modelResolver = { "test-model" },
            usageTracker = UsageTracker(UsageRecorder { _, _ -> }),
            killSwitch = KillSwitch(),
            settingsProvider = { JarvisSettings() },
            draftRepository = repository,
        )
        return composer to repository
    }

    private fun request(topic: String = "new collection", platform: String = "X / Twitter") =
        DraftRequest(topic = topic, platform = platform, tone = "warm")

    @Test
    fun `happy path saves a DRAFT with the generated text`() = runBlocking {
        val llm = FakeLlmClient().thenRespondText("Our new collection is here! ✂️")
        val (composer, repository) = composer(llm)

        val result = composer.generate(request())
        assertTrue(result is JarvisResult.Success)
        val generated = (result as JarvisResult.Success).value
        assertEquals("Our new collection is here! ✂️", generated.draft.body)
        assertEquals(DraftStatus.DRAFT, generated.draft.status)
        assertEquals(280, generated.charLimit)
        assertFalse(generated.truncated)
        assertFalse(generated.wasRewritten)
        assertTrue(generated.draft.id > 0)

        // The draft is actually stored.
        assertEquals(1, repository.count())
        val stored = repository.getById(generated.draft.id)
        assertEquals("new collection", stored?.title)
        assertEquals(DraftStatus.DRAFT, stored?.status)
    }

    @Test
    fun `over-limit first attempt triggers exactly one rewrite`() = runBlocking {
        val tooLong = "x".repeat(300)
        val llm = FakeLlmClient()
            .thenRespondText(tooLong)
            .thenRespondText("Short version.")
        val (composer, _) = composer(llm)

        val result = composer.generate(request())
        val generated = (result as JarvisResult.Success).value
        assertEquals("Short version.", generated.draft.body)
        assertTrue(generated.wasRewritten)
        assertFalse(generated.truncated)
        assertEquals(2, llm.callCount)
    }

    @Test
    fun `still over the limit after the rewrite is truncated honestly`() = runBlocking {
        val llm = FakeLlmClient()
            .thenRespondText("a".repeat(400))
            .thenRespondText("b".repeat(350))
        val (composer, _) = composer(llm)

        val result = composer.generate(request())
        val generated = (result as JarvisResult.Success).value
        assertEquals(280, generated.draft.body.length)
        assertTrue(generated.draft.body.endsWith("…"))
        assertTrue(generated.truncated)
        assertTrue(generated.wasRewritten)
        assertEquals(2, llm.callCount) // never more than one retry
    }

    @Test
    fun `code fences and surrounding quotes are stripped`() = runBlocking {
        val llm = FakeLlmClient().thenRespondText("```text\nHello, world!\n```")
        val (composer, _) = composer(llm)
        val result = composer.generate(request())
        val generated = (result as JarvisResult.Success).value
        assertEquals("Hello, world!", generated.draft.body)
    }

    @Test
    fun `quotes inside the post survive`() = runBlocking {
        val llm = FakeLlmClient().thenRespondText("He said \"hello\" to the crowd.")
        val (composer, _) = composer(llm)
        val result = composer.generate(request())
        val generated = (result as JarvisResult.Success).value
        assertEquals("He said \"hello\" to the crowd.", generated.draft.body)
    }

    @Test
    fun `a failing LLM call fails the generation`() = runBlocking {
        val llm = FakeLlmClient().thenFail("rate limited")
        val (composer, repository) = composer(llm)
        val result = composer.generate(request())
        assertTrue(result is JarvisResult.Failure)
        assertEquals(0, repository.count())
    }

    @Test
    fun `instagram limit is 2200 not 280`() = runBlocking {
        val llm = FakeLlmClient().thenRespondText("i".repeat(500))
        val (composer, _) = composer(llm)
        val result = composer.generate(request(platform = "Instagram"))
        val generated = (result as JarvisResult.Success).value
        assertEquals(2200, generated.charLimit)
        assertFalse(generated.truncated)
        assertEquals(500, generated.draft.body.length)
    }
}
