package com.zaid.jarvis.agent

import com.zaid.jarvis.agent.clients.parseClaudeResponse
import com.zaid.jarvis.agent.clients.parseGeminiResponse
import com.zaid.jarvis.agent.clients.parseOpenAiCompatibleResponse
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Recorded JSON fixtures for provider response parsing (Master Prompt §8:
 * no real API calls in tests). Fixtures mirror the real wire formats.
 */
class ProviderParsingTest {

    // ── Claude (Anthropic Messages API) ──────────────────────────────────

    @Test
    fun `claude text response parses`() {
        val response = parseClaudeResponse(
            """
            {
              "id": "msg_01",
              "type": "message",
              "role": "assistant",
              "content": [{"type": "text", "text": "Paris is the capital of France."}],
              "model": "claude-sonnet-5-5",
              "stop_reason": "end_turn",
              "usage": {"input_tokens": 12, "output_tokens": 9}
            }
            """.trimIndent(),
        )
        assertEquals("Paris is the capital of France.", response.text)
        assertTrue(response.toolCalls.isEmpty())
        assertEquals(12, response.usage.inputTokens)
        assertEquals(9, response.usage.outputTokens)
        assertEquals("end_turn", response.finishReason)
    }

    @Test
    fun `claude tool use response parses`() {
        val response = parseClaudeResponse(
            """
            {
              "id": "msg_02",
              "type": "message",
              "role": "assistant",
              "content": [
                {"type": "text", "text": "I'll check the time."},
                {"type": "tool_use", "id": "toolu_123", "name": "get_time", "input": {}}
              ],
              "model": "claude-sonnet-5-5",
              "stop_reason": "tool_use",
              "usage": {"input_tokens": 20, "output_tokens": 15}
            }
            """.trimIndent(),
        )
        assertEquals(1, response.toolCalls.size)
        assertEquals("toolu_123", response.toolCalls[0].id)
        assertEquals("get_time", response.toolCalls[0].name)
        assertEquals("tool_use", response.finishReason)
    }

    // ── OpenAI-compatible (OpenAI, OpenRouter, custom) ──────────────────

    @Test
    fun `openai text response parses`() {
        val response = parseOpenAiCompatibleResponse(
            """
            {
              "id": "chatcmpl-1",
              "object": "chat.completion",
              "created": 1794772020,
              "model": "gpt-5",
              "choices": [{
                "index": 0,
                "message": {"role": "assistant", "content": "Hello!"},
                "finish_reason": "stop"
              }],
              "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}
            }
            """.trimIndent(),
        )
        assertEquals("Hello!", response.text)
        assertEquals(10, response.usage.inputTokens)
        assertEquals(5, response.usage.outputTokens)
        assertEquals("stop", response.finishReason)
    }

    @Test
    fun `openai tool call response parses`() {
        val response = parseOpenAiCompatibleResponse(
            """
            {
              "id": "chatcmpl-2",
              "object": "chat.completion",
              "created": 1794772020,
              "model": "gpt-5",
              "choices": [{
                "index": 0,
                "message": {
                  "role": "assistant",
                  "content": null,
                  "tool_calls": [{
                    "id": "call_abc",
                    "type": "function",
                    "function": {"name": "calculator", "arguments": "{\"expression\":\"2+2\"}"}
                  }]
                },
                "finish_reason": "tool_calls"
              }],
              "usage": {"prompt_tokens": 30, "completion_tokens": 12, "total_tokens": 42}
            }
            """.trimIndent(),
        )
        assertEquals(1, response.toolCalls.size)
        assertEquals("call_abc", response.toolCalls[0].id)
        assertEquals("calculator", response.toolCalls[0].name)
        assertTrue(response.toolCalls[0].argumentsJson.contains("2+2"))
        assertEquals("tool_calls", response.finishReason)
    }

    @Test
    fun `openai response without usage defaults to zero tokens`() {
        val response = parseOpenAiCompatibleResponse(
            """
            {
              "id": "chatcmpl-3",
              "object": "chat.completion",
              "created": 1794772020,
              "model": "local-model",
              "choices": [{
                "index": 0,
                "message": {"role": "assistant", "content": "Local answer."},
                "finish_reason": "stop"
              }]
            }
            """.trimIndent(),
        )
        assertEquals("Local answer.", response.text)
        assertEquals(0, response.usage.inputTokens)
        assertEquals(0, response.usage.outputTokens)
    }

    // ── Gemini ───────────────────────────────────────────────────────────

    @Test
    fun `gemini text response parses`() {
        val response = parseGeminiResponse(
            """
            {
              "candidates": [{
                "content": {
                  "parts": [{"text": "Gemini says hello."}],
                  "role": "model"
                },
                "finishReason": "STOP"
              }],
              "usageMetadata": {"promptTokenCount": 8, "candidatesTokenCount": 6, "totalTokenCount": 14}
            }
            """.trimIndent(),
        )
        assertEquals("Gemini says hello.", response.text)
        assertEquals(8, response.usage.inputTokens)
        assertEquals(6, response.usage.outputTokens)
        assertEquals("STOP", response.finishReason)
    }

    @Test
    fun `gemini function call parses with tool name as call id`() {
        val response = parseGeminiResponse(
            """
            {
              "candidates": [{
                "content": {
                  "parts": [{
                    "functionCall": {
                      "name": "get_time",
                      "args": {}
                    }
                  }],
                  "role": "model"
                },
                "finishReason": "STOP"
              }],
              "usageMetadata": {"promptTokenCount": 15, "candidatesTokenCount": 7, "totalTokenCount": 22}
            }
            """.trimIndent(),
        )
        assertEquals(1, response.toolCalls.size)
        // Gemini has no call ids; the tool name is the pairing key.
        assertEquals("get_time", response.toolCalls[0].id)
        assertEquals("get_time", response.toolCalls[0].name)
    }

    @Test
    fun `gemini blocked response yields an empty text answer`() {
        val response = parseGeminiResponse(
            """
            {
              "candidates": [],
              "promptFeedback": {"blockReason": "SAFETY"}
            }
            """.trimIndent(),
        )
        assertEquals("", response.text)
        assertTrue(response.toolCalls.isEmpty())
    }
}
