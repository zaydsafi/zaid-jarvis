package com.zaid.jarvis.agent.social

import com.zaid.jarvis.core.confirmation.sha256Hex
import com.zaid.jarvis.core.research.ContentDraft
import com.zaid.jarvis.core.research.DraftStatus
import com.zaid.jarvis.core.social.PublishRequest
import com.zaid.jarvis.core.social.PublishResult
import com.zaid.jarvis.core.social.ScheduledPost
import com.zaid.jarvis.core.social.ScheduledPostStatus
import com.zaid.jarvis.core.social.SocialAccount
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.db.ContentDraftDao
import com.zaid.jarvis.data.db.ContentDraftEntity
import com.zaid.jarvis.data.db.ScheduledPostDao
import com.zaid.jarvis.data.db.ScheduledPostEntity
import com.zaid.jarvis.data.repository.DraftRepository
import com.zaid.jarvis.data.repository.ScheduledPostRepository
import com.zaid.jarvis.tools.social.SocialPublisher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The publishing gate (Phase 8) with fake DAOs and a fake publisher:
 * DRAFT refused, APPROVED allowed, edited-after-approval refused,
 * over-limit refused, PUBLISHED only via markPublished, and scheduled
 * posts cancelled (never published stale) when the draft changed.
 */
class PublishServiceTest {

    private class FakeDraftDao : ContentDraftDao {
        val rows = mutableListOf<ContentDraftEntity>()
        private var nextId = 1L

        override fun observeAll(limit: Int): Flow<List<ContentDraftEntity>> =
            flowOf(rows.take(limit))
        override suspend fun getAll(): List<ContentDraftEntity> = rows.toList()
        override suspend fun getAllIds(): List<Long> = rows.map { it.id }
        override suspend fun getById(id: Long): ContentDraftEntity? = rows.find { it.id == id }
        override suspend fun upsert(entity: ContentDraftEntity): Long {
            return if (entity.id == 0L) {
                val id = nextId++
                rows += entity.copy(id = id)
                id
            } else {
                rows.removeAll { it.id == entity.id }
                rows += entity
                entity.id
            }
        }

        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
        }

        override suspend fun deleteAll() = rows.clear()
        override suspend fun count(): Int = rows.size
    }

    private class FakeScheduledPostDao : ScheduledPostDao {
        val rows = mutableListOf<ScheduledPostEntity>()
        private var nextId = 1L

        override fun observeAll(limit: Int): Flow<List<ScheduledPostEntity>> =
            flowOf(rows.take(limit))
        override suspend fun getAll(): List<ScheduledPostEntity> = rows.toList()
        override suspend fun getAllIds(): List<Long> = rows.map { it.id }
        override suspend fun getById(id: Long): ScheduledPostEntity? = rows.find { it.id == id }
        override suspend fun upsert(entity: ScheduledPostEntity): Long {
            return if (entity.id == 0L) {
                val id = nextId++
                rows += entity.copy(id = id)
                id
            } else {
                rows.removeAll { it.id == entity.id }
                rows += entity
                entity.id
            }
        }

        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
        }

        override suspend fun deleteAll() = rows.clear()
        override suspend fun count(): Int = rows.size
    }

    private class FakePublisher(
        var result: JarvisResult<PublishResult> = JarvisResult.Success(
            PublishResult(SocialPlatform.X, "post-1", "https://x.com/zaid/status/post-1", 1000L),
        ),
    ) : SocialPublisher {
        val published = mutableListOf<PublishRequest>()

        override suspend fun connectedAccount(platform: SocialPlatform): SocialAccount? =
            SocialAccount(platform, "42", "zaid", "Zaid")

        override suspend fun publish(request: PublishRequest): JarvisResult<PublishResult> {
            published += request
            return result
        }

        override suspend fun fetchProfile(platform: SocialPlatform): JarvisResult<SocialAccount> =
            JarvisResult.Success(SocialAccount(platform, "42", "zaid", "Zaid"))
    }

    private class Fixture {
        val draftDao = FakeDraftDao()
        val postDao = FakeScheduledPostDao()
        val draftRepository = DraftRepository(draftDao)
        val postRepository = ScheduledPostRepository(postDao)
        val publisher = FakePublisher()
        val service = PublishServiceImpl(draftRepository, postRepository, publisher)

        suspend fun saveDraft(
            status: DraftStatus = DraftStatus.APPROVED,
            body: String = "Hello from Jarvis.",
            platform: String = "X / Twitter",
            approvedBodyHash: String? = sha256Hex(body),
        ): Long {
            val id = draftDao.upsert(
                ContentDraftEntity(
                    title = "Test",
                    body = body,
                    platform = platform,
                    status = status.name,
                    approvedBodyHash = approvedBodyHash,
                    createdAtMillis = 0L,
                    updatedAtMillis = 0L,
                ),
            )
            return id
        }

        suspend fun saveScheduledPost(
            draftId: Long,
            body: String = "Hello from Jarvis.",
            platform: SocialPlatform = SocialPlatform.X,
            status: ScheduledPostStatus = ScheduledPostStatus.SCHEDULED,
        ): Long {
            return postDao.upsert(
                ScheduledPostEntity(
                    draftId = draftId,
                    platform = platform.name,
                    accountHandle = "zaid",
                    scheduledAtMillis = 1_700_000_000_000L,
                    contentHash = sha256Hex(body),
                    status = status.name,
                    createdAtMillis = 0L,
                    updatedAtMillis = 0L,
                ),
            )
        }
    }

    // ── publishDraftNow ──────────────────────────────────────────────

    @Test
    fun `an APPROVED draft publishes and becomes PUBLISHED`() = runBlocking {
        val f = Fixture()
        val draftId = f.saveDraft()
        val result = f.service.publishDraftNow(draftId)
        assertTrue(result is JarvisResult.Success)
        assertEquals("https://x.com/zaid/status/post-1", (result as JarvisResult.Success).value.postUrl)
        assertEquals(DraftStatus.PUBLISHED, f.draftRepository.getById(draftId)?.status)
        assertEquals(1, f.publisher.published.size)
    }

    @Test
    fun `a DRAFT is refused and nothing is published`() = runBlocking {
        val f = Fixture()
        val draftId = f.saveDraft(status = DraftStatus.DRAFT)
        val result = f.service.publishDraftNow(draftId)
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("approve it"))
        assertTrue(f.publisher.published.isEmpty())
        assertEquals(DraftStatus.DRAFT, f.draftRepository.getById(draftId)?.status)
    }

    @Test
    fun `an already-published draft is refused`() = runBlocking {
        val f = Fixture()
        val draftId = f.saveDraft(status = DraftStatus.PUBLISHED)
        val result = f.service.publishDraftNow(draftId)
        assertTrue(result is JarvisResult.Failure)
        assertTrue(f.publisher.published.isEmpty())
    }

    @Test
    fun `a draft edited after approval is refused until re-approved`() = runBlocking {
        val f = Fixture()
        val draftId = f.saveDraft(
            body = "Hello from Jarvis — edited.",
            approvedBodyHash = sha256Hex("Hello from Jarvis."),
        )
        val result = f.service.publishDraftNow(draftId)
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("edited after"))
        assertTrue(f.publisher.published.isEmpty())
    }

    @Test
    fun `a draft approved before Phase 8 (no hash) can still publish`() = runBlocking {
        val f = Fixture()
        val draftId = f.saveDraft(approvedBodyHash = null)
        val result = f.service.publishDraftNow(draftId)
        assertTrue(result is JarvisResult.Success)
    }

    @Test
    fun `over-limit text is refused and never truncated`() = runBlocking {
        val f = Fixture()
        val longBody = "x".repeat(281) // X limit is 280
        val draftId = f.saveDraft(body = longBody)
        val result = f.service.publishDraftNow(draftId)
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("over the"))
        assertTrue(f.publisher.published.isEmpty())
    }

    @Test
    fun `text exactly at the limit publishes`() = runBlocking {
        val f = Fixture()
        val draftId = f.saveDraft(body = "x".repeat(280))
        val result = f.service.publishDraftNow(draftId)
        assertTrue(result is JarvisResult.Success)
    }

    @Test
    fun `a non-social platform is refused`() = runBlocking {
        val f = Fixture()
        val draftId = f.saveDraft(platform = "Blog")
        val result = f.service.publishDraftNow(draftId)
        assertTrue(result is JarvisResult.Failure)
        assertTrue(f.publisher.published.isEmpty())
    }

    @Test
    fun `an Instagram draft without an image URL is refused`() = runBlocking {
        val f = Fixture()
        val draftId = f.saveDraft(platform = "Instagram")
        val result = f.service.publishDraftNow(draftId, imageUrl = null)
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("photo"))
        assertTrue(f.publisher.published.isEmpty())
    }

    @Test
    fun `an Instagram draft with an image URL publishes with it`() = runBlocking {
        val f = Fixture()
        val draftId = f.saveDraft(platform = "Instagram")
        val result = f.service.publishDraftNow(draftId, imageUrl = "https://example.com/p.jpg")
        assertTrue(result is JarvisResult.Success)
        assertEquals("https://example.com/p.jpg", f.publisher.published.single().imageUrl)
    }

    @Test
    fun `a publish failure leaves the draft APPROVED`() = runBlocking {
        val f = Fixture()
        f.publisher.result = JarvisResult.Failure("X said no.")
        val draftId = f.saveDraft()
        val result = f.service.publishDraftNow(draftId)
        assertTrue(result is JarvisResult.Failure)
        assertEquals(DraftStatus.APPROVED, f.draftRepository.getById(draftId)?.status)
    }

    // ── publishScheduled ─────────────────────────────────────────────

    @Test
    fun `an unchanged scheduled post publishes and marks both rows`() = runBlocking {
        val f = Fixture()
        val draftId = f.saveDraft()
        val postId = f.saveScheduledPost(draftId)
        val result = f.service.publishScheduled(postId)
        assertTrue(result is JarvisResult.Success)
        assertEquals(DraftStatus.PUBLISHED, f.draftRepository.getById(draftId)?.status)
        val post = f.postRepository.getById(postId)
        assertEquals(ScheduledPostStatus.PUBLISHED, post?.status)
        assertEquals("https://x.com/zaid/status/post-1", post?.postUrl)
    }

    @Test
    fun `a scheduled post is cancelled when the draft text changed`() = runBlocking {
        val f = Fixture()
        val draftId = f.saveDraft(body = "Hello from Jarvis — edited.")
        // Scheduled against the ORIGINAL text.
        val postId = f.saveScheduledPost(draftId, body = "Hello from Jarvis.")
        val result = f.service.publishScheduled(postId)
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("cancelled"))
        assertTrue(f.publisher.published.isEmpty())
        val post = f.postRepository.getById(postId)
        assertEquals(ScheduledPostStatus.CANCELLED, post?.status)
        assertTrue(post?.failureReason?.contains("changed since scheduling") == true)
    }

    @Test
    fun `a scheduled post is cancelled when the draft was edited after approval`() = runBlocking {
        // Phase 11 regression: the draft was edited AFTER approval but
        // BEFORE scheduling, so the schedule-time hash matches the
        // edited text — the hash check alone cannot catch it. The
        // approval binding must cancel the post instead of publishing
        // text Zaid never approved.
        val f = Fixture()
        val draftId = f.saveDraft(
            body = "Edited text Zaid never approved.",
            approvedBodyHash = sha256Hex("Original approved text."),
        )
        val postId = f.saveScheduledPost(draftId, body = "Edited text Zaid never approved.")
        val result = f.service.publishScheduled(postId)
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("cancelled"))
        assertTrue(f.publisher.published.isEmpty())
        val post = f.postRepository.getById(postId)
        assertEquals(ScheduledPostStatus.CANCELLED, post?.status)
        assertTrue(post?.failureReason?.contains("edited after approval") == true)
        assertEquals(DraftStatus.APPROVED, f.draftRepository.getById(draftId)?.status)
    }

    @Test
    fun `a scheduled post is cancelled when the draft is no longer approved`() = runBlocking {
        val f = Fixture()
        val draftId = f.saveDraft(status = DraftStatus.DRAFT)
        val postId = f.saveScheduledPost(draftId)
        val result = f.service.publishScheduled(postId)
        assertTrue(result is JarvisResult.Failure)
        assertTrue(f.publisher.published.isEmpty())
        assertEquals(
            ScheduledPostStatus.CANCELLED,
            f.postRepository.getById(postId)?.status,
        )
    }

    @Test
    fun `a scheduled post fails when the draft was deleted`() = runBlocking {
        val f = Fixture()
        val postId = f.saveScheduledPost(draftId = 999L)
        val result = f.service.publishScheduled(postId)
        assertTrue(result is JarvisResult.Failure)
        assertEquals(ScheduledPostStatus.FAILED, f.postRepository.getById(postId)?.status)
    }

    @Test
    fun `a scheduled post that already ran is refused`() = runBlocking {
        val f = Fixture()
        val draftId = f.saveDraft()
        val postId = f.saveScheduledPost(draftId, status = ScheduledPostStatus.PUBLISHED)
        val result = f.service.publishScheduled(postId)
        assertTrue(result is JarvisResult.Failure)
        assertTrue(f.publisher.published.isEmpty())
    }

    @Test
    fun `a failed publish marks the scheduled post FAILED with the reason`() = runBlocking {
        val f = Fixture()
        f.publisher.result = JarvisResult.Failure("X is down.")
        val draftId = f.saveDraft()
        val postId = f.saveScheduledPost(draftId)
        val result = f.service.publishScheduled(postId)
        assertTrue(result is JarvisResult.Failure)
        val post = f.postRepository.getById(postId)
        assertEquals(ScheduledPostStatus.FAILED, post?.status)
        assertEquals("X is down.", post?.failureReason)
        assertEquals(DraftStatus.APPROVED, f.draftRepository.getById(draftId)?.status)
    }
}
