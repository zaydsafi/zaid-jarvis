package com.zaid.jarvis.agent

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ConversationContextTest {

    @Test
    fun `messages are kept in order`() {
        val context = ConversationContext()
        context.addUser("Hello")
        context.addAssistant("Hi there")
        val messages = context.snapshot()
        assertEquals(2, messages.size)
        assertEquals("Hello", messages[0].content)
        assertEquals("Hi there", messages[1].content)
    }

    @Test
    fun `context is bounded to twenty messages`() {
        val context = ConversationContext()
        repeat(15) { i ->
            context.addUser("q$i")
            context.addAssistant("a$i")
        }
        assertEquals(20, context.size())
        // 30 messages went in, the oldest 10 were dropped, the newest kept.
        assertEquals("q5", context.snapshot().first().content)
        assertEquals("a14", context.snapshot().last().content)
    }

    @Test
    fun `tool results are prefixed with the tool name`() {
        val context = ConversationContext()
        context.addToolResult("call-1", "get_time", "Sunday, 15 November 2026")
        val messages = context.snapshot()
        assertEquals(1, messages.size)
        assertTrue(messages[0].content.startsWith("get_time: "))
        assertEquals("call-1", messages[0].toolCallId)
    }
}
