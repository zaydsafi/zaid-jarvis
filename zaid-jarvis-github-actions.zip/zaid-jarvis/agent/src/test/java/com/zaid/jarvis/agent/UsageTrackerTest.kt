package com.zaid.jarvis.agent

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class UsageTrackerTest {

    @Test
    fun `records tokens and estimated cost`() = runBlocking {
        val recorded = mutableListOf<Pair<Long, Double>>()
        val tracker = UsageTracker(UsageRecorder { tokens, cost -> recorded += tokens to cost })
        tracker.record("claude-sonnet-5-5", LlmUsage(inputTokens = 1_000, outputTokens = 500))
        assertEquals(1, recorded.size)
        assertEquals(1_500L, recorded[0].first)
        // 1000 * $3/1M + 500 * $15/1M = $0.003 + $0.0075 = $0.0105.
        assertEquals(0.0105, recorded[0].second, 0.000001)
    }

    @Test
    fun `zero usage records nothing`() = runBlocking {
        var calls = 0
        val tracker = UsageTracker(UsageRecorder { _, _ -> calls++ })
        tracker.record("gpt-5", LlmUsage(0, 0))
        assertEquals(0, calls)
    }

    @Test
    fun `unknown model still records an estimated cost`() = runBlocking {
        val recorded = mutableListOf<Pair<Long, Double>>()
        val tracker = UsageTracker(UsageRecorder { tokens, cost -> recorded += tokens to cost })
        tracker.record("mystery-model", LlmUsage(100, 100))
        assertEquals(1, recorded.size)
        assertTrue(recorded[0].second > 0.0)
    }
}
