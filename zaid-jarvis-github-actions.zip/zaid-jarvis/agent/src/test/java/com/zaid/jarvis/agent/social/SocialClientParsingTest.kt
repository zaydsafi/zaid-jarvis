package com.zaid.jarvis.agent.social

import com.zaid.jarvis.core.social.SocialAccount
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.core.util.JarvisResult
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Platform client request/response parsing (Phase 8) from recorded
 * fixtures — no network. The live flows are thin sequences of these
 * calls, so a parsing mistake here is a publishing mistake in
 * production; the fixtures pin the exact shapes each platform returns.
 */
class SocialClientParsingTest {

    private val xAccount = SocialAccount(SocialPlatform.X, "12345", "zaid", "Zaid")

    private fun responseWithHeaders(vararg headers: Pair<String, String>): Response {
        val builder = Response.Builder()
            .request(Request.Builder().url("https://example.com/").build())
            .protocol(Protocol.HTTP_1_1)
            .code(201)
            .message("Created")
            .body("".toResponseBody())
        headers.forEach { (name, value) -> builder.header(name, value) }
        return builder.build()
    }

    // ── X ────────────────────────────────────────────────────────────

    @Test
    fun `X publish response parses the post id and builds the URL`() {
        val body = """{"data":{"id":"187654321","text":"Hello from Jarvis."}}"""
        val result = XSocialClient.parsePublishResponse(201, body, xAccount, nowMillis = 1000L)
        assertTrue(result is JarvisResult.Success)
        val published = (result as JarvisResult.Success).value
        assertEquals("187654321", published.postId)
        assertEquals("https://x.com/zaid/status/187654321", published.postUrl)
        assertEquals(SocialPlatform.X, published.platform)
        assertEquals(1000L, published.publishedAtMillis)
    }

    @Test
    fun `X publish error surfaces the platform message`() {
        val body = """{"errors":[{"message":"You are not permitted to create a Tweet with duplicate content.","code":187}],"title":"Forbidden","detail":"Forbidden","status":403}"""
        val result = XSocialClient.parsePublishResponse(403, body, xAccount)
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("duplicate content"))
    }

    @Test
    fun `X profile response parses id, username, and name`() {
        val body = """{"data":{"id":"12345","name":"Zaid","username":"zaid"}}"""
        val result = XSocialClient.parseProfileResponse(body)
        assertTrue(result is JarvisResult.Success)
        val account = (result as JarvisResult.Success).value
        assertEquals("12345", account.accountId)
        assertEquals("zaid", account.handle)
        assertEquals("Zaid", account.displayName)
    }

    @Test
    fun `X profile response without a username fails plainly`() {
        val result = XSocialClient.parseProfileResponse("""{"data":{"id":"12345"}}""")
        assertTrue(result is JarvisResult.Failure)
    }

    // ── Threads ──────────────────────────────────────────────────────

    @Test
    fun `Threads container response parses the container id`() {
        val result = ThreadsSocialClient.parseContainerResponse(200, """{"id":"1234567890"}""")
        assertTrue(result is JarvisResult.Success)
        assertEquals("1234567890", (result as JarvisResult.Success).value)
    }

    @Test
    fun `Threads publish response parses the media id`() {
        val result = ThreadsSocialClient.parsePublishContainerResponse(
            200,
            """{"id":"987654321"}""",
        )
        assertTrue(result is JarvisResult.Success)
        assertEquals("987654321", (result as JarvisResult.Success).value)
    }

    @Test
    fun `Threads permalink response parses the permalink`() {
        val result = ThreadsSocialClient.parsePermalinkResponse(
            200,
            """{"permalink":"https://www.threads.net/@zaid/post/abc123","id":"987654321"}""",
        )
        assertTrue(result is JarvisResult.Success)
        assertEquals(
            "https://www.threads.net/@zaid/post/abc123",
            (result as JarvisResult.Success).value,
        )
    }

    @Test
    fun `Threads profile response parses id, username, and name`() {
        val body = """{"id":"12345","username":"zaid","name":"Zaid"}"""
        val result = ThreadsSocialClient.parseProfileResponse(body)
        assertTrue(result is JarvisResult.Success)
        val account = (result as JarvisResult.Success).value
        assertEquals(SocialPlatform.THREADS, account.platform)
        assertEquals("zaid", account.handle)
    }

    @Test
    fun `Threads Graph error surfaces the error message`() {
        val body = """{"error":{"message":"The access token is invalid.","type":"OAuthException","code":190}}"""
        val result = ThreadsSocialClient.parseContainerResponse(400, body)
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("access token is invalid"))
    }

    // ── LinkedIn ─────────────────────────────────────────────────────

    @Test
    fun `LinkedIn publish reads the post URN from the x-restli-id header`() {
        val response = responseWithHeaders("x-restli-id" to "urn:li:share:1234567890")
        val result = LinkedInSocialClient.parsePublishResponse(201, "", response, nowMillis = 2000L)
        assertTrue(result is JarvisResult.Success)
        val published = (result as JarvisResult.Success).value
        assertEquals("urn:li:share:1234567890", published.postId)
        assertEquals(
            "https://www.linkedin.com/feed/update/urn:li:share:1234567890",
            published.postUrl,
        )
        assertEquals(2000L, published.publishedAtMillis)
    }

    @Test
    fun `LinkedIn publish without the header fails plainly`() {
        val response = responseWithHeaders()
        val result = LinkedInSocialClient.parsePublishResponse(201, "", response)
        assertTrue(result is JarvisResult.Failure)
    }

    @Test
    fun `LinkedIn userinfo parses the person id and name`() {
        val body = """{"sub":"AbCdEf123","name":"Zaid Safi","given_name":"Zaid","family_name":"Safi"}"""
        val result = LinkedInSocialClient.parseProfileResponse(body)
        assertTrue(result is JarvisResult.Success)
        val account = (result as JarvisResult.Success).value
        assertEquals("AbCdEf123", account.accountId)
        assertEquals("Zaid Safi", account.displayName)
        assertEquals("Zaid Safi", account.handle) // userinfo has no username
    }

    // ── Instagram ────────────────────────────────────────────────────

    @Test
    fun `Instagram container and publish responses parse ids`() {
        val container = InstagramSocialClient.parseContainerResponse(200, """{"id":"17841400008460056"}""")
        assertEquals("17841400008460056", (container as JarvisResult.Success).value)
        val published = InstagramSocialClient.parsePublishContainerResponse(
            200,
            """{"id":"17841400008460057"}""",
        )
        assertEquals("17841400008460057", (published as JarvisResult.Success).value)
    }

    @Test
    fun `Instagram publish failure hints at the image URL`() {
        val body = """{"error":{"message":"Media ID is not available","code":9007}}"""
        val result = InstagramSocialClient.parsePublishContainerResponse(400, body)
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("public"))
    }

    @Test
    fun `Instagram pages response finds the linked business account`() {
        val body = """
            {"data":[
              {"id":"111","name":"No IG here"},
              {"id":"222","name":"My Page","instagram_business_account":{"id":"17841400008460056"}}
            ]}
        """.trimIndent()
        val result = InstagramSocialClient.parsePagesResponse(200, body)
        assertTrue(result is JarvisResult.Success)
        assertEquals("17841400008460056", (result as JarvisResult.Success).value)
    }

    @Test
    fun `Instagram pages response without a linked account explains the fix`() {
        val body = """{"data":[{"id":"111","name":"No IG here"}]}"""
        val result = InstagramSocialClient.parsePagesResponse(200, body)
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("Business or Creator"))
    }

    @Test
    fun `Instagram profile response parses id and username`() {
        val body = """{"id":"17841400008460056","username":"zaid","name":"Zaid"}"""
        val result = InstagramSocialClient.parseProfileResponse(body)
        assertTrue(result is JarvisResult.Success)
        val account = (result as JarvisResult.Success).value
        assertEquals("17841400008460056", account.accountId)
        assertEquals("zaid", account.handle)
    }

    // ── Token responses ──────────────────────────────────────────────

    @Test
    fun `token response parses access token, refresh token, and expiry`() {
        val body = """{"token_type":"bearer","expires_in":7200,"access_token":"abc","refresh_token":"def","scope":"tweet.read tweet.write"}"""
        val result = OAuthClient.parseTokenResponse(body, nowMillis = 1_700_000_000_000L)
        assertTrue(result is JarvisResult.Success)
        val tokens = (result as JarvisResult.Success).value
        assertEquals("abc", tokens.accessToken)
        assertEquals("def", tokens.refreshToken)
        assertEquals(1_700_000_000_000L + 7_200_000L, tokens.expiresAtMillis)
    }

    @Test
    fun `token response without an access token fails`() {
        val result = OAuthClient.parseTokenResponse("""{"expires_in":7200}""", 0L)
        assertTrue(result is JarvisResult.Failure)
    }

    @Test
    fun `long-lived token response without a refresh token is fine`() {
        val body = """{"access_token":"long-lived","token_type":"bearer","expires_in":5184000}"""
        val result = OAuthClient.parseTokenResponse(body, nowMillis = 1_000L)
        assertTrue(result is JarvisResult.Success)
        val tokens = (result as JarvisResult.Success).value
        assertEquals("long-lived", tokens.accessToken)
        assertNull(tokens.refreshToken)
        assertEquals(1_000L + 5_184_000_000L, tokens.expiresAtMillis)
    }

    // ── Error mapping ────────────────────────────────────────────────

    @Test
    fun `rate-limit errors say to wait and retry`() {
        val result = XSocialClient.parsePublishResponse(
            429,
            """{"title":"Too Many Requests","detail":"Too Many Requests"}""",
            xAccount,
        )
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("rate-limited"))
    }

    @Test
    fun `server errors say to try again later`() {
        val result = LinkedInSocialClient.parsePublishResponse(
            503,
            "",
            responseWithHeaders(),
        )
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("try again"))
    }
}
