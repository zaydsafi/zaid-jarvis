package com.zaid.jarvis.agent.productivity

import com.zaid.jarvis.agent.FakeLlmClient
import com.zaid.jarvis.agent.LlmUsage
import com.zaid.jarvis.agent.UsageRecorder
import com.zaid.jarvis.agent.UsageTracker
import com.zaid.jarvis.core.model.JarvisSettings
import com.zaid.jarvis.core.productivity.CalendarEvent
import com.zaid.jarvis.core.productivity.Task
import com.zaid.jarvis.core.productivity.TaskStatus
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.productivity.BriefingProvider
import com.zaid.jarvis.tools.productivity.CalendarReader
import com.zaid.jarvis.tools.productivity.NoOpTaskStore
import com.zaid.jarvis.tools.productivity.TaskStore
import java.time.LocalDate
import java.time.ZoneId
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** BriefingService (Phase 9): LLM polish + plain fallback, never fails. */
class BriefingServiceTest {

    private val zone: ZoneId = ZoneId.systemDefault()
    private val nowMillis: Long = 1_793_050_200_000L // 2026-11-15 10:30 UTC

    private class FakeTaskStore(private val tasks: List<Task>) : TaskStore by NoOpTaskStore() {
        override suspend fun listAll(): List<Task> = tasks
    }

    private class FakeCalendarReader(
        private val events: List<CalendarEvent>,
        private val access: Boolean = true,
    ) : CalendarReader {
        override fun hasCalendarAccess(): Boolean = access

        override suspend fun eventsBetween(
            startMillis: Long,
            endMillis: Long,
        ): JarvisResult<List<CalendarEvent>> =
            JarvisResult.Success(events.filter { it.startMillis in startMillis until endMillis })
    }

    private fun service(
        tasks: List<Task> = emptyList(),
        events: List<CalendarEvent> = emptyList(),
        calendarAccess: Boolean = true,
        client: FakeLlmClient? = null,
        clientFailure: String? = null,
    ): BriefingProvider {
        val usageTracker = UsageTracker(UsageRecorder { _, _ -> })
        return BriefingService(
            taskStore = FakeTaskStore(tasks),
            calendarReader = FakeCalendarReader(events, calendarAccess),
            clientResolver = { settings ->
                when {
                    clientFailure != null -> JarvisResult.Failure(clientFailure)
                    client != null -> JarvisResult.Success(client)
                    else -> JarvisResult.Failure("No API key stored.")
                }
            },
            modelResolver = { "test-model" },
            usageTracker = usageTracker,
            settingsProvider = { JarvisSettings() },
            nowMillis = { nowMillis },
            zone = zone,
        )
    }

    private fun todayAt(hour: Int): Long {
        val date = LocalDate.ofInstant(java.time.Instant.ofEpochMilli(nowMillis), zone)
        return date.atTime(hour, 0).atZone(zone).toInstant().toEpochMilli()
    }

    @Test
    fun `LLM briefing returns the polished text and records usage`() = runBlocking {
        val recorded = mutableListOf<Pair<Long, Double>>()
        val usageTracker = UsageTracker(UsageRecorder { tokens, cost -> recorded += tokens to cost })
        val client = FakeLlmClient().thenRespondText(
            "Good morning! Dentist at 15:00, and milk is on your list.",
            LlmUsage(inputTokens = 100, outputTokens = 20),
        )
        val briefingService = BriefingService(
            taskStore = FakeTaskStore(
                listOf(Task(title = "Buy milk", dueAtMillis = todayAt(18))),
            ),
            calendarReader = FakeCalendarReader(
                listOf(
                    CalendarEvent(
                        id = 1,
                        title = "Dentist",
                        startMillis = todayAt(15),
                        endMillis = todayAt(16),
                    ),
                ),
            ),
            clientResolver = { JarvisResult.Success(client) },
            modelResolver = { "test-model" },
            usageTracker = usageTracker,
            settingsProvider = { JarvisSettings() },
            nowMillis = { nowMillis },
            zone = zone,
        )
        val result = briefingService.briefing()
        assertTrue(result is JarvisResult.Success)
        val text = (result as JarvisResult.Success).value
        assertTrue(text.contains("Dentist"))
        assertTrue(text.contains("milk"))
        // The LLM saw the facts in its prompt.
        assertTrue(client.requestsReceived.first().messages.first().content.contains("Dentist"))
        assertTrue(client.requestsReceived.first().messages.first().content.contains("Buy milk"))
        assertEquals(1, recorded.size)
        assertEquals(120L, recorded[0].first)
    }

    @Test
    fun `no LLM key falls back to the plain template`() = runBlocking {
        val provider = service(
            tasks = listOf(Task(title = "Buy milk", dueAtMillis = todayAt(18))),
            clientFailure = "No Claude API key stored.",
        )
        val result = provider.briefing()
        assertTrue(result is JarvisResult.Success)
        val text = (result as JarvisResult.Success).value
        assertTrue(text.contains("Buy milk"))
        assertTrue(text.contains("Due today"))
    }

    @Test
    fun `an LLM failure falls back to the plain template`() = runBlocking {
        val client = FakeLlmClient().thenFail("HTTP 500")
        val provider = service(
            tasks = listOf(
                Task(title = "Pay rent", dueAtMillis = todayAt(9)), // Overdue by 10:30.
            ),
            client = client,
        )
        val result = provider.briefing()
        assertTrue(result is JarvisResult.Success)
        val text = (result as JarvisResult.Success).value
        assertTrue(text.contains("Pay rent"))
        assertTrue(text.contains("Overdue"))
    }

    @Test
    fun `an empty LLM reply falls back to the plain template`() = runBlocking {
        val client = FakeLlmClient().thenRespondText("   ")
        val provider = service(client = client)
        val result = provider.briefing()
        assertTrue(result is JarvisResult.Success)
        assertTrue((result as JarvisResult.Success).value.contains("clear day"))
    }

    @Test
    fun `no calendar access is explained, tasks still covered`() = runBlocking {
        val provider = service(
            tasks = listOf(Task(title = "Buy milk", dueAtMillis = todayAt(18))),
            calendarAccess = false,
            clientFailure = "No API key stored.",
        )
        val result = provider.briefing()
        val text = (result as JarvisResult.Success).value
        assertTrue(text.contains("can't see your calendar"))
        assertTrue(text.contains("Buy milk"))
    }

    @Test
    fun `a throwing task store still returns an honest briefing`() = runBlocking {
        val throwingStore = object : TaskStore by NoOpTaskStore() {
            override suspend fun listAll(): List<Task> = throw IllegalStateException("DB locked")
        }
        val provider = BriefingService(
            taskStore = throwingStore,
            calendarReader = FakeCalendarReader(emptyList()),
            clientResolver = { JarvisResult.Failure("No API key stored.") },
            modelResolver = { "test-model" },
            usageTracker = UsageTracker(UsageRecorder { _, _ -> }),
            settingsProvider = { JarvisSettings() },
            nowMillis = { nowMillis },
            zone = zone,
        )
        val result = provider.briefing()
        assertTrue(result is JarvisResult.Success)
        assertTrue((result as JarvisResult.Success).value.contains("couldn't load your day"))
    }
}
