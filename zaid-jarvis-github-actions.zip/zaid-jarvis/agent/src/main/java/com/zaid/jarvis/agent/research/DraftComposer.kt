package com.zaid.jarvis.agent.research

import com.zaid.jarvis.agent.ChatMessage
import com.zaid.jarvis.agent.LlmProviderClient
import com.zaid.jarvis.agent.LlmRequest
import com.zaid.jarvis.agent.UsageTracker
import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.core.model.JarvisSettings
import com.zaid.jarvis.core.research.ContentDraft
import com.zaid.jarvis.core.research.DraftLimits
import com.zaid.jarvis.core.research.DraftStatus
import com.zaid.jarvis.core.research.PlatformPreset
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.repository.DraftRepository
import com.zaid.jarvis.tools.research.DraftGenerationResult
import com.zaid.jarvis.tools.research.DraftGenerator
import com.zaid.jarvis.tools.research.DraftRequest

/**
 * Draft composer (Phase 7): writes a post with the LLM and saves it
 * as a DRAFT for Zaid to review.
 *
 * Length handling: the prompt states the platform limit, and the
 * result is enforced in code — if the first attempt is over the
 * limit, the model gets exactly ONE rewrite request ("too long,
 * rewrite under N characters"); if it is still over, the text is
 * hard-truncated and flagged [DraftGenerationResult.truncated], so
 * Zaid sees the cut in the Drafts screen instead of a silently
 * over-long draft.
 *
 * The saved draft is always DRAFT. Approval is a deliberate user
 * action in the Draft editor — never automatic, never here. Nothing
 * in this phase publishes anything (Phase 8).
 */
class DraftComposer(
    /** Resolves the LLM client for the current settings (LlmClientFactory in production). */
    private val clientResolver: suspend (JarvisSettings) -> JarvisResult<LlmProviderClient>,
    /** Resolves the model ID for the current settings. */
    private val modelResolver: (JarvisSettings) -> String,
    private val usageTracker: UsageTracker,
    private val killSwitch: KillSwitch,
    private val settingsProvider: suspend () -> JarvisSettings,
    private val draftRepository: DraftRepository,
) : DraftGenerator {

    override suspend fun generate(request: DraftRequest): JarvisResult<DraftGenerationResult> {
        val generation = killSwitch.currentGeneration()
        val settings = settingsProvider()
        val client = when (val resolved = clientResolver(settings)) {
            is JarvisResult.Success -> resolved.value
            is JarvisResult.Failure -> return resolved
        }
        if (killSwitch.currentGeneration() != generation) {
            return JarvisResult.Failure("Stopped.")
        }
        val preset = PlatformPreset.fromName(request.platform)
        val limit = preset.charLimit
        val modelApiId = modelResolver(settings)
        val maxTokens = (limit / 4 + 128).coerceIn(256, 4096)

        val messages = mutableListOf(
            ChatMessage(role = "user", content = buildPrompt(request, preset, limit)),
        )
        val first = callLlm(client, modelApiId, messages, maxTokens)
            ?: return JarvisResult.Failure("The AI request failed while drafting.")
        var text = cleanDraftText(first)
        var wasRewritten = false
        if (text.length > limit) {
            // One rewrite, then enforce.
            wasRewritten = true
            messages += ChatMessage(role = "assistant", content = text)
            messages += ChatMessage(
                role = "user",
                content = "That was ${text.length} characters — too long. Rewrite it under " +
                    "$limit characters, keeping the meaning. Reply with only the post text.",
            )
            val second = callLlm(client, modelApiId, messages, maxTokens)
            if (second != null) {
                text = cleanDraftText(second)
            }
        }
        if (killSwitch.currentGeneration() != generation) {
            return JarvisResult.Failure("Stopped.")
        }
        val enforced = DraftLimits.enforce(text, limit)
        val title = request.topic.trim().take(TITLE_MAX_CHARS)
        val draft = ContentDraft(
            title = title,
            body = enforced.text,
            platform = preset.displayName,
            status = DraftStatus.DRAFT,
            researchId = request.researchId,
        )
        return when (val saved = draftRepository.save(draft)) {
            is JarvisResult.Success -> JarvisResult.Success(
                DraftGenerationResult(
                    draft = draft.copy(id = saved.value),
                    charLimit = limit,
                    truncated = enforced.truncated,
                    wasRewritten = wasRewritten,
                ),
            )
            is JarvisResult.Failure -> saved
        }
    }

    /** One LLM call; returns the cleaned text, or null on failure (usage still recorded on success). */
    private suspend fun callLlm(
        client: LlmProviderClient,
        modelApiId: String,
        messages: List<ChatMessage>,
        maxTokens: Int,
    ): String? {
        val request = LlmRequest(
            provider = client.provider,
            modelApiId = modelApiId,
            messages = messages,
            systemPrompt = SYSTEM_PROMPT,
            maxTokens = maxTokens,
        )
        return when (val result = client.chat(request)) {
            is JarvisResult.Success -> {
                usageTracker.record(modelApiId, result.value.usage)
                result.value.text
            }
            is JarvisResult.Failure -> null
        }
    }

    private fun buildPrompt(request: DraftRequest, preset: PlatformPreset, limit: Int): String =
        buildString {
            append("Write a ${preset.displayName} post about: ${request.topic}\n")
            append("Tone: ${request.tone}\n")
            append("Maximum $limit characters including spaces.\n")
            if (!request.context.isNullOrBlank()) {
                append("\nBase it on these notes/research:\n${request.context.trim().take(MAX_CONTEXT_CHARS)}\n")
            }
            append("\nReply with ONLY the post text — no preamble, no quotation marks around it, no hashtags unless they fit naturally.")
        }

    /**
     * Strips the wrappers models love to add: code fences and
     * surrounding quotes. Only strips a fence/quote pair when it wraps
     * the whole text, so quotes inside the post survive.
     */
    private fun cleanDraftText(raw: String): String {
        var text = raw.trim()
        if (text.startsWith("```") && text.endsWith("```") && text.length > 6) {
            text = text.removePrefix("```").removeSuffix("```").trim()
            // A fence may carry a language tag on its first line ("```text").
            // Only drop the first line when it looks like a tag (one short
            // word) — a real first line of the post must survive.
            val lines = text.lines()
            if (lines.size > 1 && Regex("^[A-Za-z0-9_-]{1,20}$").matches(lines.first().trim())) {
                text = lines.drop(1).joinToString("\n").trim()
            }
        }
        if (text.length >= 2 && text.startsWith("\"") && text.endsWith("\"")) {
            text = text.substring(1, text.length - 1).trim()
        }
        return text
    }

    companion object {
        private const val SYSTEM_PROMPT =
            "You are Jarvis, a careful writing assistant. You write social posts that " +
                "sound human, stay on topic, and respect the character limit you are given. " +
                "You never invent facts, statistics, or links."
        private const val TITLE_MAX_CHARS: Int = 60
        private const val MAX_CONTEXT_CHARS: Int = 4000
    }
}
