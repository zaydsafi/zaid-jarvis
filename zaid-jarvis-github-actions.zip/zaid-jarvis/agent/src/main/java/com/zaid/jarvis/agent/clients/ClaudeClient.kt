package com.zaid.jarvis.agent.clients

import com.zaid.jarvis.agent.ChatMessage
import com.zaid.jarvis.agent.LlmProviderClient
import com.zaid.jarvis.agent.LlmRequest
import com.zaid.jarvis.agent.LlmResponse
import com.zaid.jarvis.agent.LlmToolCall
import com.zaid.jarvis.agent.LlmUsage
import com.zaid.jarvis.core.model.LlmProvider
import com.zaid.jarvis.core.util.JarvisResult
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

/**
 * Anthropic Claude client (https://api.anthropic.com/v1/messages) with
 * native tool use (`tool_use` / `tool_result` blocks).
 *
 * The API key is supplied per call by [apiKeyProvider] (reads
 * ApiKeyRepository at call time) and is sent only in the `x-api-key`
 * header — never in a URL, never logged.
 */
class ClaudeClient(
    private val okHttpClient: OkHttpClient,
    private val apiKeyProvider: () -> String?,
) : LlmProviderClient {

    override val provider: LlmProvider = LlmProvider.CLAUDE

    private val api: ClaudeApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(LlmJson.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(ClaudeApi::class.java)
    }

    override suspend fun chat(request: LlmRequest): JarvisResult<LlmResponse> {
        val apiKey = apiKeyProvider()?.takeIf { it.isNotBlank() }
            ?: return JarvisResult.Failure(
                "No Claude API key stored. Add one in Settings → API keys.",
            )
        val body = buildRequestBody(request)
        return try {
            val response = api.messages(apiKey, ANTHROPIC_VERSION, body)
            if (!response.isSuccessful) {
                val errorBody = response.errorBody()?.string()
                return JarvisResult.Failure(
                    "Claude API error (HTTP ${response.code()}): " +
                        extractErrorMessage(errorBody),
                )
            }
            val json = response.body()?.string()
                ?: return JarvisResult.Failure("Claude returned an empty response.")
            JarvisResult.Success(parseClaudeResponse(json))
        } catch (e: Exception) {
            JarvisResult.Failure("Could not reach Claude: ${e.message ?: e::class.simpleName}")
        }
    }

    private interface ClaudeApi {
        @POST("messages")
        suspend fun messages(
            @Header("x-api-key") apiKey: String,
            @Header("anthropic-version") version: String,
            @Body body: JsonObject,
        ): Response<ResponseBody>
    }

    companion object {
        const val BASE_URL: String = "https://api.anthropic.com/v1/"
        const val ANTHROPIC_VERSION: String = "2023-06-01"

        /** Builds the Anthropic wire format from a provider-neutral request. */
        fun buildRequestBody(request: LlmRequest): JsonObject = buildJsonObject {
            put("model", request.modelApiId)
            put("max_tokens", request.maxTokens)
            request.systemPrompt?.let { put("system", it) }
            putJsonArray("messages") {
                request.messages.forEach { message -> add(messageToJson(message)) }
            }
            if (request.tools.isNotEmpty()) {
                putJsonArray("tools") {
                    request.tools.forEach { tool ->
                        add(
                            buildJsonObject {
                                put("name", tool.name)
                                put("description", tool.description)
                                put("input_schema", tool.inputSchema)
                            },
                        )
                    }
                }
            }
        }

        private fun messageToJson(message: ChatMessage): JsonObject = buildJsonObject {
            when (message.role) {
                "tool" -> {
                    put("role", "user")
                    putJsonArray("content") {
                        add(
                            buildJsonObject {
                                put("type", "tool_result")
                                put("tool_use_id", message.toolCallId ?: "")
                                put("content", message.content)
                            },
                        )
                    }
                }
                "assistant" -> {
                    put("role", "assistant")
                    if (message.toolCalls.isEmpty()) {
                        put("content", message.content)
                    } else {
                        putJsonArray("content") {
                            if (message.content.isNotBlank()) {
                                add(
                                    buildJsonObject {
                                        put("type", "text")
                                        put("text", message.content)
                                    },
                                )
                            }
                            message.toolCalls.forEach { call ->
                                add(
                                    buildJsonObject {
                                        put("type", "tool_use")
                                        put("id", call.id)
                                        put("name", call.name)
                                        put(
                                            "input",
                                            runCatching {
                                                LlmJson.parseToJsonElement(call.argumentsJson).jsonObject
                                            }.getOrDefault(JsonObject(emptyMap())),
                                        )
                                    },
                                )
                            }
                        }
                    }
                }
                else -> {
                    // "user" (and "system", which clients send as systemPrompt
                    // instead — a stray system message is treated as user text).
                    put("role", "user")
                    put("content", message.content)
                }
            }
        }
    }
}

/**
 * Parses an Anthropic messages response into a provider-neutral response.
 * Public (not internal) so unit tests can feed it recorded fixtures.
 */
fun parseClaudeResponse(responseJson: String): LlmResponse {
    val root = LlmJson.parseToJsonElement(responseJson).jsonObject
    val text = StringBuilder()
    val toolCalls = mutableListOf<LlmToolCall>()
    root.array("content")?.forEach { block ->
        val obj = runCatching { block.jsonObject }.getOrNull() ?: return@forEach
        when (obj.string("type")) {
            "text" -> obj.string("text")?.let { text.append(it) }
            "tool_use" -> {
                val id = obj.string("id") ?: return@forEach
                val name = obj.string("name") ?: return@forEach
                val input = obj.element("input") ?: JsonObject(emptyMap())
                toolCalls += LlmToolCall(id, name, input.toString())
            }
        }
    }
    val usageObj = root.obj("usage")
    return LlmResponse(
        text = text.toString(),
        toolCalls = toolCalls,
        usage = LlmUsage(
            inputTokens = usageObj?.long("input_tokens") ?: 0,
            outputTokens = usageObj?.long("output_tokens") ?: 0,
        ),
        finishReason = root.string("stop_reason"),
    )
}
