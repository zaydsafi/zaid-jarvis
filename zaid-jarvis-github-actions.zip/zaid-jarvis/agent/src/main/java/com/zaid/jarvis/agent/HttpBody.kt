package com.zaid.jarvis.agent

import okhttp3.ResponseBody

/**
 * Reads a response body as UTF-8, capped at [maxBytes].
 *
 * Okio's `BufferedSource.readUtf8(n)` throws EOFException when the
 * body is smaller than `n`, so a naive `readUtf8(MAX)` fails on every
 * small response — which is most API responses. This requests up to
 * [maxBytes] and reads only what actually arrived, so small bodies
 * read fully and huge bodies are still capped.
 *
 * (Phase 8 fix: the Phase 7 search/fetcher call sites and the Phase 8
 * social caller all used the throwing form; the AuthenticatedApiCaller
 * test caught it because its fake responses are small.)
 */
internal fun ResponseBody.readUtf8Capped(maxBytes: Long): String {
    val source = source()
    return try {
        source.request(maxBytes)
        val buffered = source.buffer
        buffered.readUtf8(minOf(buffered.size, maxBytes))
    } catch (e: Exception) {
        ""
    }
}
