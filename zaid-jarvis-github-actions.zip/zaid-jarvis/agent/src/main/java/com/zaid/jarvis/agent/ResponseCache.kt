package com.zaid.jarvis.agent

import java.security.MessageDigest
import kotlinx.serialization.json.Json

/**
 * Response cache (Master Prompt §4: "response caching").
 *
 * Identical prompts — same provider, model, messages, and tools — return
 * the cached final answer instead of calling the API again, saving tokens
 * and time. Only pure text answers are cached: a response that calls tools
 * is never cached, because the world may have changed since.
 *
 * In-memory only (cleared when the app process dies); entries expire after
 * [TTL_MILLIS]. Cache keys are SHA-256 hashes of the request — the cache
 * never stores anything more sensitive than the response itself.
 */
class ResponseCache(
    private val maxEntries: Int = MAX_ENTRIES,
    private val ttlMillis: Long = TTL_MILLIS,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    companion object {
        const val MAX_ENTRIES: Int = 50
        /** 15 minutes. */
        const val TTL_MILLIS: Long = 15 * 60 * 1000L
    }

    private data class Entry(val response: LlmResponse, val storedAtMillis: Long)

    private val json = Json { encodeDefaults = true }

    // Access-ordered LinkedHashMap = simple LRU.
    private val entries = object : LinkedHashMap<String, Entry>(maxEntries, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Entry>): Boolean =
            size > maxEntries
    }

    private val lock = Any()

    /** Cache key for a request — stable for identical requests. */
    fun keyFor(request: LlmRequest): String {
        val material = buildString {
            append(request.provider.name).append('|')
            append(request.modelApiId).append('|')
            append(json.encodeToString(request.messages)).append('|')
            append(json.encodeToString(request.tools)).append('|')
            append(request.systemPrompt ?: "")
        }
        return MessageDigest.getInstance("SHA-256")
            .digest(material.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    fun get(request: LlmRequest): LlmResponse? {
        val entry = synchronized(lock) { entries[keyFor(request)] } ?: return null
        if (clock() - entry.storedAtMillis > ttlMillis) {
            synchronized(lock) { entries.remove(keyFor(request)) }
            return null
        }
        return entry.response
    }

    /** Stores a response. Responses with tool calls are never cached. */
    fun put(request: LlmRequest, response: LlmResponse) {
        if (response.toolCalls.isNotEmpty()) return
        synchronized(lock) {
            entries[keyFor(request)] = Entry(response, clock())
        }
    }

    fun clear() {
        synchronized(lock) { entries.clear() }
    }

    fun size(): Int = synchronized(lock) { entries.size }
}
