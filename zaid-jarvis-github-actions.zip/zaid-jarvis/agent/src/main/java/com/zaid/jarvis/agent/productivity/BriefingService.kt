package com.zaid.jarvis.agent.productivity

import com.zaid.jarvis.agent.ChatMessage
import com.zaid.jarvis.agent.LlmProviderClient
import com.zaid.jarvis.agent.LlmRequest
import com.zaid.jarvis.agent.UsageTracker
import com.zaid.jarvis.core.model.JarvisSettings
import com.zaid.jarvis.core.productivity.BriefingData
import com.zaid.jarvis.core.productivity.BriefingFormat
import com.zaid.jarvis.core.productivity.TaskStatus
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.productivity.BriefingProvider
import com.zaid.jarvis.tools.productivity.CalendarReader
import com.zaid.jarvis.tools.productivity.TaskStore
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/**
 * The morning briefing (Phase 9): today's calendar events + tasks
 * due today + overdue tasks, as text.
 *
 * The briefing NEVER fails: when an LLM is configured and reachable,
 * the facts are polished into a short briefing (usage recorded
 * through the normal [UsageTracker]); when there is no key, no
 * network, or the LLM call fails, the plain templated summary
 * ([BriefingFormat.formatPlain]) is returned instead. No weather in
 * Phase 9 — no weather API is wired.
 *
 * Calendar access is read-only and optional: without it the briefing
 * says so and still covers the tasks.
 */
class BriefingService(
    private val taskStore: TaskStore,
    private val calendarReader: CalendarReader,
    /** Resolves the LLM client for the current settings (LlmClientFactory in production). */
    private val clientResolver: suspend (JarvisSettings) -> JarvisResult<LlmProviderClient>,
    /** Resolves the model ID for the current settings. */
    private val modelResolver: (JarvisSettings) -> String,
    private val usageTracker: UsageTracker,
    private val settingsProvider: suspend () -> JarvisSettings,
    private val nowMillis: () -> Long = { System.currentTimeMillis() },
    private val zone: ZoneId = ZoneId.systemDefault(),
) : BriefingProvider {

    override suspend fun briefing(): JarvisResult<String> {
        val data = try {
            gatherData()
        } catch (e: Exception) {
            // Even gathering failed (e.g. the database is unavailable):
            // still answer, honestly, instead of failing the briefing.
            return JarvisResult.Success(
                "Good morning — I couldn't load your day just now " +
                    "(${e.message ?: e::class.simpleName}). Try again in a moment.",
            )
        }
        return JarvisResult.Success(polishOrFallback(data))
    }

    /** Gathers today's events + tasks. Throws only on unexpected errors. */
    private suspend fun gatherData(): BriefingData {
        val now = nowMillis()
        val today = LocalDate.ofInstant(Instant.ofEpochMilli(now), zone)
        val dayStart = today.atStartOfDay(zone).toInstant().toEpochMilli()
        val dayEnd = today.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()

        val tasks = taskStore.listAll().filter { it.status == TaskStatus.OPEN }
        val tasksDueToday = tasks.filter { it.isDueToday(now, zone) }
        val overdueTasks = tasks.filter { it.isOverdue(now) }

        val calendarAvailable = calendarReader.hasCalendarAccess()
        val events = if (calendarAvailable) {
            when (val result = calendarReader.eventsBetween(dayStart, dayEnd)) {
                is JarvisResult.Success -> result.value
                is JarvisResult.Failure -> emptyList()
            }
        } else {
            emptyList()
        }
        return BriefingData(
            date = today,
            events = events,
            tasksDueToday = tasksDueToday,
            overdueTasks = overdueTasks,
            calendarUnavailable = !calendarAvailable,
        )
    }

    /** LLM polish when possible, plain template otherwise. Never throws. */
    private suspend fun polishOrFallback(data: BriefingData): String {
        return try {
            val settings = settingsProvider()
            val client = when (val resolved = clientResolver(settings)) {
                is JarvisResult.Success -> resolved.value
                is JarvisResult.Failure -> return BriefingFormat.formatPlain(data, zone)
            }
            val modelApiId = modelResolver(settings)
            if (modelApiId.isBlank()) return BriefingFormat.formatPlain(data, zone)
            val request = LlmRequest(
                provider = client.provider,
                modelApiId = modelApiId,
                messages = listOf(
                    ChatMessage(role = "user", content = BriefingFormat.buildLlmPrompt(data)),
                ),
                systemPrompt = SYSTEM_PROMPT,
                maxTokens = 512,
            )
            when (val response = client.chat(request)) {
                is JarvisResult.Success -> {
                    usageTracker.record(modelApiId, response.value.usage)
                    val text = response.value.text.trim()
                    if (text.isBlank()) BriefingFormat.formatPlain(data, zone) else text
                }
                is JarvisResult.Failure -> BriefingFormat.formatPlain(data, zone)
            }
        } catch (e: Exception) {
            BriefingFormat.formatPlain(data, zone)
        }
    }

    companion object {
        private const val SYSTEM_PROMPT =
            "You are Jarvis, Zaid's assistant. Write short morning briefings " +
                "from the facts you are given. Never invent events, tasks, or times."
    }
}
