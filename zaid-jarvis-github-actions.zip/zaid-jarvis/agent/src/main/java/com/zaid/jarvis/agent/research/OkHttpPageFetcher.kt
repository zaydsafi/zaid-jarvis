package com.zaid.jarvis.agent.research

import com.zaid.jarvis.agent.readUtf8Capped
import com.zaid.jarvis.core.research.HtmlTextExtractor
import com.zaid.jarvis.core.research.PageContent
import com.zaid.jarvis.core.research.UrlSafety
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.research.PageFetcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

/**
 * Fetches one web page and reduces it to readable text (Phase 7,
 * `fetch_page`).
 *
 * Guards (see [UrlSafety] for the SSRF rules):
 * - URL validated before the request (http(s) only, no localhost, no
 *   private IPs) — and re-validated after redirects: OkHttp follows
 *   redirects automatically, so the *final* URL is checked too, and a
 *   redirect to a private address is refused.
 * - DNS rebinding is closed by [ValidatingDns] on the shared
 *   OkHttpClient (Phase 11): every address a hostname resolves to is
 *   validated before OkHttp connects to it, so a public name pointing
 *   at a private IP is refused at lookup time.
 * - Response capped at [MAX_DOWNLOAD_BYTES] (200 KB) — a huge page
 *   can't eat memory or the LLM's context.
 * - Only `text/html` and `text/plain` content is read; binary content
 *   (PDFs, images, archives) is refused with a clear message.
 * - Extracted text is capped at [HtmlTextExtractor.DEFAULT_MAX_CHARS].
 *
 * Fetched text is UNTRUSTED DATA: callers (the planner, the
 * ResearchEngine) scan it with the Phase 3 InjectionGuard before
 * acting on it.
 */
class OkHttpPageFetcher(private val okHttpClient: OkHttpClient) : PageFetcher {

    override suspend fun fetch(url: String): JarvisResult<PageContent> =
        withContext(Dispatchers.IO) {
            when (val valid = UrlSafety.validateUrl(url)) {
                is JarvisResult.Failure -> return@withContext valid
                is JarvisResult.Success -> { /* safe — fetch it */ }
            }
            try {
                val request = Request.Builder()
                    .url(url.trim())
                    .header("User-Agent", USER_AGENT)
                    .header("Accept", "text/html, text/plain")
                    .get()
                    .build()
                okHttpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext JarvisResult.Failure(
                            "Could not fetch $url (HTTP ${response.code}).",
                        )
                    }
                    // Redirect guard: the final URL must pass the same checks.
                    val finalUrl = response.request.url.toString()
                    when (val finalCheck = UrlSafety.validateUrl(finalUrl)) {
                        is JarvisResult.Failure -> return@withContext JarvisResult.Failure(
                            "The page redirected to an address Jarvis won't fetch: " +
                                finalCheck.message,
                        )
                        is JarvisResult.Success -> { /* fine */ }
                    }
                    val contentType = response.header("Content-Type")?.lowercase() ?: ""
                    val isText = contentType.startsWith("text/html") ||
                        contentType.startsWith("text/plain") ||
                        contentType.isEmpty()
                    if (!isText) {
                        return@withContext JarvisResult.Failure(
                            "That URL is not a readable page (content type: " +
                                "${contentType.substringBefore(";")}). Jarvis only reads " +
                                "HTML and plain-text pages.",
                        )
                    }
                    val html = response.body?.readUtf8Capped(MAX_DOWNLOAD_BYTES) ?: ""
                    JarvisResult.Success(
                        HtmlTextExtractor.extract(url = finalUrl, html = html),
                    )
                }
            } catch (e: Exception) {
                JarvisResult.Failure(
                    "Could not fetch $url: ${e.message ?: e::class.simpleName}.",
                )
            }
        }

    companion object {
        /** Max bytes downloaded per page (200 KB). */
        const val MAX_DOWNLOAD_BYTES: Long = 200L * 1024L
        private const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/130.0 Mobile Safari/537.36"
    }
}
