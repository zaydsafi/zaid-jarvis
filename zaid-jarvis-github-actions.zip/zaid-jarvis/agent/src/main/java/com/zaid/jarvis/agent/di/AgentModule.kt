package com.zaid.jarvis.agent.di

import com.zaid.jarvis.agent.AgentPlanner
import com.zaid.jarvis.agent.GatedToolExecutorAdapter
import com.zaid.jarvis.agent.LlmClientFactory
import com.zaid.jarvis.agent.ResponseCache
import com.zaid.jarvis.agent.ToolExecutor
import com.zaid.jarvis.agent.UsageRecorder
import com.zaid.jarvis.agent.UsageTracker
import com.zaid.jarvis.agent.productivity.BriefingService
import com.zaid.jarvis.agent.research.ConfigurableWebSearch
import com.zaid.jarvis.agent.research.DraftComposer
import com.zaid.jarvis.agent.research.DuckDuckGoSearch
import com.zaid.jarvis.agent.research.OkHttpPageFetcher
import com.zaid.jarvis.agent.research.ResearchEngine
import com.zaid.jarvis.agent.research.ValidatingDns
import com.zaid.jarvis.agent.research.TavilySearch
import com.zaid.jarvis.agent.social.AuthenticatedApiCaller
import com.zaid.jarvis.agent.social.InstagramSocialClient
import com.zaid.jarvis.agent.social.LinkedInSocialClient
import com.zaid.jarvis.agent.social.OAuthClient
import com.zaid.jarvis.agent.social.PlatformClient
import com.zaid.jarvis.agent.social.PublishServiceImpl
import com.zaid.jarvis.agent.social.SocialPublisherImpl
import com.zaid.jarvis.agent.social.ThreadsSocialClient
import com.zaid.jarvis.agent.social.XSocialClient
import com.zaid.jarvis.core.analytics.AnalyticsSink
import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.data.datastore.SettingsRepository
import com.zaid.jarvis.data.device.DeviceContextProvider
import com.zaid.jarvis.data.repository.ApiKeyRepository
import com.zaid.jarvis.data.repository.DraftRepository
import com.zaid.jarvis.data.repository.ResearchRepository
import com.zaid.jarvis.data.repository.ScheduledPostRepository
import com.zaid.jarvis.tools.GatedToolExecutor
import com.zaid.jarvis.tools.ToolRegistry
import com.zaid.jarvis.tools.productivity.BriefingProvider
import com.zaid.jarvis.tools.productivity.CalendarReader
import com.zaid.jarvis.tools.productivity.TaskStore
import com.zaid.jarvis.tools.research.DraftGenerator
import com.zaid.jarvis.tools.research.PageFetcher
import com.zaid.jarvis.tools.research.ResearchRunner
import com.zaid.jarvis.tools.research.WebSearch
import com.zaid.jarvis.tools.social.PublishService
import com.zaid.jarvis.tools.social.SocialAccountStore
import com.zaid.jarvis.tools.social.SocialPublisher
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.flow.first
import okhttp3.OkHttpClient
import javax.inject.Singleton

/**
 * Agent bindings (Phase 3).
 *
 * NOTE: the OkHttp client has NO logging interceptor on purpose — request
 * logging could leak API keys or conversation text into logcat. Timeouts
 * are generous because LLM calls can take a while on slow networks.
 *
 * DNS (Phase 11): the shared client resolves through [ValidatingDns],
 * which refuses any hostname that resolves to a private / loopback /
 * link-local / reserved address (DNS rebinding). This covers the page
 * fetcher and search clients — the ones that fetch user/LLM-supplied
 * URLs — and, deliberately, the LLM, OAuth, and social clients too:
 * their hosts are fixed public https endpoints, so the guard is a
 * no-op for them in practice and defense in depth against a poisoned
 * resolver. Custom LLM providers are user-configured, not
 * attacker-controlled, but they are https-only since Phase 11
 * (CustomProviderConfig refuses http://), so a custom provider whose
 * hostname resolves to a private address is refused here as well —
 * consistent with local servers no longer being supported. See
 * [ValidatingDns] for the precise guarantees and limits.
 */
@Module
@InstallIn(SingletonComponent::class)
object AgentModule {

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient = OkHttpClient.Builder()
        .dns(ValidatingDns())
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    @Provides
    @Singleton
    fun provideResponseCache(): ResponseCache = ResponseCache()

    @Provides
    @Singleton
    fun provideUsageTracker(settingsRepository: SettingsRepository): UsageTracker =
        UsageTracker(
            UsageRecorder { tokens, cost ->
                settingsRepository.recordUsage(tokens, cost)
            },
        )

    @Provides
    @Singleton
    fun provideToolExecutor(gatedExecutor: GatedToolExecutor): ToolExecutor =
        GatedToolExecutorAdapter(gatedExecutor)

    @Provides
    @Singleton
    fun provideAgentPlanner(
        toolRegistry: ToolRegistry,
        toolExecutor: ToolExecutor,
        usageTracker: UsageTracker,
        responseCache: ResponseCache,
        killSwitch: KillSwitch,
        deviceContextProvider: DeviceContextProvider,
    ): AgentPlanner = AgentPlanner(
        toolRegistry = toolRegistry,
        toolExecutor = toolExecutor,
        usageTracker = usageTracker,
        responseCache = responseCache,
        killSwitch = killSwitch,
        isOnline = { deviceContextProvider.isOnline() },
    )

    // ── Research & content (Phase 7) ──────────────────────────────────
    // The tools in :tools program against the WebSearch / PageFetcher /
    // ResearchRunner / DraftGenerator interfaces; these providers are the
    // real implementations. The shared OkHttp client has no logging
    // interceptor (see above) — search queries and fetched pages must
    // never reach logcat, and neither must the Tavily key.

    @Provides
    @Singleton
    fun provideWebSearch(
        settingsRepository: SettingsRepository,
        apiKeyRepository: ApiKeyRepository,
        okHttpClient: OkHttpClient,
    ): WebSearch = ConfigurableWebSearch(
        settingsProvider = { settingsRepository.settings.first() },
        duckDuckGo = DuckDuckGoSearch(okHttpClient),
        tavily = TavilySearch(okHttpClient) { apiKeyRepository.getTavilyApiKey() },
        hasTavilyKey = { apiKeyRepository.hasTavilyApiKey() },
    )

    @Provides
    @Singleton
    fun providePageFetcher(okHttpClient: OkHttpClient): PageFetcher =
        OkHttpPageFetcher(okHttpClient)

    @Provides
    @Singleton
    fun provideResearchRunner(
        webSearch: WebSearch,
        pageFetcher: PageFetcher,
        clientFactory: LlmClientFactory,
        usageTracker: UsageTracker,
        killSwitch: KillSwitch,
        settingsRepository: SettingsRepository,
        researchRepository: ResearchRepository,
    ): ResearchRunner = ResearchEngine(
        webSearch = webSearch,
        pageFetcher = pageFetcher,
        clientResolver = { settings -> clientFactory.clientFor(settings) },
        modelResolver = { settings ->
            clientFactory.modelApiIdFor(settings, simpleIntent = false)
        },
        usageTracker = usageTracker,
        killSwitch = killSwitch,
        settingsProvider = { settingsRepository.settings.first() },
        researchRepository = researchRepository,
    )

    @Provides
    @Singleton
    fun provideDraftGenerator(
        clientFactory: LlmClientFactory,
        usageTracker: UsageTracker,
        killSwitch: KillSwitch,
        settingsRepository: SettingsRepository,
        draftRepository: DraftRepository,
    ): DraftGenerator = DraftComposer(
        clientResolver = { settings -> clientFactory.clientFor(settings) },
        modelResolver = { settings ->
            clientFactory.modelApiIdFor(settings, simpleIntent = false)
        },
        usageTracker = usageTracker,
        killSwitch = killSwitch,
        settingsProvider = { settingsRepository.settings.first() },
        draftRepository = draftRepository,
    )

    // ── Social publishing (Phase 8) ───────────────────────────────────
    // One client per platform, all via official APIs. The shared
    // OkHttp client has no logging interceptor (see above) — Bearer
    // tokens must never reach logcat.

    @Provides
    @Singleton
    fun provideOAuthClient(okHttpClient: OkHttpClient): OAuthClient = OAuthClient(okHttpClient)

    @Provides
    @Singleton
    fun provideAuthenticatedApiCaller(
        okHttpClient: OkHttpClient,
        accountStore: SocialAccountStore,
        oAuthClient: OAuthClient,
    ): AuthenticatedApiCaller = AuthenticatedApiCaller(okHttpClient, accountStore, oAuthClient)

    @Provides
    @Singleton
    fun providePlatformClients(): Map<SocialPlatform, PlatformClient> = mapOf(
        SocialPlatform.X to XSocialClient(),
        SocialPlatform.THREADS to ThreadsSocialClient(),
        SocialPlatform.LINKEDIN to LinkedInSocialClient(),
        SocialPlatform.INSTAGRAM to InstagramSocialClient(),
    )

    @Provides
    @Singleton
    fun provideSocialPublisher(
        caller: AuthenticatedApiCaller,
        accountStore: SocialAccountStore,
        clients: Map<SocialPlatform, PlatformClient>,
    ): SocialPublisher = SocialPublisherImpl(caller, accountStore, clients)

    @Provides
    @Singleton
    fun providePublishService(
        draftRepository: DraftRepository,
        scheduledPostRepository: ScheduledPostRepository,
        publisher: SocialPublisher,
        analyticsSink: AnalyticsSink,
    ): PublishService = PublishServiceImpl(draftRepository, scheduledPostRepository, publisher, analyticsSink)

    // ── Morning briefing (Phase 9) ────────────────────────────────────
    // The LLM polishes the briefing when one is configured; otherwise
    // the plain templated summary is used (BriefingService never
    // fails). TaskStore and CalendarReader are bound in :app
    // (AppModule); Hilt resolves them across modules.

    @Provides
    @Singleton
    fun provideBriefingProvider(
        taskStore: TaskStore,
        calendarReader: CalendarReader,
        clientFactory: LlmClientFactory,
        usageTracker: UsageTracker,
        settingsRepository: SettingsRepository,
    ): BriefingProvider = BriefingService(
        taskStore = taskStore,
        calendarReader = calendarReader,
        clientResolver = { settings -> clientFactory.clientFor(settings) },
        modelResolver = { settings ->
            clientFactory.modelApiIdFor(settings, simpleIntent = true)
        },
        usageTracker = usageTracker,
        settingsProvider = { settingsRepository.settings.first() },
    )
}
