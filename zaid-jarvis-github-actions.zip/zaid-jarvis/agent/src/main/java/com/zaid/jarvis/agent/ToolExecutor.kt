package com.zaid.jarvis.agent

import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.GatedToolExecutor
import kotlinx.serialization.json.JsonObject
import javax.inject.Inject
import javax.inject.Singleton

/**
 * How the planner runs a tool. This interface is the seam that keeps the
 * planner testable (tests inject a fake); the only production
 * implementation is [GatedToolExecutorAdapter], so every tool call in the
 * real app still passes through the Phase 2 Confirmation Engine.
 *
 * The planner must NEVER call [com.zaid.jarvis.tools.JarvisTool.execute]
 * directly — that would bypass Zaid's approval.
 */
fun interface ToolExecutor {
    suspend fun execute(toolName: String, params: JsonObject): JarvisResult<String>
}

/** Production [ToolExecutor]: delegates to the gated executor (Phase 2). */
@Singleton
class GatedToolExecutorAdapter @Inject constructor(
    private val gatedExecutor: GatedToolExecutor,
) : ToolExecutor {
    override suspend fun execute(toolName: String, params: JsonObject): JarvisResult<String> =
        gatedExecutor.execute(toolName, params)
}
