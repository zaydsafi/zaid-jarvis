package com.zaid.jarvis.agent.social

import com.zaid.jarvis.core.social.PublishRequest
import com.zaid.jarvis.core.social.PublishResult
import com.zaid.jarvis.core.social.SocialAccount
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.social.SocialAccountStore
import com.zaid.jarvis.tools.social.SocialPublisher
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The [SocialPublisher] implementation (Phase 8): routes a publish
 * request to the right platform client, and fetches/saves the account
 * profile at connect time.
 *
 * Token refresh is handled one layer down, in [AuthenticatedApiCaller]
 * (401 → refresh once → retry once; refresh failure → disconnected).
 * This class never sees a token.
 */
@Singleton
class SocialPublisherImpl @Inject constructor(
    private val caller: AuthenticatedApiCaller,
    private val accountStore: SocialAccountStore,
    private val clients: Map<SocialPlatform, @JvmSuppressWildcards PlatformClient>,
) : SocialPublisher {

    override suspend fun connectedAccount(platform: SocialPlatform): SocialAccount? {
        // An account only counts as connected while it still has tokens.
        // (A failed refresh clears the tokens; the metadata row is kept
        // so the UI can show "expired — reconnect" instead of nothing.)
        if (accountStore.getTokens(platform) == null) return null
        return accountStore.getAccount(platform)
    }

    override suspend fun publish(request: PublishRequest): JarvisResult<PublishResult> {
        val account = connectedAccount(request.platform)
            ?: return JarvisResult.Failure(
                "No ${request.platform.displayName} account connected — connect one in " +
                    "Settings → Connected accounts first.",
            )
        val client = clients[request.platform]
            ?: return JarvisResult.Failure(
                "${request.platform.displayName} publishing is not wired up in this build.",
            )
        return client.publish(caller, account, request)
    }

    /**
     * Fetches the /me profile for a freshly connected account, fills in
     * the token expiry from the stored tokens, saves the account, and
     * returns it. Called by the connect flow after the token exchange.
     */
    override suspend fun fetchProfile(platform: SocialPlatform): JarvisResult<SocialAccount> {
        val client = clients[platform]
            ?: return JarvisResult.Failure(
                "${platform.displayName} publishing is not wired up in this build.",
            )
        return when (val profile = client.fetchProfile(caller)) {
            is JarvisResult.Success -> {
                val tokens = accountStore.getTokens(platform)
                val account = profile.value.copy(
                    tokenExpiresAtMillis = tokens?.expiresAtMillis ?: 0L,
                    connectedAtMillis = System.currentTimeMillis(),
                )
                accountStore.saveAccount(account)
                JarvisResult.Success(account)
            }
            is JarvisResult.Failure -> profile
        }
    }
}
