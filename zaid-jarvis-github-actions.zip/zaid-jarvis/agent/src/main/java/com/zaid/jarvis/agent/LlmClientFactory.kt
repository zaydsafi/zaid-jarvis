package com.zaid.jarvis.agent

import com.zaid.jarvis.agent.clients.ClaudeClient
import com.zaid.jarvis.agent.clients.CustomProviderClient
import com.zaid.jarvis.agent.clients.GeminiClient
import com.zaid.jarvis.agent.clients.OpenAiClient
import com.zaid.jarvis.agent.clients.OpenRouterClient
import com.zaid.jarvis.core.model.JarvisSettings
import com.zaid.jarvis.core.model.LlmModel
import com.zaid.jarvis.core.model.LlmProvider
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.repository.ApiKeyRepository
import okhttp3.OkHttpClient
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Builds the right LLM client for the current settings (Master Prompt §4).
 *
 * Resolution rules:
 * - The provider comes from [JarvisSettings.llmProvider]; the model ID
 *   from [JarvisSettings.resolvedModelApiId] (preset, OpenRouter free-text
 *   override, or the selected custom provider's model).
 * - CUSTOM with no provider selected, or an invalid custom config, is a
 *   failure with a plain-language message — never a silent fallback to
 *   another provider.
 * - A missing API key is also a failure with a message pointing at
 *   Settings → API keys. Clients read their key at call time; this factory
 *   only checks presence early so Zaid gets the error before waiting.
 */
@Singleton
class LlmClientFactory @Inject constructor(
    private val apiKeyRepository: ApiKeyRepository,
    private val okHttpClient: OkHttpClient,
) {

    /** Builds the client for the selected provider, or explains why not. */
    fun clientFor(settings: JarvisSettings): JarvisResult<LlmProviderClient> {
        return when (settings.llmProvider) {
            LlmProvider.CLAUDE -> {
                if (!apiKeyRepository.hasApiKey(LlmProvider.CLAUDE)) {
                    return missingKey("Claude")
                }
                JarvisResult.Success(
                    ClaudeClient(okHttpClient) { apiKeyRepository.getApiKey(LlmProvider.CLAUDE) },
                )
            }
            LlmProvider.OPENAI -> {
                if (!apiKeyRepository.hasApiKey(LlmProvider.OPENAI)) {
                    return missingKey("OpenAI")
                }
                JarvisResult.Success(
                    OpenAiClient(okHttpClient) { apiKeyRepository.getApiKey(LlmProvider.OPENAI) },
                )
            }
            LlmProvider.GEMINI -> {
                if (!apiKeyRepository.hasApiKey(LlmProvider.GEMINI)) {
                    return missingKey("Gemini")
                }
                JarvisResult.Success(
                    GeminiClient(okHttpClient) { apiKeyRepository.getApiKey(LlmProvider.GEMINI) },
                )
            }
            LlmProvider.OPENROUTER -> {
                if (!apiKeyRepository.hasApiKey(LlmProvider.OPENROUTER)) {
                    return missingKey("OpenRouter")
                }
                JarvisResult.Success(
                    OpenRouterClient(okHttpClient) {
                        apiKeyRepository.getApiKey(LlmProvider.OPENROUTER)
                    },
                )
            }
            LlmProvider.CUSTOM -> {
                val config = settings.selectedCustomProvider()
                    ?: return JarvisResult.Failure(
                        "No custom provider selected. Add one in Settings → Custom providers.",
                    )
                val errors = config.validationErrors()
                if (errors.isNotEmpty()) {
                    return JarvisResult.Failure(
                        "Custom provider \"${config.name}\" is incomplete: ${errors.joinToString(" ")}",
                    )
                }
                if (!apiKeyRepository.hasCustomApiKey(config.id)) {
                    return JarvisResult.Failure(
                        "No API key stored for custom provider \"${config.name}\". " +
                            "Add one in Settings → Custom providers.",
                    )
                }
                JarvisResult.Success(
                    CustomProviderClient(
                        okHttpClient,
                        { apiKeyRepository.getCustomApiKey(config.id) },
                        config,
                    ),
                )
            }
        }
    }

    /**
     * The model ID to send for [settings]. When [simpleIntent] is true and
     * the user enabled cheap models for simple intents, returns the
     * provider's cheap-tier model (or the OpenRouter free-text override,
     * which always wins when set). CUSTOM providers have no cheap tier —
     * the configured model is always used.
     */
    fun modelApiIdFor(settings: JarvisSettings, simpleIntent: Boolean): String {
        if (simpleIntent && settings.useCheapModelForSimpleIntents) {
            when (settings.llmProvider) {
                LlmProvider.OPENROUTER -> {
                    if (settings.customModelId.isBlank()) {
                        return LlmModel.cheapFor(LlmProvider.OPENROUTER)?.apiId
                            ?: settings.resolvedModelApiId()
                    }
                }
                LlmProvider.CUSTOM -> { /* No cheap tier for custom providers. */ }
                else -> {
                    return LlmModel.cheapFor(settings.llmProvider)?.apiId
                        ?: settings.resolvedModelApiId()
                }
            }
        }
        return settings.resolvedModelApiId()
    }

    private fun missingKey(providerDisplayName: String): JarvisResult<LlmProviderClient> =
        JarvisResult.Failure(
            "No $providerDisplayName API key stored. Add one in Settings → API keys.",
        )
}
