package com.zaid.jarvis.agent.clients

import com.zaid.jarvis.agent.ChatMessage
import com.zaid.jarvis.agent.LlmProviderClient
import com.zaid.jarvis.agent.LlmRequest
import com.zaid.jarvis.agent.LlmResponse
import com.zaid.jarvis.agent.LlmToolCall
import com.zaid.jarvis.agent.LlmUsage
import com.zaid.jarvis.core.model.CustomProviderConfig
import com.zaid.jarvis.core.model.LlmProvider
import com.zaid.jarvis.core.util.JarvisResult
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

/**
 * Shared implementation for every OpenAI-compatible Chat Completions API:
 * OpenAI itself, OpenRouter, and user-added custom providers (Phase 3).
 *
 * Differences between them are only the base URL, the auth header value,
 * and a few extra headers (OpenRouter wants an app identifier):
 * - OpenAI: `Authorization: Bearer <key>`, `max_completion_tokens`.
 * - OpenRouter: same, plus `HTTP-Referer` and `X-Title` headers.
 * - Custom: same auth; `max_tokens` (more widely supported by
 *   third-party servers than `max_completion_tokens`).
 *
 * The API key is supplied per call by [apiKeyProvider] and sent only in
 * the Authorization header — never in a URL, never logged.
 */
abstract class OpenAiCompatibleClient(
    protected val okHttpClient: OkHttpClient,
    protected val apiKeyProvider: () -> String?,
    private val baseUrl: String,
    private val missingKeyMessage: String,
    private val useMaxCompletionTokens: Boolean,
    private val extraHeaders: Map<String, String> = emptyMap(),
) : LlmProviderClient {

    private val api: ChatCompletionsApi by lazy {
        val client = if (extraHeaders.isEmpty()) {
            okHttpClient
        } else {
            okHttpClient.newBuilder()
                .addInterceptor(
                    Interceptor { chain ->
                        val builder = chain.request().newBuilder()
                        extraHeaders.forEach { (name, value) -> builder.header(name, value) }
                        chain.proceed(builder.build())
                    },
                )
                .build()
        }
        Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(LlmJson.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(ChatCompletionsApi::class.java)
    }

    override suspend fun chat(request: LlmRequest): JarvisResult<LlmResponse> {
        val apiKey = apiKeyProvider()?.takeIf { it.isNotBlank() }
            ?: return JarvisResult.Failure(missingKeyMessage)
        val body = buildRequestBody(request, useMaxCompletionTokens)
        return try {
            val response = api.chatCompletions("Bearer $apiKey", body)
            if (!response.isSuccessful) {
                val errorBody = response.errorBody()?.string()
                return JarvisResult.Failure(
                    "${provider.displayName} API error (HTTP ${response.code()}): " +
                        extractErrorMessage(errorBody),
                )
            }
            val json = response.body()?.string()
                ?: return JarvisResult.Failure("${provider.displayName} returned an empty response.")
            JarvisResult.Success(parseOpenAiCompatibleResponse(json))
        } catch (e: Exception) {
            JarvisResult.Failure(
                "Could not reach ${provider.displayName}: ${e.message ?: e::class.simpleName}",
            )
        }
    }

    private interface ChatCompletionsApi {
        @POST("chat/completions")
        suspend fun chatCompletions(
            @Header("Authorization") authorization: String,
            @Body body: JsonObject,
        ): Response<ResponseBody>
    }

    companion object {
        /** Builds the OpenAI Chat Completions wire format. */
        fun buildRequestBody(request: LlmRequest, useMaxCompletionTokens: Boolean): JsonObject =
            buildJsonObject {
                put("model", request.modelApiId)
                if (useMaxCompletionTokens) {
                    put("max_completion_tokens", request.maxTokens)
                } else {
                    put("max_tokens", request.maxTokens)
                }
                putJsonArray("messages") {
                    request.systemPrompt?.let {
                        add(
                            buildJsonObject {
                                put("role", "system")
                                put("content", it)
                            },
                        )
                    }
                    request.messages.forEach { message -> add(messageToJson(message)) }
                }
                if (request.tools.isNotEmpty()) {
                    putJsonArray("tools") {
                        request.tools.forEach { tool ->
                            add(
                                buildJsonObject {
                                    put("type", "function")
                                    putJsonObject("function") {
                                        put("name", tool.name)
                                        put("description", tool.description)
                                        put("parameters", tool.inputSchema)
                                    }
                                },
                            )
                        }
                    }
                }
            }

        private fun messageToJson(message: ChatMessage): JsonObject = buildJsonObject {
            put("role", message.role)
            put("content", message.content)
            if (message.toolCalls.isNotEmpty()) {
                putJsonArray("tool_calls") {
                    message.toolCalls.forEach { call ->
                        add(
                            buildJsonObject {
                                put("id", call.id)
                                put("type", "function")
                                putJsonObject("function") {
                                    put("name", call.name)
                                    put("arguments", call.argumentsJson)
                                }
                            },
                        )
                    }
                }
            }
            message.toolCallId?.let { put("tool_call_id", it) }
        }
    }
}

/** OpenAI Chat Completions (https://api.openai.com/v1/). */
class OpenAiClient(
    okHttpClient: OkHttpClient,
    apiKeyProvider: () -> String?,
) : OpenAiCompatibleClient(
    okHttpClient = okHttpClient,
    apiKeyProvider = apiKeyProvider,
    baseUrl = "https://api.openai.com/v1/",
    missingKeyMessage = "No OpenAI API key stored. Add one in Settings → API keys.",
    useMaxCompletionTokens = true,
) {
    override val provider: LlmProvider = LlmProvider.OPENAI
}

/**
 * OpenRouter (https://openrouter.ai/api/v1/) — one key for many models.
 * OpenRouter asks apps to identify themselves with HTTP-Referer / X-Title.
 */
class OpenRouterClient(
    okHttpClient: OkHttpClient,
    apiKeyProvider: () -> String?,
) : OpenAiCompatibleClient(
    okHttpClient = okHttpClient,
    apiKeyProvider = apiKeyProvider,
    baseUrl = "https://openrouter.ai/api/v1/",
    missingKeyMessage = "No OpenRouter API key stored. Add one in Settings → API keys.",
    useMaxCompletionTokens = true,
    extraHeaders = mapOf(
        "HTTP-Referer" to "https://zaid-jarvis.app",
        "X-Title" to "Zaid Jarvis",
    ),
) {
    override val provider: LlmProvider = LlmProvider.OPENROUTER
}

/**
 * A user-added OpenAI-compatible provider (Phase 3): any server speaking
 * the Chat Completions API at `[baseUrl]/chat/completions`.
 */
class CustomProviderClient(
    okHttpClient: OkHttpClient,
    apiKeyProvider: () -> String?,
    config: CustomProviderConfig,
) : OpenAiCompatibleClient(
    okHttpClient = okHttpClient,
    apiKeyProvider = apiKeyProvider,
    baseUrl = config.normalizedBaseUrl(),
    missingKeyMessage =
        "No API key stored for custom provider \"${config.name}\". " +
            "Add one in Settings → Custom providers.",
    useMaxCompletionTokens = false,
) {
    override val provider: LlmProvider = LlmProvider.CUSTOM
}

/**
 * Parses an OpenAI-compatible Chat Completions response into a
 * provider-neutral response. Public so unit tests can feed it recorded
 * fixtures.
 */
fun parseOpenAiCompatibleResponse(responseJson: String): LlmResponse {
    val root = LlmJson.parseToJsonElement(responseJson).jsonObject
    val choice = root.array("choices")?.firstOrNull()
        ?.let { runCatching { it.jsonObject }.getOrNull() }
    val message = choice?.obj("message")
    val text = message?.string("content") ?: ""
    val toolCalls = message?.array("tool_calls")?.mapNotNull { element ->
        val call = runCatching { element.jsonObject }.getOrNull() ?: return@mapNotNull null
        val function = call.obj("function") ?: return@mapNotNull null
        val id = call.string("id") ?: return@mapNotNull null
        val name = function.string("name") ?: return@mapNotNull null
        LlmToolCall(id, name, function.string("arguments") ?: "{}")
    } ?: emptyList()
    val usageObj = root.obj("usage")
    return LlmResponse(
        text = text,
        toolCalls = toolCalls,
        usage = LlmUsage(
            inputTokens = usageObj?.long("prompt_tokens") ?: 0,
            outputTokens = usageObj?.long("completion_tokens") ?: 0,
        ),
        finishReason = choice?.string("finish_reason"),
    )
}
