package com.zaid.jarvis.agent.social

import com.zaid.jarvis.core.analytics.AnalyticsSink
import com.zaid.jarvis.core.analytics.NoOpAnalyticsSink
import com.zaid.jarvis.core.confirmation.sha256Hex
import com.zaid.jarvis.core.research.DraftStatus
import com.zaid.jarvis.core.social.PublishRequest
import com.zaid.jarvis.core.social.PublishResult
import com.zaid.jarvis.core.social.ScheduledPostStatus
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.repository.DraftRepository
import com.zaid.jarvis.data.repository.ScheduledPostRepository
import com.zaid.jarvis.tools.social.PublishService
import com.zaid.jarvis.tools.social.SocialPublisher
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The publishing gate, enforced in code (Phase 8) — the single place
 * where a draft may move to PUBLISHED. Shared by the `publish_draft`
 * tool (immediate publish) and the WorkManager worker (scheduled
 * publish), so both paths enforce exactly the same rules:
 *
 * 1. Only APPROVED drafts can be published — DRAFT is refused with a
 *    plain message ("approve it in Drafts first").
 * 2. If the draft was edited after approval (the body no longer matches
 *    the approval content hash), the publish is refused — the edited
 *    text must be approved again first.
 * 3. The platform character limit is re-checked at publish time; the
 *    approved text is never silently truncated.
 * 4. Instagram requires a public image URL (the API has no text-only
 *    posts).
 * 5. Scheduled posts re-check the content hash recorded at schedule
 *    time: if the draft changed, the post is CANCELLED — never
 *    published stale.
 * 6. Only after the platform confirms the post does the draft become
 *    PUBLISHED, via [DraftRepository.markPublished] — the only place
 *    PUBLISHED may be set.
 *
 * The approval card (Tier 2, exact text on the card) is the layer
 * above this one: the Confirmation Engine, via GatedToolExecutor.
 * This service enforces the data rules even if the card layer is
 * bypassed, so a bug or a prompt injection can never publish an
 * unapproved draft.
 *
 * Analytics (Phase 10): every publish attempt records one local,
 * on-device event (platform + success/failure — no text, no URLs).
 */
@Singleton
class PublishServiceImpl @Inject constructor(
    private val draftRepository: DraftRepository,
    private val scheduledPostRepository: ScheduledPostRepository,
    private val publisher: SocialPublisher,
    private val analyticsSink: AnalyticsSink = NoOpAnalyticsSink,
) : PublishService {

    override suspend fun getDraft(draftId: Long) = draftRepository.getById(draftId)

    override suspend fun publishDraftNow(
        draftId: Long,
        imageUrl: String?,
    ): JarvisResult<PublishResult> {
        val draft = draftRepository.getById(draftId)
            ?: return JarvisResult.Failure("No draft with id $draftId exists.")
        when (draft.status) {
            DraftStatus.DRAFT -> return JarvisResult.Failure(
                "“${draft.title}” is still a draft — approve it in Drafts first. " +
                    "Only APPROVED drafts can be published.",
            )
            DraftStatus.PUBLISHED -> return JarvisResult.Failure(
                "“${draft.title}” is already published.",
            )
            DraftStatus.APPROVED -> Unit
        }
        if (draft.editedSinceApproval()) {
            return JarvisResult.Failure(
                "“${draft.title}” was edited after you approved it — approve the " +
                    "edited text again in Drafts before publishing.",
            )
        }
        val platform = SocialPlatform.fromName(draft.platform)
            ?: return JarvisResult.Failure(
                "“${draft.platform}” is not a social platform Jarvis can publish to.",
            )
        if (draft.body.length > platform.charLimit) {
            val over = draft.body.length - platform.charLimit
            return JarvisResult.Failure(
                "The text is $over characters over the ${platform.displayName} limit " +
                    "(${platform.charLimit}). Shorten it and approve it again — " +
                    "Jarvis never truncates approved text at publish time.",
            )
        }
        if (platform == SocialPlatform.INSTAGRAM && imageUrl.isNullOrBlank()) {
            return JarvisResult.Failure(
                "Instagram posts need a photo — the Instagram API cannot publish " +
                    "text-only posts. Add a public image URL when publishing to Instagram.",
            )
        }
        return when (val published = publisher.publish(PublishRequest(platform, draft.body, imageUrl))) {
            is JarvisResult.Success -> {
                // The post is live. If marking the draft fails (a
                // database error at this point is near-impossible — we
                // just read from the same database), the publish still
                // happened, so the success stands; the draft stays
                // APPROVED, which Zaid can see and re-publish from.
                draftRepository.markPublished(draftId)
                recordPublish(platform, success = true)
                published
            }
            is JarvisResult.Failure -> {
                recordPublish(platform, success = false)
                published
            }
        }
    }

    override suspend fun publishScheduled(scheduledPostId: Long): JarvisResult<PublishResult> {
        val post = scheduledPostRepository.getById(scheduledPostId)
            ?: return JarvisResult.Failure("No scheduled post with id $scheduledPostId exists.")
        if (post.status != ScheduledPostStatus.SCHEDULED) {
            return JarvisResult.Failure(
                "Scheduled post #$scheduledPostId is already ${post.status.name.lowercase()} — " +
                    "it will not run again.",
            )
        }
        val draft = draftRepository.getById(post.draftId)
        if (draft == null) {
            scheduledPostRepository.updateStatus(
                scheduledPostId,
                ScheduledPostStatus.FAILED,
                failureReason = "The draft was deleted before the scheduled time.",
            )
            return JarvisResult.Failure("The draft for scheduled post #$scheduledPostId was deleted.")
        }
        if (draft.status != DraftStatus.APPROVED) {
            val reason = "The draft is no longer approved " +
                "(it is ${draft.status.name.lowercase()} now)."
            scheduledPostRepository.updateStatus(
                scheduledPostId,
                ScheduledPostStatus.CANCELLED,
                failureReason = reason,
            )
            return JarvisResult.Failure("Scheduled post #$scheduledPostId cancelled: $reason")
        }
        // Edited after approval (Phase 11 fix): the schedule-time hash
        // check below cannot catch a draft that was edited BEFORE it
        // was scheduled — the hash was recorded from the edited text —
        // so the approval binding is checked here too. Without this, a
        // draft edited after approval could be scheduled and then
        // published with text Zaid never approved.
        if (draft.editedSinceApproval()) {
            val reason = "The draft was edited after approval — approve the " +
                "edited text again in Drafts before it can publish."
            scheduledPostRepository.updateStatus(
                scheduledPostId,
                ScheduledPostStatus.CANCELLED,
                failureReason = reason,
            )
            return JarvisResult.Failure("Scheduled post #$scheduledPostId cancelled: $reason")
        }
        if (sha256Hex(draft.body) != post.contentHash) {
            val reason = "The draft text changed since scheduling — " +
                "the post was cancelled instead of publishing the old text."
            scheduledPostRepository.updateStatus(
                scheduledPostId,
                ScheduledPostStatus.CANCELLED,
                failureReason = reason,
            )
            return JarvisResult.Failure("Scheduled post #$scheduledPostId cancelled: $reason")
        }
        val platform = post.platform
        if (draft.body.length > platform.charLimit) {
            val reason = "The text is over the ${platform.displayName} limit " +
                "(${platform.charLimit} characters)."
            scheduledPostRepository.updateStatus(
                scheduledPostId,
                ScheduledPostStatus.FAILED,
                failureReason = reason,
            )
            return JarvisResult.Failure("Scheduled post #$scheduledPostId failed: $reason")
        }
        return when (
            val published = publisher.publish(
                PublishRequest(platform, draft.body, imageUrl = post.imageUrl),
            )
        ) {
            is JarvisResult.Success -> {
                scheduledPostRepository.updateStatus(
                    scheduledPostId,
                    ScheduledPostStatus.PUBLISHED,
                    postUrl = published.value.postUrl,
                )
                draftRepository.markPublished(post.draftId)
                recordPublish(platform, success = true)
                published
            }
            is JarvisResult.Failure -> {
                scheduledPostRepository.updateStatus(
                    scheduledPostId,
                    ScheduledPostStatus.FAILED,
                    failureReason = published.message,
                )
                recordPublish(platform, success = false)
                published
            }
        }
    }

    /** One analytics event per publish attempt (platform + outcome only). Never throws. */
    private suspend fun recordPublish(platform: SocialPlatform, success: Boolean) {
        runCatching { analyticsSink.recordPublish(platform.name, success) }
    }
}
