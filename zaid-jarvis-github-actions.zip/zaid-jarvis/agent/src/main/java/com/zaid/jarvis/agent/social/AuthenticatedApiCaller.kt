package com.zaid.jarvis.agent.social

import com.zaid.jarvis.agent.readUtf8Capped
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.social.SocialAccountStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response

/**
 * Authenticated API calls for the social platform clients (Phase 8).
 *
 * One place for the token lifecycle every platform shares:
 * - No tokens stored → plain failure ("connect an account first").
 * - Token expired (or expiring within a minute) → refresh before the call.
 * - API returns 401 → refresh once, retry the call once.
 * - Refresh fails, or the retried call still 401s → the connection is
 *   dead: tokens are cleared (the account shows as disconnected) and
 *   Zaid is told to reconnect in Settings → Connected accounts.
 *
 * The [parse] callback receives the HTTP status, the response body
 * (capped at 512 KB), and the response headers — LinkedIn's post id
 * comes back in a header, not the body.
 *
 * No request or response logging anywhere: bodies and headers can
 * contain tokens.
 */
class AuthenticatedApiCaller(
    private val okHttpClient: OkHttpClient,
    private val accountStore: SocialAccountStore,
    private val oAuthClient: OAuthClient,
) {

    /**
     * Executes [buildRequest] with a valid access token and parses the
     * response with [parse]. Handles the refresh-on-401 dance above.
     */
    suspend fun <T> call(
        platform: SocialPlatform,
        buildRequest: (accessToken: String) -> Request,
        parse: (statusCode: Int, body: String, response: Response) -> JarvisResult<T>,
    ): JarvisResult<T> = withContext(Dispatchers.IO) {
        val firstToken = when (val token = validAccessToken(platform)) {
            is JarvisResult.Success -> token.value
            is JarvisResult.Failure -> return@withContext token
        }
        val first = execute(platform, buildRequest(firstToken), parse)
        if (first !is Unauthorized) return@withContext first.result

        // 401: refresh once and retry once.
        val refreshed = refreshOrDisconnect(platform)
        if (refreshed is JarvisResult.Failure) return@withContext refreshed
        val retry = execute(platform, buildRequest((refreshed as JarvisResult.Success).value), parse)
        if (retry is Unauthorized) {
            // The fresh token was also rejected — the connection is
            // dead (revoked on the platform's side). Disconnect.
            accountStore.clearTokens(platform)
            return@withContext JarvisResult.Failure(
                "${platform.displayName} rejected the connection even after refreshing — " +
                    "the account may have been revoked there. Reconnect it in " +
                    "Settings → Connected accounts.",
            )
        }
        retry.result
    }

    /** A valid access token for [platform], refreshing first when expired. */
    suspend fun validAccessToken(platform: SocialPlatform): JarvisResult<String> {
        val tokens = accountStore.getTokens(platform)
            ?: return JarvisResult.Failure(
                "No ${platform.displayName} account connected — connect one in " +
                    "Settings → Connected accounts first.",
            )
        if (!tokens.isExpired(System.currentTimeMillis())) {
            return JarvisResult.Success(tokens.accessToken)
        }
        return refreshOrDisconnect(platform)
    }

    /**
     * Refreshes the stored tokens and returns the new access token.
     * On refresh failure the tokens are cleared (disconnected) and a
     * plain-language failure is returned.
     */
    private suspend fun refreshOrDisconnect(platform: SocialPlatform): JarvisResult<String> {
        val current = accountStore.getTokens(platform)
            ?: return JarvisResult.Failure(
                "No ${platform.displayName} account connected — connect one in " +
                    "Settings → Connected accounts first.",
            )
        val credentials = accountStore.getClientCredentials(platform)
            ?: return JarvisResult.Failure(
                "No OAuth client credentials stored for ${platform.displayName} — " +
                    "reconnect the account in Settings → Connected accounts.",
            )
        return when (val refreshed = oAuthClient.refreshTokens(platform, current, credentials)) {
            is JarvisResult.Success -> {
                accountStore.saveTokens(platform, refreshed.value)
                JarvisResult.Success(refreshed.value.accessToken)
            }
            is JarvisResult.Failure -> {
                accountStore.clearTokens(platform)
                JarvisResult.Failure(
                    "Your ${platform.displayName} connection expired and could not be " +
                        "refreshed — reconnect it in Settings → Connected accounts. " +
                        "(${refreshed.message})",
                )
            }
        }
    }

    /** One attempt: executes the request and parses the response. */
    private fun <T> execute(
        platform: SocialPlatform,
        request: Request,
        parse: (statusCode: Int, body: String, response: Response) -> JarvisResult<T>,
    ): Attempt<T> {
        return try {
            okHttpClient.newCall(request).execute().use { response ->
                val body = response.body?.readUtf8Capped(MAX_RESPONSE_BYTES) ?: ""
                if (response.code == 401) {
                    Unauthorized(parse(response.code, body, response))
                } else {
                    Attempt(parse(response.code, body, response))
                }
            }
        } catch (e: Exception) {
            Attempt(
                JarvisResult.Failure(
                    "Could not reach ${platform.displayName}: " +
                        "${e.message ?: e::class.simpleName}. Check your connection and try again.",
                ),
            )
        }
    }

    private open class Attempt<T>(val result: JarvisResult<T>)
    private class Unauthorized<T>(result: JarvisResult<T>) : Attempt<T>(result)

    companion object {
        const val MAX_RESPONSE_BYTES: Long = 512L * 1024L
    }
}
