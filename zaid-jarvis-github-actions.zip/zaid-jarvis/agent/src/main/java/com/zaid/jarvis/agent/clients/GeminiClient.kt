package com.zaid.jarvis.agent.clients

import com.zaid.jarvis.agent.ChatMessage
import com.zaid.jarvis.agent.LlmProviderClient
import com.zaid.jarvis.agent.LlmRequest
import com.zaid.jarvis.agent.LlmResponse
import com.zaid.jarvis.agent.LlmToolCall
import com.zaid.jarvis.agent.LlmUsage
import com.zaid.jarvis.core.model.LlmProvider
import com.zaid.jarvis.core.util.JarvisResult
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path

/**
 * Google Gemini client (`:generateContent` on generativelanguage.googleapis.com)
 * with native function calling (`functionCall` / `functionResponse` parts).
 *
 * The API key is supplied per call by [apiKeyProvider] and sent only in the
 * `x-goog-api-key` header — never as a URL query parameter (URLs can end up
 * in logs), never logged.
 */
class GeminiClient(
    private val okHttpClient: OkHttpClient,
    private val apiKeyProvider: () -> String?,
) : LlmProviderClient {

    override val provider: LlmProvider = LlmProvider.GEMINI

    private val api: GeminiApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(LlmJson.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(GeminiApi::class.java)
    }

    override suspend fun chat(request: LlmRequest): JarvisResult<LlmResponse> {
        val apiKey = apiKeyProvider()?.takeIf { it.isNotBlank() }
            ?: return JarvisResult.Failure(
                "No Gemini API key stored. Add one in Settings → API keys.",
            )
        val body = buildRequestBody(request)
        return try {
            val response = api.generateContent(request.modelApiId, apiKey, body)
            if (!response.isSuccessful) {
                val errorBody = response.errorBody()?.string()
                return JarvisResult.Failure(
                    "Gemini API error (HTTP ${response.code()}): " +
                        extractErrorMessage(errorBody),
                )
            }
            val json = response.body()?.string()
                ?: return JarvisResult.Failure("Gemini returned an empty response.")
            JarvisResult.Success(parseGeminiResponse(json))
        } catch (e: Exception) {
            JarvisResult.Failure("Could not reach Gemini: ${e.message ?: e::class.simpleName}")
        }
    }

    private interface GeminiApi {
        @POST("v1beta/models/{model}:generateContent")
        suspend fun generateContent(
            @Path("model") model: String,
            @Header("x-goog-api-key") apiKey: String,
            @Body body: JsonObject,
        ): Response<ResponseBody>
    }

    companion object {
        const val BASE_URL: String = "https://generativelanguage.googleapis.com/"

        /** Builds the Gemini wire format from a provider-neutral request. */
        fun buildRequestBody(request: LlmRequest): JsonObject = buildJsonObject {
            request.systemPrompt?.let { system ->
                putJsonObject("system_instruction") {
                    putJsonArray("parts") {
                        add(buildJsonObject { put("text", system) })
                    }
                }
            }
            putJsonArray("contents") {
                request.messages.forEach { message -> add(messageToJson(message)) }
            }
            putJsonObject("generationConfig") {
                put("maxOutputTokens", request.maxTokens)
            }
            if (request.tools.isNotEmpty()) {
                putJsonArray("tools") {
                    add(
                        buildJsonObject {
                            putJsonArray("functionDeclarations") {
                                request.tools.forEach { tool ->
                                    add(
                                        buildJsonObject {
                                            put("name", tool.name)
                                            put("description", tool.description)
                                            put("parameters", tool.inputSchema)
                                        },
                                    )
                                }
                            }
                        },
                    )
                }
            }
        }

        private fun messageToJson(message: ChatMessage): JsonObject = buildJsonObject {
            when (message.role) {
                "tool" -> {
                    // Tool results travel as role "function" with a
                    // functionResponse part. The name is recovered from the
                    // content prefix the planner adds ("<tool>: <result>");
                    // if absent, Gemini still accepts the part.
                    put("role", "function")
                    putJsonArray("parts") {
                        add(
                            buildJsonObject {
                                putJsonObject("functionResponse") {
                                    put("name", message.toolCallId ?: "tool")
                                    putJsonObject("response") {
                                        put("result", message.content)
                                    }
                                }
                            },
                        )
                    }
                }
                "assistant" -> {
                    put("role", "model")
                    putJsonArray("parts") {
                        if (message.content.isNotBlank()) {
                            add(buildJsonObject { put("text", message.content) })
                        }
                        message.toolCalls.forEach { call ->
                            add(
                                buildJsonObject {
                                    putJsonObject("functionCall") {
                                        put("name", call.name)
                                        put(
                                            "args",
                                            runCatching {
                                                LlmJson.parseToJsonElement(call.argumentsJson).jsonObject
                                            }.getOrDefault(JsonObject(emptyMap())),
                                        )
                                    }
                                },
                            )
                        }
                    }
                }
                else -> {
                    put("role", "user")
                    putJsonArray("parts") {
                        add(buildJsonObject { put("text", message.content) })
                    }
                }
            }
        }
    }
}

/**
 * Parses a Gemini `:generateContent` response into a provider-neutral
 * response. Public so unit tests can feed it recorded fixtures.
 *
 * Note: Gemini function calls carry no id, so the planner pairs a
 * functionResponse with its call by tool name (see the planner's
 * tool-result messages, which carry the name in `toolCallId`).
 */
fun parseGeminiResponse(responseJson: String): LlmResponse {
    val root = LlmJson.parseToJsonElement(responseJson).jsonObject
    val candidate = root.array("candidates")?.firstOrNull()
        ?.let { runCatching { it.jsonObject }.getOrNull() }
    val content = candidate?.obj("content")
    val text = StringBuilder()
    val toolCalls = mutableListOf<LlmToolCall>()
    content?.array("parts")?.forEach { part ->
        val obj = runCatching { part.jsonObject }.getOrNull() ?: return@forEach
        obj.string("text")?.let { text.append(it) }
        obj.obj("functionCall")?.let { call ->
            val name = call.string("name") ?: return@let
            val args = call.element("args") ?: JsonObject(emptyMap())
            // Gemini gives no call id — use the tool name as the pairing key.
            toolCalls += LlmToolCall(id = name, name = name, argumentsJson = args.toString())
        }
    }
    val usageObj = root.obj("usageMetadata")
    return LlmResponse(
        text = text.toString(),
        toolCalls = toolCalls,
        usage = LlmUsage(
            inputTokens = usageObj?.long("promptTokenCount") ?: 0,
            outputTokens = usageObj?.long("candidatesTokenCount") ?: 0,
        ),
        finishReason = candidate?.string("finishReason"),
    )
}
