package com.zaid.jarvis.agent.clients

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * Shared JSON helpers for the LLM clients. All clients build requests and
 * parse responses as [JsonObject]s (rather than generated DTOs) so a new
 * field in a provider's API can never break parsing — unknown fields are
 * ignored, and missing optional fields default safely.
 */
internal val LlmJson: Json = Json {
    ignoreUnknownKeys = true
    encodeDefaults = false
}

internal fun JsonObject.string(key: String): String? =
    this[key]?.let { runCatching { it.jsonPrimitive.content }.getOrNull() }

internal fun JsonObject.long(key: String): Long? =
    this[key]?.let { runCatching { it.jsonPrimitive.content.toLong() }.getOrNull() }

internal fun JsonObject.obj(key: String): JsonObject? =
    this[key]?.let { runCatching { it.jsonObject }.getOrNull() }

internal fun JsonObject.array(key: String): JsonArray? =
    this[key]?.let { runCatching { it.jsonArray }.getOrNull() }

internal fun JsonObject.element(key: String): JsonElement? = this[key]

internal fun JsonPrimitive?.asText(): String? =
    this?.let { runCatching { it.content }.getOrNull() }

/**
 * Extracts a human-readable error message from a provider error body.
 * Anthropic, OpenAI, and Gemini all nest it under `error.message`.
 * Falls back to the raw body (truncated) when the shape is unknown.
 * Never returns anything containing an API key — error bodies don't
 * include one, and callers must never log the request itself.
 */
internal fun extractErrorMessage(body: String?): String {
    if (body.isNullOrBlank()) return "Empty error response from provider."
    val message = runCatching {
        LlmJson.parseToJsonElement(body).jsonObject
            .obj("error")?.string("message")
    }.getOrNull()
    return message?.takeIf { it.isNotBlank() } ?: body.take(300)
}
