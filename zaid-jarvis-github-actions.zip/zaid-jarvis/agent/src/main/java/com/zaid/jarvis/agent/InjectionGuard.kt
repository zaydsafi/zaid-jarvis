package com.zaid.jarvis.agent

/**
 * Prompt-injection defense (Master Prompt §7).
 *
 * Text that comes back from a tool — a web page, a message, on-screen text —
 * is DATA, never instructions. Before the planner acts on a tool result, it
 * runs that result through this guard. When the text contains instruction-like
 * patterns (an attempt to make Jarvis do something Zaid never asked for),
 * the planner stops and asks Zaid instead of acting on it.
 *
 * This is a heuristic safety net, not a guarantee: patterns are deliberately
 * narrow (strong imperatives and override attempts) to avoid flagging
 * ordinary text like "send the report" in a document Zaid wrote.
 */
object InjectionGuard {

    /** One suspicious pattern found in tool-result text. */
    data class Finding(
        /** What kind of attempt this looks like. */
        val description: String,
        /** The matched snippet (truncated), shown to Zaid for transparency. */
        val snippet: String,
    )

    private data class Pattern(val regex: Regex, val description: String)

    private val patterns: List<Pattern> = listOf(
        Pattern(
            Regex("(?i)\\b(ignore|disregard|forget|override)\\s+(all\\s+)?(previous|prior|above|earlier|your|the)\\s+(instructions|rules|guidelines|prompts|safety)"),
            "Attempt to override Jarvis's instructions",
        ),
        Pattern(
            Regex("(?i)\\b(ignore|disregard)\\s+(safety|content\\s+polic)"),
            "Attempt to bypass safety rules",
        ),
        Pattern(
            Regex("(?i)\\byou\\s+are\\s+now\\s+"),
            "Attempt to redefine Jarvis's role",
        ),
        Pattern(
            Regex("(?i)\\b(reveal|show|print|repeat|disclose)\\s+(your\\s+)?(system\\s+prompt|initial\\s+prompt|instructions|api\\s*key|secret)"),
            "Attempt to extract Jarvis's instructions or secrets",
        ),
        Pattern(
            Regex("(?i)\\b(send|share|forward|leak)\\s+(the\\s+)?(password|api\\s*key|secret|otp|verification\\s+code|private\\s+key)"),
            "Attempt to exfiltrate credentials",
        ),
        Pattern(
            Regex("(?i)\\b(transfer|wire|send)\\s+\\$?\\d"),
            "Attempt to move money",
        ),
        Pattern(
            Regex("(?i)\\b(delete|erase|wipe|format)\\s+(all|everything|every)"),
            "Attempt to delete everything",
        ),
        Pattern(
            Regex("(?i)\\b(run|execute)\\s+(this\\s+)?(command|script|code)\\b"),
            "Attempt to run arbitrary code",
        ),
        Pattern(
            Regex("(?i)\\bsudo\\b"),
            "Attempt to gain elevated privileges",
        ),
        Pattern(
            Regex("(?i)\\b(do\\s+not|don't|never)\\s+(ask|tell|notify|show|inform)\\s+(the\\s+)?user\\b"),
            "Attempt to hide an action from Zaid",
        ),
        Pattern(
            Regex("(?i)\\bjailbreak\\b"),
            "Jailbreak attempt",
        ),
    )

    /** Scans [toolResultText] for instruction-like patterns. Empty = clean. */
    fun scan(toolResultText: String): List<Finding> {
        if (toolResultText.isBlank()) return emptyList()
        val findings = mutableListOf<Finding>()
        for (pattern in patterns) {
            val match = pattern.regex.find(toolResultText) ?: continue
            findings += Finding(
                description = pattern.description,
                snippet = match.value.take(120),
            )
        }
        return findings
    }
}
