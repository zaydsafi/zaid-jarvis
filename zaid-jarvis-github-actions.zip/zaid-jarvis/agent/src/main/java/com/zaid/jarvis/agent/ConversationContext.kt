package com.zaid.jarvis.agent

/**
 * Short-term conversation context (Master Prompt §4: "short-term
 * conversation context").
 *
 * Holds the recent turns of the current chat so follow-up messages make
 * sense ("do it again, but shorter"). Bounded to the last [MAX_MESSAGES]
 * messages so the prompt stays small; the system prompt is NOT stored
 * here — the planner builds it fresh per run.
 *
 * Long-term memory (preferences, nicknames, routines) is separate: it
 * lives in Room via MemoryRepository and is summarised into the system
 * prompt instead.
 */
class ConversationContext(
    private val maxMessages: Int = MAX_MESSAGES,
) {
    companion object {
        const val MAX_MESSAGES: Int = 20
    }

    private val messages = mutableListOf<ChatMessage>()
    private val lock = Any()

    fun addUser(text: String) = add(ChatMessage(role = "user", content = text))

    fun addAssistant(text: String, toolCalls: List<LlmToolCall> = emptyList()) =
        add(ChatMessage(role = "assistant", content = text, toolCalls = toolCalls))

    fun addToolResult(toolCallId: String, toolName: String, result: String) =
        add(
            ChatMessage(
                role = "tool",
                // The "<tool>: <result>" prefix lets providers without
                // tool-call ids (Gemini) recover the tool name.
                content = "$toolName: $result",
                toolCallId = toolCallId,
            ),
        )

    fun add(message: ChatMessage) {
        synchronized(lock) {
            messages += message
            while (messages.size > maxMessages) messages.removeAt(0)
        }
    }

    /** Snapshot of the conversation so far, oldest first. */
    fun snapshot(): List<ChatMessage> = synchronized(lock) { messages.toList() }

    fun clear() {
        synchronized(lock) { messages.clear() }
    }

    fun size(): Int = synchronized(lock) { messages.size }
}
