package com.zaid.jarvis.agent.social

import com.zaid.jarvis.core.social.PublishRequest
import com.zaid.jarvis.core.social.PublishResult
import com.zaid.jarvis.core.social.SocialAccount
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.core.util.JarvisResult
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response

/**
 * Social platform clients (Phase 8) — one implementation per platform
 * behind the [PlatformClient] interface, all via OFFICIAL APIs only.
 *
 * - X: POST /2/tweets (text only in Phase 8).
 * - Threads: two-step container flow — POST /v1.0/{user-id}/threads
 *   (media_type=TEXT) creates a container, then POST
 *   /v1.0/{user-id}/threads_publish publishes it; the permalink is
 *   fetched afterwards.
 * - LinkedIn: the current Posts API — POST /v2/posts (the older
 *   /v2/ugcPosts endpoint is deprecated for new apps). The post URN
 *   comes back in the `x-restli-id` response header.
 * - Instagram: Instagram Graph API container + publish flow —
 *   POST /{ig-user-id}/media then POST /{ig-user-id}/media_publish.
 *   Instagram cannot publish text-only posts, so a public image URL
 *   is required; the connected account must be a Business/Creator
 *   account linked to a Facebook Page (discovered at connect time).
 *
 * Endpoints are the best-known documented flows as of the build date;
 * PHASE8.md marks each one "verify against current docs before first
 * use". All response parsing lives in public companion functions so
 * the flows are unit-tested from recorded fixtures with no network.
 *
 * No logging anywhere: requests carry Bearer tokens.
 */
interface PlatformClient {
    val platform: SocialPlatform

    /** Publishes [request] as [account]. Fails plainly on API errors. */
    suspend fun publish(
        caller: AuthenticatedApiCaller,
        account: SocialAccount,
        request: PublishRequest,
    ): JarvisResult<PublishResult>

    /** Fetches the /me profile (used at connect time to learn the handle). */
    suspend fun fetchProfile(caller: AuthenticatedApiCaller): JarvisResult<SocialAccount>
}

/** Small JSON helpers shared by the clients (lenient: missing fields → null). */
internal object SocialJson {
    val json = Json { ignoreUnknownKeys = true }

    fun parse(body: String): JsonObject? =
        runCatching { json.parseToJsonElement(body).jsonObject }.getOrNull()
}

/** Reads a string field from a JSON object (null when missing or not a string). */
internal fun JsonObject.string(name: String): String? =
    runCatching { this[name]?.jsonPrimitive?.content }.getOrNull()

/** Reads a nested object field from a JSON object (null when missing or not an object). */
internal fun JsonObject.obj(name: String): JsonObject? =
    runCatching { this[name]?.jsonObject }.getOrNull()

/**
 * Turns an API error response into a plain-language failure. Looks for
 * the platform's error message fields (X: errors[0].message / detail,
 * Graph APIs: error.message, LinkedIn: message) and adds a plain
 * explanation for the common status codes.
 */
internal fun apiErrorFailure(
    platform: SocialPlatform,
    statusCode: Int,
    body: String,
    action: String,
): JarvisResult.Failure {
    val detail = SocialJson.parse(body)?.let { obj ->
        obj.obj("error")?.string("message")
            ?: runCatching { obj["errors"]?.jsonArray?.firstOrNull()?.jsonObject?.string("message") }.getOrNull()
            ?: obj.string("detail")
            ?: obj.string("message")
    }
    val hint = when (statusCode) {
        400 -> "The request was rejected"
        401 -> "The connection was rejected — reconnect the account in Settings → Connected accounts"
        403 -> "The app may not have the publish permission — check the app's permissions in the developer portal"
        404 -> "The account or endpoint was not found"
        429 -> "The platform rate-limited the request — wait a few minutes and retry"
        in 500..599 -> "The platform's servers had a problem — try again in a few minutes"
        else -> "The request failed"
    }
    val message = buildString {
        append("$hint while $action on ${platform.displayName} (HTTP $statusCode).")
        if (!detail.isNullOrBlank()) append(" The platform said: “$detail”.")
    }
    return JarvisResult.Failure(message)
}

/** X (Twitter): POST /2/tweets, text only in Phase 8. */
class XSocialClient : PlatformClient {
    override val platform: SocialPlatform = SocialPlatform.X

    override suspend fun publish(
        caller: AuthenticatedApiCaller,
        account: SocialAccount,
        request: PublishRequest,
    ): JarvisResult<PublishResult> {
        return caller.call(platform, { token ->
            val body = "{\"text\":${jsonString(request.text)}}"
                .toRequestBody("application/json".toMediaType())
            Request.Builder()
                .url("https://api.x.com/2/tweets")
                .header("Authorization", "Bearer $token")
                .post(body)
                .build()
        }) { status, responseBody, _ ->
            parsePublishResponse(status, responseBody, account)
        }
    }

    override suspend fun fetchProfile(caller: AuthenticatedApiCaller): JarvisResult<SocialAccount> {
        return caller.call(platform, { token ->
            Request.Builder()
                .url("https://api.x.com/2/users/me")
                .header("Authorization", "Bearer $token")
                .get()
                .build()
        }) { status, responseBody, _ ->
            if (status !in 200..299) {
                apiErrorFailure(platform, status, responseBody, "reading the account")
            } else {
                parseProfileResponse(responseBody)
            }
        }
    }

    companion object {
        /** Parses POST /2/tweets: {data: {id, text}}. */
        fun parsePublishResponse(
            status: Int,
            body: String,
            account: SocialAccount,
            nowMillis: Long = System.currentTimeMillis(),
        ): JarvisResult<PublishResult> {
            if (status !in 200..299) {
                return apiErrorFailure(SocialPlatform.X, status, body, "publishing")
            }
            val data = SocialJson.parse(body)?.obj("data")
            val id = data?.string("id")
                ?: return JarvisResult.Failure("X published the post but did not return a post id.")
            return JarvisResult.Success(
                PublishResult(
                    platform = SocialPlatform.X,
                    postId = id,
                    postUrl = "https://x.com/${account.handle}/status/$id",
                    publishedAtMillis = nowMillis,
                ),
            )
        }

        /** Parses GET /2/users/me: {data: {id, name, username}}. */
        fun parseProfileResponse(body: String): JarvisResult<SocialAccount> {
            val data = SocialJson.parse(body)?.obj("data")
            val id = data?.string("id")
            val username = data?.string("username")
            val name = data?.string("name")
            if (id == null || username == null) {
                return JarvisResult.Failure("X did not return the account details.")
            }
            return JarvisResult.Success(
                SocialAccount(
                    platform = SocialPlatform.X,
                    accountId = id,
                    handle = username,
                    displayName = name ?: username,
                ),
            )
        }
    }
}

/**
 * Threads: two-step container flow — create the container, publish it,
 * then fetch the permalink (best effort; the post id alone is enough
 * for the report if the permalink fetch fails).
 */
class ThreadsSocialClient : PlatformClient {
    override val platform: SocialPlatform = SocialPlatform.THREADS

    override suspend fun publish(
        caller: AuthenticatedApiCaller,
        account: SocialAccount,
        request: PublishRequest,
    ): JarvisResult<PublishResult> {
        // Step 1: create the text container.
        val containerId = when (
            val created = caller.call(platform, { token ->
                val url = "https://graph.threads.net/v1.0/${account.accountId}/threads"
                    .toHttpUrl().newBuilder()
                    .addQueryParameter("media_type", "TEXT")
                    .addQueryParameter("text", request.text)
                    .build()
                Request.Builder()
                    .url(url)
                    .header("Authorization", "Bearer $token")
                    .post(EMPTY_BODY)
                    .build()
            }) { status, body, _ -> parseContainerResponse(status, body) }
        ) {
            is JarvisResult.Success -> created.value
            is JarvisResult.Failure -> return created
        }
        // Step 2: publish the container.
        val mediaId = when (
            val published = caller.call(platform, { token ->
                val url = "https://graph.threads.net/v1.0/${account.accountId}/threads_publish"
                    .toHttpUrl().newBuilder()
                    .addQueryParameter("creation_id", containerId)
                    .build()
                Request.Builder()
                    .url(url)
                    .header("Authorization", "Bearer $token")
                    .post(EMPTY_BODY)
                    .build()
            }) { status, body, _ -> parsePublishContainerResponse(status, body) }
        ) {
            is JarvisResult.Success -> published.value
            is JarvisResult.Failure -> return published
        }
        // Step 3 (best effort): fetch the public permalink.
        val permalink = when (
            val fetched = caller.call(platform, { token ->
                val url = "https://graph.threads.net/v1.0/$mediaId".toHttpUrl().newBuilder()
                    .addQueryParameter("fields", "permalink")
                    .build()
                Request.Builder()
                    .url(url)
                    .header("Authorization", "Bearer $token")
                    .get()
                    .build()
            }) { status, body, _ -> parsePermalinkResponse(status, body) }
        ) {
            is JarvisResult.Success -> fetched.value
            is JarvisResult.Failure -> null
        }
        return JarvisResult.Success(
            PublishResult(
                platform = platform,
                postId = mediaId,
                postUrl = permalink,
                publishedAtMillis = System.currentTimeMillis(),
            ),
        )
    }

    override suspend fun fetchProfile(caller: AuthenticatedApiCaller): JarvisResult<SocialAccount> {
        return caller.call(platform, { token ->
            val url = "https://graph.threads.net/v1.0/me".toHttpUrl().newBuilder()
                .addQueryParameter("fields", "id,username,name")
                .build()
            Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $token")
                .get()
                .build()
        }) { status, responseBody, _ ->
            if (status !in 200..299) {
                apiErrorFailure(platform, status, responseBody, "reading the account")
            } else {
                parseProfileResponse(responseBody)
            }
        }
    }

    companion object {
        /** Parses the container creation response: {id}. */
        fun parseContainerResponse(status: Int, body: String): JarvisResult<String> {
            if (status !in 200..299) {
                return apiErrorFailure(SocialPlatform.THREADS, status, body, "creating the post")
            }
            return SocialJson.parse(body)?.string("id")?.let { JarvisResult.Success(it) }
                ?: JarvisResult.Failure("Threads did not return a container id.")
        }

        /** Parses the threads_publish response: {id} (the media id). */
        fun parsePublishContainerResponse(status: Int, body: String): JarvisResult<String> {
            if (status !in 200..299) {
                return apiErrorFailure(SocialPlatform.THREADS, status, body, "publishing")
            }
            return SocialJson.parse(body)?.string("id")?.let { JarvisResult.Success(it) }
                ?: JarvisResult.Failure("Threads published the post but did not return a post id.")
        }

        /** Parses a permalink lookup: {permalink} (or {id, permalink}). */
        fun parsePermalinkResponse(status: Int, body: String): JarvisResult<String> {
            if (status !in 200..299) {
                return JarvisResult.Failure("Permalink lookup failed (HTTP $status).")
            }
            return SocialJson.parse(body)?.string("permalink")?.let { JarvisResult.Success(it) }
                ?: JarvisResult.Failure("No permalink in the response.")
        }

        /** Parses GET /v1.0/me: {id, username, name}. */
        fun parseProfileResponse(body: String): JarvisResult<SocialAccount> {
            val obj = SocialJson.parse(body)
            val id = obj?.string("id")
            val username = obj?.string("username")
            val name = obj?.string("name")
            if (id == null || username == null) {
                return JarvisResult.Failure("Threads did not return the account details.")
            }
            return JarvisResult.Success(
                SocialAccount(
                    platform = SocialPlatform.THREADS,
                    accountId = id,
                    handle = username,
                    displayName = name ?: username,
                ),
            )
        }
    }
}

/**
 * LinkedIn: the current Posts API (POST /v2/posts). The older
 * /v2/ugcPosts endpoint is deprecated for new apps — see PHASE8.md.
 * The author URN is built from the /v2/userinfo `sub` (person id).
 */
class LinkedInSocialClient : PlatformClient {
    override val platform: SocialPlatform = SocialPlatform.LINKEDIN

    override suspend fun publish(
        caller: AuthenticatedApiCaller,
        account: SocialAccount,
        request: PublishRequest,
    ): JarvisResult<PublishResult> {
        return caller.call(platform, { token ->
            val body = buildString {
                append("{")
                append("\"author\":\"urn:li:person:${account.accountId}\",")
                append("\"commentary\":${jsonString(request.text)},")
                append("\"visibility\":\"PUBLIC\",")
                append("\"distribution\":{\"feedDistribution\":\"MAIN_FEED\"},")
                append("\"lifecycleState\":\"PUBLISHED\"")
                append("}")
            }.toRequestBody("application/json".toMediaType())
            Request.Builder()
                .url("https://api.linkedin.com/v2/posts")
                .header("Authorization", "Bearer $token")
                .header("X-Restli-Protocol-Version", "2.0.0")
                .post(body)
                .build()
        }) { status, responseBody, response ->
            parsePublishResponse(status, responseBody, response)
        }
    }

    override suspend fun fetchProfile(caller: AuthenticatedApiCaller): JarvisResult<SocialAccount> {
        return caller.call(platform, { token ->
            Request.Builder()
                .url("https://api.linkedin.com/v2/userinfo")
                .header("Authorization", "Bearer $token")
                .get()
                .build()
        }) { status, responseBody, _ ->
            if (status !in 200..299) {
                apiErrorFailure(platform, status, responseBody, "reading the account")
            } else {
                parseProfileResponse(responseBody)
            }
        }
    }

    companion object {
        /**
         * Parses POST /v2/posts: a 201 with the post URN in the
         * `x-restli-id` header (the body is empty).
         */
        fun parsePublishResponse(
            status: Int,
            body: String,
            response: Response,
            nowMillis: Long = System.currentTimeMillis(),
        ): JarvisResult<PublishResult> {
            if (status !in 200..299) {
                return apiErrorFailure(SocialPlatform.LINKEDIN, status, body, "publishing")
            }
            val urn = response.header("x-restli-id")
                ?: return JarvisResult.Failure(
                    "LinkedIn published the post but did not return a post id.",
                )
            return JarvisResult.Success(
                PublishResult(
                    platform = SocialPlatform.LINKEDIN,
                    postId = urn,
                    postUrl = "https://www.linkedin.com/feed/update/$urn",
                    publishedAtMillis = nowMillis,
                ),
            )
        }

        /** Parses GET /v2/userinfo: {sub, name, given_name, family_name}. */
        fun parseProfileResponse(body: String): JarvisResult<SocialAccount> {
            val obj = SocialJson.parse(body)
            val sub = obj?.string("sub")
            val name = obj?.string("name")
            if (sub == null) {
                return JarvisResult.Failure("LinkedIn did not return the account details.")
            }
            // LinkedIn's userinfo has no public username — the display
            // name is used as the handle.
            return JarvisResult.Success(
                SocialAccount(
                    platform = SocialPlatform.LINKEDIN,
                    accountId = sub,
                    handle = name ?: sub,
                    displayName = name ?: sub,
                ),
            )
        }
    }
}

/**
 * Instagram (Graph API): container + publish flow for photo posts.
 * Instagram cannot publish text-only posts — [PublishRequest.imageUrl]
 * is required and must be publicly reachable. The account must be a
 * Business/Creator account linked to a Facebook Page; the IG user id
 * is discovered at connect time (see [fetchProfile]).
 */
class InstagramSocialClient : PlatformClient {
    override val platform: SocialPlatform = SocialPlatform.INSTAGRAM

    override suspend fun publish(
        caller: AuthenticatedApiCaller,
        account: SocialAccount,
        request: PublishRequest,
    ): JarvisResult<PublishResult> {
        val imageUrl = request.imageUrl?.takeIf { it.isNotBlank() }
            ?: return JarvisResult.Failure(
                "Instagram posts need a photo — the Instagram API cannot publish " +
                    "text-only posts. Add a public image URL when publishing to Instagram.",
            )
        // Step 1: create the media container.
        val containerId = when (
            val created = caller.call(platform, { token ->
                val url = "https://graph.facebook.com/$GRAPH_VERSION/${account.accountId}/media"
                    .toHttpUrl().newBuilder()
                    .addQueryParameter("image_url", imageUrl)
                    .addQueryParameter("caption", request.text)
                    .build()
                Request.Builder()
                    .url(url)
                    .header("Authorization", "Bearer $token")
                    .post(EMPTY_BODY)
                    .build()
            }) { status, body, _ -> parseContainerResponse(status, body) }
        ) {
            is JarvisResult.Success -> created.value
            is JarvisResult.Failure -> return created
        }
        // Step 2: publish the container.
        val mediaId = when (
            val published = caller.call(platform, { token ->
                val url = "https://graph.facebook.com/$GRAPH_VERSION/${account.accountId}/media_publish"
                    .toHttpUrl().newBuilder()
                    .addQueryParameter("creation_id", containerId)
                    .build()
                Request.Builder()
                    .url(url)
                    .header("Authorization", "Bearer $token")
                    .post(EMPTY_BODY)
                    .build()
            }) { status, body, _ -> parsePublishContainerResponse(status, body) }
        ) {
            is JarvisResult.Success -> published.value
            is JarvisResult.Failure -> return published
        }
        // Step 3 (best effort): fetch the public permalink.
        val permalink = when (
            val fetched = caller.call(platform, { token ->
                val url = "https://graph.facebook.com/$GRAPH_VERSION/$mediaId"
                    .toHttpUrl().newBuilder()
                    .addQueryParameter("fields", "permalink")
                    .build()
                Request.Builder()
                    .url(url)
                    .header("Authorization", "Bearer $token")
                    .get()
                    .build()
            }) { status, body, _ -> ThreadsSocialClient.parsePermalinkResponse(status, body) }
        ) {
            is JarvisResult.Success -> fetched.value
            is JarvisResult.Failure -> null
        }
        return JarvisResult.Success(
            PublishResult(
                platform = platform,
                postId = mediaId,
                postUrl = permalink,
                publishedAtMillis = System.currentTimeMillis(),
            ),
        )
    }

    /**
     * Discovers the Instagram Business/Creator account: lists the
     * user's Facebook Pages, takes the first one with a linked
     * Instagram account, then reads that account's profile. Fails
     * plainly when no Page has a linked Instagram account.
     */
    override suspend fun fetchProfile(caller: AuthenticatedApiCaller): JarvisResult<SocialAccount> {
        val igUserId = when (
            val pages = caller.call(platform, { token ->
                val url = "https://graph.facebook.com/$GRAPH_VERSION/me/accounts"
                    .toHttpUrl().newBuilder()
                    .addQueryParameter("fields", "id,name,instagram_business_account")
                    .build()
                Request.Builder()
                    .url(url)
                    .header("Authorization", "Bearer $token")
                    .get()
                    .build()
            }) { status, body, _ -> parsePagesResponse(status, body) }
        ) {
            is JarvisResult.Success -> pages.value
            is JarvisResult.Failure -> return pages
        }
        return caller.call(platform, { token ->
            val url = "https://graph.facebook.com/$GRAPH_VERSION/$igUserId"
                .toHttpUrl().newBuilder()
                .addQueryParameter("fields", "id,username,name")
                .build()
            Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $token")
                .get()
                .build()
        }) { status, responseBody, _ ->
            if (status !in 200..299) {
                apiErrorFailure(platform, status, responseBody, "reading the Instagram account")
            } else {
                parseProfileResponse(responseBody)
            }
        }
    }

    companion object {
        /** Graph API version used for Instagram calls (verify before first use). */
        const val GRAPH_VERSION: String = "v21.0"

        /** Parses the media container response: {id}. */
        fun parseContainerResponse(status: Int, body: String): JarvisResult<String> {
            if (status !in 200..299) {
                return apiErrorFailure(SocialPlatform.INSTAGRAM, status, body, "creating the post")
            }
            return SocialJson.parse(body)?.string("id")?.let { JarvisResult.Success(it) }
                ?: JarvisResult.Failure("Instagram did not return a container id.")
        }

        /** Parses the media_publish response: {id} (the media id). */
        fun parsePublishContainerResponse(status: Int, body: String): JarvisResult<String> {
            if (status !in 200..299) {
                // The common cause: the image URL isn't publicly
                // reachable, or the container wasn't ready yet.
                val base = apiErrorFailure(SocialPlatform.INSTAGRAM, status, body, "publishing")
                return JarvisResult.Failure(
                    base.message + " If the image URL is private or slow to load, " +
                        "Instagram rejects the post — use a public, fast image URL and retry.",
                )
            }
            return SocialJson.parse(body)?.string("id")?.let { JarvisResult.Success(it) }
                ?: JarvisResult.Failure("Instagram published the post but did not return a post id.")
        }

        /** Parses GET /me/accounts: finds the first Page with a linked Instagram account. */
        fun parsePagesResponse(status: Int, body: String): JarvisResult<String> {
            if (status !in 200..299) {
                return apiErrorFailure(
                    SocialPlatform.INSTAGRAM,
                    status,
                    body,
                    "listing the Facebook Pages",
                )
            }
            val pages = runCatching { SocialJson.parse(body)?.get("data")?.jsonArray }.getOrNull()
                ?: return JarvisResult.Failure("Instagram did not return the Facebook Pages.")
            for (page in pages) {
                val ig = runCatching { page.jsonObject.obj("instagram_business_account") }.getOrNull()
                val igId = ig?.string("id")
                if (igId != null) return JarvisResult.Success(igId)
            }
            return JarvisResult.Failure(
                "No Instagram Business or Creator account is linked to a Facebook Page " +
                    "on this Facebook account. Link one first: in the Instagram app, " +
                    "switch to a Business/Creator account, then link it to a Facebook " +
                    "Page (Settings → Accounts Centre → Pages), then connect again.",
            )
        }

        /** Parses the IG user lookup: {id, username, name}. */
        fun parseProfileResponse(body: String): JarvisResult<SocialAccount> {
            val obj = SocialJson.parse(body)
            val id = obj?.string("id")
            val username = obj?.string("username")
            val name = obj?.string("name")
            if (id == null || username == null) {
                return JarvisResult.Failure("Instagram did not return the account details.")
            }
            return JarvisResult.Success(
                SocialAccount(
                    platform = SocialPlatform.INSTAGRAM,
                    accountId = id,
                    handle = username,
                    displayName = name ?: username,
                ),
            )
        }
    }
}

/** Empty body for Graph-style POSTs whose parameters are in the URL. */
private val EMPTY_BODY = ByteArray(0).toRequestBody(null)

/** JSON-encodes a string value (quotes, backslashes, control chars). */
internal fun jsonString(value: String): String {
    val escaped = buildString {
        append('"')
        for (ch in value) {
            when (ch) {
                '"' -> append("\\\"")
                '\\' -> append("\\\\")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> if (ch < ' ') append("\\u%04x".format(ch.code)) else append(ch)
            }
        }
        append('"')
    }
    return escaped
}
