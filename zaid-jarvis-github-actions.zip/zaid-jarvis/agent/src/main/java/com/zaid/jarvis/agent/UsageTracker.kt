package com.zaid.jarvis.agent

import com.zaid.jarvis.core.model.PricingTable

/**
 * Persists LLM usage (Master Prompt §4: "token and cost counter in
 * Settings"). The planner calls [record] after every LLM response with
 * the provider-reported token counts; the cost is estimated from
 * [PricingTable] (approximate rates, labelled as estimates in Settings).
 *
 * [UsageRecorder] is a seam so tests can capture usage without a database.
 */
fun interface UsageRecorder {
    suspend fun record(tokens: Long, costUsd: Double)
}

class UsageTracker(
    private val recorder: UsageRecorder,
) {
    /** Records one LLM response's usage. Safe to call with zero usage. */
    suspend fun record(modelApiId: String, usage: LlmUsage) {
        if (usage.totalTokens <= 0) return
        val cost = PricingTable.estimateCostUsd(
            modelApiId = modelApiId,
            inputTokens = usage.inputTokens,
            outputTokens = usage.outputTokens,
        )
        recorder.record(usage.totalTokens, cost)
    }
}
