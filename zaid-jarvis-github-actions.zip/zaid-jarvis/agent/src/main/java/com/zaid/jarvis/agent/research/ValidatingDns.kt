package com.zaid.jarvis.agent.research

import com.zaid.jarvis.core.research.UrlSafety
import java.net.InetAddress
import java.net.UnknownHostException
import okhttp3.Dns

/**
 * DNS-rebinding guard (Phase 11 hardening — the item deferred from
 * Phase 7).
 *
 * The Phase 7 SSRF guard ([UrlSafety.validateUrl]) only sees the host
 * *as written*: it refuses literal private IPs, but a hostname that
 * *resolves* to a private IP (a public name pointing at 192.168.x.x,
 * or a rebinding attack where the second lookup returns a private
 * address) sailed straight through. This [Dns] closes that hole: it
 * resolves through [delegate] (the system resolver by default),
 * validates EVERY resolved address with [UrlSafety.isNonPublicAddress]
 * (private / loopback / link-local / reserved, IPv4 and IPv6,
 * including IPv4-mapped and IPv4-compatible forms), and refuses the
 * whole lookup when ANY address is non-public.
 *
 * What this guarantees, precisely:
 * - OkHttp connects only to the [InetAddress] objects a [Dns.lookup]
 *   returns — it never re-resolves between lookup and connect — so
 *   validating inside lookup() means a socket is only ever opened to
 *   an address that passed validation. There is no TOCTOU gap between
 *   the check and the connect.
 * - Every lookup is validated independently, including the fresh
 *   lookup of each redirect hop: a redirect to a host that resolves
 *   privately is refused at that hop's lookup (on top of the literal
 *   re-validation of the final URL in OkHttpPageFetcher).
 * - Alternative IP spellings are caught here even though the literal
 *   check misses them: resolution normalizes them — `2130706433`
 *   resolves to 127.0.0.1, `::ffff:7f00:1` to the mapped loopback —
 *   and the byte-level check sees the real address.
 *
 * What this does NOT guarantee:
 * - It says nothing about the server at a public IP: a malicious page
 *   hosted on a public address is still fetched (that is what the
 *   InjectionGuard and the "web content is untrusted data" rule are
 *   for), and it does not validate TLS — that is the platform's job.
 * - It does not pin DNS answers: a hostname that resolves to a public
 *   IP now and a private IP on a later lookup is refused only on the
 *   later lookup. Each individual connection still only ever uses
 *   addresses validated for that lookup.
 * - It does not unwrap IPv6 transition mechanisms (6to4, Teredo):
 *   those packets go to a public relay, not to the embedded IPv4
 *   directly, so the embedded address is not a connection target.
 *
 * Scope: this Dns is installed on the shared OkHttpClient in
 * AgentModule, so it covers the page fetcher and the search clients
 * (the ones that fetch user/LLM-supplied URLs) AND the LLM, OAuth,
 * and social clients. That is deliberate: their hosts are fixed
 * public https endpoints, so the guard is a no-op for them in
 * practice and defense in depth against a poisoned resolver — and a
 * custom LLM provider whose hostname resolves to a private address is
 * refused, which is consistent with Phase 11 refusing http:// custom
 * providers outright (local servers are no longer supported; see
 * CustomProviderConfig).
 *
 * A refused lookup throws [UnknownHostException] with a plain-language
 * message; every caller already turns that into a user-facing failure
 * (no crash, no retry storm — the planner treats it as a failed tool
 * step, and the fetchers catch it as a fetch failure).
 */
class ValidatingDns(
    private val delegate: Dns = Dns.SYSTEM,
) : Dns {

    override fun lookup(hostname: String): List<InetAddress> {
        // The delegate throws UnknownHostException when the name does
        // not resolve at all — that propagates unchanged (clear error,
        // no crash) and is not reinterpreted here.
        val addresses = delegate.lookup(hostname)
        val bad = addresses.firstOrNull { UrlSafety.isNonPublicAddress(it) }
        if (bad != null) {
            throw UnknownHostException(
                "Refusing to connect to $hostname: it resolves to a private or " +
                    "local address (${bad.hostAddress}). Jarvis only connects to " +
                    "public addresses.",
            )
        }
        if (addresses.isEmpty()) {
            throw UnknownHostException("Could not resolve $hostname.")
        }
        return addresses
    }
}
