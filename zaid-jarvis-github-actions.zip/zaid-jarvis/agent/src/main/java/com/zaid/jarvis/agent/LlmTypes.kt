package com.zaid.jarvis.agent

import com.zaid.jarvis.core.model.LlmProvider
import com.zaid.jarvis.core.util.JarvisResult
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject

/**
 * Types shared by every LLM provider client (Master Prompt §4).
 * These are provider-neutral: each client translates them to and from
 * its own wire format (Anthropic, OpenAI, Gemini, OpenRouter, custom).
 */

// ── Messages ─────────────────────────────────────────────────────────────

/** One turn of conversation sent to (or received from) the LLM. */
@Serializable
data class ChatMessage(
    /** "system" | "user" | "assistant" | "tool". */
    val role: String,
    val content: String,
    /** Tool calls the assistant asked for (assistant messages only). */
    val toolCalls: List<LlmToolCall> = emptyList(),
    /** The tool call this result answers (tool messages only). */
    val toolCallId: String? = null,
)

// ── Tools ────────────────────────────────────────────────────────────────

/** A tool the LLM may call, as described to it. */
@Serializable
data class ToolDefinition(
    val name: String,
    val description: String,
    /** JSON Schema for the tool's arguments (see :tools ToolSchema). */
    val inputSchema: JsonObject,
)

/** One tool call requested by the LLM. */
@Serializable
data class LlmToolCall(
    /** Provider-assigned id, used to pair the call with its result. */
    val id: String,
    val name: String,
    /** Raw JSON string of the arguments object. */
    val argumentsJson: String,
)

// ── Requests / responses ─────────────────────────────────────────────────

/** A request to an LLM provider. */
data class LlmRequest(
    val provider: LlmProvider,
    /** The exact model ID to send to the API (resolved by LlmClientFactory). */
    val modelApiId: String,
    val messages: List<ChatMessage>,
    val tools: List<ToolDefinition> = emptyList(),
    /** System prompt, sent separately so clients can map it correctly. */
    val systemPrompt: String? = null,
    val maxTokens: Int = 1024,
)

/** Token usage reported by the provider for one response. */
@Serializable
data class LlmUsage(
    val inputTokens: Long = 0,
    val outputTokens: Long = 0,
) {
    val totalTokens: Long get() = inputTokens + outputTokens
}

/** A response from an LLM provider. */
data class LlmResponse(
    /** The assistant's text reply (may be empty when it only calls tools). */
    val text: String,
    /** Tool calls the assistant wants performed, in order. */
    val toolCalls: List<LlmToolCall> = emptyList(),
    val usage: LlmUsage = LlmUsage(),
    /** Provider's finish reason, e.g. "stop", "tool_calls", "end_turn". */
    val finishReason: String? = null,
)

/**
 * Contract every LLM provider client implements (Claude, OpenAI, Gemini,
 * OpenRouter, custom OpenAI-compatible providers).
 *
 * Implementations must:
 * - read their API key from ApiKeyRepository at call time (never cache it
 *   in a field, never log it, never put it in a URL),
 * - translate [LlmRequest.tools] into the provider's native tool format,
 * - report real token usage in [LlmResponse.usage] so the cost counter
 *   (Phase 3) is honest.
 */
interface LlmProviderClient {
    val provider: LlmProvider
    suspend fun chat(request: LlmRequest): JarvisResult<LlmResponse>
}
