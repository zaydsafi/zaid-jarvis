package com.zaid.jarvis.agent.social

import com.zaid.jarvis.core.social.OAuthClientCredentials
import com.zaid.jarvis.core.social.OAuthTokens
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.core.util.JarvisResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import okhttp3.FormBody
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.Base64

/**
 * OAuth 2.0 token operations (Phase 8): authorization-code exchange
 * (PKCE), refresh, and the long-lived-token exchanges Threads and
 * Instagram need for scheduling (their short-lived tokens last about
 * an hour — useless for a post scheduled for tomorrow).
 *
 * Per-platform differences, all in one place:
 * - X: POST form to the token endpoint; PKCE-only when no client
 *   secret is configured (public/native client), HTTP Basic auth when
 *   one is. Refresh uses grant_type=refresh_token (needs the
 *   `offline.access` scope, requested at connect time).
 * - Threads: POST form with client_secret (required). Short-lived
 *   tokens are exchanged for 60-day long-lived tokens
 *   (grant_type=th_exchange_token); long-lived tokens refresh with
 *   grant_type=th_refresh_token using the ACCESS token (Threads has no
 *   separate refresh token).
 * - LinkedIn: POST form with client_secret. Refresh uses
 *   grant_type=refresh_token.
 * - Instagram (Meta Graph API): the token endpoint takes GET query
 *   params. Short-lived user tokens are exchanged for 60-day
 *   long-lived tokens (grant_type=fb_exchange_token); long-lived
 *   tokens refresh the same way, with the current token as
 *   fb_exchange_token.
 *
 * Tokens are never logged. Error messages quote only the OAuth
 * error/error_description fields, never the response body wholesale.
 */
class OAuthClient(private val okHttpClient: OkHttpClient) {

    private val json = Json { ignoreUnknownKeys = true }

    /**
     * Exchanges an authorization code for tokens (PKCE). For Threads
     * and Instagram the returned tokens are immediately exchanged for
     * long-lived ones; for X and LinkedIn the tokens are returned as-is.
     */
    suspend fun exchangeCode(
        platform: SocialPlatform,
        code: String,
        codeVerifier: String,
        redirectUri: String,
        credentials: OAuthClientCredentials,
        nowMillis: Long = System.currentTimeMillis(),
    ): JarvisResult<OAuthTokens> = withContext(Dispatchers.IO) {
        try {
            val request = when (platform) {
                SocialPlatform.INSTAGRAM -> instagramTokenRequest(
                    params = mapOf(
                        "client_id" to credentials.clientId,
                        "client_secret" to (credentials.clientSecret ?: ""),
                        "redirect_uri" to redirectUri,
                        "code" to code,
                    ),
                )
                else -> {
                    val form = FormBody.Builder()
                        .add("grant_type", "authorization_code")
                        .add("code", code)
                        .add("redirect_uri", redirectUri)
                        .add("client_id", credentials.clientId)
                        .add("code_verifier", codeVerifier)
                        .apply {
                            // Threads and LinkedIn require the secret in the body.
                            if (platform != SocialPlatform.X) {
                                credentials.clientSecret?.let { add("client_secret", it) }
                            }
                        }
                        .build()
                    val builder = Request.Builder().url(platform.tokenUrl).post(form)
                    // X confidential clients authenticate with HTTP Basic.
                    val clientSecret = credentials.clientSecret
                    if (platform == SocialPlatform.X && clientSecret != null) {
                        builder.header(
                            "Authorization",
                            basicAuth(credentials.clientId, clientSecret),
                        )
                    }
                    builder.build()
                }
            }
            val tokens = executeTokenRequest(platform, request, nowMillis)
            when (tokens) {
                is JarvisResult.Failure -> tokens
                is JarvisResult.Success -> exchangeForLongLived(platform, tokens.value, credentials, nowMillis)
            }
        } catch (e: Exception) {
            JarvisResult.Failure(
                "Could not reach ${platform.displayName} to finish signing in: " +
                    "${e.message ?: e::class.simpleName}. Check your connection and try again.",
            )
        }
    }

    /**
     * Refreshes the current tokens. X and LinkedIn use their refresh
     * token; Threads and Instagram refresh their long-lived access
     * token directly. A failure here means the account must be
     * reconnected (the caller clears the tokens and tells Zaid).
     */
    suspend fun refreshTokens(
        platform: SocialPlatform,
        current: OAuthTokens,
        credentials: OAuthClientCredentials,
        nowMillis: Long = System.currentTimeMillis(),
    ): JarvisResult<OAuthTokens> = withContext(Dispatchers.IO) {
        try {
            val request = when (platform) {
                SocialPlatform.THREADS -> {
                    // Threads refreshes the long-lived access token itself.
                    val url = platform.tokenUrl.toHttpUrl().newBuilder()
                        .addQueryParameter("grant_type", "th_refresh_token")
                        .addQueryParameter("access_token", current.accessToken)
                        .build()
                    Request.Builder().url(url).get().build()
                }
                SocialPlatform.INSTAGRAM -> {
                    // Instagram refreshes the long-lived token the same
                    // way it was created (fb_exchange_token).
                    val url = "https://graph.facebook.com/oauth/access_token".toHttpUrl().newBuilder()
                        .addQueryParameter("grant_type", "fb_exchange_token")
                        .addQueryParameter("client_id", credentials.clientId)
                        .addQueryParameter("client_secret", credentials.clientSecret ?: "")
                        .addQueryParameter("fb_exchange_token", current.accessToken)
                        .build()
                    Request.Builder().url(url).get().build()
                }
                else -> {
                    val refreshToken = current.refreshToken
                        ?: return@withContext JarvisResult.Failure(
                            "No refresh token was stored for ${platform.displayName} — " +
                                "reconnect the account in Settings → Connected accounts.",
                        )
                    val form = FormBody.Builder()
                        .add("grant_type", "refresh_token")
                        .add("refresh_token", refreshToken)
                        .add("client_id", credentials.clientId)
                        .apply {
                            if (platform == SocialPlatform.LINKEDIN) {
                                credentials.clientSecret?.let { add("client_secret", it) }
                            }
                        }
                        .build()
                    val builder = Request.Builder().url(platform.tokenUrl).post(form)
                    val clientSecret = credentials.clientSecret
                    if (platform == SocialPlatform.X && clientSecret != null) {
                        builder.header(
                            "Authorization",
                            basicAuth(credentials.clientId, clientSecret),
                        )
                    }
                    builder.build()
                }
            }
            when (val refreshed = executeTokenRequest(platform, request, nowMillis)) {
                is JarvisResult.Success -> {
                    // Some providers don't return a new refresh token —
                    // keep the old one rather than losing it.
                    val kept = refreshed.value.refreshToken ?: current.refreshToken
                    JarvisResult.Success(refreshed.value.copy(refreshToken = kept))
                }
                is JarvisResult.Failure -> refreshed
            }
        } catch (e: Exception) {
            JarvisResult.Failure(
                "Could not reach ${platform.displayName} to refresh the connection: " +
                    "${e.message ?: e::class.simpleName}.",
            )
        }
    }

    /**
     * Threads and Instagram: exchanges a short-lived token (about 1
     * hour) for a 60-day long-lived token, so scheduled posts keep
     * working. X and LinkedIn tokens are returned unchanged.
     */
    private suspend fun exchangeForLongLived(
        platform: SocialPlatform,
        tokens: OAuthTokens,
        credentials: OAuthClientCredentials,
        nowMillis: Long,
    ): JarvisResult<OAuthTokens> {
        val url = when (platform) {
            SocialPlatform.THREADS -> platform.tokenUrl.toHttpUrl().newBuilder()
                .addQueryParameter("grant_type", "th_exchange_token")
                .addQueryParameter("client_secret", credentials.clientSecret ?: "")
                .addQueryParameter("access_token", tokens.accessToken)
                .build()
            SocialPlatform.INSTAGRAM -> "https://graph.facebook.com/oauth/access_token".toHttpUrl().newBuilder()
                .addQueryParameter("grant_type", "fb_exchange_token")
                .addQueryParameter("client_id", credentials.clientId)
                .addQueryParameter("client_secret", credentials.clientSecret ?: "")
                .addQueryParameter("fb_exchange_token", tokens.accessToken)
                .build()
            else -> return JarvisResult.Success(tokens)
        }
        val request = Request.Builder().url(url).get().build()
        return when (val exchanged = executeTokenRequest(platform, request, nowMillis)) {
            is JarvisResult.Success -> JarvisResult.Success(
                exchanged.value.copy(refreshToken = tokens.refreshToken),
            )
            // If the long-lived exchange fails, keep the short-lived
            // token rather than failing the whole sign-in — publishing
            // still works for the next hour; scheduling is the only
            // casualty, and the worker will report it honestly.
            is JarvisResult.Failure -> JarvisResult.Success(tokens)
        }
    }

    /** Executes a token-endpoint request and parses the token response. */
    private fun executeTokenRequest(
        platform: SocialPlatform,
        request: Request,
        nowMillis: Long,
    ): JarvisResult<OAuthTokens> {
        okHttpClient.newCall(request).execute().use { response ->
            val body = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                return JarvisResult.Failure(
                    "${platform.displayName} refused the request " +
                        "(HTTP ${response.code}): ${oauthErrorMessage(body)}",
                )
            }
            return parseTokenResponse(body, nowMillis)
        }
    }

    /** Meta's token endpoint takes its parameters as a GET query string. */
    private fun instagramTokenRequest(params: Map<String, String>): Request {
        val builder = SocialPlatform.INSTAGRAM.tokenUrl.toHttpUrl().newBuilder()
        params.forEach { (key, value) -> builder.addQueryParameter(key, value) }
        return Request.Builder().url(builder.build()).get().build()
    }

    private fun basicAuth(clientId: String, clientSecret: String): String {
        val raw = "$clientId:$clientSecret".toByteArray(Charsets.UTF_8)
        return "Basic " + Base64.getEncoder().encodeToString(raw)
    }

    /**
     * Extracts the OAuth error description from an error body
     * ({error, error_description}), or a generic message when the body
     * doesn't parse. Never returns the raw body (it could contain
     * sensitive data).
     */
    internal fun oauthErrorMessage(body: String): String {
        return try {
            val obj = json.parseToJsonElement(body).jsonObject
            obj["error_description"]?.jsonPrimitive?.content
                ?: obj["error"]?.jsonPrimitive?.content
                ?: "the sign-in request was rejected"
        } catch (_: Exception) {
            "the sign-in request was rejected"
        }
    }

    companion object {
        /**
         * Parses a token response ({access_token, refresh_token?,
         * expires_in?}) into [OAuthTokens]. Public for fixture tests —
         * no network involved.
         */
        fun parseTokenResponse(body: String, nowMillis: Long): JarvisResult<OAuthTokens> {
            return try {
                val json = Json { ignoreUnknownKeys = true }
                val obj = json.parseToJsonElement(body).jsonObject
                val accessToken = obj["access_token"]?.jsonPrimitive?.content
                    ?: return JarvisResult.Failure(
                        "The sign-in response had no access token.",
                    )
                val refreshToken = obj["refresh_token"]?.jsonPrimitive?.content
                val expiresInSeconds = obj["expires_in"]?.jsonPrimitive?.longOrNull
                val expiresAt = if (expiresInSeconds != null && expiresInSeconds > 0) {
                    nowMillis + expiresInSeconds * 1000L
                } else {
                    0L
                }
                JarvisResult.Success(
                    OAuthTokens(
                        accessToken = accessToken,
                        refreshToken = refreshToken,
                        expiresAtMillis = expiresAt,
                    ),
                )
            } catch (e: Exception) {
                JarvisResult.Failure(
                    "Could not read the sign-in response: ${e.message ?: e::class.simpleName}.",
                )
            }
        }
    }
}
