package com.zaid.jarvis.agent.research

import com.zaid.jarvis.agent.readUtf8Capped
import com.zaid.jarvis.core.model.JarvisSettings
import com.zaid.jarvis.core.research.SearchBackend
import com.zaid.jarvis.core.research.SearchResult
import com.zaid.jarvis.core.research.SearchResultParser
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.research.WebSearch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * Web-search backends (Phase 7).
 *
 * - [DuckDuckGoSearch] (default, free, no key): DuckDuckGo's lite HTML
 *   endpoint. No account, no key, no tracking by Jarvis — but result
 *   quality and markup stability depend on DuckDuckGo, and heavy use
 *   may be rate-limited (HTTP 403/429 → a clear failure, not a crash).
 * - [TavilySearch] (optional, key-based): Tavily's research search API,
 *   chosen over Brave because it is built for AI research (relevance-
 *   ranked snippets, one JSON call, generous free tier). Key from
 *   https://app.tavily.com — stored Keystore-encrypted like all keys.
 * - [ConfigurableWebSearch] picks the backend from Settings at call time.
 *
 * No logging interceptor anywhere: queries could contain anything Zaid
 * typed, and the Tavily key must never reach logcat.
 */

/** DuckDuckGo lite search — free, no key. */
class DuckDuckGoSearch(private val okHttpClient: OkHttpClient) : WebSearch {

    override suspend fun search(query: String, maxResults: Int): JarvisResult<List<SearchResult>> =
        withContext(Dispatchers.IO) {
            try {
                val url = "https://lite.duckduckgo.com/lite/".toHttpUrl().newBuilder()
                    .addQueryParameter("q", query)
                    .build()
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", USER_AGENT)
                    .header("Accept", "text/html")
                    .get()
                    .build()
                okHttpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext JarvisResult.Failure(
                            "DuckDuckGo search failed (HTTP ${response.code}). " +
                                "Try again in a moment, or switch the search backend in " +
                                "Settings → Research.",
                        )
                    }
                    val html = response.body?.readUtf8Capped(MAX_RESPONSE_BYTES) ?: ""
                    val results = SearchResultParser.parseDuckDuckGoLite(
                        html = html,
                        maxResults = maxResults.coerceIn(1, 10),
                        fetchedAtMillis = System.currentTimeMillis(),
                    )
                    JarvisResult.Success(results)
                }
            } catch (e: Exception) {
                JarvisResult.Failure(
                    "Could not reach DuckDuckGo: ${e.message ?: e::class.simpleName}. " +
                        "Check your connection and try again.",
                )
            }
        }

    companion object {
        /** Cap on the search page we read (DuckDuckGo lite pages are small). */
        const val MAX_RESPONSE_BYTES: Long = 512L * 1024L
        private const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/130.0 Mobile Safari/537.36"
    }
}

/** Tavily search — needs a Tavily API key (Settings → Research). */
class TavilySearch(
    private val okHttpClient: OkHttpClient,
    private val apiKeyProvider: () -> String?,
) : WebSearch {

    override suspend fun search(query: String, maxResults: Int): JarvisResult<List<SearchResult>> =
        withContext(Dispatchers.IO) {
            val apiKey = apiKeyProvider()?.takeIf { it.isNotBlank() }
                ?: return@withContext JarvisResult.Failure(
                    "No Tavily API key stored. Add one in Settings → Research, " +
                        "or switch the search backend back to DuckDuckGo.",
                )
            try {
                val body = buildJsonObject {
                    put("query", query)
                    put("max_results", maxResults.coerceIn(1, 10))
                    put("search_depth", "basic")
                    put("include_answer", false)
                }.toString().toRequestBody("application/json".toMediaType())
                val request = Request.Builder()
                    .url("https://api.tavily.com/search")
                    .header("Authorization", "Bearer $apiKey")
                    .post(body)
                    .build()
                okHttpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext JarvisResult.Failure(
                            "Tavily search failed (HTTP ${response.code}). " +
                                if (response.code == 401) {
                                    "The stored Tavily key may be wrong — check it in Settings → Research."
                                } else {
                                    "Try again in a moment."
                                },
                        )
                    }
                    val jsonText = response.body?.readUtf8Capped(MAX_RESPONSE_BYTES) ?: ""
                    val results = SearchResultParser.parseTavilyJson(
                        jsonText = jsonText,
                        maxResults = maxResults.coerceIn(1, 10),
                        fetchedAtMillis = System.currentTimeMillis(),
                    )
                    JarvisResult.Success(results)
                }
            } catch (e: Exception) {
                JarvisResult.Failure(
                    "Could not reach Tavily: ${e.message ?: e::class.simpleName}. " +
                        "Check your connection and try again.",
                )
            }
        }

    companion object {
        const val MAX_RESPONSE_BYTES: Long = 512L * 1024L
    }
}

/**
 * Picks the search backend from the current Settings at call time.
 * Tavily without a stored key fails with a plain-language message
 * (never a silent fallback to DuckDuckGo — Zaid chose Tavily, so a
 * missing key is something he should know about).
 */
class ConfigurableWebSearch(
    private val settingsProvider: suspend () -> JarvisSettings,
    private val duckDuckGo: WebSearch,
    private val tavily: WebSearch,
    private val hasTavilyKey: () -> Boolean,
) : WebSearch {
    override suspend fun search(query: String, maxResults: Int): JarvisResult<List<SearchResult>> {
        return when (settingsProvider().searchBackend) {
            SearchBackend.TAVILY -> {
                if (!hasTavilyKey()) {
                    JarvisResult.Failure(
                        "Tavily is selected as the search backend but no Tavily API key " +
                            "is stored. Add one in Settings → Research, or switch the " +
                            "backend back to DuckDuckGo.",
                    )
                } else {
                    tavily.search(query, maxResults)
                }
            }
            SearchBackend.DUCKDUCKGO -> duckDuckGo.search(query, maxResults)
        }
    }
}
