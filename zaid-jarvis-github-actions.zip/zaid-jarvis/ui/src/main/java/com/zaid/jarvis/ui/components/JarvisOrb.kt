package com.zaid.jarvis.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * The animated Jarvis orb — the voice-first home screen's centerpiece.
 * Phase 1: a breathing glow placeholder. Phase 4 wires it to live
 * voice state (listening / thinking / speaking) and the wake word.
 */
@Composable
fun JarvisOrb(
    modifier: Modifier = Modifier,
    size: Dp = 160.dp,
    isActive: Boolean = false,
) {
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(
        initialValue = 1f,
        targetValue = if (isActive) 1.18f else 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isActive) 700 else 1600),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "orbPulse",
    )
    val glowAlpha by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.7f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1600),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "orbGlow",
    )

    Box(modifier = modifier.size(size)) {
        // Outer glow halo.
        Box(
            modifier = Modifier
                .matchParentSize()
                .scale(pulse)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = glowAlpha * 0.4f))
                .blur(24.dp),
        )
        // Core orb.
        Box(
            modifier = Modifier
                .matchParentSize()
                .scale(0.72f)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary),
        )
        // Inner highlight.
        Box(
            modifier = Modifier
                .matchParentSize()
                .scale(0.4f)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)),
        )
    }
}
