package com.zaid.jarvis.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import com.zaid.jarvis.core.model.ThemeMode

private val JarvisTypography = Typography()

/**
 * Zaid Jarvis Material 3 theme.
 * Supports Light, Dark, AMOLED (true black), and Follow system.
 */
@Composable
fun JarvisTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit,
) {
    val useDark = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK, ThemeMode.AMOLED -> true
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val colors = when {
        themeMode == ThemeMode.AMOLED -> JarvisAmoledColors
        useDark -> JarvisDarkColors
        else -> JarvisLightColors
    }
    MaterialTheme(
        colorScheme = colors,
        typography = JarvisTypography,
        content = content,
    )
}
