package com.zaid.jarvis.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

// Zaid Jarvis brand: deep navy + electric cyan orb glow.

private val JarvisCyan = Color(0xFF22D3EE)
private val JarvisCyanDark = Color(0xFF0891B2)
private val JarvisNavy = Color(0xFF0B1220)
private val JarvisNavySurface = Color(0xFF111C33)

val JarvisLightColors = lightColorScheme(
    primary = JarvisCyanDark,
    onPrimary = Color.White,
    secondary = Color(0xFF0E7490),
    tertiary = Color(0xFF6366F1),
    background = Color(0xFFF8FAFC),
    surface = Color.White,
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF0F172A),
)

val JarvisDarkColors = darkColorScheme(
    primary = JarvisCyan,
    onPrimary = Color(0xFF082F3A),
    secondary = Color(0xFF67E8F9),
    tertiary = Color(0xFFA5B4FC),
    background = JarvisNavy,
    surface = JarvisNavySurface,
    onBackground = Color(0xFFE2E8F0),
    onSurface = Color(0xFFE2E8F0),
)

/** AMOLED: true black backgrounds so OLED pixels stay off. */
val JarvisAmoledColors = darkColorScheme(
    primary = JarvisCyan,
    onPrimary = Color(0xFF082F3A),
    secondary = Color(0xFF67E8F9),
    tertiary = Color(0xFFA5B4FC),
    background = Color.Black,
    surface = Color.Black,
    surfaceVariant = Color(0xFF0A0A0A),
    onBackground = Color(0xFFE2E8F0),
    onSurface = Color(0xFFE2E8F0),
)
