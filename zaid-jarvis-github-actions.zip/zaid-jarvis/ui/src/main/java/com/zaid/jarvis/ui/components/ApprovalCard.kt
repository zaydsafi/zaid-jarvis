package com.zaid.jarvis.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.zaid.jarvis.core.confirmation.ApprovalRequest
import com.zaid.jarvis.core.confirmation.RiskTier

/**
 * The approval card (Master Prompt §6): shows the action, the target, the
 * data used, and the exact content to be sent, with Allow / Edit / Deny.
 * Lives in :ui so the overlay bubble (Phase 4) can reuse it.
 *
 * @param remainingSeconds seconds left in the 2-minute approval window.
 * @param onTrust shown only for tiers 0–1 ("always allow this action").
 */
@Composable
fun ApprovalCard(
    request: ApprovalRequest,
    remainingSeconds: Long,
    onAllow: () -> Unit,
    onDeny: () -> Unit,
    onEdit: (String) -> Unit,
    onTrust: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    var editing by remember(request.id) { mutableStateOf(false) }
    var editedText by remember(request.id) { mutableStateOf(request.exactContent) }

    Card(
        modifier = modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, tierColor(request.tier)),
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                RiskTierChip(tier = request.tier)
                Text(
                    text = "Expires in ${remainingSeconds}s",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (remainingSeconds <= 30) {
                        MaterialTheme.colorScheme.error
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                )
            }

            Text(
                text = request.action,
                style = MaterialTheme.typography.titleMedium,
            )
            Text(
                text = "Tool: ${request.toolName}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            ApprovalRow(label = "Target", value = request.target)
            ApprovalRow(label = "Data used", value = request.dataUsed)

            Text(
                text = "Exact content:",
                style = MaterialTheme.typography.labelMedium,
            )
            if (editing) {
                OutlinedTextField(
                    value = editedText,
                    onValueChange = { editedText = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            onEdit(editedText)
                            editing = false
                        },
                        enabled = editedText.isNotBlank() && editedText != request.exactContent,
                    ) {
                        Text("Submit edit")
                    }
                    OutlinedButton(onClick = { editing = false }) {
                        Text("Cancel edit")
                    }
                }
            } else {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = MaterialTheme.shapes.small,
                ) {
                    Text(
                        text = request.exactContent,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontFamily = FontFamily.Monospace,
                        ),
                        modifier = Modifier.padding(12.dp),
                    )
                }
            }

            if (request.requiresSecondConfirmation) {
                Text(
                    text = "This action leaves the device — you will be asked to confirm a second time.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (request.requiresBiometric) {
                Text(
                    text = "This is a sensitive action — biometric authentication is required after Allow.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Button(
                    onClick = onAllow,
                    modifier = Modifier.weight(1f),
                ) {
                    Text("Allow")
                }
                OutlinedButton(
                    onClick = { editing = true },
                    modifier = Modifier.weight(1f),
                    enabled = !editing,
                ) {
                    Text("Edit")
                }
                Button(
                    onClick = onDeny,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                    ),
                ) {
                    Text("Deny")
                }
            }

            if (onTrust != null && request.tier.canBeTrusted) {
                TextButton(onClick = onTrust, modifier = Modifier.fillMaxWidth()) {
                    Text("Always allow “${request.toolName}” (trust this action)")
                }
                Text(
                    text = "Trusted actions can be revoked any time in Settings → Permissions & trust.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ApprovalRow(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelMedium)
        Text(text = value, style = MaterialTheme.typography.bodyMedium)
    }
}

/** Color-coded risk-tier chip: green → blue → amber → red. */
@Composable
fun RiskTierChip(tier: RiskTier, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = tierColor(tier),
        shape = MaterialTheme.shapes.small,
    ) {
        Text(
            text = "Tier ${tier.level} · ${tier.displayName}",
            style = MaterialTheme.typography.labelMedium,
            color = Color.White,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
        )
    }
}

private fun tierColor(tier: RiskTier): Color = when (tier) {
    RiskTier.READ_ONLY -> Color(0xFF2E7D32)
    RiskTier.REVERSIBLE -> Color(0xFF1565C0)
    RiskTier.EXTERNAL -> Color(0xFFEF6C00)
    RiskTier.SENSITIVE -> Color(0xFFC62828)
}
