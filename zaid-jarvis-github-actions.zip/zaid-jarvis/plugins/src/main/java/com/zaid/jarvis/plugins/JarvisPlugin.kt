package com.zaid.jarvis.plugins

import com.zaid.jarvis.tools.JarvisTool
import kotlinx.coroutines.flow.Flow

// ─────────────────────────────────────────────────────────────────────────────
// Plugin system (Phase 10).
//
// A plugin is a self-contained capability package that registers tools
// with the planner. Plugins are BUILT-IN compiled code only — there is
// NO dynamic code loading (no DexClassLoader, no downloading code, no
// executing arbitrary code from files). That is a deliberate security
// decision: a plugin runs with the app's full privileges, so loading
// code at runtime would be a remote-code-execution hole dressed up as
// a feature. A plugin is added by writing a Kotlin class that
// implements [JarvisPlugin] and registering it in the plugin list
// (see [BuiltInPlugins]) — that is the extension point for developers.
// Dynamic loading is a Phase 11+ hardening question, not something to
// bolt on here.
//
// Every plugin tool routes through the Phase 2 [GatedToolExecutor]
// exactly like a built-in tool, with its declared risk tier — no
// bypass, no exception. Plugin tools appear in the planner's tool
// list only while their plugin is enabled.
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Something a plugin declares it needs, shown in plain language in the
 * Plugins screen. Either an Android permission (which the system may
 * still ask for at use time) or a capability flag (a Jarvis-level
 * concept such as network access or local storage).
 */
sealed interface PluginPermission {
    /** Short plain-language name, e.g. "Read contacts". */
    val displayName: String

    /** One sentence explaining why the plugin needs it. */
    val description: String

    /** An Android permission string, e.g. android.permission.READ_CONTACTS. */
    data class AndroidPermission(
        val permission: String,
        override val displayName: String,
        override val description: String,
    ) : PluginPermission

    /** A Jarvis-level capability, e.g. "network" or "local_storage". */
    data class Capability(
        val id: String,
        override val displayName: String,
        override val description: String,
    ) : PluginPermission
}

/** Per-plugin user state: enabled, and whether its low-risk tools may be trusted. */
data class PluginState(
    /** Whether the plugin's tools are registered with the planner. Default: on. */
    val enabled: Boolean = true,
    /**
     * Whether the plugin's Tier 0/1 tools may be auto-allowed. Default:
     * NOT trusted — trust is an explicit user action in the Plugins
     * screen, and Tier 2+ tools can never be trusted (see RiskTier).
     */
    val trusted: Boolean = false,
)

/**
 * Persists per-plugin state. Production implementation is DataStore-
 * backed (:data PluginStateRepository); [InMemoryPluginStateStore] is
 * for tests.
 */
interface PluginStateStore {
    suspend fun state(pluginId: String): PluginState
    suspend fun setEnabled(pluginId: String, enabled: Boolean)
    suspend fun setTrusted(pluginId: String, trusted: Boolean)
    fun observeStates(): Flow<Map<String, PluginState>>
}

/** In-memory plugin state store for tests. Not used in production. */
class InMemoryPluginStateStore : PluginStateStore {
    private val states = kotlinx.coroutines.flow.MutableStateFlow<Map<String, PluginState>>(emptyMap())

    override suspend fun state(pluginId: String): PluginState =
        states.value[pluginId] ?: PluginState()

    override suspend fun setEnabled(pluginId: String, enabled: Boolean) {
        val current = states.value[pluginId] ?: PluginState()
        states.value = states.value + (pluginId to current.copy(enabled = enabled))
    }

    override suspend fun setTrusted(pluginId: String, trusted: Boolean) {
        val current = states.value[pluginId] ?: PluginState()
        states.value = states.value + (pluginId to current.copy(trusted = trusted))
    }

    override fun observeStates(): Flow<Map<String, PluginState>> = states
}

/**
 * A plugin: a named, versioned capability package that contributes
 * tools to Jarvis. Built-in compiled code only (see the header note) —
 * implement this interface and register the instance in
 * [BuiltInPlugins] to add a plugin.
 */
interface JarvisPlugin {
    /** Stable id, e.g. "notes". Used as the state-store key. */
    val id: String

    /** Display name shown in the Plugins screen. */
    val displayName: String

    /** Version string, e.g. "1.0". */
    val version: String

    /** One or two sentences describing what the plugin does. */
    val description: String

    /** Permissions and capabilities the plugin declares it needs. */
    val declaredPermissions: List<PluginPermission>

    /** The tools this plugin provides. Fresh instances per call are fine. */
    fun tools(): List<JarvisTool>
}
