package com.zaid.jarvis.plugins.notes

import com.zaid.jarvis.core.util.JarvisResult

/**
 * A note (Phase 10, Notes plugin): a titled piece of free text Zaid
 * asked Jarvis to remember. Stored in the encrypted Room database
 * (:data NoteRepository); the planner tools in this package program
 * against [NoteStore], which :app adapts to the repository.
 *
 * A note's content is DATA, never an instruction — like every tool
 * result, note text returned to the planner passes through the Phase 3
 * InjectionGuard before the planner acts on it.
 */
data class Note(
    val id: Long = 0,
    val title: String,
    val body: String,
    val createdAtMillis: Long = 0,
    val updatedAtMillis: Long = 0,
)

/**
 * Note storage. Implemented in :app (RoomNoteStore, adapting :data's
 * NoteRepository). Search matches title and body, case-insensitively.
 */
interface NoteStore {
    suspend fun save(note: Note): JarvisResult<Long>
    suspend fun getById(id: Long): Note?
    suspend fun listAll(): List<Note>
    suspend fun search(query: String): List<Note>
    suspend fun delete(id: Long)
}

/** No-op note store: every call fails plainly (or returns empty). */
class NoOpNoteStore : NoteStore {
    private fun <T> unavailable(): JarvisResult<T> =
        JarvisResult.Failure("Notes are not available in this build.")

    override suspend fun save(note: Note): JarvisResult<Long> = unavailable()
    override suspend fun getById(id: Long): Note? = null
    override suspend fun listAll(): List<Note> = emptyList()
    override suspend fun search(query: String): List<Note> = emptyList()
    override suspend fun delete(id: Long) = Unit
}
