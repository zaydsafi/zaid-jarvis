package com.zaid.jarvis.plugins.converter

import com.zaid.jarvis.core.util.JarvisResult

/**
 * Unit conversion (Phase 10, Unit converter plugin) — pure Kotlin, no
 * permissions, no network, no storage.
 *
 * Categories: length, mass, temperature. Currency is deliberately NOT
 * included: converting money needs live exchange rates, and a stale
 * or invented rate would be worse than refusing. Currency conversion
 * is a future addition needing an exchange-rate API.
 *
 * Length and mass convert through a base unit (metre / kilogram);
 * temperature converts through Celsius (affine, not just a factor).
 * Unknown units and cross-category conversions are refused with a
 * plain message — never guessed.
 */
object UnitConverter {

    /** Conversion categories. */
    enum class Category(val displayName: String) {
        LENGTH("Length"),
        MASS("Mass"),
        TEMPERATURE("Temperature"),
    }

    /** One successful conversion. */
    data class ConversionResult(
        val value: Double,
        val fromUnit: String,
        val toUnit: String,
        val category: Category,
    )

    /** Linear units: factor to the category's base unit. */
    private data class LinearUnit(val canonical: String, val toBase: Double)

    private val lengthUnits: Map<String, LinearUnit> = mapOf(
        // Metres (base).
        "m" to LinearUnit("m", 1.0),
        "meter" to LinearUnit("m", 1.0),
        "meters" to LinearUnit("m", 1.0),
        "metre" to LinearUnit("m", 1.0),
        "metres" to LinearUnit("m", 1.0),
        "km" to LinearUnit("km", 1_000.0),
        "kilometer" to LinearUnit("km", 1_000.0),
        "kilometers" to LinearUnit("km", 1_000.0),
        "kilometre" to LinearUnit("km", 1_000.0),
        "kilometres" to LinearUnit("km", 1_000.0),
        "cm" to LinearUnit("cm", 0.01),
        "centimeter" to LinearUnit("cm", 0.01),
        "centimeters" to LinearUnit("cm", 0.01),
        "centimetre" to LinearUnit("cm", 0.01),
        "centimetres" to LinearUnit("cm", 0.01),
        "mm" to LinearUnit("mm", 0.001),
        "millimeter" to LinearUnit("mm", 0.001),
        "millimeters" to LinearUnit("mm", 0.001),
        "millimetre" to LinearUnit("mm", 0.001),
        "millimetres" to LinearUnit("mm", 0.001),
        "mi" to LinearUnit("mi", 1_609.344),
        "mile" to LinearUnit("mi", 1_609.344),
        "miles" to LinearUnit("mi", 1_609.344),
        "yd" to LinearUnit("yd", 0.9144),
        "yard" to LinearUnit("yd", 0.9144),
        "yards" to LinearUnit("yd", 0.9144),
        "ft" to LinearUnit("ft", 0.3048),
        "foot" to LinearUnit("ft", 0.3048),
        "feet" to LinearUnit("ft", 0.3048),
        "in" to LinearUnit("in", 0.0254),
        "inch" to LinearUnit("in", 0.0254),
        "inches" to LinearUnit("in", 0.0254),
    )

    private val massUnits: Map<String, LinearUnit> = mapOf(
        // Kilograms (base).
        "kg" to LinearUnit("kg", 1.0),
        "kilogram" to LinearUnit("kg", 1.0),
        "kilograms" to LinearUnit("kg", 1.0),
        "g" to LinearUnit("g", 0.001),
        "gram" to LinearUnit("g", 0.001),
        "grams" to LinearUnit("g", 0.001),
        "mg" to LinearUnit("mg", 0.000001),
        "milligram" to LinearUnit("mg", 0.000001),
        "milligrams" to LinearUnit("mg", 0.000001),
        "lb" to LinearUnit("lb", 0.45359237),
        "pound" to LinearUnit("lb", 0.45359237),
        "pounds" to LinearUnit("lb", 0.45359237),
        "oz" to LinearUnit("oz", 0.028349523125),
        "ounce" to LinearUnit("oz", 0.028349523125),
        "ounces" to LinearUnit("oz", 0.028349523125),
        // "ton" is a metric tonne here (1,000 kg), not a short ton.
        "t" to LinearUnit("t", 1_000.0),
        "tonne" to LinearUnit("t", 1_000.0),
        "tonnes" to LinearUnit("t", 1_000.0),
        "ton" to LinearUnit("t", 1_000.0),
        "tons" to LinearUnit("t", 1_000.0),
    )

    private val temperatureUnits: Set<String> = setOf(
        "c", "celsius", "°c",
        "f", "fahrenheit", "°f",
        "k", "kelvin",
    )

    /** Canonical unit names per category, for help text and the tool description. */
    fun supportedUnits(): Map<Category, List<String>> = mapOf(
        Category.LENGTH to listOf("m", "km", "cm", "mm", "mi", "yd", "ft", "in"),
        Category.MASS to listOf("kg", "g", "mg", "lb", "oz", "t"),
        Category.TEMPERATURE to listOf("C", "F", "K"),
    )

    /**
     * Converts [value] from [from] to [to]. Unit names are matched
     * case-insensitively (with common aliases). Refuses unknown units
     * and cross-category conversions.
     */
    fun convert(value: Double, from: String, to: String): JarvisResult<ConversionResult> {
        if (value.isNaN() || value.isInfinite()) {
            return JarvisResult.Failure("That value isn't a number I can convert.")
        }
        val fromNorm = normalize(from)
        val toNorm = normalize(to)
        val fromCategory = categoryOf(fromNorm)
            ?: return JarvisResult.Failure(
                "I don't know the unit “$from”. Supported units: ${supportedUnitsDescription()}.",
            )
        val toCategory = categoryOf(toNorm)
            ?: return JarvisResult.Failure(
                "I don't know the unit “$to”. Supported units: ${supportedUnitsDescription()}.",
            )
        if (fromCategory != toCategory) {
            return JarvisResult.Failure(
                "I can't convert ${fromCategory.displayName.lowercase()} to " +
                    "${toCategory.displayName.lowercase()} — they're different kinds of quantity.",
            )
        }
        if (fromNorm == toNorm) {
            return JarvisResult.Success(ConversionResult(value, fromNorm, toNorm, fromCategory))
        }
        val converted = when (fromCategory) {
            Category.TEMPERATURE -> convertTemperature(value, fromNorm, toNorm)
            Category.LENGTH -> convertLinear(value, fromNorm, toNorm, lengthUnits)
            Category.MASS -> convertLinear(value, fromNorm, toNorm, massUnits)
        }
        return JarvisResult.Success(
            ConversionResult(converted, canonicalName(fromNorm), canonicalName(toNorm), fromCategory),
        )
    }

    private fun convertLinear(
        value: Double,
        from: String,
        to: String,
        units: Map<String, LinearUnit>,
    ): Double {
        val fromUnit = units.getValue(from)
        val toUnit = units.getValue(to)
        return value * fromUnit.toBase / toUnit.toBase
    }

    private fun convertTemperature(value: Double, from: String, to: String): Double {
        val celsius = when (from) {
            "c", "celsius", "°c" -> value
            "f", "fahrenheit", "°f" -> (value - 32.0) * 5.0 / 9.0
            else -> value - 273.15 // Kelvin
        }
        return when (to) {
            "c", "celsius", "°c" -> celsius
            "f", "fahrenheit", "°f" -> celsius * 9.0 / 5.0 + 32.0
            else -> celsius + 273.15 // Kelvin
        }
    }

    private fun categoryOf(normalized: String): Category? = when {
        normalized in lengthUnits -> Category.LENGTH
        normalized in massUnits -> Category.MASS
        normalized in temperatureUnits -> Category.TEMPERATURE
        else -> null
    }

    private fun canonicalName(normalized: String): String = when {
        normalized in lengthUnits -> lengthUnits.getValue(normalized).canonical
        normalized in massUnits -> massUnits.getValue(normalized).canonical
        normalized in setOf("c", "celsius", "°c") -> "°C"
        normalized in setOf("f", "fahrenheit", "°f") -> "°F"
        else -> "K"
    }

    private fun normalize(unit: String): String =
        unit.trim().lowercase().removeSuffix("s").let { singular ->
            // Keep the original when the singular form isn't known
            // ("meters" → "meter" is known; "glass" → "glas" is not).
            val trimmed = unit.trim().lowercase()
            if (trimmed in lengthUnits || trimmed in massUnits || trimmed in temperatureUnits) {
                trimmed
            } else {
                singular
            }
        }

    private fun supportedUnitsDescription(): String =
        "length (m, km, cm, mm, mi, yd, ft, in), mass (kg, g, mg, lb, oz, t), " +
            "temperature (C, F, K). Currency isn't supported yet — it needs live exchange rates."
}
