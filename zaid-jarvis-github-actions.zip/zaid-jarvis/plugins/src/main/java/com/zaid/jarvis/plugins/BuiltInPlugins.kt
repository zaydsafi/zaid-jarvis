package com.zaid.jarvis.plugins

import com.zaid.jarvis.plugins.converter.UnitConverterPlugin
import com.zaid.jarvis.plugins.notes.NotesPlugin
import com.zaid.jarvis.plugins.notes.NoteStore

/**
 * The plugins Jarvis ships with (Phase 10).
 *
 * To add a plugin: write a Kotlin class implementing [JarvisPlugin]
 * (in :plugins, or in a module :plugins can see), and add an instance
 * here. There is no dynamic loading by design — see the header note
 * in JarvisPlugin.kt.
 */
object BuiltInPlugins {
    /** The built-in plugins, in registration order. */
    fun all(noteStore: NoteStore): List<JarvisPlugin> = listOf(
        NotesPlugin(noteStore),
        UnitConverterPlugin(),
    )
}
