package com.zaid.jarvis.plugins

import com.zaid.jarvis.core.confirmation.TrustedActionStore
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.ToolRegistry
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Loads and manages installed plugins (Phase 10).
 *
 * The registry owns the link between plugins and the planner's
 * [ToolRegistry]: a plugin's tools are registered only while the
 * plugin is enabled, and disabling a plugin unregisters its tools
 * immediately. [sync] applies the stored state (called once at app
 * start, and after any state change) so a disabled plugin's tools
 * never reach the planner.
 *
 * Tool-name collisions: a plugin tool whose name already exists in
 * the registry (a built-in tool, or a tool from another plugin) is
 * SKIPPED, never registered over it — a plugin must never silently
 * replace a built-in capability. Skipped names are exposed in
 * [skippedToolNames] so the Plugins screen can say so. Two plugins
 * declaring the same tool name is a programming error and fails fast
 * in the constructor.
 *
 * Trust: [setTrusted] adds (or removes) the plugin's Tier 0/1 tools
 * in the [TrustedActionStore] — Tier 2+ tools can never be trusted.
 * [sync] re-applies trust for trusted plugins, but never revokes:
 * trust granted directly on the approval card ("always allow this
 * action") survives a restart; only an explicit un-trust removes it.
 */
class PluginRegistry(
    private val toolRegistry: ToolRegistry,
    private val stateStore: PluginStateStore,
    private val trustedStore: TrustedActionStore,
    private val plugins: List<JarvisPlugin>,
) {
    private val _skippedToolNames = MutableStateFlow<Set<String>>(emptySet())

    /**
     * Tool names skipped during the last sync because they collided
     * with an already-registered tool.
     */
    val skippedToolNames: StateFlow<Set<String>> = _skippedToolNames.asStateFlow()

    /** Tool names this registry currently owns (registered by a plugin). */
    private val ownedToolNames = mutableSetOf<String>()

    init {
        val seen = mutableSetOf<String>()
        for (plugin in plugins) {
            for (tool in plugin.tools()) {
                require(seen.add(tool.name)) {
                    "Duplicate tool name across plugins: ${tool.name}"
                }
            }
        }
    }

    /** All installed plugins, in registration order. */
    fun installed(): List<JarvisPlugin> = plugins.toList()

    fun pluginById(pluginId: String): JarvisPlugin? = plugins.firstOrNull { it.id == pluginId }

    suspend fun state(pluginId: String): PluginState = stateStore.state(pluginId)

    fun observeStates(): Flow<Map<String, PluginState>> = stateStore.observeStates()

    /**
     * Applies the stored state to the tool registry: enabled plugins'
     * tools are registered, disabled plugins' tools are unregistered.
     * Trusted plugins get their Tier 0/1 tools re-trusted. Idempotent.
     */
    suspend fun sync() {
        val skipped = mutableSetOf<String>()
        for (plugin in plugins) {
            val state = stateStore.state(plugin.id)
            if (state.enabled) {
                for (tool in plugin.tools()) {
                    val existing = toolRegistry.get(tool.name)
                    if (existing != null && tool.name !in ownedToolNames) {
                        // A built-in (or another registry's) tool owns
                        // this name — never register over it.
                        skipped += tool.name
                        continue
                    }
                    toolRegistry.register(tool)
                    ownedToolNames += tool.name
                }
                if (state.trusted) {
                    trustPluginTools(plugin)
                }
            } else {
                unregisterPluginTools(plugin)
            }
        }
        _skippedToolNames.value = skipped
    }

    /** Enables or disables a plugin. Disabling unregisters its tools immediately. */
    suspend fun setEnabled(pluginId: String, enabled: Boolean): JarvisResult<Unit> {
        val plugin = pluginById(pluginId)
            ?: return JarvisResult.Failure("No plugin with id $pluginId.")
        stateStore.setEnabled(pluginId, enabled)
        if (enabled) {
            sync()
        } else {
            unregisterPluginTools(plugin)
        }
        return JarvisResult.Success(Unit)
    }

    /**
     * Trusts or un-trusts a plugin. Trusting adds the plugin's Tier
     * 0/1 tools to the trusted-action store (auto-allow); un-trusting
     * removes them. Tier 2+ tools are never trusted.
     */
    suspend fun setTrusted(pluginId: String, trusted: Boolean): JarvisResult<Unit> {
        val plugin = pluginById(pluginId)
            ?: return JarvisResult.Failure("No plugin with id $pluginId.")
        stateStore.setTrusted(pluginId, trusted)
        if (trusted) {
            trustPluginTools(plugin)
        } else {
            for (tool in plugin.tools()) {
                if (tool.riskTier.canBeTrusted) {
                    trustedStore.revoke(tool.name)
                }
            }
        }
        return JarvisResult.Success(Unit)
    }

    private suspend fun trustPluginTools(plugin: JarvisPlugin) {
        for (tool in plugin.tools()) {
            if (tool.riskTier.canBeTrusted) {
                trustedStore.trust(tool.name)
            }
        }
    }

    private fun unregisterPluginTools(plugin: JarvisPlugin) {
        for (tool in plugin.tools()) {
            if (tool.name in ownedToolNames) {
                toolRegistry.unregister(tool.name)
                ownedToolNames -= tool.name
            }
        }
    }
}
