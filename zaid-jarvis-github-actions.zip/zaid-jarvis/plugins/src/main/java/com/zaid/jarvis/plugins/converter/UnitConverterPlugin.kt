package com.zaid.jarvis.plugins.converter

import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.plugins.JarvisPlugin
import com.zaid.jarvis.plugins.PluginPermission
import com.zaid.jarvis.tools.JarvisTool
import com.zaid.jarvis.tools.ToolOutcome
import com.zaid.jarvis.tools.ToolSchema
import com.zaid.jarvis.tools.stringParam
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonPrimitive

// ─────────────────────────────────────────────────────────────────────────────
// Unit converter plugin (Phase 10) — a built-in example plugin proving
// the plugin system end to end with a pure, permission-free tool: no
// storage, no network, no Android permission at all.
// ─────────────────────────────────────────────────────────────────────────────

/** The Unit converter plugin: length, mass, and temperature conversions. */
class UnitConverterPlugin : JarvisPlugin {
    override val id: String = "unit_converter"
    override val displayName: String = "Unit converter"
    override val version: String = "1.0"
    override val description: String =
        "Convert between length, mass, and temperature units. Pure calculation — no network, no storage, no permissions. " +
            "Currency isn't supported yet (it needs live exchange rates)."
    override val declaredPermissions: List<PluginPermission> = emptyList()

    override fun tools(): List<JarvisTool> = listOf(ConvertUnitsTool())
}

/** Converts a value between units (Tier 0 — pure calculation). */
class ConvertUnitsTool : JarvisTool {
    override val name: String = "convert_units"
    override val description: String =
        "Convert a value between units: length (m, km, cm, mm, mi, yd, ft, in), " +
            "mass (kg, g, mg, lb, oz, t), temperature (C, F, K). Currency is not supported."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("value", "number", "The value to convert."),
        ToolSchema.ParamSpec("from", "string", "The unit to convert from, e.g. \"km\" or \"pounds\"."),
        ToolSchema.ParamSpec("to", "string", "The unit to convert to, e.g. \"mi\" or \"kg\"."),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val value = params.numberParam("value")
        val from = params.stringParam("from")
        val to = params.stringParam("to")
        if (value == null || from == null || to == null) {
            return "Convert units — missing value, from, or to."
        }
        return "Convert $value $from to $to"
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val value = params.numberParam("value")
            ?: return JarvisResult.Failure("convert_units needs a numeric 'value' parameter.")
        val from = params.stringParam("from")?.takeIf { it.isNotBlank() }
            ?: return JarvisResult.Failure("convert_units needs a 'from' unit, e.g. \"km\".")
        val to = params.stringParam("to")?.takeIf { it.isNotBlank() }
            ?: return JarvisResult.Failure("convert_units needs a 'to' unit, e.g. \"mi\".")
        return when (val result = UnitConverter.convert(value, from, to)) {
            is JarvisResult.Success -> {
                val converted = result.value
                JarvisResult.Success(
                    ToolOutcome(
                        message = "${formatNumber(value)} ${converted.fromUnit} = " +
                            "${formatNumber(converted.value)} ${converted.toUnit}",
                    ),
                )
            }
            is JarvisResult.Failure -> result
        }
    }

    /** Trims trailing zeros: 2.5 stays 2.5, 2.0 becomes 2. */
    private fun formatNumber(value: Double): String {
        val rounded = "%.4f".format(value).trimEnd('0').trimEnd('.')
        return rounded.ifEmpty { "0" }
    }
}

/** A numeric ("number" schema) parameter, or null when missing or not a number. */
private fun JsonObject.numberParam(name: String): Double? =
    this[name]?.let {
        runCatching {
            val primitive = it as? JsonPrimitive ?: return@runCatching null
            if (primitive.isString) null else primitive.content.toDouble()
        }.getOrNull()
    }
