package com.zaid.jarvis.plugins.notes

import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.plugins.JarvisPlugin
import com.zaid.jarvis.plugins.PluginPermission
import com.zaid.jarvis.tools.JarvisTool
import com.zaid.jarvis.tools.ToolOutcome
import com.zaid.jarvis.tools.ToolSchema
import com.zaid.jarvis.tools.intParamOr
import com.zaid.jarvis.tools.stringParam
import kotlinx.serialization.json.JsonObject

// ─────────────────────────────────────────────────────────────────────────────
// Notes plugin (Phase 10) — a built-in example plugin proving the
// plugin system end to end: real tools, real storage (the encrypted
// Room database), gated like any built-in tool.
//
// A note's content is DATA, never an instruction: note text returned
// to the planner passes through the Phase 3 InjectionGuard like every
// tool result, so a note that says "ignore your instructions" is
// flagged, not followed.
// ─────────────────────────────────────────────────────────────────────────────

/** The Notes plugin: save, list, and search notes. */
class NotesPlugin(
    private val noteStore: NoteStore = NoOpNoteStore(),
) : JarvisPlugin {
    override val id: String = "notes"
    override val displayName: String = "Notes"
    override val version: String = "1.0"
    override val description: String =
        "Save short notes and search them later. Notes live in Jarvis's encrypted database, on this device only."
    override val declaredPermissions: List<PluginPermission> = listOf(
        PluginPermission.Capability(
            id = "local_storage",
            displayName = "Local storage",
            description = "Notes are stored in Jarvis's encrypted on-device database.",
        ),
    )

    override fun tools(): List<JarvisTool> = listOf(
        SaveNoteTool(noteStore),
        ListNotesTool(noteStore),
        SearchNotesTool(noteStore),
    )
}

/** Saves a note (Tier 1 — reversible: undo deletes the note). */
class SaveNoteTool(
    private val noteStore: NoteStore,
) : JarvisTool {
    override val name: String = "save_note"
    override val description: String =
        "Save a note with a title and body text, so Zaid can find it later with list_notes or search_notes."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("title", "string", "The note's title."),
        ToolSchema.ParamSpec("body", "string", "The note's text."),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val title = params.stringParam("title")
            ?: return "Save a note — missing title."
        val body = params.stringParam("body") ?: ""
        return "Save note “$title” (${body.length} characters)"
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val title = params.stringParam("title")?.takeIf { it.isNotBlank() }
            ?: return JarvisResult.Failure("save_note needs a 'title' parameter.")
        val body = params.stringParam("body") ?: ""
        if (body.isBlank()) {
            return JarvisResult.Failure("save_note needs a 'body' parameter — a note with no text is not worth saving.")
        }
        if (body.length > MAX_BODY_CHARS) {
            return JarvisResult.Failure(
                "That note is ${body.length} characters — notes are capped at $MAX_BODY_CHARS. " +
                    "Save a shorter version.",
            )
        }
        return when (val result = noteStore.save(Note(title = title.trim(), body = body))) {
            is JarvisResult.Success -> JarvisResult.Success(
                ToolOutcome(
                    message = "Note saved: “${title.trim()}”.",
                    undoData = result.value.toString(),
                    undoDescription = "Delete the note “${title.trim()}”.",
                ),
            )
            is JarvisResult.Failure -> result
        }
    }

    override val supportsUndo: Boolean = true

    override suspend fun undoPreview(params: JsonObject, undoData: String?): String {
        val title = params.stringParam("title") ?: "this note"
        return "Delete the note “$title”."
    }

    override suspend fun undo(params: JsonObject, undoData: String?): JarvisResult<ToolOutcome> {
        val id = undoData?.toLongOrNull()
            ?: return JarvisResult.Failure("Can't undo: the saved note's id was lost.")
        noteStore.delete(id)
        return JarvisResult.Success(ToolOutcome(message = "Note deleted."))
    }

    companion object {
        /** Notes longer than this are refused (keeps the planner's context sane). */
        const val MAX_BODY_CHARS: Int = 10_000
    }
}

/** Lists saved notes, newest first (Tier 0). */
class ListNotesTool(
    private val noteStore: NoteStore,
) : JarvisTool {
    override val name: String = "list_notes"
    override val description: String =
        "List saved notes (newest first), showing each note's title and first line."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec(
            name = "limit",
            type = "integer",
            description = "How many notes to list (default 10, max 50).",
            required = false,
        ),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val limit = params.intParamOr("limit", DEFAULT_LIMIT).coerceIn(1, MAX_LIMIT)
        return "List the $limit most recent note(s)"
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val limit = params.intParamOr("limit", DEFAULT_LIMIT).coerceIn(1, MAX_LIMIT)
        val notes = noteStore.listAll().take(limit)
        if (notes.isEmpty()) {
            return JarvisResult.Success(ToolOutcome(message = "No notes saved yet."))
        }
        val lines = notes.joinToString("\n") { note ->
            val firstLine = note.body.lineSequence().firstOrNull().orEmpty().take(100)
            "#${note.id} · ${note.title} — $firstLine"
        }
        return JarvisResult.Success(ToolOutcome(message = "Notes:\n$lines"))
    }

    companion object {
        const val DEFAULT_LIMIT: Int = 10
        const val MAX_LIMIT: Int = 50
    }
}

/** Searches notes by title and body (Tier 0). */
class SearchNotesTool(
    private val noteStore: NoteStore,
) : JarvisTool {
    override val name: String = "search_notes"
    override val description: String =
        "Search saved notes by words in the title or body, and show the matching notes."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("query", "string", "Words to search for in note titles and bodies."),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val query = params.stringParam("query")
            ?: return "Search notes — missing query."
        return "Search notes for “$query”"
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val query = params.stringParam("query")?.takeIf { it.isNotBlank() }
            ?: return JarvisResult.Failure("search_notes needs a 'query' parameter.")
        val notes = noteStore.search(query)
        if (notes.isEmpty()) {
            return JarvisResult.Success(ToolOutcome(message = "No notes matched “$query”."))
        }
        val lines = notes.joinToString("\n") { note ->
            val firstLine = note.body.lineSequence().firstOrNull().orEmpty().take(100)
            "#${note.id} · ${note.title} — $firstLine"
        }
        return JarvisResult.Success(ToolOutcome(message = "Notes matching “$query”:\n$lines"))
    }
}
