package com.zaid.jarvis.plugins.notes

import com.zaid.jarvis.core.util.JarvisResult
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Notes plugin tools (Phase 10) with a fake NoteStore. */
class NotesPluginTest {

    private class FakeNoteStore : NoteStore {
        val notes = mutableListOf<Note>()
        private var nextId = 1L

        // Monotonic clock: two saves in the same millisecond still get
        // distinct timestamps, so "newest first" is deterministic.
        private var lastTime = 0L
        private fun now(): Long {
            val t = maxOf(System.currentTimeMillis(), lastTime + 1)
            lastTime = t
            return t
        }

        override suspend fun save(note: Note): JarvisResult<Long> {
            return if (note.id == 0L) {
                val id = nextId++
                val timestamp = now()
                notes += note.copy(id = id, createdAtMillis = timestamp, updatedAtMillis = timestamp)
                JarvisResult.Success(id)
            } else {
                notes.removeAll { it.id == note.id }
                notes += note.copy(updatedAtMillis = now())
                JarvisResult.Success(note.id)
            }
        }

        override suspend fun getById(id: Long): Note? = notes.find { it.id == id }

        // Mirrors the real store's contract (Room orders by updatedAtMillis DESC).
        override suspend fun listAll(): List<Note> =
            notes.sortedByDescending { it.updatedAtMillis }
        override suspend fun search(query: String): List<Note> = notes.filter {
            it.title.contains(query, ignoreCase = true) ||
                it.body.contains(query, ignoreCase = true)
        }

        override suspend fun delete(id: Long) {
            notes.removeAll { it.id == id }
        }
    }

    @Test
    fun `save_note stores a note and reports its title`() = runBlocking {
        val store = FakeNoteStore()
        val result = SaveNoteTool(store).execute(
            buildJsonObject { put("title", "Groceries"); put("body", "Milk, eggs") },
        )
        assertTrue(result is JarvisResult.Success)
        assertEquals(1, store.notes.size)
        assertEquals("Groceries", store.notes.single().title)
        assertEquals("Milk, eggs", store.notes.single().body)
    }

    @Test
    fun `save_note refuses a blank title or body`() = runBlocking {
        val store = FakeNoteStore()
        val tool = SaveNoteTool(store)
        assertTrue(
            tool.execute(buildJsonObject { put("title", "  "); put("body", "text") })
                is JarvisResult.Failure,
        )
        assertTrue(
            tool.execute(buildJsonObject { put("title", "T"); put("body", "   ") })
                is JarvisResult.Failure,
        )
        assertEquals(0, store.notes.size)
    }

    @Test
    fun `save_note refuses an over-long body`() = runBlocking {
        val store = FakeNoteStore()
        val result = SaveNoteTool(store).execute(
            buildJsonObject {
                put("title", "Too long")
                put("body", "x".repeat(SaveNoteTool.MAX_BODY_CHARS + 1))
            },
        )
        assertTrue(result is JarvisResult.Failure)
        assertEquals(0, store.notes.size)
    }

    @Test
    fun `undoing save_note deletes the note`() = runBlocking {
        val store = FakeNoteStore()
        val tool = SaveNoteTool(store)
        val params = buildJsonObject { put("title", "Temp"); put("body", "temporary") }
        val executed = tool.execute(params) as JarvisResult.Success
        assertEquals(1, store.notes.size)
        val undone = tool.undo(params, executed.value.undoData)
        assertTrue(undone is JarvisResult.Success)
        assertEquals(0, store.notes.size)
    }

    @Test
    fun `list_notes returns notes newest first`() = runBlocking {
        val store = FakeNoteStore()
        val save = SaveNoteTool(store)
        save.execute(buildJsonObject { put("title", "First"); put("body", "one") })
        save.execute(buildJsonObject { put("title", "Second"); put("body", "two") })
        val result = ListNotesTool(store).execute(buildJsonObject {})
        assertTrue(result is JarvisResult.Success)
        val message = (result as JarvisResult.Success).value.message
        assertTrue(message.contains("First"))
        assertTrue(message.contains("Second"))
        // Newest first: "Second" appears before "First".
        assertTrue(message.indexOf("Second") < message.indexOf("First"))
    }

    @Test
    fun `list_notes says so when there are no notes`() = runBlocking {
        val result = ListNotesTool(FakeNoteStore()).execute(buildJsonObject {})
        assertTrue(result is JarvisResult.Success)
        assertTrue((result as JarvisResult.Success).value.message.contains("No notes"))
    }

    @Test
    fun `search_notes matches title and body, case-insensitively`() = runBlocking {
        val store = FakeNoteStore()
        val save = SaveNoteTool(store)
        save.execute(buildJsonObject { put("title", "Shopping"); put("body", "buy milk") })
        save.execute(buildJsonObject { put("title", "Ideas"); put("body", "build a treehouse") })
        val result = SearchNotesTool(store).execute(
            buildJsonObject { put("query", "MILK") },
        )
        assertTrue(result is JarvisResult.Success)
        val message = (result as JarvisResult.Success).value.message
        assertTrue(message.contains("Shopping"))
        assertTrue(!message.contains("Ideas"))
    }

    @Test
    fun `search_notes reports no match plainly`() = runBlocking {
        val store = FakeNoteStore()
        SaveNoteTool(store).execute(buildJsonObject { put("title", "A"); put("body", "b") })
        val result = SearchNotesTool(store).execute(buildJsonObject { put("query", "zzz") })
        assertTrue(result is JarvisResult.Success)
        assertTrue((result as JarvisResult.Success).value.message.contains("No notes"))
    }

    @Test
    fun `the notes plugin declares its tools and permissions`() {
        val plugin = NotesPlugin(FakeNoteStore())
        assertEquals("notes", plugin.id)
        assertEquals(
            listOf("save_note", "list_notes", "search_notes"),
            plugin.tools().map { it.name },
        )
        assertTrue(plugin.declaredPermissions.isNotEmpty())
    }

    @Test
    fun `the unit converter plugin needs no permissions`() {
        val plugin = com.zaid.jarvis.plugins.converter.UnitConverterPlugin()
        assertEquals("unit_converter", plugin.id)
        assertEquals(listOf("convert_units"), plugin.tools().map { it.name })
        assertTrue(plugin.declaredPermissions.isEmpty())
    }
}
