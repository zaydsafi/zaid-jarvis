package com.zaid.jarvis.plugins

import com.zaid.jarvis.core.confirmation.InMemoryTrustedActionStore
import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.plugins.notes.NoOpNoteStore
import com.zaid.jarvis.tools.BuiltInTools
import com.zaid.jarvis.tools.JarvisTool
import com.zaid.jarvis.tools.ToolOutcome
import com.zaid.jarvis.tools.ToolRegistry
import com.zaid.jarvis.tools.ToolSchema
import com.zaid.jarvis.tools.phone.NoOpPhoneDevice
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Plugin registry (Phase 10): register/enable/disable/trust/collisions. */
class PluginRegistryTest {

    private class FakeTool(
        override val name: String,
        override val riskTier: RiskTier = RiskTier.READ_ONLY,
    ) : JarvisTool {
        override val description: String = "Fake tool $name"
        override val requiredPermissions: List<String> = emptyList()
        override val inputSchema: JsonObject = ToolSchema.objectSchema()
        override suspend fun dryRun(params: JsonObject): String = "run $name"
        override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> =
            JarvisResult.Success(ToolOutcome("ran $name"))
    }

    private class FakePlugin(
        override val id: String,
        private val toolNames: List<String>,
        private val tiers: List<RiskTier> = toolNames.map { RiskTier.READ_ONLY },
    ) : JarvisPlugin {
        override val displayName: String = "Fake $id"
        override val version: String = "1.0.0"
        override val description: String = "Fake plugin for tests."
        override val declaredPermissions: List<PluginPermission> = emptyList()
        override fun tools(): List<JarvisTool> =
            toolNames.zip(tiers).map { (name, tier) -> FakeTool(name, tier) }
    }

    private class Fixture(plugins: List<JarvisPlugin>) {
        val toolRegistry = ToolRegistry()
        val stateStore = InMemoryPluginStateStore()
        val trustedStore = InMemoryTrustedActionStore()
        val registry = PluginRegistry(toolRegistry, stateStore, trustedStore, plugins)
    }

    @Test
    fun `sync registers enabled plugins tools`() = runBlocking {
        val f = Fixture(listOf(FakePlugin("a", listOf("tool_a"))))
        f.registry.sync()
        assertNotNull(f.toolRegistry.get("tool_a"))
    }

    @Test
    fun `disabling a plugin unregisters its tools immediately`() = runBlocking {
        val f = Fixture(listOf(FakePlugin("a", listOf("tool_a"))))
        f.registry.sync()
        assertNotNull(f.toolRegistry.get("tool_a"))
        val result = f.registry.setEnabled("a", false)
        assertTrue(result is JarvisResult.Success)
        assertNull(f.toolRegistry.get("tool_a"))
    }

    @Test
    fun `re-enabling a plugin registers its tools again`() = runBlocking {
        val f = Fixture(listOf(FakePlugin("a", listOf("tool_a"))))
        f.registry.sync()
        f.registry.setEnabled("a", false)
        assertNull(f.toolRegistry.get("tool_a"))
        f.registry.setEnabled("a", true)
        assertNotNull(f.toolRegistry.get("tool_a"))
    }

    @Test
    fun `a disabled plugin stays unregistered across sync`() = runBlocking {
        val f = Fixture(listOf(FakePlugin("a", listOf("tool_a"))))
        f.registry.setEnabled("a", false)
        f.registry.sync()
        assertNull(f.toolRegistry.get("tool_a"))
    }

    @Test
    fun `trust defaults to off`() = runBlocking {
        val f = Fixture(listOf(FakePlugin("a", listOf("tool_a"))))
        val state = f.registry.state("a")
        assertTrue(state.enabled)
        assertFalse(state.trusted)
    }

    @Test
    fun `trusting a plugin trusts only its tier 0 and 1 tools`() = runBlocking {
        val f = Fixture(
            listOf(
                FakePlugin(
                    "a",
                    listOf("safe_tool", "risky_tool"),
                    listOf(RiskTier.READ_ONLY, RiskTier.EXTERNAL),
                ),
            ),
        )
        f.registry.sync()
        f.registry.setTrusted("a", true)
        val trusted = f.trustedStore.observeTrusted().first()
        assertTrue("safe_tool" in trusted)
        assertFalse("risky_tool" in trusted)
    }

    @Test
    fun `un-trusting a plugin revokes its tools`() = runBlocking {
        val f = Fixture(listOf(FakePlugin("a", listOf("tool_a"))))
        f.registry.sync()
        f.registry.setTrusted("a", true)
        assertTrue("tool_a" in f.trustedStore.observeTrusted().first())
        f.registry.setTrusted("a", false)
        assertFalse("tool_a" in f.trustedStore.observeTrusted().first())
    }

    @Test
    fun `a plugin tool colliding with a built-in is skipped, never registered over`() = runBlocking {
        val f = Fixture(listOf(FakePlugin("a", listOf("get_time"))))
        // Simulate a built-in tool already in the registry.
        f.toolRegistry.register(FakeTool("get_time"))
        val builtIn = f.toolRegistry.get("get_time")
        f.registry.sync()
        // The registry still holds the built-in instance, not the plugin's.
        assertTrue(f.toolRegistry.get("get_time") === builtIn)
        assertTrue("get_time" in f.registry.skippedToolNames.value)
    }

    @Test
    fun `two plugins declaring the same tool name fail fast`() {
        try {
            PluginRegistry(
                ToolRegistry(),
                InMemoryPluginStateStore(),
                InMemoryTrustedActionStore(),
                listOf(
                    FakePlugin("a", listOf("same_tool")),
                    FakePlugin("b", listOf("same_tool")),
                ),
            )
        } catch (e: IllegalArgumentException) {
            assertTrue(e.message?.contains("same_tool") == true)
            return
        }
        throw AssertionError("Expected IllegalArgumentException for duplicate tool names")
    }

    @Test
    fun `enabling an unknown plugin fails plainly`() = runBlocking {
        val f = Fixture(listOf(FakePlugin("a", listOf("tool_a"))))
        val result = f.registry.setEnabled("nope", true)
        assertTrue(result is JarvisResult.Failure)
    }

    @Test
    fun `the registry holds all 49 tools with the built-in plugins enabled`() = runBlocking {
        val toolRegistry = ToolRegistry()
        BuiltInTools.registerAll(toolRegistry, NoOpPhoneDevice)
        assertEquals(45, toolRegistry.all().size)
        val pluginRegistry = PluginRegistry(
            toolRegistry,
            InMemoryPluginStateStore(),
            InMemoryTrustedActionStore(),
            BuiltInPlugins.all(NoOpNoteStore()),
        )
        pluginRegistry.sync()
        assertEquals(49, toolRegistry.all().size)
        assertNotNull(toolRegistry.get("save_note"))
        assertNotNull(toolRegistry.get("list_notes"))
        assertNotNull(toolRegistry.get("search_notes"))
        assertNotNull(toolRegistry.get("convert_units"))
    }

    @Test
    fun `sync is idempotent`() = runBlocking {
        val f = Fixture(listOf(FakePlugin("a", listOf("tool_a"))))
        f.registry.sync()
        f.registry.sync()
        assertEquals(1, f.toolRegistry.all().size)
    }
}
