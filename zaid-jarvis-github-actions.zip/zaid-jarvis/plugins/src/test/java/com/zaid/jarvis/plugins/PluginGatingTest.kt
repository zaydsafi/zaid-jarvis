package com.zaid.jarvis.plugins

import com.zaid.jarvis.core.confirmation.ApprovalDecision
import com.zaid.jarvis.core.confirmation.ConfirmationEngine
import com.zaid.jarvis.core.confirmation.InMemoryAuditLog
import com.zaid.jarvis.core.confirmation.InMemoryTrustedActionStore
import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.plugins.notes.Note
import com.zaid.jarvis.plugins.notes.NoteStore
import com.zaid.jarvis.plugins.notes.NotesPlugin
import com.zaid.jarvis.tools.GatedToolExecutor
import com.zaid.jarvis.tools.ToolRegistry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Plugin tool gating (Phase 10): a plugin tool executes only through
 * the Phase 2 [GatedToolExecutor] — approval first, denial means the
 * tool never runs. A disabled plugin's tools are not in the registry
 * at all, so the executor refuses them as unknown.
 */
class PluginGatingTest {

    private class FakeNoteStore : NoteStore {
        val notes = mutableListOf<Note>()
        private var nextId = 1L

        override suspend fun save(note: Note): JarvisResult<Long> {
            val id = nextId++
            notes += note.copy(id = id)
            return JarvisResult.Success(id)
        }

        override suspend fun getById(id: Long): Note? = notes.find { it.id == id }
        override suspend fun listAll(): List<Note> = notes.toList()
        override suspend fun search(query: String): List<Note> = notes.filter {
            it.title.contains(query, ignoreCase = true) ||
                it.body.contains(query, ignoreCase = true)
        }

        override suspend fun delete(id: Long) {
            notes.removeAll { it.id == id }
        }
    }

    private class Fixture {
        val noteStore = FakeNoteStore()
        val auditLog = InMemoryAuditLog()
        val engine = ConfirmationEngine(
            auditLog = auditLog,
            trustedStore = InMemoryTrustedActionStore(),
            killSwitch = KillSwitch(),
        )
        val toolRegistry = ToolRegistry()
        val pluginRegistry = PluginRegistry(
            toolRegistry,
            InMemoryPluginStateStore(),
            InMemoryTrustedActionStore(),
            listOf(NotesPlugin(noteStore)),
        )
        val executor = GatedToolExecutor(toolRegistry, engine)
        val scope = CoroutineScope(Dispatchers.Unconfined)

        suspend fun pendingId(): String {
            repeat(50) {
                engine.pendingRequest.value?.let { return it.id }
                delay(10)
            }
            error("No pending request appeared")
        }
    }

    @Test
    fun `an approved plugin tool runs`() = runBlocking {
        val f = Fixture()
        f.pluginRegistry.sync()
        val job = f.scope.async {
            f.executor.execute(
                "save_note",
                buildJsonObject { put("title", "Gated"); put("body", "via the executor") },
            )
        }
        val id = f.pendingId()
        assertTrue(f.engine.resolve(id, ApprovalDecision.Allow))
        val result = job.await()
        assertTrue(result is JarvisResult.Success)
        assertEquals(1, f.noteStore.notes.size)
        assertEquals("Gated", f.noteStore.notes.single().title)
    }

    @Test
    fun `a denied plugin tool never runs`() = runBlocking {
        val f = Fixture()
        f.pluginRegistry.sync()
        val job = f.scope.async {
            f.executor.execute(
                "save_note",
                buildJsonObject { put("title", "Denied"); put("body", "must not be saved") },
            )
        }
        val id = f.pendingId()
        assertTrue(f.engine.resolve(id, ApprovalDecision.Deny))
        val result = job.await()
        assertTrue(result is JarvisResult.Failure)
        assertEquals(0, f.noteStore.notes.size)
    }

    @Test
    fun `a disabled plugin's tools are unknown to the executor`() = runBlocking {
        val f = Fixture()
        f.pluginRegistry.sync()
        f.pluginRegistry.setEnabled("notes", false)
        val result = f.executor.execute(
            "save_note",
            buildJsonObject { put("title", "Off"); put("body", "plugin disabled") },
        )
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("save_note"))
        assertEquals(0, f.noteStore.notes.size)
    }
}
