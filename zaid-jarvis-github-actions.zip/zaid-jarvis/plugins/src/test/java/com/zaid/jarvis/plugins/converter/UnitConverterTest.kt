package com.zaid.jarvis.plugins.converter

import com.zaid.jarvis.core.util.JarvisResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Unit converter (Phase 10): length, mass, temperature — no currency. */
class UnitConverterTest {

    private fun converted(value: Double, from: String, to: String): Double {
        val result = UnitConverter.convert(value, from, to)
        assertTrue("Expected success converting $value $from -> $to, got $result", result is JarvisResult.Success)
        return (result as JarvisResult.Success).value.value
    }

    private fun assertFailure(value: Double, from: String, to: String) {
        val result = UnitConverter.convert(value, from, to)
        assertTrue("Expected failure converting $value $from -> $to, got $result", result is JarvisResult.Failure)
    }

    @Test
    fun `length conversions are correct`() {
        assertEquals(1.0, converted(1000.0, "m", "km"), 1e-9)
        assertEquals(100.0, converted(1.0, "m", "cm"), 1e-9)
        assertEquals(1.609344, converted(1.0, "mi", "km"), 1e-9)
        assertEquals(30.48, converted(1.0, "ft", "cm"), 1e-9)
        assertEquals(2.54, converted(1.0, "in", "cm"), 1e-9)
    }

    @Test
    fun `mass conversions are correct`() {
        assertEquals(1000.0, converted(1.0, "kg", "g"), 1e-9)
        assertEquals(0.45359237, converted(1.0, "lb", "kg"), 1e-9)
        assertEquals(16.0, converted(1.0, "lb", "oz"), 1e-9)
        assertEquals(1000.0, converted(1.0, "ton", "kg"), 1e-9)
    }

    @Test
    fun `temperature conversions are correct`() {
        assertEquals(32.0, converted(0.0, "C", "F"), 1e-9)
        assertEquals(212.0, converted(100.0, "C", "F"), 1e-9)
        assertEquals(0.0, converted(32.0, "F", "C"), 1e-9)
        assertEquals(273.15, converted(0.0, "C", "K"), 1e-9)
        assertEquals(-273.15, converted(0.0, "K", "C"), 1e-9)
    }

    @Test
    fun `aliases and case are accepted`() {
        assertEquals(1.0, converted(1000.0, "meters", "kilometers"), 1e-9)
        assertEquals(1.0, converted(1000.0, "Metres", "KM"), 1e-9)
        assertEquals(2.0, converted(2.0, "pounds", "lb"), 1e-9)
        assertEquals(32.0, converted(0.0, "celsius", "fahrenheit"), 1e-9)
    }

    @Test
    fun `converting a unit to itself returns the value`() {
        assertEquals(5.0, converted(5.0, "kg", "kilograms"), 1e-9)
    }

    @Test
    fun `unknown units are refused`() {
        assertFailure(1.0, "furlongs", "m")
        assertFailure(1.0, "m", "lightyears")
        assertFailure(1.0, "", "m")
    }

    @Test
    fun `cross-category conversions are refused`() {
        assertFailure(1.0, "kg", "m")
        assertFailure(1.0, "m", "C")
        assertFailure(100.0, "C", "kg")
    }

    @Test
    fun `currency is refused (no exchange-rate API)`() {
        assertFailure(100.0, "USD", "EUR")
        assertFailure(100.0, "dollars", "euros")
    }

    @Test
    fun `non-finite values are refused`() {
        assertFailure(Double.NaN, "m", "km")
        assertFailure(Double.POSITIVE_INFINITY, "m", "km")
    }

    @Test
    fun `supported units list every category`() {
        val supported = UnitConverter.supportedUnits()
        assertEquals(3, supported.size)
        assertTrue(supported[UnitConverter.Category.LENGTH]?.contains("km") == true)
        assertTrue(supported[UnitConverter.Category.MASS]?.contains("lb") == true)
        assertTrue(supported[UnitConverter.Category.TEMPERATURE]?.contains("F") == true)
    }
}
