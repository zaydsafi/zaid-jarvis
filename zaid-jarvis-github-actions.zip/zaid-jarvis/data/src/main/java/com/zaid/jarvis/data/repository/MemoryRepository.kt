package com.zaid.jarvis.data.repository

import com.zaid.jarvis.data.db.ListLimits
import com.zaid.jarvis.data.db.MemoryDao
import com.zaid.jarvis.data.db.MemoryItem
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Long-term memory (Master Prompt §4): preferences, contacts' nicknames,
 * writing style, favourite apps, routines.
 *
 * Zaid can view, edit, and delete any memory item (Memory screen, Phase 3),
 * and the planner reads a short summary of memory into its system prompt so
 * Jarvis remembers what matters — never more than Zaid has told it.
 * Memory lives in the SQLCipher-encrypted database; nothing is sent to an
 * LLM provider except the summary the planner builds per request.
 *
 * Lists are capped ([ListLimits]): the screen observes the most recent
 * 500 items, search returns at most 200, and the planner summary reads
 * at most [maxItems] rows from SQL (never the whole table).
 */
@Singleton
class MemoryRepository @Inject constructor(
    private val memoryDao: MemoryDao,
) {
    /** All memory items, newest first — capped ([ListLimits.MEMORY_LIST]). */
    fun observeAll(): Flow<List<MemoryItem>> = memoryDao.observeAll(ListLimits.MEMORY_LIST)

    suspend fun search(query: String): List<MemoryItem> =
        if (query.isBlank()) {
            // An empty query matches everything via the LIKE pattern;
            // still capped, like any other search.
            memoryDao.search("", ListLimits.MEMORY_SEARCH)
        } else {
            memoryDao.search(query.trim(), ListLimits.MEMORY_SEARCH)
        }

    /** Adds a new item, or updates the existing item with the same id. */
    suspend fun save(item: MemoryItem): Long =
        memoryDao.upsert(item.copy(updatedAtMillis = System.currentTimeMillis()))

    suspend fun delete(id: Long) = memoryDao.deleteById(id)

    suspend fun deleteAll() = memoryDao.deleteAll()

    /**
     * Short summary for the planner's system prompt (at most [maxItems]
     * items, newest first). Returns "" when there is nothing to remember.
     * The limit is applied in SQL — the whole table is never loaded.
     */
    suspend fun summaryForPrompt(maxItems: Int = 10): String {
        val items = memoryDao.search("", maxItems.coerceAtLeast(0))
        if (items.isEmpty()) return ""
        return items.joinToString("\n") { "- ${it.kind} / ${it.key}: ${it.value}" }
    }
}
