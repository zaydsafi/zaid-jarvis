package com.zaid.jarvis.data.db

/**
 * List caps (Phase 11 hardening): every list query Jarvis runs is
 * bounded, so no screen, worker, or tool can load an unbounded table
 * into memory.
 *
 * Two kinds of cap:
 * - **List caps** (`*_LIST`, `*_SEARCH`): SQL `LIMIT`s on the
 *   `observeAll()` / `search()` queries the screens read. The UI
 *   shows the most recent N rows; older rows still exist and are
 *   reachable through search (which has its own cap) and backup.
 * - **Bulk caps** (`*_BULK`): safety valves on the suspend `getAll()`
 *   reads the Insights screen, the briefing, and the planner tools
 *   use. 5,000 rows is far beyond what a person creates by hand; the
 *   cap only guards against pathological growth (e.g. a runaway
 *   import), never against normal use.
 *
 * Deliberately NOT capped: the DAOs' `getAll()` itself — backup
 * export and merge-by-id must see the whole table to be correct.
 * The fast-growing tables (audit log, analytics events) are bounded
 * at the source instead, by the retention policy
 * ([RetentionPolicy]): the audit log keeps at most 10,000 entries
 * and analytics events older than 90 days are pruned, so a backup
 * export is bounded in practice.
 */
object ListLimits {
    /** Audit-log screen: the most recent entries. */
    const val AUDIT_LOG_LIST: Int = 1_000

    /** Audit-log search results. */
    const val AUDIT_LOG_SEARCH: Int = 500

    /** Tasks screen (also feeds the open-task count chip). */
    const val TASK_LIST: Int = 2_000

    /** Suspend `getAll()` reads of tasks (Insights, briefing, tools). */
    const val TASK_BULK: Int = 5_000

    /** Filtered task queries (open / overdue / due today). */
    const val TASK_FILTERED: Int = 2_000

    /** Notes screen. Note bodies can be up to 10,000 chars, so this stays modest. */
    const val NOTE_LIST: Int = 500

    /** Note search results. */
    const val NOTE_SEARCH: Int = 200

    /** Suspend `getAll()` reads of notes (list_notes tool). */
    const val NOTE_BULK: Int = 5_000

    /** Memory screen. */
    const val MEMORY_LIST: Int = 500

    /** Memory search results (also the planner-summary source). */
    const val MEMORY_SEARCH: Int = 200

    /** Research history. Brief JSON is large, so this stays modest. */
    const val RESEARCH_LIST: Int = 200

    /** Drafts screen. Draft bodies can be up to 10,000 chars. */
    const val DRAFT_LIST: Int = 500

    /** Macros screen. */
    const val MACRO_LIST: Int = 500

    /** Scheduled-posts screen. */
    const val SCHEDULED_POST_LIST: Int = 500

    /** Suspend `getAll()` reads of scheduled posts (Insights, tools). */
    const val SCHEDULED_POST_BULK: Int = 5_000

    /** Focus-session history (Wellness screen). */
    const val FOCUS_SESSION_LIST: Int = 500

    /** Suspend `getAll()` reads of focus sessions (Insights). */
    const val FOCUS_SESSION_BULK: Int = 5_000

    /** Analytics events read for one Insights range (7/30 days). */
    const val ANALYTICS_EVENTS: Int = 10_000
}
