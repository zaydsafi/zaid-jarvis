package com.zaid.jarvis.data.di

import android.content.Context
import com.zaid.jarvis.core.confirmation.AuditLog
import com.zaid.jarvis.core.confirmation.TrustedActionStore
import com.zaid.jarvis.core.util.AppDispatchers
import com.zaid.jarvis.data.datastore.PluginStateRepository
import com.zaid.jarvis.data.datastore.SettingsRepository
import com.zaid.jarvis.data.datastore.TrustedActionRepository
import com.zaid.jarvis.data.db.AnalyticsEventDao
import com.zaid.jarvis.data.db.AuditLogDao
import com.zaid.jarvis.data.db.ContentDraftDao
import com.zaid.jarvis.data.db.FocusSessionDao
import com.zaid.jarvis.data.db.JarvisDatabase
import com.zaid.jarvis.data.db.MacroDao
import com.zaid.jarvis.data.db.MemoryDao
import com.zaid.jarvis.data.db.NoteDao
import com.zaid.jarvis.data.db.ResearchDao
import com.zaid.jarvis.data.db.ScheduledPostDao
import com.zaid.jarvis.data.db.TaskDao
import com.zaid.jarvis.data.device.DeviceContextProvider
import com.zaid.jarvis.data.repository.AnalyticsRepository
import com.zaid.jarvis.data.repository.BackupService
import com.zaid.jarvis.data.repository.BackupSettingsPort
import com.zaid.jarvis.data.repository.DraftRepository
import com.zaid.jarvis.data.repository.FocusSessionRepository
import com.zaid.jarvis.data.repository.LastAnswerRepository
import com.zaid.jarvis.data.repository.MacroRepository
import com.zaid.jarvis.data.repository.MaintenanceService
import com.zaid.jarvis.data.repository.MemoryRepository
import com.zaid.jarvis.data.repository.NoteRepository
import com.zaid.jarvis.data.repository.ResearchRepository
import com.zaid.jarvis.data.repository.RoomAuditLog
import com.zaid.jarvis.data.repository.RoomTransactionRunner
import com.zaid.jarvis.data.repository.ScheduledPostRepository
import com.zaid.jarvis.data.repository.SettingsRepositoryBackupPort
import com.zaid.jarvis.data.repository.SocialAccountRepository
import com.zaid.jarvis.data.repository.TaskRepository
import com.zaid.jarvis.data.repository.TransactionRunner
import com.zaid.jarvis.data.security.SecureKeyStore
import com.zaid.jarvis.plugins.PluginStateStore
import kotlinx.coroutines.flow.first
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DataModule {

    @Provides
    @Singleton
    fun provideAppDispatchers(): AppDispatchers = AppDispatchers()

    @Provides
    @Singleton
    fun provideSecureKeyStore(
        @ApplicationContext context: Context,
    ): SecureKeyStore = SecureKeyStore(context)

    @Provides
    @Singleton
    fun provideJarvisDatabase(
        @ApplicationContext context: Context,
        secureKeyStore: SecureKeyStore,
    ): JarvisDatabase = JarvisDatabase.getInstance(context, secureKeyStore)

    @Provides
    fun provideMemoryDao(database: JarvisDatabase): MemoryDao = database.memoryDao()

    @Provides
    fun provideAuditLogDao(database: JarvisDatabase): AuditLogDao = database.auditLogDao()

    @Provides
    fun provideMacroDao(database: JarvisDatabase): MacroDao = database.macroDao()

    @Provides
    fun provideResearchDao(database: JarvisDatabase): ResearchDao = database.researchDao()

    @Provides
    fun provideContentDraftDao(database: JarvisDatabase): ContentDraftDao =
        database.contentDraftDao()

    @Provides
    fun provideScheduledPostDao(database: JarvisDatabase): ScheduledPostDao =
        database.scheduledPostDao()

    @Provides
    fun provideTaskDao(database: JarvisDatabase): TaskDao = database.taskDao()

    @Provides
    fun provideFocusSessionDao(database: JarvisDatabase): FocusSessionDao =
        database.focusSessionDao()

    @Provides
    fun provideNoteDao(database: JarvisDatabase): NoteDao = database.noteDao()

    @Provides
    fun provideAnalyticsEventDao(database: JarvisDatabase): AnalyticsEventDao =
        database.analyticsEventDao()

    @Provides
    @Singleton
    fun provideMemoryRepository(memoryDao: MemoryDao): MemoryRepository = MemoryRepository(memoryDao)

    @Provides
    @Singleton
    fun provideMacroRepository(macroDao: MacroDao): MacroRepository = MacroRepository(macroDao)

    @Provides
    @Singleton
    fun provideResearchRepository(researchDao: ResearchDao): ResearchRepository =
        ResearchRepository(researchDao)

    @Provides
    @Singleton
    fun provideDraftRepository(draftDao: ContentDraftDao): DraftRepository =
        DraftRepository(draftDao)

    @Provides
    @Singleton
    fun provideScheduledPostRepository(dao: ScheduledPostDao): ScheduledPostRepository =
        ScheduledPostRepository(dao)

    @Provides
    @Singleton
    fun provideTaskRepository(dao: TaskDao): TaskRepository = TaskRepository(dao)

    @Provides
    @Singleton
    fun provideFocusSessionRepository(dao: FocusSessionDao): FocusSessionRepository =
        FocusSessionRepository(dao)

    @Provides
    @Singleton
    fun provideNoteRepository(dao: NoteDao): NoteRepository = NoteRepository(dao)

    /**
     * Analytics recording honours the "Usage insights" toggle: when it
     * is off, nothing is recorded at all.
     */
    @Provides
    @Singleton
    fun provideAnalyticsRepository(
        dao: AnalyticsEventDao,
        settingsRepository: SettingsRepository,
    ): AnalyticsRepository = AnalyticsRepository(
        dao = dao,
        isEnabled = { settingsRepository.settings.first().analyticsEnabled },
    )

    @Provides
    @Singleton
    fun provideBackupSettingsPort(
        settingsRepository: SettingsRepository,
    ): BackupSettingsPort = SettingsRepositoryBackupPort(settingsRepository)

    @Provides
    @Singleton
    fun provideTransactionRunner(database: JarvisDatabase): TransactionRunner =
        RoomTransactionRunner(database)

    @Provides
    @Singleton
    fun provideBackupService(
        taskDao: TaskDao,
        noteDao: NoteDao,
        macroDao: MacroDao,
        draftDao: ContentDraftDao,
        researchDao: ResearchDao,
        memoryDao: MemoryDao,
        scheduledPostDao: ScheduledPostDao,
        focusSessionDao: FocusSessionDao,
        auditLogDao: AuditLogDao,
        settingsPort: BackupSettingsPort,
        trustedStore: TrustedActionStore,
        transactionRunner: TransactionRunner,
    ): BackupService = BackupService(
        taskDao = taskDao,
        noteDao = noteDao,
        macroDao = macroDao,
        draftDao = draftDao,
        researchDao = researchDao,
        memoryDao = memoryDao,
        scheduledPostDao = scheduledPostDao,
        focusSessionDao = focusSessionDao,
        auditLogDao = auditLogDao,
        settingsPort = settingsPort,
        trustedStore = trustedStore,
        transactionRunner = transactionRunner,
    )

    @Provides
    @Singleton
    fun providePluginStateStore(
        @ApplicationContext context: Context,
    ): PluginStateStore = PluginStateRepository(context)

    @Provides
    @Singleton
    fun provideSocialAccountRepository(
        @ApplicationContext context: Context,
        secureKeyStore: SecureKeyStore,
    ): SocialAccountRepository = SocialAccountRepository(context, secureKeyStore)

    @Provides
    @Singleton
    fun provideDeviceContextProvider(
        @ApplicationContext context: Context,
    ): DeviceContextProvider = DeviceContextProvider(context)

    @Provides
    @Singleton
    fun provideLastAnswerRepository(
        @ApplicationContext context: Context,
    ): LastAnswerRepository = LastAnswerRepository(context)

    @Provides
    @Singleton
    fun provideAuditLog(roomAuditLog: RoomAuditLog): AuditLog = roomAuditLog

    /**
     * The concrete Room audit log (Phase 11): the maintenance service
     * needs the prune methods, which are not on the [AuditLog]
     * interface — one instance serves both bindings.
     */
    @Provides
    @Singleton
    fun provideRoomAuditLog(dao: AuditLogDao): RoomAuditLog = RoomAuditLog(dao)

    /**
     * Data maintenance (Phase 11): the weekly retention prune. The
     * repositories are passed as their pruner interfaces.
     */
    @Provides
    @Singleton
    fun provideMaintenanceService(
        analyticsRepository: AnalyticsRepository,
        roomAuditLog: RoomAuditLog,
    ): MaintenanceService = MaintenanceService(analyticsRepository, roomAuditLog)

    @Provides
    @Singleton
    fun provideTrustedActionStore(
        @ApplicationContext context: Context,
    ): TrustedActionStore = TrustedActionRepository(context)
}
