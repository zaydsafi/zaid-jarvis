package com.zaid.jarvis.data.db

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * A focus session (Phase 9): a timed DND session, logged for the
 * Wellness screen's history list.
 *
 * [previousDndMode] is the DndMode name Jarvis restores when the
 * session ends (null when DND was already in the focus mode).
 * [endWorkId] is the WorkManager job id for the end-of-session
 * worker, so stopping early also cancels the job.
 *
 * Status is stored as the FocusSessionStatus enum name. An unknown
 * status string read back maps to CANCELLED (fail-safe: an unreadable
 * session must never be treated as running, or its DND restore could
 * fire twice).
 */
@Entity(tableName = "focus_sessions")
data class FocusSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startedAtMillis: Long,
    val durationMinutes: Int,
    val endedAtMillis: Long? = null,
    /** FocusSessionStatus name. */
    val status: String,
    /** DndMode name to restore at the end (null = nothing to restore). */
    val previousDndMode: String? = null,
    /** WorkManager one-time work request id (UUID string), null until enqueued. */
    val endWorkId: String? = null,
)

@Dao
interface FocusSessionDao {
    /**
     * The most recent sessions — capped ([ListLimits.FOCUS_SESSION_LIST])
     * so the history list never loads the whole table.
     */
    @Query("SELECT * FROM focus_sessions ORDER BY startedAtMillis DESC LIMIT :limit")
    fun observeAll(limit: Int): Flow<List<FocusSessionEntity>>

    /**
     * All sessions. Deliberately uncapped — backup export must see
     * the whole table. The history list reads through [getRecent].
     */
    @Query("SELECT * FROM focus_sessions ORDER BY startedAtMillis DESC")
    suspend fun getAll(): List<FocusSessionEntity>

    /** All row ids (used by backup merge planning — cheaper than loading full rows). */
    @Query("SELECT id FROM focus_sessions")
    suspend fun getAllIds(): List<Long>

    /** The most recent [limit] sessions, newest first (Wellness history list). */
    @Query("SELECT * FROM focus_sessions ORDER BY startedAtMillis DESC LIMIT :limit")
    suspend fun getRecent(limit: Int): List<FocusSessionEntity>

    @Query("SELECT * FROM focus_sessions WHERE id = :id")
    suspend fun getById(id: Long): FocusSessionEntity?

    /** The currently running session, if any (there can be at most one). */
    @Query("SELECT * FROM focus_sessions WHERE status = 'RUNNING' ORDER BY startedAtMillis DESC LIMIT 1")
    suspend fun getRunning(): FocusSessionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: FocusSessionEntity): Long

    @Query("DELETE FROM focus_sessions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM focus_sessions")
    suspend fun deleteAll()
}
