package com.zaid.jarvis.data.db

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query

/**
 * One usage-analytics event (Phase 10): an event name, a timestamp,
 * and a small JSON payload of NON-PERSONAL data only (tool name, tier,
 * outcome, platform, duration bucket). See
 * [com.zaid.jarvis.core.analytics.AnalyticsPayload] for the rules that
 * keep free text out of [payloadJson] — the repository refuses to
 * record anything that fails validation.
 *
 * Events are local only: nothing leaves the device, and the Insights
 * screen can wipe the whole table ("Clear analytics data").
 */
@Entity(tableName = "analytics_events")
data class AnalyticsEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val eventName: String,
    val timestampMillis: Long,
    /** JSON object of validated, non-personal key/value pairs. */
    val payloadJson: String,
)

@Dao
interface AnalyticsEventDao {
    @Insert
    suspend fun insert(event: AnalyticsEventEntity): Long

    /**
     * Events at or after [sinceMillis], newest first — capped
     * ([ListLimits.ANALYTICS_EVENTS]) so a 30-day Insights range
     * cannot load an unbounded table.
     */
    @Query("SELECT * FROM analytics_events WHERE timestampMillis >= :sinceMillis ORDER BY timestampMillis DESC LIMIT :limit")
    suspend fun getSince(sinceMillis: Long, limit: Int): List<AnalyticsEventEntity>

    @Query("SELECT COUNT(*) FROM analytics_events")
    suspend fun count(): Int

    /**
     * Retention prune: deletes events older than [cutoffMillis].
     * Returns the number of rows deleted.
     */
    @Query("DELETE FROM analytics_events WHERE timestampMillis < :cutoffMillis")
    suspend fun deleteOlderThan(cutoffMillis: Long): Int

    @Query("DELETE FROM analytics_events")
    suspend fun deleteAll()
}
