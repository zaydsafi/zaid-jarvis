package com.zaid.jarvis.data.db

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * A content draft (Phase 7): a post Jarvis wrote for Zaid to review.
 *
 * Status is stored as the [DraftStatus] enum name ("DRAFT" /
 * "APPROVED" / "PUBLISHED"). Only DRAFT and APPROVED are reachable in
 * Phase 7 — [DraftRepository] refuses to store PUBLISHED, because
 * publishing is Phase 8 and a draft must never claim to be published
 * when it isn't. An unknown status string read back from the database
 * maps to DRAFT (fail-safe: an unreadable draft is never treated as
 * approved).
 *
 * Phase 8 adds [approvedBodyHash]: the SHA-256 of the body at approve
 * time. The publish path refuses an APPROVED draft whose body no
 * longer matches it — an edited draft must be re-approved first.
 */
@Entity(tableName = "content_drafts")
data class ContentDraftEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    /** Platform hint: a preset name or free text ("X", "Instagram", …). */
    val platform: String,
    /** DraftStatus name. */
    val status: String,
    /** Research this draft was based on, if any. */
    val researchId: Long? = null,
    /** SHA-256 hex of the body at approve time (Phase 8), null when never approved. */
    val approvedBodyHash: String? = null,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
)

@Dao
interface ContentDraftDao {
    /**
     * The most recently updated drafts — capped ([ListLimits.DRAFT_LIST])
     * so the Drafts screen never loads the whole table.
     */
    @Query("SELECT * FROM content_drafts ORDER BY updatedAtMillis DESC LIMIT :limit")
    fun observeAll(limit: Int): Flow<List<ContentDraftEntity>>

    /** All drafts (used by backup export). Deliberately uncapped — backup must see the whole table. */
    @Query("SELECT * FROM content_drafts ORDER BY updatedAtMillis DESC")
    suspend fun getAll(): List<ContentDraftEntity>

    /** All row ids (used by backup merge planning — cheaper than loading full rows). */
    @Query("SELECT id FROM content_drafts")
    suspend fun getAllIds(): List<Long>

    @Query("SELECT * FROM content_drafts WHERE id = :id")
    suspend fun getById(id: Long): ContentDraftEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ContentDraftEntity): Long

    @Query("DELETE FROM content_drafts WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM content_drafts")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM content_drafts")
    suspend fun count(): Int
}
