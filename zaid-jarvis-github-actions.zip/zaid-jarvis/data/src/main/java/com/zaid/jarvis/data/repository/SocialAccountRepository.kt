package com.zaid.jarvis.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.zaid.jarvis.core.social.OAuthClientCredentials
import com.zaid.jarvis.core.social.OAuthTokens
import com.zaid.jarvis.core.social.SocialAccount
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.data.security.SecureKeyStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

private val Context.socialAccountsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "jarvis_social_accounts",
)

/**
 * Connected social accounts (Phase 8).
 *
 * Split storage, on purpose:
 * - Public account metadata ([SocialAccount]: platform, id, handle,
 *   display name, token expiry) lives in its own DataStore file as
 *   JSON, one entry per platform. No secrets here.
 * - OAuth tokens and client credentials live ONLY in [SecureKeyStore]
 *   (Keystore + EncryptedSharedPreferences), under the `social_`
 *   prefix. They are never in Room, never in DataStore, never logged.
 *
 * The [com.zaid.jarvis.tools.social.SocialAccountStore] interface
 * (used by :agent and :app) is implemented by a thin adapter in :app
 * over this repository — the same pattern as RoomMacroStore (Phase 6),
 * because :data does not depend on :tools.
 */
@Singleton
class SocialAccountRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val secureKeyStore: SecureKeyStore,
) {
    private val json = Json { ignoreUnknownKeys = true }

    /** All connected accounts, as a Flow (for the Connected accounts screen). */
    val accounts: Flow<List<SocialAccount>> =
        context.socialAccountsDataStore.data.map { prefs ->
            SocialPlatform.entries.mapNotNull { platform ->
                prefs[accountKey(platform)]?.let { raw ->
                    runCatching { json.decodeFromString<SocialAccount>(raw) }.getOrNull()
                }
            }
        }

    suspend fun getAccount(platform: SocialPlatform): SocialAccount? {
        val raw = context.socialAccountsDataStore.data.map { prefs ->
            prefs[accountKey(platform)]
        }.first()
        return raw?.let { runCatching { json.decodeFromString<SocialAccount>(it) }.getOrNull() }
    }

    suspend fun allAccounts(): List<SocialAccount> = accounts.first()

    suspend fun saveAccount(account: SocialAccount) {
        context.socialAccountsDataStore.edit { prefs ->
            prefs[accountKey(account.platform)] = json.encodeToString(account)
        }
    }

    /** Disconnects a platform: removes its metadata AND its tokens. */
    suspend fun deleteAccount(platform: SocialPlatform) {
        context.socialAccountsDataStore.edit { prefs ->
            prefs.remove(accountKey(platform))
        }
        clearTokens(platform)
    }

    suspend fun getTokens(platform: SocialPlatform): OAuthTokens? {
        val access = secureKeyStore.getSecret(SecureKeyStore.socialAccessTokenKey(platform.name))
            ?: return null
        val refresh = secureKeyStore.getSecret(SecureKeyStore.socialRefreshTokenKey(platform.name))
        val expiry = secureKeyStore.getSecret(SecureKeyStore.socialTokenExpiryKey(platform.name))
            ?.toLongOrNull() ?: 0L
        return OAuthTokens(accessToken = access, refreshToken = refresh, expiresAtMillis = expiry)
    }

    suspend fun saveTokens(platform: SocialPlatform, tokens: OAuthTokens) {
        secureKeyStore.putSecret(SecureKeyStore.socialAccessTokenKey(platform.name), tokens.accessToken)
        val refreshToken = tokens.refreshToken
        if (refreshToken != null) {
            secureKeyStore.putSecret(
                SecureKeyStore.socialRefreshTokenKey(platform.name),
                refreshToken,
            )
        }
        secureKeyStore.putSecret(
            SecureKeyStore.socialTokenExpiryKey(platform.name),
            tokens.expiresAtMillis.toString(),
        )
    }

    suspend fun clearTokens(platform: SocialPlatform) {
        secureKeyStore.removeSecret(SecureKeyStore.socialAccessTokenKey(platform.name))
        secureKeyStore.removeSecret(SecureKeyStore.socialRefreshTokenKey(platform.name))
        secureKeyStore.removeSecret(SecureKeyStore.socialTokenExpiryKey(platform.name))
    }

    suspend fun getClientCredentials(platform: SocialPlatform): OAuthClientCredentials? {
        val clientId = secureKeyStore.getSecret(SecureKeyStore.socialClientIdKey(platform.name))
            ?: return null
        val secret = secureKeyStore.getSecret(SecureKeyStore.socialClientSecretKey(platform.name))
        return OAuthClientCredentials(clientId = clientId, clientSecret = secret)
    }

    suspend fun saveClientCredentials(platform: SocialPlatform, credentials: OAuthClientCredentials) {
        secureKeyStore.putSecret(
            SecureKeyStore.socialClientIdKey(platform.name),
            credentials.clientId,
        )
        val clientSecret = credentials.clientSecret
        if (clientSecret != null) {
            secureKeyStore.putSecret(
                SecureKeyStore.socialClientSecretKey(platform.name),
                clientSecret,
            )
        } else {
            secureKeyStore.removeSecret(SecureKeyStore.socialClientSecretKey(platform.name))
        }
    }

    suspend fun clearClientCredentials(platform: SocialPlatform) {
        secureKeyStore.removeSecret(SecureKeyStore.socialClientIdKey(platform.name))
        secureKeyStore.removeSecret(SecureKeyStore.socialClientSecretKey(platform.name))
    }

    /** Whether OAuth client credentials are stored for [platform] (presence only, never the value). */
    fun hasClientCredentials(platform: SocialPlatform): Boolean =
        secureKeyStore.hasSecret(SecureKeyStore.socialClientIdKey(platform.name))

    /** Removes every social secret (tokens + client credentials) — "Delete all secrets". */
    suspend fun clearAllSocialSecrets() {
        for (key in secureKeyStore.allSecretKeys()) {
            if (key.startsWith(SecureKeyStore.SOCIAL_SECRET_PREFIX)) {
                secureKeyStore.removeSecret(key)
            }
        }
    }

    /**
     * Deletes every connected account: its metadata (DataStore) and
     * its tokens + client credentials (Keystore). Used by
     * delete-all-data (Phase 11) — after this, no platform is
     * connected and no social secret remains.
     */
    suspend fun clearAll() {
        context.socialAccountsDataStore.edit { prefs -> prefs.clear() }
        clearAllSocialSecrets()
    }

    private fun accountKey(platform: SocialPlatform) =
        stringPreferencesKey("account_${platform.name.lowercase()}")
}
