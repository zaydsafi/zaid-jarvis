package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.confirmation.AuditDecision
import com.zaid.jarvis.core.confirmation.AuditEntry
import com.zaid.jarvis.core.confirmation.AuditLog
import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.data.db.AuditLogDao
import com.zaid.jarvis.data.db.AuditLogEntryEntity
import com.zaid.jarvis.data.db.ListLimits
import com.zaid.jarvis.data.db.RetentionPolicy
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Room-backed audit log (Master Prompt §6). Entries live in the
 * SQLCipher-encrypted database, so the audit trail is protected at rest
 * along with everything else Jarvis stores.
 *
 * Lists are capped ([ListLimits]): the screen reads the most recent
 * 1,000 entries and search returns at most 500 — the table itself can
 * hold up to [RetentionPolicy.AUDIT_LOG_KEEP_COUNT] entries before the
 * weekly maintenance prune trims it.
 */
@Singleton
class RoomAuditLog @Inject constructor(
    private val dao: AuditLogDao,
) : AuditLog, AuditLogPruner {

    override suspend fun record(entry: AuditEntry): Long =
        dao.insert(entry.toEntity())

    override fun observeAll(): Flow<List<AuditEntry>> =
        dao.observeAll(ListLimits.AUDIT_LOG_LIST).map { rows -> rows.map { it.toModel() } }

    override suspend fun search(query: String): List<AuditEntry> =
        dao.search(query, ListLimits.AUDIT_LOG_SEARCH).map { it.toModel() }

    override suspend fun get(id: Long): AuditEntry? =
        dao.getById(id)?.toModel()

    override suspend fun delete(id: Long) = dao.deleteById(id)

    override suspend fun clear() = dao.deleteAll()

    override suspend fun markUndone(id: Long) = dao.markUndone(id)

    override suspend fun count(): Int = dao.count()

    /**
     * Retention prune: deletes everything except the newest
     * [keepCount] entries. Returns the number of rows deleted.
     */
    override suspend fun pruneToNewest(keepCount: Int): Int =
        dao.deleteBeyondNewest(keepCount)

    private fun AuditEntry.toEntity() = AuditLogEntryEntity(
        id = id,
        timestampMillis = timestampMillis,
        toolName = toolName,
        tier = tier.name,
        action = action,
        target = target,
        paramsSummary = paramsSummary,
        decision = decision.name,
        resultSummary = resultSummary,
        undoable = undoable,
        undoDescription = undoDescription,
        undoData = undoData,
        undone = undone,
    )

    private fun AuditLogEntryEntity.toModel() = AuditEntry(
        id = id,
        timestampMillis = timestampMillis,
        toolName = toolName,
        tier = runCatching { RiskTier.valueOf(tier) }.getOrDefault(RiskTier.REVERSIBLE),
        action = action,
        target = target,
        paramsSummary = paramsSummary,
        decision = runCatching { AuditDecision.valueOf(decision) }.getOrDefault(AuditDecision.DENIED),
        resultSummary = resultSummary,
        undoable = undoable,
        undoDescription = undoDescription,
        undoData = undoData,
        undone = undone,
    )
}
