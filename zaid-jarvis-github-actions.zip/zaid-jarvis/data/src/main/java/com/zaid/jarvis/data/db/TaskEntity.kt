package com.zaid.jarvis.data.db

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * A task (Phase 9): the productivity core.
 *
 * [dueAtMillis] and [reminderAtMillis] are epoch millis (null = no due
 * date / no reminder). [overdueNotifiedDay] is the epoch day (UTC) on
 * which Jarvis last sent an overdue nudge for this task — the
 * smart-reminder dedupe key (one nudge per task per day).
 * [reminderWorkId] is the WorkManager job id for the reminder, so
 * cancelling the reminder (or deleting the task) also cancels the job.
 *
 * Priority and status are stored as the enum names. An unknown value
 * read back maps to MEDIUM / OPEN (fail-safe: a task is never lost
 * because of an unreadable field).
 */
@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val notes: String = "",
    val dueAtMillis: Long? = null,
    /** TaskPriority name. */
    val priority: String,
    /** TaskStatus name. */
    val status: String,
    val reminderAtMillis: Long? = null,
    /** WorkManager one-time work request id (UUID string), null until enqueued. */
    val reminderWorkId: String? = null,
    /** Epoch day (UTC) of the last overdue nudge, null when never nudged. */
    val overdueNotifiedDay: Long? = null,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
)

@Dao
interface TaskDao {
    /**
     * The most recently updated tasks — capped ([ListLimits.TASK_LIST])
     * so the Tasks screen never loads the whole table.
     */
    @Query("SELECT * FROM tasks ORDER BY updatedAtMillis DESC LIMIT :limit")
    fun observeAll(limit: Int): Flow<List<TaskEntity>>

    /**
     * All tasks. Deliberately uncapped — backup export must see the
     * whole table. UI and tools read through the capped queries or
     * the repository's bulk cap instead.
     */
    @Query("SELECT * FROM tasks ORDER BY updatedAtMillis DESC")
    suspend fun getAll(): List<TaskEntity>

    /** All row ids (used by backup merge planning — cheaper than loading full rows). */
    @Query("SELECT id FROM tasks")
    suspend fun getAllIds(): List<Long>

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun getById(id: Long): TaskEntity?

    /**
     * Open tasks, earliest due first (undated last) — capped
     * ([ListLimits.TASK_FILTERED]). Filtered in SQL so the
     * 15-minute proactive worker and the Home "Today" card never
     * load the whole table just to find the open ones. The filter is
     * `status != 'DONE'` (not `= 'OPEN'`) so a row with an unreadable
     * status still counts as open — the same fail-safe as the
     * repository's mapping.
     */
    @Query(
        "SELECT * FROM tasks WHERE status != 'DONE' " +
            "ORDER BY dueAtMillis IS NULL, dueAtMillis ASC, updatedAtMillis ASC LIMIT :limit",
    )
    suspend fun getOpen(limit: Int): List<TaskEntity>

    /** Open tasks whose due time has passed — capped ([ListLimits.TASK_FILTERED]). */
    @Query(
        "SELECT * FROM tasks WHERE status != 'DONE' AND dueAtMillis IS NOT NULL " +
            "AND dueAtMillis < :nowMillis ORDER BY dueAtMillis ASC LIMIT :limit",
    )
    suspend fun getOverdue(nowMillis: Long, limit: Int): List<TaskEntity>

    /**
     * Open tasks due in `[startMillis, endMillis)` — capped
     * ([ListLimits.TASK_FILTERED]). The caller computes the day
     * boundaries in the device time zone (see TaskRepository).
     */
    @Query(
        "SELECT * FROM tasks WHERE status != 'DONE' AND dueAtMillis IS NOT NULL " +
            "AND dueAtMillis >= :startMillis AND dueAtMillis < :endMillis " +
            "ORDER BY dueAtMillis ASC LIMIT :limit",
    )
    suspend fun getDueBetween(startMillis: Long, endMillis: Long, limit: Int): List<TaskEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: TaskEntity): Long

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM tasks")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM tasks")
    suspend fun count(): Int
}
