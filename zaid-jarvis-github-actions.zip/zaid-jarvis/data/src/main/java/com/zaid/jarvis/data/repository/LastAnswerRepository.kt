package com.zaid.jarvis.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.lastAnswerDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "jarvis_last_answer",
)

/**
 * The widget's "last answer" line (Master Prompt §5.4): the most recent
 * Jarvis reply, persisted in its own small DataStore so the home-screen
 * widget (a BroadcastReceiver, no ViewModel) can read it without the
 * app running.
 *
 * Only the latest answer is kept — no conversation history leaves the
 * chat screen. Formatting for the widget lives in
 * [com.zaid.jarvis.core.voice.LastAnswer].
 */
@Singleton
class LastAnswerRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    /** The latest answer text ("" when Jarvis has not answered yet). */
    val lastAnswer: Flow<String> = context.lastAnswerDataStore.data.map { prefs ->
        prefs[KEY_LAST_ANSWER] ?: ""
    }

    /** When the latest answer was saved (0 when none yet). */
    val lastAnswerAtMillis: Flow<Long> = context.lastAnswerDataStore.data.map { prefs ->
        prefs[KEY_LAST_ANSWER_AT] ?: 0L
    }

    suspend fun save(answer: String) {
        context.lastAnswerDataStore.edit { prefs ->
            prefs[KEY_LAST_ANSWER] = answer
            prefs[KEY_LAST_ANSWER_AT] = System.currentTimeMillis()
        }
    }

    suspend fun clear() {
        context.lastAnswerDataStore.edit { prefs ->
            prefs.remove(KEY_LAST_ANSWER)
            prefs.remove(KEY_LAST_ANSWER_AT)
        }
    }

    private companion object {
        val KEY_LAST_ANSWER = stringPreferencesKey("last_answer")
        val KEY_LAST_ANSWER_AT = longPreferencesKey("last_answer_at_millis")
    }
}
