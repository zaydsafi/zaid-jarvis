package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.social.ScheduledPost
import com.zaid.jarvis.core.social.ScheduledPostStatus
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.db.ListLimits
import com.zaid.jarvis.data.db.ScheduledPostDao
import com.zaid.jarvis.data.db.ScheduledPostEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Scheduled posts (Phase 8): the Room side of the scheduler. The
 * WorkManager side lives in :app (WorkManagerSocialScheduler); the
 * publish gate lives in :agent (PublishServiceImpl).
 *
 * Fail-safe mapping: an unknown status string from the database maps
 * to CANCELLED (an unreadable scheduled post must never run), and an
 * unknown platform name maps to null — the row is skipped rather than
 * published to the wrong platform.
 */
@Singleton
class ScheduledPostRepository @Inject constructor(
    private val dao: ScheduledPostDao,
) {
    /** All scheduled posts — capped ([ListLimits.SCHEDULED_POST_LIST]). */
    fun observeAll(): Flow<List<ScheduledPost>> =
        dao.observeAll(ListLimits.SCHEDULED_POST_LIST).map { rows -> rows.mapNotNull { it.toModel() } }

    /** All scheduled posts — capped ([ListLimits.SCHEDULED_POST_BULK]) as a safety valve. */
    suspend fun getAll(): List<ScheduledPost> =
        dao.getAll().take(ListLimits.SCHEDULED_POST_BULK).mapNotNull { it.toModel() }

    suspend fun getById(id: Long): ScheduledPost? = dao.getById(id)?.toModel()

    /** Inserts or replaces a scheduled post; returns the row id. */
    suspend fun save(post: ScheduledPost, workRequestId: String? = null): JarvisResult<Long> {
        val now = System.currentTimeMillis()
        val entity = ScheduledPostEntity(
            id = post.id,
            draftId = post.draftId,
            platform = post.platform.name,
            accountHandle = post.accountHandle,
            scheduledAtMillis = post.scheduledAtMillis,
            contentHash = post.contentHash,
            imageUrl = post.imageUrl,
            status = post.status.name,
            failureReason = post.failureReason,
            postUrl = post.postUrl,
            workRequestId = workRequestId ?: existingWorkRequestId(post.id),
            createdAtMillis = if (post.createdAtMillis == 0L) now else post.createdAtMillis,
            updatedAtMillis = now,
        )
        return JarvisResult.Success(dao.upsert(entity))
    }

    /** Updates only the status (and optional reason / post URL) of a row. */
    suspend fun updateStatus(
        id: Long,
        status: ScheduledPostStatus,
        failureReason: String? = null,
        postUrl: String? = null,
    ): JarvisResult<Unit> {
        val current = dao.getById(id)
            ?: return JarvisResult.Failure("No scheduled post with id $id.")
        dao.upsert(
            current.copy(
                status = status.name,
                failureReason = failureReason,
                postUrl = postUrl ?: current.postUrl,
                updatedAtMillis = System.currentTimeMillis(),
            ),
        )
        return JarvisResult.Success(Unit)
    }

    /** Records the WorkManager job id for a row (after enqueueing). */
    suspend fun setWorkRequestId(id: Long, workRequestId: String) {
        val current = dao.getById(id) ?: return
        dao.upsert(current.copy(workRequestId = workRequestId))
    }

    /** The WorkManager job id for a row (null when never enqueued). */
    suspend fun workRequestIdFor(id: Long): String? = dao.getById(id)?.workRequestId

    suspend fun deleteById(id: Long) = dao.deleteById(id)

    suspend fun deleteAll() = dao.deleteAll()

    suspend fun count(): Int = dao.count()

    private suspend fun existingWorkRequestId(id: Long): String? =
        if (id == 0L) null else dao.getById(id)?.workRequestId

    private fun ScheduledPostEntity.toModel(): ScheduledPost? {
        val platform = runCatching { SocialPlatform.valueOf(platform) }.getOrNull()
            ?: return null
        val status = runCatching { ScheduledPostStatus.valueOf(status) }
            .getOrDefault(ScheduledPostStatus.CANCELLED)
        return ScheduledPost(
            id = id,
            draftId = draftId,
            platform = platform,
            accountHandle = accountHandle,
            scheduledAtMillis = scheduledAtMillis,
            contentHash = contentHash,
            imageUrl = imageUrl,
            status = status,
            failureReason = failureReason,
            postUrl = postUrl,
            createdAtMillis = createdAtMillis,
            updatedAtMillis = updatedAtMillis,
        )
    }
}
