package com.zaid.jarvis.data.db

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * Long-term memory item (Master Prompt §4).
 * Phase 1: the table exists so the encrypted database is real; the memory
 * UI and agent use land in Phase 3.
 */
@Entity(tableName = "memory_items")
data class MemoryItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** e.g. "preference", "nickname", "routine", "writing_style". */
    val kind: String,
    val key: String,
    val value: String,
    val updatedAtMillis: Long = System.currentTimeMillis(),
)

@Dao
interface MemoryDao {
    /**
     * The most recently updated items — capped ([ListLimits.MEMORY_LIST])
     * so the Memory screen never loads the whole table.
     */
    @Query("SELECT * FROM memory_items ORDER BY updatedAtMillis DESC LIMIT :limit")
    fun observeAll(limit: Int): Flow<List<MemoryItem>>

    /**
     * All items (used by backup export). Deliberately uncapped —
     * backup must see the whole table.
     */
    @Query("SELECT * FROM memory_items ORDER BY updatedAtMillis DESC")
    suspend fun getAll(): List<MemoryItem>

    /** All row ids (used by backup merge planning — cheaper than loading full rows). */
    @Query("SELECT id FROM memory_items")
    suspend fun getAllIds(): List<Long>

    /** Case-insensitive search over kind, key, and value — capped ([ListLimits.MEMORY_SEARCH]). */
    @Query(
        "SELECT * FROM memory_items WHERE kind LIKE '%' || :query || '%' " +
            "OR key LIKE '%' || :query || '%' " +
            "OR value LIKE '%' || :query || '%' ORDER BY updatedAtMillis DESC LIMIT :limit",
    )
    suspend fun search(query: String, limit: Int): List<MemoryItem>

    /** Items of one kind, newest first — capped. */
    @Query("SELECT * FROM memory_items WHERE kind = :kind ORDER BY updatedAtMillis DESC LIMIT :limit")
    suspend fun getByKind(kind: String, limit: Int): List<MemoryItem>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: MemoryItem): Long

    @Query("DELETE FROM memory_items WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM memory_items")
    suspend fun deleteAll()
}
