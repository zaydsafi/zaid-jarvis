package com.zaid.jarvis.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.zaid.jarvis.data.security.SecureKeyStore
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory

/**
 * Jarvis's local database, encrypted at rest with SQLCipher.
 *
 * The encryption passphrase is a random 256-bit value generated once and
 * kept in the Keystore-backed [SecureKeyStore] — it is never hard-coded,
 * never logged, and never leaves the device.
 *
 * Version history:
 * - v1 (Phase 1): `memory_items`
 * - v2 (Phase 2): adds `audit_log_entries`
 * - v3 (Phase 5): adds `undoData` to `audit_log_entries` (real undo)
 * - v4 (Phase 6): adds `macros` (recorded automation sequences)
 * - v5 (Phase 7): adds `research_records` and `content_drafts`
 * - v6 (Phase 8): adds `scheduled_posts`
 * - v7 (Phase 9): adds `tasks` and `focus_sessions`
 * - v8 (Phase 10): adds `notes` and `analytics_events`
 */
@Database(
    entities = [
        MemoryItem::class,
        AuditLogEntryEntity::class,
        MacroEntity::class,
        ResearchEntity::class,
        ContentDraftEntity::class,
        ScheduledPostEntity::class,
        TaskEntity::class,
        FocusSessionEntity::class,
        NoteEntity::class,
        AnalyticsEventEntity::class,
    ],
    version = 8,
    exportSchema = false,
)
abstract class JarvisDatabase : RoomDatabase() {
    abstract fun memoryDao(): MemoryDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun macroDao(): MacroDao
    abstract fun researchDao(): ResearchDao
    abstract fun contentDraftDao(): ContentDraftDao
    abstract fun scheduledPostDao(): ScheduledPostDao
    abstract fun taskDao(): TaskDao
    abstract fun focusSessionDao(): FocusSessionDao
    abstract fun noteDao(): NoteDao
    abstract fun analyticsEventDao(): AnalyticsEventDao

    companion object {
        /** v1 → v2: create the audit-log table. Existing data is kept. */
        val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `audit_log_entries` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`timestampMillis` INTEGER NOT NULL, " +
                        "`toolName` TEXT NOT NULL, " +
                        "`tier` TEXT NOT NULL, " +
                        "`action` TEXT NOT NULL, " +
                        "`target` TEXT NOT NULL, " +
                        "`paramsSummary` TEXT NOT NULL, " +
                        "`decision` TEXT NOT NULL, " +
                        "`resultSummary` TEXT, " +
                        "`undoable` INTEGER NOT NULL, " +
                        "`undoDescription` TEXT, " +
                        "`undone` INTEGER NOT NULL)",
                )
            }
        }

        /** v2 → v3: add the undo payload column to the audit table. */
        val MIGRATION_2_3: Migration = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `audit_log_entries` ADD COLUMN `undoData` TEXT")
            }
        }

        /** v3 → v4: create the macros table. Existing data is kept. */
        val MIGRATION_3_4: Migration = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `macros` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`name` TEXT NOT NULL, " +
                        "`stepsJson` TEXT NOT NULL, " +
                        "`createdAtMillis` INTEGER NOT NULL, " +
                        "`lastRunAtMillis` INTEGER)",
                )
            }
        }

        /** v4 → v5: create the research and drafts tables. Existing data is kept. */
        val MIGRATION_4_5: Migration = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `research_records` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`topic` TEXT NOT NULL, " +
                        "`briefJson` TEXT NOT NULL, " +
                        "`createdAtMillis` INTEGER NOT NULL)",
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `content_drafts` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`title` TEXT NOT NULL, " +
                        "`body` TEXT NOT NULL, " +
                        "`platform` TEXT NOT NULL, " +
                        "`status` TEXT NOT NULL, " +
                        "`researchId` INTEGER, " +
                        "`createdAtMillis` INTEGER NOT NULL, " +
                        "`updatedAtMillis` INTEGER NOT NULL)",
                )
            }
        }

        /** v5 → v6: create the scheduled-posts table, and add the approval
         * content-hash column to content_drafts (Phase 8). Existing data is kept. */
        val MIGRATION_5_6: Migration = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `scheduled_posts` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`draftId` INTEGER NOT NULL, " +
                        "`platform` TEXT NOT NULL, " +
                        "`accountHandle` TEXT NOT NULL, " +
                        "`scheduledAtMillis` INTEGER NOT NULL, " +
                        "`contentHash` TEXT NOT NULL, " +
                        "`imageUrl` TEXT, " +
                        "`status` TEXT NOT NULL, " +
                        "`failureReason` TEXT, " +
                        "`postUrl` TEXT, " +
                        "`workRequestId` TEXT, " +
                        "`createdAtMillis` INTEGER NOT NULL, " +
                        "`updatedAtMillis` INTEGER NOT NULL)",
                )
                db.execSQL(
                    "ALTER TABLE `content_drafts` ADD COLUMN `approvedBodyHash` TEXT",
                )
            }
        }

        /** v6 → v7: create the tasks and focus-sessions tables. Existing data is kept. */
        val MIGRATION_6_7: Migration = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `tasks` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`title` TEXT NOT NULL, " +
                        "`notes` TEXT NOT NULL, " +
                        "`dueAtMillis` INTEGER, " +
                        "`priority` TEXT NOT NULL, " +
                        "`status` TEXT NOT NULL, " +
                        "`reminderAtMillis` INTEGER, " +
                        "`reminderWorkId` TEXT, " +
                        "`overdueNotifiedDay` INTEGER, " +
                        "`createdAtMillis` INTEGER NOT NULL, " +
                        "`updatedAtMillis` INTEGER NOT NULL)",
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `focus_sessions` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`startedAtMillis` INTEGER NOT NULL, " +
                        "`durationMinutes` INTEGER NOT NULL, " +
                        "`endedAtMillis` INTEGER, " +
                        "`status` TEXT NOT NULL, " +
                        "`previousDndMode` TEXT, " +
                        "`endWorkId` TEXT)",
                )
            }
        }

        /** v7 → v8: create the notes and analytics-events tables. Existing data is kept. */
        val MIGRATION_7_8: Migration = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `notes` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`title` TEXT NOT NULL, " +
                        "`body` TEXT NOT NULL, " +
                        "`createdAtMillis` INTEGER NOT NULL, " +
                        "`updatedAtMillis` INTEGER NOT NULL)",
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `analytics_events` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`eventName` TEXT NOT NULL, " +
                        "`timestampMillis` INTEGER NOT NULL, " +
                        "`payloadJson` TEXT NOT NULL)",
                )
            }
        }

        @Volatile
        private var instance: JarvisDatabase? = null

        /** The database file name (plus -wal / -shm / -journal sidecars). */
        const val DATABASE_NAME: String = "jarvis.db"

        fun getInstance(context: Context, secureKeyStore: SecureKeyStore): JarvisDatabase =
            instance ?: synchronized(this) {
                instance ?: buildDatabase(context, secureKeyStore).also { instance = it }
            }

        /**
         * Drops the cached instance (delete-all-data, Phase 11). Called
         * after the database has been closed and its files deleted, so a
         * later [getInstance] builds a fresh, empty database instead of
         * returning the closed one.
         */
        fun clearInstance() {
            synchronized(this) { instance = null }
        }

        private fun buildDatabase(
            context: Context,
            secureKeyStore: SecureKeyStore,
        ): JarvisDatabase {
            val passphrase = SQLiteDatabase.getBytes(
                secureKeyStore.getOrCreateDatabasePassphrase().toCharArray(),
            )
            val factory = SupportFactory(passphrase)
            return Room.databaseBuilder(context, JarvisDatabase::class.java, DATABASE_NAME)
                .openHelperFactory(factory)
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8)
                .build()
        }
    }
}
