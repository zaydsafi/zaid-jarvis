package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.productivity.FocusSession
import com.zaid.jarvis.core.productivity.FocusSessionStatus
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.db.FocusSessionDao
import com.zaid.jarvis.data.db.FocusSessionEntity
import com.zaid.jarvis.data.db.ListLimits
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Focus sessions (Phase 9): the Room side of focus mode. The DND
 * toggling and the foreground service live in :app
 * (FocusSessionManagerImpl); the planner tools in :tools program
 * against the FocusSessionManager interface.
 *
 * Fail-safe mapping: an unknown status string maps to CANCELLED — an
 * unreadable session must never be treated as running, or its DND
 * restore could fire twice.
 */
@Singleton
class FocusSessionRepository @Inject constructor(
    private val dao: FocusSessionDao,
) {
    /** All sessions — capped ([ListLimits.FOCUS_SESSION_LIST]). */
    fun observeAll(): Flow<List<FocusSession>> =
        dao.observeAll(ListLimits.FOCUS_SESSION_LIST).map { rows -> rows.map { it.toModel() } }

    /** All sessions — capped ([ListLimits.FOCUS_SESSION_BULK]) as a safety valve. */
    suspend fun getAll(): List<FocusSession> =
        dao.getAll().take(ListLimits.FOCUS_SESSION_BULK).map { it.toModel() }

    suspend fun getById(id: Long): FocusSession? = dao.getById(id)?.toModel()

    /** The currently running session, if any. */
    suspend fun getRunning(): FocusSession? = dao.getRunning()?.toModel()

    /**
     * Recent sessions, newest first (for the Wellness history list).
     * The limit is applied in SQL — the whole table is never loaded.
     */
    suspend fun getRecent(limit: Int): List<FocusSession> =
        dao.getRecent(limit.coerceAtLeast(0)).map { it.toModel() }

    /** Inserts or replaces a session; returns the row id. */
    suspend fun save(session: FocusSession): JarvisResult<Long> {
        val entity = FocusSessionEntity(
            id = session.id,
            startedAtMillis = session.startedAtMillis,
            durationMinutes = session.durationMinutes,
            endedAtMillis = session.endedAtMillis,
            status = session.status.name,
            previousDndMode = session.previousDndMode,
            endWorkId = session.endWorkId,
        )
        return JarvisResult.Success(dao.upsert(entity))
    }

    /**
     * Finishes a RUNNING session (COMPLETED when the timer ran out,
     * CANCELLED when stopped early). Returns false when the session
     * was already finished — this is what makes the end path
     * idempotent: the foreground service and the WorkManager worker
     * can both try to end the same session, and only the first one
     * restores DND.
     */
    suspend fun finish(id: Long, status: FocusSessionStatus, endedAtMillis: Long): Boolean {
        val current = dao.getById(id) ?: return false
        if (current.status != FocusSessionStatus.RUNNING.name) return false
        dao.upsert(
            current.copy(
                status = status.name,
                endedAtMillis = endedAtMillis,
            ),
        )
        return true
    }

    /** Records the WorkManager job id for a session (after enqueueing). */
    suspend fun setEndWorkId(id: Long, workId: String) {
        val current = dao.getById(id) ?: return
        dao.upsert(current.copy(endWorkId = workId))
    }

    suspend fun deleteById(id: Long) = dao.deleteById(id)

    suspend fun deleteAll() = dao.deleteAll()

    private fun FocusSessionEntity.toModel(): FocusSession {
        val status = runCatching { FocusSessionStatus.valueOf(status) }
            .getOrDefault(FocusSessionStatus.CANCELLED)
        return FocusSession(
            id = id,
            startedAtMillis = startedAtMillis,
            durationMinutes = durationMinutes,
            endedAtMillis = endedAtMillis,
            status = status,
            previousDndMode = previousDndMode,
            endWorkId = endWorkId,
        )
    }
}
