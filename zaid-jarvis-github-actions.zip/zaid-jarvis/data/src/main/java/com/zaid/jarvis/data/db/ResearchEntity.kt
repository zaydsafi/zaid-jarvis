package com.zaid.jarvis.data.db

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * A saved research job (Phase 7): the topic Zaid asked about and the
 * structured brief the ResearchEngine produced for it.
 *
 * The brief is stored as one JSON string ([briefJson]) — a brief is
 * always read and written as a whole, so a separate facts/sources
 * table would add joins for no benefit. The whole database is
 * encrypted at rest (SQLCipher).
 */
@Entity(tableName = "research_records")
data class ResearchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val topic: String,
    /** JSON of ResearchBrief (kotlinx.serialization). */
    val briefJson: String,
    val createdAtMillis: Long,
)

@Dao
interface ResearchDao {
    /**
     * The most recent records — capped ([ListLimits.RESEARCH_LIST]) so
     * the Research screen never loads the whole table (brief JSON is large).
     */
    @Query("SELECT * FROM research_records ORDER BY createdAtMillis DESC LIMIT :limit")
    fun observeAll(limit: Int): Flow<List<ResearchEntity>>

    /** All records (used by backup export). Deliberately uncapped — backup must see the whole table. */
    @Query("SELECT * FROM research_records ORDER BY createdAtMillis DESC")
    suspend fun getAll(): List<ResearchEntity>

    /** All row ids (used by backup merge planning — cheaper than loading full rows). */
    @Query("SELECT id FROM research_records")
    suspend fun getAllIds(): List<Long>

    @Query("SELECT * FROM research_records WHERE id = :id")
    suspend fun getById(id: Long): ResearchEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: ResearchEntity): Long

    @Query("DELETE FROM research_records WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM research_records")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM research_records")
    suspend fun count(): Int
}
