package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.automation.Macro
import com.zaid.jarvis.core.automation.MacroStep
import com.zaid.jarvis.core.automation.MacroValidation
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.db.ListLimits
import com.zaid.jarvis.data.db.MacroDao
import com.zaid.jarvis.data.db.MacroEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Saved macros (Phase 6): recorded sequences of taps, typing, and
 * scrolling that Jarvis can replay with `run_macro`.
 *
 * Names are unique (case-insensitive) so "run the morning macro" can
 * never be ambiguous. Every save is validated ([MacroValidation]) —
 * an invalid macro is refused with the reasons, never stored half-broken.
 * Macros live in the SQLCipher-encrypted database; step text never
 * contains passwords (the recorder never records them).
 */
@Singleton
class MacroRepository @Inject constructor(
    private val macroDao: MacroDao,
) {
    private val json = Json { ignoreUnknownKeys = true }
    private val stepsSerializer = ListSerializer(MacroStep.serializer())

    /** All macros, alphabetically — capped ([ListLimits.MACRO_LIST]). */
    fun observeAll(): Flow<List<Macro>> =
        macroDao.observeAll(ListLimits.MACRO_LIST).map { entities -> entities.mapNotNull { toMacro(it) } }

    /** Live macro count (a SQL COUNT — no rows loaded). */
    fun observeCount(): Flow<Int> = macroDao.observeCount()

    suspend fun getByName(name: String): Macro? =
        macroDao.getByName(name.trim())?.let { toMacro(it) }

    suspend fun getById(id: Long): Macro? =
        macroDao.getById(id)?.let { toMacro(it) }

    suspend fun count(): Int = macroDao.count()

    /**
     * Saves a new macro or updates an existing one (same id). Returns
     * the row id, or a Failure with the validation / name-conflict
     * reasons. A macro whose name is taken by a *different* macro is
     * refused — rename the other one first.
     */
    suspend fun save(macro: Macro): JarvisResult<Long> {
        val trimmed = macro.copy(name = macro.name.trim())
        val errors = MacroValidation.validate(trimmed)
        if (errors.isNotEmpty()) {
            return JarvisResult.Failure(errors.joinToString(" "))
        }
        val existing = macroDao.getByName(trimmed.name)
        if (existing != null && existing.id != trimmed.id) {
            return JarvisResult.Failure(
                "A macro named “${trimmed.name}” already exists — pick another name.",
            )
        }
        val entity = MacroEntity(
            id = trimmed.id,
            name = trimmed.name,
            stepsJson = json.encodeToString(stepsSerializer, trimmed.steps),
            createdAtMillis = if (trimmed.id == 0L) {
                System.currentTimeMillis()
            } else {
                existing?.createdAtMillis ?: System.currentTimeMillis()
            },
            lastRunAtMillis = trimmed.lastRunAtMillis,
        )
        return JarvisResult.Success(macroDao.upsert(entity))
    }

    /** Renames a macro (name uniqueness still enforced). */
    suspend fun rename(id: Long, newName: String): JarvisResult<Unit> {
        val macro = getById(id)
            ?: return JarvisResult.Failure("That macro no longer exists.")
        return when (val result = save(macro.copy(name = newName))) {
            is JarvisResult.Success -> JarvisResult.Success(Unit)
            is JarvisResult.Failure -> result
        }
    }

    suspend fun delete(id: Long) = macroDao.deleteById(id)

    suspend fun deleteAll() = macroDao.deleteAll()

    /** Records that the macro ran just now. */
    suspend fun markRun(id: Long) = macroDao.markRun(id, System.currentTimeMillis())

    /** Decodes an entity, or null when its steps JSON is unreadable (never crashes). */
    private fun toMacro(entity: MacroEntity): Macro? {
        val steps = runCatching {
            json.decodeFromString(stepsSerializer, entity.stepsJson)
        }.getOrNull() ?: return null
        return Macro(
            id = entity.id,
            name = entity.name,
            steps = steps,
            createdAtMillis = entity.createdAtMillis,
            lastRunAtMillis = entity.lastRunAtMillis,
        )
    }
}
