package com.zaid.jarvis.data.db

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * A saved macro (Phase 6): a named, ordered list of automation steps.
 *
 * Steps are stored as one JSON array ([stepsJson]) — a macro's steps
 * are always read and written as a whole, so a separate steps table
 * would add joins for no benefit. The whole database is encrypted at
 * rest (SQLCipher), and step text never contains passwords (the
 * recorder never records them).
 */
@Entity(tableName = "macros")
data class MacroEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** Unique by convention (enforced in MacroRepository, not by Room). */
    val name: String,
    /** JSON array of MacroStep (kotlinx.serialization). */
    val stepsJson: String,
    val createdAtMillis: Long,
    val lastRunAtMillis: Long? = null,
)

@Dao
interface MacroDao {
    /**
     * All macros, alphabetically — capped ([ListLimits.MACRO_LIST]) so
     * the Macros screen never loads the whole table.
     */
    @Query("SELECT * FROM macros ORDER BY name ASC LIMIT :limit")
    fun observeAll(limit: Int): Flow<List<MacroEntity>>

    /** All macros (used by backup export). Deliberately uncapped — backup must see the whole table. */
    @Query("SELECT * FROM macros ORDER BY name ASC")
    suspend fun getAll(): List<MacroEntity>

    /** All row ids (used by backup merge planning — cheaper than loading full rows). */
    @Query("SELECT id FROM macros")
    suspend fun getAllIds(): List<Long>

    /** Live macro count (for the Settings Automation section — no rows loaded). */
    @Query("SELECT COUNT(*) FROM macros")
    fun observeCount(): Flow<Int>

    @Query("SELECT * FROM macros WHERE name = :name COLLATE NOCASE LIMIT 1")
    suspend fun getByName(name: String): MacroEntity?

    @Query("SELECT * FROM macros WHERE id = :id")
    suspend fun getById(id: Long): MacroEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: MacroEntity): Long

    @Query("UPDATE macros SET lastRunAtMillis = :timestampMillis WHERE id = :id")
    suspend fun markRun(id: Long, timestampMillis: Long)

    @Query("DELETE FROM macros WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM macros")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM macros")
    suspend fun count(): Int
}
