package com.zaid.jarvis.data.repository

import androidx.room.withTransaction
import com.zaid.jarvis.core.backup.BackupAuditEntry
import com.zaid.jarvis.core.backup.BackupData
import com.zaid.jarvis.core.backup.BackupDraft
import com.zaid.jarvis.core.backup.BackupFocusSession
import com.zaid.jarvis.core.backup.BackupMacro
import com.zaid.jarvis.core.backup.BackupMemoryItem
import com.zaid.jarvis.core.backup.BackupMerge
import com.zaid.jarvis.core.backup.BackupNote
import com.zaid.jarvis.core.backup.BackupResearchRecord
import com.zaid.jarvis.core.backup.BackupScheduledPost
import com.zaid.jarvis.core.backup.BackupTask
import com.zaid.jarvis.core.confirmation.TrustedActionStore
import com.zaid.jarvis.core.model.JarvisSettings
import com.zaid.jarvis.core.productivity.FocusSessionStatus
import com.zaid.jarvis.core.productivity.Task
import com.zaid.jarvis.core.productivity.TaskPriority
import com.zaid.jarvis.core.productivity.TaskStatus
import com.zaid.jarvis.core.social.ScheduledPostStatus
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.datastore.SettingsRepository
import com.zaid.jarvis.data.db.AuditLogDao
import com.zaid.jarvis.data.db.AuditLogEntryEntity
import com.zaid.jarvis.data.db.ContentDraftDao
import com.zaid.jarvis.data.db.ContentDraftEntity
import com.zaid.jarvis.data.db.FocusSessionDao
import com.zaid.jarvis.data.db.FocusSessionEntity
import com.zaid.jarvis.data.db.JarvisDatabase
import com.zaid.jarvis.data.db.MacroDao
import com.zaid.jarvis.data.db.MacroEntity
import com.zaid.jarvis.data.db.MemoryDao
import com.zaid.jarvis.data.db.MemoryItem
import com.zaid.jarvis.data.db.NoteDao
import com.zaid.jarvis.data.db.NoteEntity
import com.zaid.jarvis.data.db.ResearchDao
import com.zaid.jarvis.data.db.ResearchEntity
import com.zaid.jarvis.data.db.ScheduledPostDao
import com.zaid.jarvis.data.db.ScheduledPostEntity
import com.zaid.jarvis.data.db.TaskDao
import com.zaid.jarvis.data.db.TaskEntity
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Runs [block] inside a single Room transaction (production) or
 * directly (tests). Import uses it so a failure leaves the database
 * unchanged.
 */
interface TransactionRunner {
    suspend fun <T> run(block: suspend () -> T): T
}

/** Room-backed transaction runner (production). */
class RoomTransactionRunner(private val database: JarvisDatabase) : TransactionRunner {
    override suspend fun <T> run(block: suspend () -> T): T = database.withTransaction(block)
}

/**
 * The settings side of backup/restore, behind an interface so tests
 * don't need DataStore. Production implementation reads/writes the
 * real SettingsRepository.
 */
interface BackupSettingsPort {
    suspend fun current(): JarvisSettings
    suspend fun replace(settings: JarvisSettings)
}

/** Production [BackupSettingsPort] over the real SettingsRepository. */
class SettingsRepositoryBackupPort(
    private val repository: SettingsRepository,
) : BackupSettingsPort {
    override suspend fun current(): JarvisSettings = repository.settings.first()

    override suspend fun replace(settings: JarvisSettings) {
        repository.updateSettings { settings }
    }
}

/**
 * Backup & restore (Phase 10): export the whole user-visible database
 * to [BackupData], and import it back with merge-by-id.
 *
 * - **Export** reads every table plus settings (non-secret) and
 *   trusted actions. API keys, OAuth tokens, client secrets, and the
 *   database passphrase are never read here — they live in
 *   Keystore-backed storage and are not part of any backup.
 * - **Import** merges by id: rows whose id already exists are SKIPPED,
 *   never overwritten. Macros are additionally deduplicated by name
 *   (names are unique by convention). There is deliberately no
 *   "replace all" mode in Phase 10.
 * - **WorkManager jobs are not restored**: a restored task keeps its
 *   reminder time but no job — the caller re-enqueues future
 *   reminders from [ImportReport.remindersToReschedule]. A restored
 *   SCHEDULED post is imported as CANCELLED (publishing is an
 *   external, Tier 2 action — it must never auto-resume from a file).
 *   A restored RUNNING focus session is imported as CANCELLED (its
 *   end worker is gone).
 * - **Transaction**: all database writes run inside one Room
 *   transaction — a failure leaves the database unchanged. Settings
 *   and trusted actions (DataStore, not Room) are applied only after
 *   the transaction succeeds.
 */
@Singleton
class BackupService @Inject constructor(
    private val taskDao: TaskDao,
    private val noteDao: NoteDao,
    private val macroDao: MacroDao,
    private val draftDao: ContentDraftDao,
    private val researchDao: ResearchDao,
    private val memoryDao: MemoryDao,
    private val scheduledPostDao: ScheduledPostDao,
    private val focusSessionDao: FocusSessionDao,
    private val auditLogDao: AuditLogDao,
    private val settingsPort: BackupSettingsPort,
    private val trustedStore: TrustedActionStore,
    private val transactionRunner: TransactionRunner,
) {
    /** What the import preview shows for one section. */
    data class ImportPreview(
        val sections: List<BackupMerge.SectionPlan>,
        /** Settings are always replaced wholesale on import (there is nothing to merge). */
        val settingsWillReplace: Boolean = true,
        /** Trusted actions in the backup that aren't trusted yet. */
        val trustedNew: Int,
        /** Trusted actions in the backup that are already trusted. */
        val trustedAlready: Int,
    )

    /** What an import actually did. */
    data class ImportReport(
        val imported: Map<String, Int>,
        val skipped: Map<String, Int>,
        /** Imported tasks with a reminder still in the future — the caller re-enqueues their jobs. */
        val remindersToReschedule: List<Task>,
        /** Scheduled posts restored as CANCELLED (their publish jobs are gone). */
        val cancelledScheduledPosts: Int,
    )

    /** Builds the full backup payload from the current database. */
    suspend fun export(): BackupData {
        val scheduled = scheduledPostDao.getAll()
        return BackupData(
            settings = settingsPort.current(),
            tasks = taskDao.getAll().map { it.toBackup() },
            notes = noteDao.getAll().map { it.toBackup() },
            macros = macroDao.getAll().map { it.toBackup() },
            drafts = draftDao.getAll().map { it.toBackup() },
            researchRecords = researchDao.getAll().map { it.toBackup() },
            memoryItems = memoryDao.getAll().map { it.toBackup() },
            scheduledPosts = scheduled
                .filter { it.status == ScheduledPostStatus.SCHEDULED.name }
                .map { it.toBackup() },
            scheduledPostHistory = scheduled
                .filter { it.status != ScheduledPostStatus.SCHEDULED.name }
                .map { it.toBackup() },
            focusSessions = focusSessionDao.getAll().map { it.toBackup() },
            trustedActions = trustedStore.observeTrusted().first().sorted(),
            auditLog = auditLogDao.getAll().map { it.toBackup() },
        )
    }

    /** Counts what an import of [data] would do, without writing anything. */
    suspend fun preview(data: BackupData): ImportPreview {
        // Merge planning only needs ids (and macro names) — loading
        // full rows here would pull every note body, draft, and
        // research brief into memory twice (preview + import).
        val existingMacros = macroDao.getAll()
        val sections = listOf(
            BackupMerge.planSection("Tasks", taskDao.getAllIds().toSet(), data.tasks.map { it.id }),
            BackupMerge.planSection("Notes", noteDao.getAllIds().toSet(), data.notes.map { it.id }),
            planMacros(
                existingIds = existingMacros.map { it.id }.toSet(),
                existingNames = existingMacros.map { it.name.lowercase() }.toSet(),
                incoming = data.macros,
            ),
            BackupMerge.planSection("Drafts", draftDao.getAllIds().toSet(), data.drafts.map { it.id }),
            BackupMerge.planSection(
                "Research",
                researchDao.getAllIds().toSet(),
                data.researchRecords.map { it.id },
            ),
            BackupMerge.planSection(
                "Memory",
                memoryDao.getAllIds().toSet(),
                data.memoryItems.map { it.id },
            ),
            BackupMerge.planSection(
                "Scheduled posts",
                scheduledPostDao.getAllIds().toSet(),
                (data.scheduledPosts + data.scheduledPostHistory).map { it.id },
            ),
            BackupMerge.planSection(
                "Focus sessions",
                focusSessionDao.getAllIds().toSet(),
                data.focusSessions.map { it.id },
            ),
            BackupMerge.planSection(
                "Audit log",
                auditLogDao.getAllIds().toSet(),
                data.auditLog.map { it.id },
            ),
        )
        val trustedNow = trustedStore.observeTrusted().first()
        val trustedNew = data.trustedActions.distinct().count { it !in trustedNow }
        return ImportPreview(
            sections = sections,
            trustedNew = trustedNew,
            trustedAlready = data.trustedActions.distinct().size - trustedNew,
        )
    }

    /**
     * Imports [data] with merge-by-id. Database writes run in one
     * transaction; settings and trusted actions are applied only
     * after it succeeds.
     */
    suspend fun import(
        data: BackupData,
        nowMillis: Long = System.currentTimeMillis(),
    ): JarvisResult<ImportReport> {
        return try {
            val report = transactionRunner.run {
                importInTransaction(data, nowMillis)
            }
            // DataStore (not Room): applied only after the transaction succeeded.
            runCatching { settingsPort.replace(data.settings) }.onFailure {
                return JarvisResult.Failure(
                    "Your data was imported, but your settings could not be applied: ${it.message}",
                )
            }
            runCatching {
                data.trustedActions.distinct().forEach { trustedStore.trust(it) }
            }.onFailure {
                return JarvisResult.Failure(
                    "Your data was imported, but your trusted actions could not be applied: ${it.message}",
                )
            }
            JarvisResult.Success(report)
        } catch (e: Exception) {
            JarvisResult.Failure("Import failed: ${e.message ?: e::class.simpleName}. Nothing was changed.")
        }
    }

    private suspend fun importInTransaction(data: BackupData, nowMillis: Long): ImportReport {
        val imported = mutableMapOf<String, Int>()
        val skipped = mutableMapOf<String, Int>()

        // Tasks.
        val existingTaskIds = taskDao.getAllIds().toSet()
        val newTasks = data.tasks.distinctBy { it.id }.filter { it.id !in existingTaskIds }
        val remindersToReschedule = mutableListOf<Task>()
        for (task in newTasks) {
            taskDao.upsert(task.toEntity())
            val reminderAt = task.reminderAtMillis
            if (reminderAt != null && reminderAt > nowMillis) {
                remindersToReschedule += task.toModel()
            }
        }
        imported["Tasks"] = newTasks.size
        skipped["Tasks"] = data.tasks.size - newTasks.size

        // Notes.
        val existingNoteIds = noteDao.getAllIds().toSet()
        val newNotes = data.notes.distinctBy { it.id }.filter { it.id !in existingNoteIds }
        newNotes.forEach { noteDao.upsert(it.toEntity()) }
        imported["Notes"] = newNotes.size
        skipped["Notes"] = data.notes.size - newNotes.size

        // Macros (deduplicated by id AND by name).
        val existingMacros = macroDao.getAll()
        val existingMacroIds = existingMacros.map { it.id }.toSet()
        val existingMacroNames = existingMacros.map { it.name.lowercase() }.toSet()
        val newMacros = data.macros.distinctBy { it.id }
            .filter { it.id !in existingMacroIds && it.name.lowercase() !in existingMacroNames }
        newMacros.forEach { macroDao.upsert(it.toEntity()) }
        imported["Macros"] = newMacros.size
        skipped["Macros"] = data.macros.size - newMacros.size

        // Drafts.
        val existingDraftIds = draftDao.getAllIds().toSet()
        val newDrafts = data.drafts.distinctBy { it.id }.filter { it.id !in existingDraftIds }
        newDrafts.forEach { draftDao.upsert(it.toEntity()) }
        imported["Drafts"] = newDrafts.size
        skipped["Drafts"] = data.drafts.size - newDrafts.size

        // Research records.
        val existingResearchIds = researchDao.getAllIds().toSet()
        val newResearch = data.researchRecords.distinctBy { it.id }
            .filter { it.id !in existingResearchIds }
        newResearch.forEach { researchDao.insert(it.toEntity()) }
        imported["Research"] = newResearch.size
        skipped["Research"] = data.researchRecords.size - newResearch.size

        // Memory items.
        val existingMemoryIds = memoryDao.getAllIds().toSet()
        val newMemory = data.memoryItems.distinctBy { it.id }.filter { it.id !in existingMemoryIds }
        newMemory.forEach { memoryDao.upsert(it.toEntity()) }
        imported["Memory"] = newMemory.size
        skipped["Memory"] = data.memoryItems.size - newMemory.size

        // Scheduled posts: SCHEDULED rows come back as CANCELLED (their
        // publish jobs are gone — publishing must never auto-resume
        // from a file); history rows come back as-is.
        val existingPostIds = scheduledPostDao.getAllIds().toSet()
        val newScheduled = data.scheduledPosts.distinctBy { it.id }
            .filter { it.id !in existingPostIds }
        // Hoisted out of the filter below: rebuilding this set per
        // history row made the check quadratic in the post count.
        val newScheduledIds = newScheduled.map { post -> post.id }.toSet()
        val newHistory = data.scheduledPostHistory.distinctBy { it.id }
            .filter { it.id !in existingPostIds && it.id !in newScheduledIds }
        newScheduled.forEach { scheduledPostDao.upsert(it.toEntity().copy(status = ScheduledPostStatus.CANCELLED.name, failureReason = RESTORED_POST_REASON)) }
        newHistory.forEach { scheduledPostDao.upsert(it.toEntity()) }
        imported["Scheduled posts"] = newScheduled.size + newHistory.size
        skipped["Scheduled posts"] = data.scheduledPosts.size + data.scheduledPostHistory.size -
            newScheduled.size - newHistory.size

        // Focus sessions: a RUNNING session comes back as CANCELLED
        // (its end worker is gone; DND is the device's current state).
        val existingFocusIds = focusSessionDao.getAllIds().toSet()
        val newFocus = data.focusSessions.distinctBy { it.id }.filter { it.id !in existingFocusIds }
        newFocus.forEach { session ->
            val entity = session.toEntity()
            val restored = if (entity.status == FocusSessionStatus.RUNNING.name) {
                entity.copy(status = FocusSessionStatus.CANCELLED.name)
            } else {
                entity
            }
            focusSessionDao.upsert(restored)
        }
        imported["Focus sessions"] = newFocus.size
        skipped["Focus sessions"] = data.focusSessions.size - newFocus.size

        // Audit log.
        val existingAuditIds = auditLogDao.getAllIds().toSet()
        val newAudit = data.auditLog.distinctBy { it.id }.filter { it.id !in existingAuditIds }
        newAudit.forEach { auditLogDao.insert(it.toEntity()) }
        imported["Audit log"] = newAudit.size
        skipped["Audit log"] = data.auditLog.size - newAudit.size

        return ImportReport(
            imported = imported,
            skipped = skipped,
            remindersToReschedule = remindersToReschedule,
            cancelledScheduledPosts = newScheduled.size,
        )
    }

    private fun planMacros(
        existingIds: Set<Long>,
        existingNames: Set<String>,
        incoming: List<BackupMacro>,
    ): BackupMerge.SectionPlan {
        // Macros are deduplicated by id AND by name (names are unique
        // by convention), so the preview counts either collision as
        // skipped — exactly what importInTransaction does.
        val distinct = incoming.distinctBy { it.id }
        val toImport = distinct.count { it.id !in existingIds && it.name.lowercase() !in existingNames }
        return BackupMerge.SectionPlan(
            section = "Macros",
            incoming = incoming.size,
            toImport = toImport,
            skipped = incoming.size - toImport,
        )
    }

    companion object {
        /** Why a restored scheduled post is CANCELLED instead of SCHEDULED. */
        const val RESTORED_POST_REASON: String =
            "Restored from backup — the scheduled publish was not resumed. " +
                "Re-schedule it from the Drafts screen if you still want it published."
    }
}

// ── Entity ↔ backup DTO mapping ──────────────────────────────────────────────

private fun TaskEntity.toBackup(): BackupTask = BackupTask(
    id = id,
    title = title,
    notes = notes,
    dueAtMillis = dueAtMillis,
    priority = priority,
    status = status,
    reminderAtMillis = reminderAtMillis,
    overdueNotifiedDay = overdueNotifiedDay,
    createdAtMillis = createdAtMillis,
    updatedAtMillis = updatedAtMillis,
)

private fun BackupTask.toEntity(): TaskEntity = TaskEntity(
    id = id,
    title = title,
    notes = notes,
    dueAtMillis = dueAtMillis,
    priority = priority,
    status = status,
    reminderAtMillis = reminderAtMillis,
    reminderWorkId = null, // The WorkManager job is not restored (see ImportReport).
    overdueNotifiedDay = overdueNotifiedDay,
    createdAtMillis = createdAtMillis,
    updatedAtMillis = updatedAtMillis,
)

private fun BackupTask.toModel(): Task = Task(
    id = id,
    title = title,
    notes = notes,
    dueAtMillis = dueAtMillis,
    priority = runCatching { TaskPriority.valueOf(priority) }.getOrDefault(TaskPriority.MEDIUM),
    status = runCatching { TaskStatus.valueOf(status) }.getOrDefault(TaskStatus.OPEN),
    reminderAtMillis = reminderAtMillis,
    createdAtMillis = createdAtMillis,
    updatedAtMillis = updatedAtMillis,
)

private fun NoteEntity.toBackup(): BackupNote = BackupNote(
    id = id,
    title = title,
    body = body,
    createdAtMillis = createdAtMillis,
    updatedAtMillis = updatedAtMillis,
)

private fun BackupNote.toEntity(): NoteEntity = NoteEntity(
    id = id,
    title = title,
    body = body,
    createdAtMillis = createdAtMillis,
    updatedAtMillis = updatedAtMillis,
)

private fun MacroEntity.toBackup(): BackupMacro = BackupMacro(
    id = id,
    name = name,
    stepsJson = stepsJson,
    createdAtMillis = createdAtMillis,
    lastRunAtMillis = lastRunAtMillis,
)

private fun BackupMacro.toEntity(): MacroEntity = MacroEntity(
    id = id,
    name = name,
    stepsJson = stepsJson,
    createdAtMillis = createdAtMillis,
    lastRunAtMillis = lastRunAtMillis,
)

private fun ContentDraftEntity.toBackup(): BackupDraft = BackupDraft(
    id = id,
    title = title,
    body = body,
    platform = platform,
    status = status,
    researchId = researchId,
    approvedBodyHash = approvedBodyHash,
    createdAtMillis = createdAtMillis,
    updatedAtMillis = updatedAtMillis,
)

private fun BackupDraft.toEntity(): ContentDraftEntity = ContentDraftEntity(
    id = id,
    title = title,
    body = body,
    platform = platform,
    status = status,
    researchId = researchId,
    approvedBodyHash = approvedBodyHash,
    createdAtMillis = createdAtMillis,
    updatedAtMillis = updatedAtMillis,
)

private fun ResearchEntity.toBackup(): BackupResearchRecord = BackupResearchRecord(
    id = id,
    topic = topic,
    briefJson = briefJson,
    createdAtMillis = createdAtMillis,
)

private fun BackupResearchRecord.toEntity(): ResearchEntity = ResearchEntity(
    id = id,
    topic = topic,
    briefJson = briefJson,
    createdAtMillis = createdAtMillis,
)

private fun MemoryItem.toBackup(): BackupMemoryItem = BackupMemoryItem(
    id = id,
    kind = kind,
    key = key,
    value = value,
    updatedAtMillis = updatedAtMillis,
)

private fun BackupMemoryItem.toEntity(): MemoryItem = MemoryItem(
    id = id,
    kind = kind,
    key = key,
    value = value,
    updatedAtMillis = updatedAtMillis,
)

private fun ScheduledPostEntity.toBackup(): BackupScheduledPost = BackupScheduledPost(
    id = id,
    draftId = draftId,
    platform = platform,
    accountHandle = accountHandle,
    scheduledAtMillis = scheduledAtMillis,
    contentHash = contentHash,
    imageUrl = imageUrl,
    status = status,
    failureReason = failureReason,
    postUrl = postUrl,
    createdAtMillis = createdAtMillis,
    updatedAtMillis = updatedAtMillis,
)

private fun BackupScheduledPost.toEntity(): ScheduledPostEntity = ScheduledPostEntity(
    id = id,
    draftId = draftId,
    platform = platform,
    accountHandle = accountHandle,
    scheduledAtMillis = scheduledAtMillis,
    contentHash = contentHash,
    imageUrl = imageUrl,
    status = status,
    failureReason = failureReason,
    postUrl = postUrl,
    workRequestId = null, // The WorkManager job is not restored.
    createdAtMillis = createdAtMillis,
    updatedAtMillis = updatedAtMillis,
)

private fun FocusSessionEntity.toBackup(): BackupFocusSession = BackupFocusSession(
    id = id,
    startedAtMillis = startedAtMillis,
    durationMinutes = durationMinutes,
    endedAtMillis = endedAtMillis,
    status = status,
    previousDndMode = previousDndMode,
)

private fun BackupFocusSession.toEntity(): FocusSessionEntity = FocusSessionEntity(
    id = id,
    startedAtMillis = startedAtMillis,
    durationMinutes = durationMinutes,
    endedAtMillis = endedAtMillis,
    status = status,
    previousDndMode = previousDndMode,
    endWorkId = null, // The WorkManager job is not restored.
)

private fun AuditLogEntryEntity.toBackup(): BackupAuditEntry = BackupAuditEntry(
    id = id,
    timestampMillis = timestampMillis,
    toolName = toolName,
    tier = tier,
    action = action,
    target = target,
    paramsSummary = paramsSummary,
    decision = decision,
    resultSummary = resultSummary,
    undoable = undoable,
    undoDescription = undoDescription,
    undoData = undoData,
    undone = undone,
)

private fun BackupAuditEntry.toEntity(): AuditLogEntryEntity = AuditLogEntryEntity(
    id = id,
    timestampMillis = timestampMillis,
    toolName = toolName,
    tier = tier,
    action = action,
    target = target,
    paramsSummary = paramsSummary,
    decision = decision,
    resultSummary = resultSummary,
    undoable = undoable,
    undoDescription = undoDescription,
    undoData = undoData,
    undone = undone,
)
