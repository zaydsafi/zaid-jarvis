package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.db.ListLimits
import com.zaid.jarvis.data.db.NoteDao
import com.zaid.jarvis.data.db.NoteEntity
import com.zaid.jarvis.plugins.notes.Note
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Notes (Phase 10, Notes plugin): the Room side of note storage. The
 * planner tools in :plugins program against the NoteStore interface,
 * which :app adapts to this repository (RoomNoteStore).
 *
 * Lists are capped ([ListLimits]): the screen observes the most recent
 * 500 notes and search returns at most 200.
 */
@Singleton
class NoteRepository @Inject constructor(
    private val dao: NoteDao,
) {
    fun observeAll(): Flow<List<Note>> =
        dao.observeAll(ListLimits.NOTE_LIST).map { rows -> rows.map { it.toModel() } }

    /** All notes — capped ([ListLimits.NOTE_BULK]) as a safety valve. */
    suspend fun getAll(): List<Note> = dao.getAll().take(ListLimits.NOTE_BULK).map { it.toModel() }

    suspend fun getById(id: Long): Note? = dao.getById(id)?.toModel()

    suspend fun search(query: String): List<Note> =
        if (query.isBlank()) emptyList()
        else dao.search(query.trim(), ListLimits.NOTE_SEARCH).map { it.toModel() }

    /** Inserts or replaces a note; returns the row id. */
    suspend fun save(note: Note): JarvisResult<Long> {
        if (note.title.isBlank()) {
            return JarvisResult.Failure("A note needs a title.")
        }
        if (note.body.isBlank()) {
            return JarvisResult.Failure("A note needs some text.")
        }
        val now = System.currentTimeMillis()
        val entity = NoteEntity(
            id = note.id,
            title = note.title.trim(),
            body = note.body,
            createdAtMillis = if (note.createdAtMillis == 0L) now else note.createdAtMillis,
            updatedAtMillis = now,
        )
        return JarvisResult.Success(dao.upsert(entity))
    }

    suspend fun deleteById(id: Long) = dao.deleteById(id)

    suspend fun deleteAll() = dao.deleteAll()

    suspend fun count(): Int = dao.count()

    private fun NoteEntity.toModel(): Note = Note(
        id = id,
        title = title,
        body = body,
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis,
    )
}
