package com.zaid.jarvis.data.db

/**
 * Retention policy (Phase 11 hardening): how long Jarvis keeps the
 * two tables that grow on their own — the audit log (one row per tool
 * call) and analytics events (one row per tool execution / publish /
 * focus session). Everything else Jarvis stores is created by Zaid
 * one row at a time and is never pruned automatically.
 *
 * Enforced by the weekly [com.zaid.jarvis.backup.MaintenanceWorker]
 * through [com.zaid.jarvis.data.repository.MaintenanceService].
 *
 * Pure computations (no database, no clock) so they are unit-testable
 * on the JVM; the SQL that applies them lives in the DAOs.
 */
object RetentionPolicy {
    /** Analytics events older than this are pruned (90 days). */
    const val ANALYTICS_RETENTION_DAYS: Long = 90

    /** The audit log keeps the most recent entries up to this count. */
    const val AUDIT_LOG_KEEP_COUNT: Int = 10_000

    /** Millis in one day. */
    const val DAY_MILLIS: Long = 24L * 60L * 60L * 1000L

    /**
     * Cutoff for analytics pruning: events with
     * `timestampMillis < cutoff` are deleted. Exactly
     * [ANALYTICS_RETENTION_DAYS] before [nowMillis].
     */
    fun analyticsCutoffMillis(nowMillis: Long): Long =
        nowMillis - ANALYTICS_RETENTION_DAYS * DAY_MILLIS

    /**
     * How many audit entries a prune would delete, given the current
     * row [count]: everything beyond the newest [AUDIT_LOG_KEEP_COUNT].
     * Zero when the table is already within the cap.
     */
    fun auditLogDeletionsFor(count: Int): Int =
        (count - AUDIT_LOG_KEEP_COUNT).coerceAtLeast(0)
}
