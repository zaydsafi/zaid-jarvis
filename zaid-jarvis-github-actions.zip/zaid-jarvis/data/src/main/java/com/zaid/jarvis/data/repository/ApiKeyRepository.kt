package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.model.LlmProvider
import com.zaid.jarvis.data.security.SecureKeyStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import javax.inject.Inject
import javax.inject.Singleton

/**
 * API keys for the LLM providers — built-in (Claude, OpenAI, Gemini,
 * OpenRouter) and user-added custom providers (Phase 3).
 *
 * - Keys are stored ONLY in [SecureKeyStore] (Keystore + EncryptedSharedPreferences).
 * - Keys are NEVER hard-coded, logged, or included in settings exports.
 * - The UI only ever learns whether a key is set, never the key itself,
 *   except while the user is typing it into the masked field.
 * - Built-in providers are keyed by provider name; custom providers by
 *   their config id (`api_key_custom_<id>`).
 */
@Singleton
class ApiKeyRepository @Inject constructor(
    private val secureKeyStore: SecureKeyStore,
) {
    private val _keyPresence = MutableStateFlow(loadPresence())

    /** Which built-in providers have a key stored (true = key present). */
    val keyPresence: Flow<Map<LlmProvider, Boolean>> = _keyPresence.asStateFlow()

    private val _customKeyPresence = MutableStateFlow(loadCustomPresence())

    /** Ids of custom providers that have a key stored. */
    val customKeyPresence: Flow<Set<String>> = _customKeyPresence.asStateFlow()

    private val _tavilyKeyPresence = MutableStateFlow(loadTavilyPresence())

    /** Whether a Tavily search API key is stored (Phase 7). */
    val tavilyKeyPresence: Flow<Boolean> = _tavilyKeyPresence.asStateFlow()

    private fun loadPresence(): Map<LlmProvider, Boolean> =
        LlmProvider.entries.associateWith { provider ->
            secureKeyStore.hasSecret(SecureKeyStore.apiKeyPreferenceKey(provider.name))
        }

    private fun loadCustomPresence(): Set<String> =
        secureKeyStore.allSecretKeys()
            .mapNotNull { key ->
                key.removePrefix("api_key_custom_").takeIf { it != key }
            }
            .toSet()

    private fun loadTavilyPresence(): Boolean =
        secureKeyStore.hasSecret(SecureKeyStore.tavilyApiKeyPreferenceKey())

    private fun refreshPresence() {
        _keyPresence.value = loadPresence()
        _customKeyPresence.value = loadCustomPresence()
        _tavilyKeyPresence.value = loadTavilyPresence()
    }

    /** Stores (or replaces) the API key for [provider]. Blank input clears it. */
    fun setApiKey(provider: LlmProvider, apiKey: String) {
        val prefKey = SecureKeyStore.apiKeyPreferenceKey(provider.name)
        setSecret(prefKey, apiKey)
        refreshPresence()
    }

    fun hasApiKey(provider: LlmProvider): Boolean =
        secureKeyStore.hasSecret(SecureKeyStore.apiKeyPreferenceKey(provider.name))

    /**
     * Returns the stored key for [provider], or null.
     * Callers must use it for exactly one request and never log or persist it.
     */
    fun getApiKey(provider: LlmProvider): String? =
        secureKeyStore.getSecret(SecureKeyStore.apiKeyPreferenceKey(provider.name))

    /** Stores (or replaces) the API key for a custom provider. Blank input clears it. */
    fun setCustomApiKey(customProviderId: String, apiKey: String) {
        val prefKey = SecureKeyStore.customApiKeyPreferenceKey(customProviderId)
        setSecret(prefKey, apiKey)
        refreshPresence()
    }

    fun hasCustomApiKey(customProviderId: String): Boolean =
        secureKeyStore.hasSecret(SecureKeyStore.customApiKeyPreferenceKey(customProviderId))

    /** Returns the stored key for a custom provider, or null. Same rules as [getApiKey]. */
    fun getCustomApiKey(customProviderId: String): String? =
        secureKeyStore.getSecret(SecureKeyStore.customApiKeyPreferenceKey(customProviderId))

    /** Clears a custom provider's key (e.g. when the provider is deleted). */
    fun clearCustomApiKey(customProviderId: String) {
        secureKeyStore.removeSecret(SecureKeyStore.customApiKeyPreferenceKey(customProviderId))
        refreshPresence()
    }

    /** Stores (or replaces) the Tavily search API key. Blank input clears it. */
    fun setTavilyApiKey(apiKey: String) {
        setSecret(SecureKeyStore.tavilyApiKeyPreferenceKey(), apiKey)
        refreshPresence()
    }

    fun hasTavilyApiKey(): Boolean =
        secureKeyStore.hasSecret(SecureKeyStore.tavilyApiKeyPreferenceKey())

    /** Returns the stored Tavily key, or null. Same rules as [getApiKey]. */
    fun getTavilyApiKey(): String? =
        secureKeyStore.getSecret(SecureKeyStore.tavilyApiKeyPreferenceKey())

    fun clearAllApiKeys() {
        secureKeyStore.allSecretKeys()
            .filter { it.startsWith(SecureKeyStore.API_KEY_PREFIX) }
            .forEach { secureKeyStore.removeSecret(it) }
        refreshPresence()
    }

    private fun setSecret(prefKey: String, apiKey: String) {
        if (apiKey.isBlank()) {
            secureKeyStore.removeSecret(prefKey)
        } else {
            secureKeyStore.putSecret(prefKey, apiKey.trim())
        }
    }
}
