package com.zaid.jarvis.data.db

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * Audit-log entry (Master Prompt §6), persisted in the encrypted Room DB.
 * One row per tool-call request: time, tool, parameters, approval, result.
 *
 * `tier` and `decision` are stored as enum names (see
 * [com.zaid.jarvis.core.confirmation.RiskTier] and
 * [com.zaid.jarvis.core.confirmation.AuditDecision]).
 */
@Entity(tableName = "audit_log_entries")
data class AuditLogEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampMillis: Long,
    val toolName: String,
    val tier: String,
    val action: String,
    val target: String,
    val paramsSummary: String,
    val decision: String,
    val resultSummary: String?,
    val undoable: Boolean,
    val undoDescription: String?,
    /** Phase 5: JSON payload the tool needs to reverse this action. */
    val undoData: String?,
    val undone: Boolean,
)

@Dao
interface AuditLogDao {
    /**
     * The most recent entries, newest first — capped ([ListLimits.AUDIT_LOG_LIST])
     * so the Audit Log screen never loads the whole table. Older entries
     * still exist (until the retention prune) and are reachable via [search].
     */
    @Query("SELECT * FROM audit_log_entries ORDER BY timestampMillis DESC LIMIT :limit")
    fun observeAll(limit: Int): Flow<List<AuditLogEntryEntity>>

    /**
     * All entries (used by backup export). Deliberately uncapped —
     * backup must see the whole table — but bounded in practice by
     * the retention policy ([RetentionPolicy.AUDIT_LOG_KEEP_COUNT]).
     */
    @Query("SELECT * FROM audit_log_entries ORDER BY timestampMillis DESC")
    suspend fun getAll(): List<AuditLogEntryEntity>

    /** All row ids (used by backup merge planning — cheaper than loading full rows). */
    @Query("SELECT id FROM audit_log_entries")
    suspend fun getAllIds(): List<Long>

    /** Search results, newest first — capped ([ListLimits.AUDIT_LOG_SEARCH]). */
    @Query(
        "SELECT * FROM audit_log_entries WHERE " +
            "toolName LIKE '%' || :query || '%' OR " +
            "action LIKE '%' || :query || '%' OR " +
            "target LIKE '%' || :query || '%' OR " +
            "paramsSummary LIKE '%' || :query || '%' OR " +
            "decision LIKE '%' || :query || '%' " +
            "ORDER BY timestampMillis DESC LIMIT :limit",
    )
    suspend fun search(query: String, limit: Int): List<AuditLogEntryEntity>

    @Query("SELECT * FROM audit_log_entries WHERE id = :id")
    suspend fun getById(id: Long): AuditLogEntryEntity?

    @Query("SELECT COUNT(*) FROM audit_log_entries")
    suspend fun count(): Int

    /**
     * Retention prune: deletes everything except the newest [keepCount]
     * entries (by time, then id — the tie-break keeps the choice
     * deterministic when several rows share a timestamp). Returns the
     * number of rows deleted.
     */
    @Query(
        "DELETE FROM audit_log_entries WHERE id NOT IN " +
            "(SELECT id FROM audit_log_entries ORDER BY timestampMillis DESC, id DESC LIMIT :keepCount)",
    )
    suspend fun deleteBeyondNewest(keepCount: Int): Int

    @Insert
    suspend fun insert(entry: AuditLogEntryEntity): Long

    @Query("DELETE FROM audit_log_entries WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM audit_log_entries")
    suspend fun deleteAll()

    @Query("UPDATE audit_log_entries SET undone = 1 WHERE id = :id")
    suspend fun markUndone(id: Long)
}
