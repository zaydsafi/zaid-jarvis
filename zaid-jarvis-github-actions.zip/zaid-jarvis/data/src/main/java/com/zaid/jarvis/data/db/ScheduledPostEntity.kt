package com.zaid.jarvis.data.db

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * A scheduled post (Phase 8): a draft Jarvis will publish at a future
 * time via WorkManager.
 *
 * The [contentHash] is the SHA-256 of the draft body at schedule time —
 * the worker compares it with the current body and CANCELS the post
 * instead of publishing stale content. [workRequestId] is the
 * WorkManager job id, so cancelling the row also cancels the job.
 *
 * Status is stored as the [ScheduledPostStatus] enum name. An unknown
 * status string read back from the database maps to CANCELLED
 * (fail-safe: an unreadable scheduled post must never run).
 */
@Entity(tableName = "scheduled_posts")
data class ScheduledPostEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val draftId: Long,
    /** SocialPlatform name ("X", "THREADS", "LINKEDIN", "INSTAGRAM"). */
    val platform: String,
    /** Handle the post will publish as (display only). */
    val accountHandle: String,
    val scheduledAtMillis: Long,
    /** SHA-256 hex of the draft body at schedule time. */
    val contentHash: String,
    /** Public image URL for the post (Instagram only, null otherwise). */
    val imageUrl: String? = null,
    /** ScheduledPostStatus name. */
    val status: String,
    /** Why a post failed or was cancelled (null otherwise). */
    val failureReason: String? = null,
    /** Public URL of the published post (on success). */
    val postUrl: String? = null,
    /** WorkManager one-time work request id (UUID string), null until enqueued. */
    val workRequestId: String? = null,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
)

@Dao
interface ScheduledPostDao {
    /**
     * The most recently scheduled posts — capped ([ListLimits.SCHEDULED_POST_LIST])
     * so the Scheduled posts screen never loads the whole table.
     */
    @Query("SELECT * FROM scheduled_posts ORDER BY scheduledAtMillis DESC LIMIT :limit")
    fun observeAll(limit: Int): Flow<List<ScheduledPostEntity>>

    /**
     * All scheduled posts. Deliberately uncapped — backup export must
     * see the whole table. UI and tools read through the capped query
     * or the repository's bulk cap instead.
     */
    @Query("SELECT * FROM scheduled_posts ORDER BY scheduledAtMillis DESC")
    suspend fun getAll(): List<ScheduledPostEntity>

    /** All row ids (used by backup merge planning — cheaper than loading full rows). */
    @Query("SELECT id FROM scheduled_posts")
    suspend fun getAllIds(): List<Long>

    @Query("SELECT * FROM scheduled_posts WHERE id = :id")
    suspend fun getById(id: Long): ScheduledPostEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ScheduledPostEntity): Long

    @Query("DELETE FROM scheduled_posts WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM scheduled_posts")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM scheduled_posts")
    suspend fun count(): Int
}
