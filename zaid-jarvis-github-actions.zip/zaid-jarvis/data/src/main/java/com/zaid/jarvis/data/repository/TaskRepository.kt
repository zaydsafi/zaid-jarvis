package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.productivity.Task
import com.zaid.jarvis.core.productivity.TaskPriority
import com.zaid.jarvis.core.productivity.TaskStatus
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.db.ListLimits
import com.zaid.jarvis.data.db.TaskDao
import com.zaid.jarvis.data.db.TaskEntity
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Tasks (Phase 9): the Room side of the productivity core. The
 * WorkManager side (reminders) lives in :app
 * (WorkManagerReminderScheduler); the planner tools in :tools program
 * against the TaskStore interface, which :app adapts to this
 * repository (RoomTaskStore).
 *
 * Fail-safe mapping: an unknown priority string maps to MEDIUM and an
 * unknown status string maps to OPEN — a task is never lost because
 * of an unreadable field.
 *
 * Lists are capped ([ListLimits]): the screen observes the most recent
 * 2,000 tasks, and the filtered reads (open / overdue / due today) run
 * in SQL so the 15-minute proactive worker and the Home "Today" card
 * never load the whole table.
 */
@Singleton
class TaskRepository @Inject constructor(
    private val dao: TaskDao,
) {
    fun observeAll(): Flow<List<Task>> =
        dao.observeAll(ListLimits.TASK_LIST).map { rows -> rows.map { it.toModel() } }

    /**
     * All tasks — capped ([ListLimits.TASK_BULK]) as a safety valve for
     * the Insights screen, the briefing, and the planner tools. Backup
     * export reads the DAO directly and is not capped.
     */
    suspend fun getAll(): List<Task> = dao.getAll().take(ListLimits.TASK_BULK).map { it.toModel() }

    suspend fun getById(id: Long): Task? = dao.getById(id)?.toModel()

    /** Open tasks, earliest due first (undated last). Filtered in SQL. */
    suspend fun getOpen(): List<Task> =
        dao.getOpen(ListLimits.TASK_FILTERED).map { it.toModel() }

    /** Open tasks whose due time has passed. Filtered in SQL. */
    suspend fun getOverdue(nowMillis: Long): List<Task> =
        dao.getOverdue(nowMillis, ListLimits.TASK_FILTERED).map { it.toModel() }

    /**
     * Open tasks due today (device zone). The day boundaries are
     * computed here (same rule as [Task.isDueToday]) and the filter
     * runs in SQL.
     */
    suspend fun getDueToday(nowMillis: Long): List<Task> {
        val zone = ZoneId.systemDefault()
        val today = LocalDate.ofInstant(Instant.ofEpochMilli(nowMillis), zone)
        val start = today.atStartOfDay(zone).toInstant().toEpochMilli()
        val end = today.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        return dao.getDueBetween(start, end, ListLimits.TASK_FILTERED).map { it.toModel() }
    }

    /** Inserts or replaces a task; returns the row id. */
    suspend fun save(task: Task): JarvisResult<Long> {
        if (task.title.isBlank()) {
            return JarvisResult.Failure("A task needs a title.")
        }
        val now = System.currentTimeMillis()
        val entity = TaskEntity(
            id = task.id,
            title = task.title.trim(),
            notes = task.notes,
            dueAtMillis = task.dueAtMillis,
            priority = task.priority.name,
            status = task.status.name,
            reminderAtMillis = task.reminderAtMillis,
            reminderWorkId = task.reminderWorkId,
            overdueNotifiedDay = task.overdueNotifiedDay,
            createdAtMillis = if (task.createdAtMillis == 0L) now else task.createdAtMillis,
            updatedAtMillis = now,
        )
        return JarvisResult.Success(dao.upsert(entity))
    }

    /** Marks a task DONE. Fails when the task does not exist. */
    suspend fun complete(id: Long): JarvisResult<Task> {
        val current = dao.getById(id)
            ?: return JarvisResult.Failure("No task with id $id.")
        val updated = current.copy(
            status = TaskStatus.DONE.name,
            updatedAtMillis = System.currentTimeMillis(),
        )
        dao.upsert(updated)
        return JarvisResult.Success(updated.toModel())
    }

    /** Records that an overdue nudge was sent today (dedupe key). */
    suspend fun markOverdueNotified(id: Long, epochDay: Long) {
        val current = dao.getById(id) ?: return
        dao.upsert(current.copy(overdueNotifiedDay = epochDay))
    }

    /** Attaches a reminder time + its WorkManager job id to a task. */
    suspend fun setReminder(id: Long, reminderAtMillis: Long, workId: String?): JarvisResult<Task> {
        val current = dao.getById(id)
            ?: return JarvisResult.Failure("No task with id $id.")
        val updated = current.copy(
            reminderAtMillis = reminderAtMillis,
            reminderWorkId = workId,
            updatedAtMillis = System.currentTimeMillis(),
        )
        dao.upsert(updated)
        return JarvisResult.Success(updated.toModel())
    }

    /** Removes a task's reminder (the caller cancels the WorkManager job). */
    suspend fun clearReminder(id: Long) {
        val current = dao.getById(id) ?: return
        dao.upsert(
            current.copy(
                reminderAtMillis = null,
                reminderWorkId = null,
                updatedAtMillis = System.currentTimeMillis(),
            ),
        )
    }

    suspend fun deleteById(id: Long) = dao.deleteById(id)

    suspend fun deleteAll() = dao.deleteAll()

    suspend fun count(): Int = dao.count()

    private fun TaskEntity.toModel(): Task {
        val priority = runCatching { TaskPriority.valueOf(priority) }
            .getOrDefault(TaskPriority.MEDIUM)
        val status = runCatching { TaskStatus.valueOf(status) }
            .getOrDefault(TaskStatus.OPEN)
        return Task(
            id = id,
            title = title,
            notes = notes,
            dueAtMillis = dueAtMillis,
            priority = priority,
            status = status,
            reminderAtMillis = reminderAtMillis,
            reminderWorkId = reminderWorkId,
            overdueNotifiedDay = overdueNotifiedDay,
            createdAtMillis = createdAtMillis,
            updatedAtMillis = updatedAtMillis,
        )
    }
}
