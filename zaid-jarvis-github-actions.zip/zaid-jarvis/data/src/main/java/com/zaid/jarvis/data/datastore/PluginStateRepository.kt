package com.zaid.jarvis.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.zaid.jarvis.plugins.PluginState
import com.zaid.jarvis.plugins.PluginStateStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.pluginStateDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "jarvis_plugin_state",
)

/**
 * DataStore-backed plugin state (Phase 10): which plugins are enabled
 * and which are trusted. Stored as two string sets (disabled ids,
 * trusted ids) — a plugin with no stored state is enabled and
 * untrusted, which are the defaults.
 */
@Singleton
class PluginStateRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) : PluginStateStore {

    override suspend fun state(pluginId: String): PluginState {
        val prefs = context.pluginStateDataStore.data.first()
        return PluginState(
            enabled = pluginId !in (prefs[KEY_DISABLED] ?: emptySet()),
            trusted = pluginId in (prefs[KEY_TRUSTED] ?: emptySet()),
        )
    }

    override suspend fun setEnabled(pluginId: String, enabled: Boolean) {
        context.pluginStateDataStore.edit { prefs ->
            val disabled = (prefs[KEY_DISABLED] ?: emptySet()).toMutableSet()
            if (enabled) disabled.remove(pluginId) else disabled.add(pluginId)
            prefs[KEY_DISABLED] = disabled
        }
    }

    override suspend fun setTrusted(pluginId: String, trusted: Boolean) {
        context.pluginStateDataStore.edit { prefs ->
            val trustedIds = (prefs[KEY_TRUSTED] ?: emptySet()).toMutableSet()
            if (trusted) trustedIds.add(pluginId) else trustedIds.remove(pluginId)
            prefs[KEY_TRUSTED] = trustedIds
        }
    }

    override fun observeStates(): Flow<Map<String, PluginState>> =
        context.pluginStateDataStore.data.map { prefs ->
            val disabled = prefs[KEY_DISABLED] ?: emptySet()
            val trusted = prefs[KEY_TRUSTED] ?: emptySet()
            (disabled + trusted).associateWith { pluginId ->
                PluginState(
                    enabled = pluginId !in disabled,
                    trusted = pluginId in trusted,
                )
            }
        }

    /**
     * Deletes all plugin state (delete-all-data, Phase 11). Every
     * plugin returns to its default: enabled and untrusted.
     */
    suspend fun clear() {
        context.pluginStateDataStore.edit { prefs -> prefs.clear() }
    }

    private companion object {
        val KEY_DISABLED = stringSetPreferencesKey("disabled_plugin_ids")
        val KEY_TRUSTED = stringSetPreferencesKey("trusted_plugin_ids")
    }
}
