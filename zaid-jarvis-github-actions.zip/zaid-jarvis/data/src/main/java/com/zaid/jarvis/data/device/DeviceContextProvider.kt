package com.zaid.jarvis.data.device

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import com.zaid.jarvis.core.model.ContextSnapshot
import dagger.hilt.android.qualifiers.ApplicationContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/**
 * On-device context for the planner (Master Prompt §4: "context providers
 * (opt-in)"). Phase 3 wires time, battery, and network state only.
 * Calendar, location, foreground app, and notification digest arrive in
 * later phases, each behind its own opt-in.
 *
 * Nothing here leaves the device except as part of the short context block
 * in the LLM system prompt — and only the fields the planner includes.
 */
@Singleton
class DeviceContextProvider @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    /** Current context snapshot for the planner's system prompt. */
    fun snapshot(): ContextSnapshot {
        val batteryStatus = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val percent = if (level >= 0 && scale > 0) (level * 100 / scale) else null
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        return ContextSnapshot(
            localDateTime = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("EEE yyyy-MM-dd HH:mm", Locale.ENGLISH)),
            batteryPercent = percent,
            isCharging = charging,
            isOnline = isOnline(),
        )
    }

    /** True when the device has a network with internet capability. */
    fun isOnline(): Boolean {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = manager.activeNetwork ?: return false
        val capabilities = manager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /**
     * The active network's transport type (Phase 5, for get_network):
     * "Wi-Fi", "Mobile", "Ethernet", "VPN", or "None".
     */
    fun networkType(): String {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return "None"
        val network = manager.activeNetwork ?: return "None"
        val capabilities = manager.getNetworkCapabilities(network) ?: return "None"
        return when {
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Other"
        }
    }
}
