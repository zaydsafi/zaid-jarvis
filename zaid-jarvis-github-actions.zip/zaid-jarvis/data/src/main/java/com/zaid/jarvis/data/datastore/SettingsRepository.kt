package com.zaid.jarvis.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.zaid.jarvis.core.model.AppLanguage
import com.zaid.jarvis.core.model.CustomProviderConfig
import com.zaid.jarvis.core.model.JarvisSettings
import com.zaid.jarvis.core.model.LlmModel
import com.zaid.jarvis.core.model.LlmProvider
import com.zaid.jarvis.core.model.Personality
import com.zaid.jarvis.core.model.ThemeMode
import com.zaid.jarvis.core.research.SearchBackend
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "jarvis_settings",
)

/**
 * Persists [JarvisSettings] in DataStore Preferences.
 * API keys are NOT stored here — see ApiKeyRepository.
 *
 * Custom providers (Phase 3) are stored as one JSON string; their API keys
 * stay in Keystore-backed storage, never in DataStore.
 */
@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val json = Json { ignoreUnknownKeys = true }

    val settings: Flow<JarvisSettings> = context.settingsDataStore.data.map { prefs ->
        readSettings(prefs)
    }

    private fun readSettings(prefs: Preferences): JarvisSettings {
        val defaults = JarvisSettings()
        return JarvisSettings(
            themeMode = prefs[KEY_THEME]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() }
                ?: defaults.themeMode,
            language = prefs[KEY_LANGUAGE]?.let { runCatching { AppLanguage.valueOf(it) }.getOrNull() }
                ?: defaults.language,
            voiceSpeed = prefs[KEY_VOICE_SPEED] ?: defaults.voiceSpeed,
            personality = prefs[KEY_PERSONALITY]?.let { runCatching { Personality.valueOf(it) }.getOrNull() }
                ?: defaults.personality,
            llmProvider = prefs[KEY_PROVIDER]?.let { runCatching { LlmProvider.valueOf(it) }.getOrNull() }
                ?: defaults.llmProvider,
            llmModel = prefs[KEY_MODEL]?.let { runCatching { LlmModel.valueOf(it) }.getOrNull() }
                ?: defaults.llmModel,
            customModelId = prefs[KEY_CUSTOM_MODEL_ID] ?: "",
            customProviders = prefs[KEY_CUSTOM_PROVIDERS]?.let { raw ->
                runCatching { json.decodeFromString(ListSerializer(CustomProviderConfig.serializer()), raw) }
                    .getOrDefault(emptyList())
            } ?: emptyList(),
            selectedCustomProviderId = prefs[KEY_SELECTED_CUSTOM_PROVIDER],
            useCheapModelForSimpleIntents =
                prefs[KEY_CHEAP_MODEL] ?: defaults.useCheapModelForSimpleIntents,
            alwaysAskReadOnly =
                prefs[KEY_ALWAYS_ASK_READ_ONLY] ?: defaults.alwaysAskReadOnly,
            wakeWordEnabled =
                prefs[KEY_WAKE_WORD] ?: defaults.wakeWordEnabled,
            voiceRepliesEnabled =
                prefs[KEY_VOICE_REPLIES] ?: defaults.voiceRepliesEnabled,
            floatingBubbleEnabled =
                prefs[KEY_FLOATING_BUBBLE] ?: defaults.floatingBubbleEnabled,
            automationEnabled =
                prefs[KEY_AUTOMATION] ?: defaults.automationEnabled,
            searchBackend = prefs[KEY_SEARCH_BACKEND]?.let {
                runCatching { SearchBackend.valueOf(it) }.getOrNull()
            } ?: defaults.searchBackend,
            maxSearchResults =
                (prefs[KEY_MAX_SEARCH_RESULTS] ?: defaults.maxSearchResults)
                    .coerceIn(1, 10),
            dailyDigestEnabled =
                prefs[KEY_DAILY_DIGEST] ?: defaults.dailyDigestEnabled,
            dailyDigestHour =
                (prefs[KEY_DAILY_DIGEST_HOUR] ?: defaults.dailyDigestHour).coerceIn(0, 23),
            dailyDigestMinute =
                (prefs[KEY_DAILY_DIGEST_MINUTE] ?: defaults.dailyDigestMinute).coerceIn(0, 59),
            quietHoursStartMinute =
                (prefs[KEY_QUIET_START] ?: defaults.quietHoursStartMinute).coerceIn(0, 1439),
            quietHoursEndMinute =
                (prefs[KEY_QUIET_END] ?: defaults.quietHoursEndMinute).coerceIn(0, 1439),
            overdueRemindersEnabled =
                prefs[KEY_OVERDUE_REMINDERS] ?: defaults.overdueRemindersEnabled,
            breakRemindersEnabled =
                prefs[KEY_BREAK_REMINDERS] ?: defaults.breakRemindersEnabled,
            breakReminderIntervalMinutes =
                (prefs[KEY_BREAK_INTERVAL] ?: defaults.breakReminderIntervalMinutes)
                    .coerceIn(15, 240),
            windDownEnabled =
                prefs[KEY_WIND_DOWN] ?: defaults.windDownEnabled,
            windDownHour =
                (prefs[KEY_WIND_DOWN_HOUR] ?: defaults.windDownHour).coerceIn(0, 23),
            windDownMinute =
                (prefs[KEY_WIND_DOWN_MINUTE] ?: defaults.windDownMinute).coerceIn(0, 59),
            analyticsEnabled =
                prefs[KEY_ANALYTICS] ?: defaults.analyticsEnabled,
            autoBackupEnabled =
                prefs[KEY_AUTO_BACKUP] ?: defaults.autoBackupEnabled,
            totalTokensUsed = prefs[KEY_TOKENS] ?: 0L,
            estimatedCostUsd = prefs[KEY_COST] ?: 0.0,
        )
    }

    suspend fun updateSettings(transform: (JarvisSettings) -> JarvisSettings) {
        // Read-modify-write through a single edit; the Flow above re-emits.
        context.settingsDataStore.edit { prefs ->
            val updated = transform(readSettings(prefs))
            prefs[KEY_THEME] = updated.themeMode.name
            prefs[KEY_LANGUAGE] = updated.language.name
            prefs[KEY_VOICE_SPEED] = updated.voiceSpeed
            prefs[KEY_PERSONALITY] = updated.personality.name
            prefs[KEY_PROVIDER] = updated.llmProvider.name
            prefs[KEY_MODEL] = updated.llmModel.name
            prefs[KEY_CUSTOM_MODEL_ID] = updated.customModelId
            prefs[KEY_CUSTOM_PROVIDERS] = json.encodeToString(
                ListSerializer(CustomProviderConfig.serializer()),
                updated.customProviders,
            )
            val selectedCustomProviderId = updated.selectedCustomProviderId
            if (selectedCustomProviderId == null) {
                prefs.remove(KEY_SELECTED_CUSTOM_PROVIDER)
            } else {
                prefs[KEY_SELECTED_CUSTOM_PROVIDER] = selectedCustomProviderId
            }
            prefs[KEY_CHEAP_MODEL] = updated.useCheapModelForSimpleIntents
            prefs[KEY_ALWAYS_ASK_READ_ONLY] = updated.alwaysAskReadOnly
            prefs[KEY_WAKE_WORD] = updated.wakeWordEnabled
            prefs[KEY_VOICE_REPLIES] = updated.voiceRepliesEnabled
            prefs[KEY_FLOATING_BUBBLE] = updated.floatingBubbleEnabled
            prefs[KEY_AUTOMATION] = updated.automationEnabled
            prefs[KEY_SEARCH_BACKEND] = updated.searchBackend.name
            prefs[KEY_MAX_SEARCH_RESULTS] = updated.maxSearchResults.coerceIn(1, 10)
            prefs[KEY_DAILY_DIGEST] = updated.dailyDigestEnabled
            prefs[KEY_DAILY_DIGEST_HOUR] = updated.dailyDigestHour.coerceIn(0, 23)
            prefs[KEY_DAILY_DIGEST_MINUTE] = updated.dailyDigestMinute.coerceIn(0, 59)
            prefs[KEY_QUIET_START] = updated.quietHoursStartMinute.coerceIn(0, 1439)
            prefs[KEY_QUIET_END] = updated.quietHoursEndMinute.coerceIn(0, 1439)
            prefs[KEY_OVERDUE_REMINDERS] = updated.overdueRemindersEnabled
            prefs[KEY_BREAK_REMINDERS] = updated.breakRemindersEnabled
            prefs[KEY_BREAK_INTERVAL] = updated.breakReminderIntervalMinutes.coerceIn(15, 240)
            prefs[KEY_WIND_DOWN] = updated.windDownEnabled
            prefs[KEY_WIND_DOWN_HOUR] = updated.windDownHour.coerceIn(0, 23)
            prefs[KEY_WIND_DOWN_MINUTE] = updated.windDownMinute.coerceIn(0, 59)
            prefs[KEY_ANALYTICS] = updated.analyticsEnabled
            prefs[KEY_AUTO_BACKUP] = updated.autoBackupEnabled
            prefs[KEY_TOKENS] = updated.totalTokensUsed
            prefs[KEY_COST] = updated.estimatedCostUsd
        }
    }

    /** Adds real usage once the agent reports it (Phase 3). Placeholder in Phase 1. */
    suspend fun recordUsage(tokens: Long, costUsd: Double) {
        context.settingsDataStore.edit { prefs ->
            prefs[KEY_TOKENS] = (prefs[KEY_TOKENS] ?: 0L) + tokens
            prefs[KEY_COST] = (prefs[KEY_COST] ?: 0.0) + costUsd
        }
    }

    /**
     * Deletes every stored setting (delete-all-data, Phase 11).
     * The settings Flow then emits plain defaults — a fresh-install
     * state as far as settings are concerned.
     */
    suspend fun clearAll() {
        context.settingsDataStore.edit { prefs -> prefs.clear() }
    }

    private companion object {
        val KEY_THEME = stringPreferencesKey("theme_mode")
        val KEY_LANGUAGE = stringPreferencesKey("language")
        val KEY_VOICE_SPEED = floatPreferencesKey("voice_speed")
        val KEY_PERSONALITY = stringPreferencesKey("personality")
        val KEY_PROVIDER = stringPreferencesKey("llm_provider")
        val KEY_MODEL = stringPreferencesKey("llm_model")
        val KEY_CUSTOM_MODEL_ID = stringPreferencesKey("custom_model_id")
        val KEY_CUSTOM_PROVIDERS = stringPreferencesKey("custom_providers_json")
        val KEY_SELECTED_CUSTOM_PROVIDER = stringPreferencesKey("selected_custom_provider_id")
        val KEY_CHEAP_MODEL = booleanPreferencesKey("use_cheap_model")
        val KEY_ALWAYS_ASK_READ_ONLY = booleanPreferencesKey("always_ask_read_only")
        val KEY_WAKE_WORD = booleanPreferencesKey("wake_word_enabled")
        val KEY_VOICE_REPLIES = booleanPreferencesKey("voice_replies_enabled")
        val KEY_FLOATING_BUBBLE = booleanPreferencesKey("floating_bubble_enabled")
        val KEY_AUTOMATION = booleanPreferencesKey("automation_enabled")
        val KEY_SEARCH_BACKEND = stringPreferencesKey("search_backend")
        val KEY_MAX_SEARCH_RESULTS = intPreferencesKey("max_search_results")
        val KEY_DAILY_DIGEST = booleanPreferencesKey("daily_digest_enabled")
        val KEY_DAILY_DIGEST_HOUR = intPreferencesKey("daily_digest_hour")
        val KEY_DAILY_DIGEST_MINUTE = intPreferencesKey("daily_digest_minute")
        val KEY_QUIET_START = intPreferencesKey("quiet_hours_start_minute")
        val KEY_QUIET_END = intPreferencesKey("quiet_hours_end_minute")
        val KEY_OVERDUE_REMINDERS = booleanPreferencesKey("overdue_reminders_enabled")
        val KEY_BREAK_REMINDERS = booleanPreferencesKey("break_reminders_enabled")
        val KEY_BREAK_INTERVAL = intPreferencesKey("break_reminder_interval_minutes")
        val KEY_WIND_DOWN = booleanPreferencesKey("wind_down_enabled")
        val KEY_WIND_DOWN_HOUR = intPreferencesKey("wind_down_hour")
        val KEY_WIND_DOWN_MINUTE = intPreferencesKey("wind_down_minute")
        val KEY_ANALYTICS = booleanPreferencesKey("analytics_enabled")
        val KEY_AUTO_BACKUP = booleanPreferencesKey("auto_backup_enabled")
        val KEY_TOKENS = longPreferencesKey("total_tokens_used")
        val KEY_COST = doublePreferencesKey("estimated_cost_usd")
    }
}
