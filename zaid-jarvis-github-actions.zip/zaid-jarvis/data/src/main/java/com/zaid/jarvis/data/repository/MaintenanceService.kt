package com.zaid.jarvis.data.repository

import com.zaid.jarvis.data.db.RetentionPolicy
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The analytics side of retention pruning, behind an interface so
 * [MaintenanceService] is unit-testable with fakes. Implemented by
 * [AnalyticsRepository].
 */
interface AnalyticsPruner {
    /** Deletes events older than [cutoffMillis]. Returns the rows deleted. */
    suspend fun pruneOlderThan(cutoffMillis: Long): Int
}

/**
 * The audit-log side of retention pruning, behind an interface so
 * [MaintenanceService] is unit-testable with fakes. Implemented by
 * [RoomAuditLog].
 */
interface AuditLogPruner {
    /** Deletes everything except the newest [keepCount] entries. Returns the rows deleted. */
    suspend fun pruneToNewest(keepCount: Int): Int

    /** Current row count (for the maintenance report). */
    suspend fun count(): Int
}

/**
 * Data maintenance (Phase 11 hardening): enforces the retention
 * policy ([RetentionPolicy]) — analytics events older than 90 days
 * are pruned, and the audit log is trimmed to its most recent 10,000
 * entries. Run weekly by the [com.zaid.jarvis.backup.MaintenanceWorker].
 *
 * What is NOT pruned here, deliberately:
 * - Everything Zaid created by hand (tasks, notes, macros, drafts,
 *   research, memory, scheduled posts, focus history) is never
 *   deleted automatically — only Zaid deletes those.
 * - Approvals are in-memory only (see
 *   `ConfirmationEngine`: the pending request, the awaiting map, and
 *   the consumed-ids set all live in the process and die with it).
 *   Expiry is checked at use, so there is nothing persisted to prune
 *   — no maintenance step exists for approvals.
 *
 * Pruning is best-effort: each step runs even if the other fails, and
 * the report says what happened. A failed prune is retried next week —
 * the tables only grow by one week of rows in the meantime.
 */
@Singleton
class MaintenanceService @Inject constructor(
    private val analyticsPruner: AnalyticsPruner,
    private val auditLogPruner: AuditLogPruner,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    /** What one maintenance run did. */
    data class MaintenanceReport(
        val analyticsDeleted: Int,
        val auditDeleted: Int,
        val auditRemaining: Int,
        /** Step names that failed (empty when everything worked). */
        val failures: List<String> = emptyList(),
    )

    /** Runs both prunes and returns what happened. Never throws. */
    suspend fun prune(nowMillis: Long = clock()): MaintenanceReport {
        var analyticsDeleted = 0
        var auditDeleted = 0
        val failures = mutableListOf<String>()
        runCatching {
            analyticsDeleted = analyticsPruner.pruneOlderThan(
                RetentionPolicy.analyticsCutoffMillis(nowMillis),
            )
        }.onFailure { failures += "analytics" }
        runCatching {
            auditDeleted = auditLogPruner.pruneToNewest(RetentionPolicy.AUDIT_LOG_KEEP_COUNT)
        }.onFailure { failures += "audit log" }
        val remaining = runCatching { auditLogPruner.count() }.getOrDefault(-1)
        return MaintenanceReport(
            analyticsDeleted = analyticsDeleted,
            auditDeleted = auditDeleted,
            auditRemaining = remaining,
            failures = failures,
        )
    }
}
