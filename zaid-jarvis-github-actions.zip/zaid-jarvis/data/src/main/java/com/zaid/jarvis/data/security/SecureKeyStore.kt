package com.zaid.jarvis.data.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import java.security.SecureRandom
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Keystore-backed encrypted storage for secrets.
 *
 * - Master key lives in the Android Keystore (AES256_GCM).
 * - Values are encrypted with EncryptedSharedPreferences (AES256_GCM for
 *   values, AES256_SIV for keys).
 * - No secret is ever written to plain storage, code, or logs.
 *
 * Two kinds of secret live here:
 * 1. LLM API keys (one per provider), entered by Zaid in Settings.
 * 2. The Room database passphrase (random, generated once on first run).
 */
@Singleton
class SecureKeyStore @Inject constructor(
    @ApplicationContext context: Context,
) {
    private val prefs: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            FILE_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    fun putSecret(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }

    fun getSecret(key: String): String? = prefs.getString(key, null)

    fun hasSecret(key: String): Boolean = prefs.contains(key)

    /** All stored secret keys (used to enumerate custom-provider keys). */
    fun allSecretKeys(): Set<String> = prefs.all.keys.toSet()

    fun removeSecret(key: String) {
        prefs.edit().remove(key).apply()
    }

    /** Deletes every stored secret (Settings → Privacy → Delete all). */
    fun deleteAllSecrets() {
        prefs.edit().clear().apply()
    }

    /**
     * Returns the Room database passphrase, generating and storing a random
     * one on first use. The passphrase never leaves encrypted storage.
     */
    fun getOrCreateDatabasePassphrase(): String {
        getSecret(KEY_DB_PASSPHRASE)?.let { return it }
        val bytes = ByteArray(32)
        SecureRandom().nextBytes(bytes)
        val passphrase = bytes.joinToString("") { "%02x".format(it) }
        putSecret(KEY_DB_PASSPHRASE, passphrase)
        return passphrase
    }

    companion object {
        private const val FILE_NAME = "zaid_jarvis_secrets"
        private const val KEY_DB_PASSPHRASE = "db_passphrase"

        /** Preference key for a provider's API key. */
        fun apiKeyPreferenceKey(providerName: String): String = "api_key_$providerName"

        /**
         * Preference key for a custom provider's API key.
         * [customProviderId] is the [CustomProviderConfig.id] (a UUID).
         */
        fun customApiKeyPreferenceKey(customProviderId: String): String =
            "api_key_custom_$customProviderId"

        /** Preference key for the Tavily search API key (Phase 7). */
        fun tavilyApiKeyPreferenceKey(): String = "api_key_tavily"

        /** Prefix shared by every stored API key (used when clearing all). */
        const val API_KEY_PREFIX: String = "api_key_"

        // ── Social publishing secrets (Phase 8) ──────────────────────
        // OAuth client credentials and tokens, one set per platform.
        // Stored under the "social_" prefix so "Delete all secrets"
        // can clear them together with the API keys. Tokens are never
        // stored in Room or DataStore, and never logged.

        /** Prefix shared by every stored social secret. */
        const val SOCIAL_SECRET_PREFIX: String = "social_"

        /** Preference key for a platform's OAuth client id. */
        fun socialClientIdKey(platformName: String): String = "social_${platformName}_client_id"

        /** Preference key for a platform's OAuth client secret. */
        fun socialClientSecretKey(platformName: String): String =
            "social_${platformName}_client_secret"

        /** Preference key for a platform's OAuth access token. */
        fun socialAccessTokenKey(platformName: String): String =
            "social_${platformName}_access_token"

        /** Preference key for a platform's OAuth refresh token. */
        fun socialRefreshTokenKey(platformName: String): String =
            "social_${platformName}_refresh_token"

        /** Preference key for a platform's token expiry (epoch millis, stored as a string). */
        fun socialTokenExpiryKey(platformName: String): String =
            "social_${platformName}_token_expiry"
    }
}
