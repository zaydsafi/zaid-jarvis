package com.zaid.jarvis.data.repository

import android.content.Context
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.db.JarvisDatabase
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Wipes the Room database itself (delete-all-data, Phase 11): empties
 * every table, closes the database, drops the cached singleton, and
 * deletes the database file and its sidecars. After this, the next
 * [JarvisDatabase.getInstance] builds a fresh, empty database.
 *
 * This runs BEFORE the Keystore passphrase is deleted (see
 * [DataWipeService]): if the passphrase went first and the app died
 * before the file was deleted, the next launch would generate a new
 * passphrase and fail to open the old, undecryptable file.
 */
class RoomDatabaseWipe(
    private val database: JarvisDatabase,
    @ApplicationContext private val context: Context,
) {
    suspend fun wipe() {
        withContext(Dispatchers.IO) {
            // Belt and braces: empty the tables first so a failure to
            // delete the file still leaves no rows behind.
            runCatching { database.clearAllTables() }
            runCatching { database.close() }
            JarvisDatabase.clearInstance()
            deleteDatabaseFiles()
        }
    }

    private fun deleteDatabaseFiles() {
        val base = context.getDatabasePath(JarvisDatabase.DATABASE_NAME)
        listOf("", "-wal", "-shm", "-journal").forEach { suffix ->
            runCatching { File(base.path + suffix).delete() }
        }
    }
}

/**
 * Wipes Jarvis's files (delete-all-data, Phase 11): the automatic
 * local backups and the cache directory. Implemented in :app
 * ([com.zaid.jarvis.backup.AppFileWipe]), where the auto-backup
 * location lives — :data only knows the interface.
 */
interface FileWipe {
    fun wipe()
}

/**
 * Delete-all-data coordinator (Phase 11 hardening): wipes every store
 * Jarvis owns — the Room database (tasks, notes, macros, drafts,
 * research, memory, scheduled posts, focus history, audit log,
 * analytics events), every DataStore file (settings, proactive state,
 * plugin state, trusted actions, last answer, social accounts),
 * Keystore-backed secrets (API keys, OAuth tokens and client
 * credentials, the database passphrase), and Jarvis's files (automatic
 * backups, cache).
 *
 * The coordinator takes ordered [WipeStep]s — one per store — so each
 * store's clear is individually unit-testable with fakes (see
 * DataWipeServiceTest) and the production wiring (AppModule) is the
 * one place that lists what "all data" means. The order matters and
 * is part of the contract:
 * 1. The database file goes first, while the passphrase still exists.
 * 2. DataStore files next (cleared through DataStore, never by
 *    deleting the files — DataStore holds them open).
 * 3. Secrets last: deleting the database passphrase makes any
 *    leftover encrypted bytes unrecoverable.
 * 4. Files (auto-backups, cache).
 *
 * Every step runs even when an earlier one failed, and the report
 * names what failed — a partial wipe is reported honestly, never as
 * a success. The caller (SettingsViewModel) cancels all WorkManager
 * work and stops the foreground services before calling this, and
 * restarts the app afterwards so every singleton rebuilds fresh.
 */
class DataWipeService(
    private val steps: List<WipeStep>,
) {
    /** One store's clear, with the name the report shows. */
    data class WipeStep(
        val name: String,
        val clear: suspend () -> Unit,
    )

    /** What a wipe did, per store. */
    data class WipeReport(
        val wiped: List<String>,
        /** Store name → failure message, empty when everything worked. */
        val failed: Map<String, String> = emptyMap(),
    )

    /**
     * Runs every step in order. Returns Success with the report when
     * all steps worked, or Failure naming the stores that failed
     * (the report is lost in that case — the message carries the
     * store names, which is what the user needs to act on).
     */
    suspend fun wipeAll(): JarvisResult<WipeReport> {
        val wiped = mutableListOf<String>()
        val failed = mutableMapOf<String, String>()
        for (step in steps) {
            runCatching { step.clear() }
                .onSuccess { wiped += step.name }
                .onFailure { failed[step.name] = it.message ?: it::class.simpleName.orEmpty() }
        }
        val report = WipeReport(wiped = wiped, failed = failed)
        return if (failed.isEmpty()) {
            JarvisResult.Success(report)
        } else {
            JarvisResult.Failure(
                "Some data could not be deleted: " +
                    failed.keys.joinToString(", ") + ". Please try again.",
            )
        }
    }
}
