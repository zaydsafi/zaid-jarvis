package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.analytics.AnalyticsPayload
import com.zaid.jarvis.data.db.AnalyticsEventDao
import com.zaid.jarvis.data.db.AnalyticsEventEntity
import com.zaid.jarvis.data.db.ListLimits
import com.zaid.jarvis.data.db.RetentionPolicy
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonObject
import javax.inject.Inject
import javax.inject.Singleton

/**
 * On-device usage analytics (Phase 10): the Room side of event
 * recording. Local only — nothing leaves the device.
 *
 * Two gates, both enforced here:
 * - **Opt-out**: when [isEnabled] returns false (the "Usage insights"
 *   toggle in Settings), nothing is recorded at all.
 * - **Payload validation**: [AnalyticsPayload] rejects free text and
 *   unknown keys; an invalid event is dropped, never recorded.
 *
 * Recording is best-effort: a failure to write is swallowed (analytics
 * must never break the feature it observes).
 */
@Singleton
class AnalyticsRepository @Inject constructor(
    private val dao: AnalyticsEventDao,
    private val isEnabled: suspend () -> Boolean = { true },
) : AnalyticsPruner {
    private val json = Json { ignoreUnknownKeys = true }

    /** One recorded event, as the Insights screen reads it. */
    data class RecordedEvent(
        val id: Long,
        val eventName: String,
        val timestampMillis: Long,
        val payload: Map<String, String>,
    )

    /** Records an event when insights are on and the payload is valid. Silently drops otherwise. */
    suspend fun record(eventName: String, payload: Map<String, String>) {
        if (!runCatching { isEnabled() }.getOrDefault(false)) return
        if (!AnalyticsPayload.isValid(eventName, payload)) return
        runCatching {
            val payloadJson = JsonObject(
                payload.mapValues { (_, value) -> JsonPrimitive(value) },
            ).toString()
            dao.insert(
                AnalyticsEventEntity(
                    eventName = eventName,
                    timestampMillis = System.currentTimeMillis(),
                    payloadJson = payloadJson,
                ),
            )
        }
    }

    /**
     * Events at or after [sinceMillis], newest first — capped
     * ([ListLimits.ANALYTICS_EVENTS]) so a 30-day Insights range
     * cannot load an unbounded table.
     */
    suspend fun eventsSince(sinceMillis: Long): List<RecordedEvent> =
        runCatching { dao.getSince(sinceMillis, ListLimits.ANALYTICS_EVENTS) }.getOrDefault(emptyList()).map { entity ->
            RecordedEvent(
                id = entity.id,
                eventName = entity.eventName,
                timestampMillis = entity.timestampMillis,
                payload = parsePayload(entity.payloadJson),
            )
        }

    suspend fun count(): Int = runCatching { dao.count() }.getOrDefault(0)

    /**
     * Retention prune: deletes events older than [cutoffMillis]
     * ([RetentionPolicy] sets the cutoff at 90 days). Returns the
     * number of rows deleted, 0 when the prune failed.
     */
    override suspend fun pruneOlderThan(cutoffMillis: Long): Int =
        runCatching { dao.deleteOlderThan(cutoffMillis) }.getOrDefault(0)

    /** Wipes all recorded events ("Clear analytics data"). */
    suspend fun clearAll() {
        runCatching { dao.deleteAll() }
    }

    private fun parsePayload(payloadJson: String): Map<String, String> {
        val element = runCatching { json.parseToJsonElement(payloadJson) }.getOrNull()
            ?: return emptyMap()
        val obj = runCatching { element.jsonObject }.getOrNull() ?: return emptyMap()
        return obj.mapValues { (_, value) ->
            runCatching { (value as JsonPrimitive).content }.getOrDefault("")
        }.filterValues { it.isNotEmpty() }
    }
}
