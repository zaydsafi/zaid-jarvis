package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.research.ResearchBrief
import com.zaid.jarvis.core.research.ResearchRecord
import com.zaid.jarvis.data.db.ListLimits
import com.zaid.jarvis.data.db.ResearchDao
import com.zaid.jarvis.data.db.ResearchEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Saved research jobs (Phase 7): the topic and the structured brief
 * the ResearchEngine produced for it.
 *
 * Records live in the SQLCipher-encrypted database. A record whose
 * brief JSON is unreadable is skipped on read (never crashes the
 * history screen) — it can still be deleted.
 */
@Singleton
class ResearchRepository @Inject constructor(
    private val researchDao: ResearchDao,
) {
    private val json = Json { ignoreUnknownKeys = true }

    /** All research, newest first — capped ([ListLimits.RESEARCH_LIST]). */
    fun observeAll(): Flow<List<ResearchRecord>> =
        researchDao.observeAll(ListLimits.RESEARCH_LIST).map { entities -> entities.mapNotNull { toRecord(it) } }

    suspend fun getById(id: Long): ResearchRecord? =
        researchDao.getById(id)?.let { toRecord(it) }

    suspend fun count(): Int = researchDao.count()

    /** Saves a finished research job. Returns the row id. */
    suspend fun save(topic: String, brief: ResearchBrief): Long {
        val entity = ResearchEntity(
            topic = topic.trim(),
            briefJson = json.encodeToString(ResearchBrief.serializer(), brief),
            createdAtMillis = System.currentTimeMillis(),
        )
        return researchDao.insert(entity)
    }

    suspend fun delete(id: Long) = researchDao.deleteById(id)

    suspend fun deleteAll() = researchDao.deleteAll()

    /** Decodes an entity, or null when its brief JSON is unreadable (never crashes). */
    private fun toRecord(entity: ResearchEntity): ResearchRecord? {
        val brief = runCatching {
            json.decodeFromString(ResearchBrief.serializer(), entity.briefJson)
        }.getOrNull() ?: return null
        return ResearchRecord(
            id = entity.id,
            topic = entity.topic,
            brief = brief,
            createdAtMillis = entity.createdAtMillis,
        )
    }
}
