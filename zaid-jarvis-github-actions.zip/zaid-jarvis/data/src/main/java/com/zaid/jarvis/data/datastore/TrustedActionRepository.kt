package com.zaid.jarvis.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.zaid.jarvis.core.confirmation.TrustedActionStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.trustedActionsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "jarvis_trusted_actions",
)

/**
 * DataStore-backed trusted actions (Master Prompt §6). Stores the set of
 * tool names Zaid has marked as trusted (tiers 0–1 only — the engine
 * enforces that at execution time). Revocation takes effect immediately:
 * the next call for that tool shows the approval card again.
 */
@Singleton
class TrustedActionRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) : TrustedActionStore {

    override suspend fun isTrusted(toolName: String): Boolean =
        context.trustedActionsDataStore.data.first()[KEY_TRUSTED]?.contains(toolName) == true

    override suspend fun trust(toolName: String) {
        context.trustedActionsDataStore.edit { prefs ->
            prefs[KEY_TRUSTED] = (prefs[KEY_TRUSTED] ?: emptySet()) + toolName
        }
    }

    override suspend fun revoke(toolName: String) {
        context.trustedActionsDataStore.edit { prefs ->
            prefs[KEY_TRUSTED] = (prefs[KEY_TRUSTED] ?: emptySet()) - toolName
        }
    }

    override suspend fun revokeAll() {
        context.trustedActionsDataStore.edit { prefs ->
            prefs[KEY_TRUSTED] = emptySet()
        }
    }

    override fun observeTrusted(): Flow<Set<String>> =
        context.trustedActionsDataStore.data.map { prefs ->
            prefs[KEY_TRUSTED] ?: emptySet()
        }

    private companion object {
        val KEY_TRUSTED = stringSetPreferencesKey("trusted_tool_names")
    }
}
