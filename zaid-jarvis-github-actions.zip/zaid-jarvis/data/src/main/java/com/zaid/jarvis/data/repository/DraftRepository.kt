package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.confirmation.sha256Hex
import com.zaid.jarvis.core.research.ContentDraft
import com.zaid.jarvis.core.research.DraftStatus
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.db.ContentDraftDao
import com.zaid.jarvis.data.db.ContentDraftEntity
import com.zaid.jarvis.data.db.ListLimits
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Content drafts (Phase 7): posts Jarvis wrote for Zaid to review,
 * edit, and approve for publishing.
 *
 * Status rules (the publishing gate):
 * - New drafts are DRAFT. [save] accepts DRAFT and APPROVED only —
 *   PUBLISHED is refused here, because a draft must never claim to be
 *   published when it isn't; only [markPublished] (Phase 8, called by
 *   the publishing flow after a real publish) can set PUBLISHED.
 * - [approve] moves a DRAFT to APPROVED, and only from DRAFT. It is a
 *   deliberate user action (the "Approve for publishing" button), never
 *   automatic. Approving an already-approved draft is a harmless no-op
 *   that still succeeds — and re-records the approval content hash.
 * - [approve] records the SHA-256 of the body at approve time
 *   ([ContentDraft.approvedBodyHash]). Editing an APPROVED draft keeps
 *   the status but the hash no longer matches, so the publish path
 *   refuses it until Zaid approves the edited text again.
 * - An unknown status string read back from the database maps to DRAFT
 *   (fail-safe: an unreadable draft is never treated as approved).
 */
@Singleton
class DraftRepository @Inject constructor(
    private val draftDao: ContentDraftDao,
) {

    /** All drafts, most recently updated first — capped ([ListLimits.DRAFT_LIST]). */
    fun observeAll(): Flow<List<ContentDraft>> =
        draftDao.observeAll(ListLimits.DRAFT_LIST).map { entities -> entities.map { toDraft(it) } }

    suspend fun getById(id: Long): ContentDraft? =
        draftDao.getById(id)?.let { toDraft(it) }

    suspend fun count(): Int = draftDao.count()

    /**
     * Saves a new draft or updates an existing one (same id). Returns
     * the row id, or a Failure when the draft is blank or claims to be
     * PUBLISHED. Editing an APPROVED draft keeps it APPROVED and keeps
     * the approval hash from approve time — the hash no longer matches
     * the edited body, so the publish path refuses it until Zaid
     * approves the edited text again (content binding, Phase 8).
     */
    suspend fun save(draft: ContentDraft): JarvisResult<Long> {
        if (draft.status == DraftStatus.PUBLISHED) {
            return JarvisResult.Failure(
                "A draft can only be marked published by the publishing flow " +
                    "after a real publish — save() never sets PUBLISHED.",
            )
        }
        val title = draft.title.trim()
        val body = draft.body.trim()
        if (title.isEmpty() || body.isEmpty()) {
            return JarvisResult.Failure("A draft needs both a title and text.")
        }
        val now = System.currentTimeMillis()
        val existing = if (draft.id != 0L) draftDao.getById(draft.id) else null
        val entity = ContentDraftEntity(
            id = draft.id,
            title = title,
            body = body,
            platform = draft.platform.trim().ifEmpty { "Other" },
            status = draft.status.name,
            researchId = draft.researchId,
            // The caller sets the hash explicitly at approve time;
            // ordinary edits preserve the hash that was recorded then.
            approvedBodyHash = draft.approvedBodyHash ?: existing?.approvedBodyHash,
            createdAtMillis = existing?.createdAtMillis ?: now,
            updatedAtMillis = now,
        )
        return JarvisResult.Success(draftDao.upsert(entity))
    }

    /**
     * Marks a draft APPROVED for publishing. Only DRAFT drafts move;
     * an already-APPROVED draft stays approved. Records the SHA-256 of
     * the current body as the approval content hash, so a later edit is
     * detectable. Returns a Failure when the draft no longer exists.
     */
    suspend fun approve(id: Long): JarvisResult<Unit> {
        val draft = getById(id)
            ?: return JarvisResult.Failure("That draft no longer exists.")
        if (draft.status == DraftStatus.PUBLISHED) {
            return JarvisResult.Failure("That draft is already published.")
        }
        val approved = draft.copy(
            status = DraftStatus.APPROVED,
            approvedBodyHash = sha256Hex(draft.body),
        )
        return when (val result = save(approved)) {
            is JarvisResult.Success -> JarvisResult.Success(Unit)
            is JarvisResult.Failure -> result
        }
    }

    /**
     * Marks a draft PUBLISHED. This is the ONLY place PUBLISHED may be
     * set — it is called by the publishing flow ([PublishServiceImpl])
     * only after the platform confirmed the post, and only from
     * APPROVED. Refuses DRAFT (never approved) and already-PUBLISHED.
     * Also refuses an APPROVED draft edited since approval (the
     * approval hash no longer matches the body) — the publishing gate
     * is enforced in [PublishServiceImpl] too, and this is the
     * defense-in-depth copy at the repository layer (Phase 11), so no
     * caller can mark an edited draft published by mistake.
     */
    suspend fun markPublished(id: Long): JarvisResult<Unit> {
        val draft = getById(id)
            ?: return JarvisResult.Failure("That draft no longer exists.")
        if (draft.status != DraftStatus.APPROVED) {
            return JarvisResult.Failure(
                "Only an APPROVED draft can be marked published — " +
                    "this one is ${draft.status.name.lowercase()}.",
            )
        }
        if (draft.editedSinceApproval()) {
            return JarvisResult.Failure(
                "This draft was edited after it was approved — " +
                    "approve the edited text before publishing.",
            )
        }
        val existing = draftDao.getById(id) ?: return JarvisResult.Failure(
            "That draft no longer exists.",
        )
        draftDao.upsert(
            existing.copy(
                status = DraftStatus.PUBLISHED.name,
                updatedAtMillis = System.currentTimeMillis(),
            ),
        )
        return JarvisResult.Success(Unit)
    }

    suspend fun delete(id: Long) = draftDao.deleteById(id)

    suspend fun deleteAll() = draftDao.deleteAll()

    private fun toDraft(entity: ContentDraftEntity): ContentDraft {
        val status = runCatching { DraftStatus.valueOf(entity.status) }
            .getOrDefault(DraftStatus.DRAFT)
        return ContentDraft(
            id = entity.id,
            title = entity.title,
            body = entity.body,
            platform = entity.platform,
            status = status,
            researchId = entity.researchId,
            approvedBodyHash = entity.approvedBodyHash,
            createdAtMillis = entity.createdAtMillis,
            updatedAtMillis = entity.updatedAtMillis,
        )
    }
}
