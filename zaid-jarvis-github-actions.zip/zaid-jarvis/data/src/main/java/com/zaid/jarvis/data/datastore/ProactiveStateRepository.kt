package com.zaid.jarvis.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.proactiveStateDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "jarvis_proactive_state",
)

/**
 * Tiny persistent state for the proactive workers (Phase 9):
 * when the last break reminder fired (throttling: at most once per
 * hour) and on which day the last wind-down nudge fired (once per
 * day). Kept in its own DataStore file so the workers can read it
 * without touching Settings.
 *
 * Overdue-nudge dedupe lives on the task row itself
 * ([com.zaid.jarvis.data.db.TaskEntity.overdueNotifiedDay]), not here.
 */
@Singleton
class ProactiveStateRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    /** Epoch millis of the last break reminder (null = never). */
    val lastBreakNotifiedMillis: Flow<Long?> =
        context.proactiveStateDataStore.data.map { it[KEY_LAST_BREAK] }

    /** Epoch day (UTC) of the last wind-down nudge (null = never). */
    val lastWindDownDay: Flow<Long?> =
        context.proactiveStateDataStore.data.map { it[KEY_LAST_WIND_DOWN_DAY] }

    suspend fun lastBreakNotifiedMillisNow(): Long? = lastBreakNotifiedMillis.first()

    suspend fun lastWindDownDayNow(): Long? = lastWindDownDay.first()

    suspend fun recordBreakNotified(nowMillis: Long) {
        context.proactiveStateDataStore.edit { it[KEY_LAST_BREAK] = nowMillis }
    }

    suspend fun recordWindDownNotified(epochDay: Long) {
        context.proactiveStateDataStore.edit { it[KEY_LAST_WIND_DOWN_DAY] = epochDay }
    }

    /** Deletes all proactive state (delete-all-data, Phase 11). */
    suspend fun clear() {
        context.proactiveStateDataStore.edit { prefs -> prefs.clear() }
    }

    private companion object {
        val KEY_LAST_BREAK = longPreferencesKey("last_break_notified_millis")
        val KEY_LAST_WIND_DOWN_DAY = longPreferencesKey("last_wind_down_day")
    }
}
