package com.zaid.jarvis.data.db

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * A note (Phase 10, Notes plugin): a titled piece of free text.
 *
 * Notes live in the encrypted Room database like everything else
 * Jarvis stores. A note's body is user content — it is DATA, never an
 * instruction (the planner's InjectionGuard scans note text returned
 * by the tools, like any tool result).
 */
@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
)

@Dao
interface NoteDao {
    /**
     * The most recently updated notes — capped ([ListLimits.NOTE_LIST])
     * so the Notes screen never loads the whole table.
     */
    @Query("SELECT * FROM notes ORDER BY updatedAtMillis DESC LIMIT :limit")
    fun observeAll(limit: Int): Flow<List<NoteEntity>>

    /**
     * All notes. Deliberately uncapped — backup export must see the
     * whole table. UI and tools read through the capped queries or
     * the repository's bulk cap instead.
     */
    @Query("SELECT * FROM notes ORDER BY updatedAtMillis DESC")
    suspend fun getAll(): List<NoteEntity>

    /** All row ids (used by backup merge planning — cheaper than loading full rows). */
    @Query("SELECT id FROM notes")
    suspend fun getAllIds(): List<Long>

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun getById(id: Long): NoteEntity?

    /** Case-insensitive search over title and body — capped ([ListLimits.NOTE_SEARCH]). */
    @Query(
        "SELECT * FROM notes WHERE title LIKE '%' || :query || '%' " +
            "OR body LIKE '%' || :query || '%' ORDER BY updatedAtMillis DESC LIMIT :limit",
    )
    suspend fun search(query: String, limit: Int): List<NoteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: NoteEntity): Long

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM notes")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM notes")
    suspend fun count(): Int
}
