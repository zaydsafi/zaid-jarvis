package com.zaid.jarvis.data.repository

import com.zaid.jarvis.data.db.RetentionPolicy
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Retention policy (Phase 11): the pure computations the weekly
 * maintenance worker applies — analytics cutoff and audit-log
 * keep count.
 */
class RetentionPolicyTest {

    @Test
    fun `analytics retention is 90 days`() {
        assertEquals(90L, RetentionPolicy.ANALYTICS_RETENTION_DAYS)
    }

    @Test
    fun `analytics cutoff is exactly 90 days before now`() {
        val now = 1_800_000_000_000L
        val expected = now - 90L * 24L * 60L * 60L * 1000L
        assertEquals(expected, RetentionPolicy.analyticsCutoffMillis(now))
    }

    @Test
    fun `audit log keeps 10000 entries`() {
        assertEquals(10_000, RetentionPolicy.AUDIT_LOG_KEEP_COUNT)
    }

    @Test
    fun `audit deletions are zero when the table is within the cap`() {
        assertEquals(0, RetentionPolicy.auditLogDeletionsFor(0))
        assertEquals(0, RetentionPolicy.auditLogDeletionsFor(9_999))
        assertEquals(0, RetentionPolicy.auditLogDeletionsFor(10_000))
    }

    @Test
    fun `audit deletions are the excess above the cap`() {
        assertEquals(1, RetentionPolicy.auditLogDeletionsFor(10_001))
        assertEquals(500, RetentionPolicy.auditLogDeletionsFor(10_500))
    }
}
