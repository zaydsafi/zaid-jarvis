package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.research.ContentDraft
import com.zaid.jarvis.core.research.DraftStatus
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.db.ContentDraftDao
import com.zaid.jarvis.data.db.ContentDraftEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Draft repository (Phase 7) with a fake DAO — the status rules of
 * the publishing gate live here, so they are tested here.
 */
class DraftRepositoryTest {

    private class FakeDraftDao : ContentDraftDao {
        val rows = mutableListOf<ContentDraftEntity>()
        private var nextId = 1L

        override fun observeAll(limit: Int): Flow<List<ContentDraftEntity>> =
            flowOf(rows.sortedByDescending { it.updatedAtMillis }.take(limit))
        override suspend fun getAll(): List<ContentDraftEntity> = rows.toList()
        override suspend fun getAllIds(): List<Long> = rows.map { it.id }
        override suspend fun getById(id: Long): ContentDraftEntity? = rows.find { it.id == id }
        override suspend fun upsert(entity: ContentDraftEntity): Long {
            return if (entity.id == 0L) {
                val id = nextId++
                rows += entity.copy(id = id)
                id
            } else {
                rows.removeAll { it.id == entity.id }
                rows += entity
                entity.id
            }
        }

        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
        }

        override suspend fun deleteAll() = rows.clear()
        override suspend fun count(): Int = rows.size
    }

    private fun draft(
        id: Long = 0L,
        status: DraftStatus = DraftStatus.DRAFT,
        title: String = "Title",
        body: String = "Body text.",
    ) = ContentDraft(id = id, title = title, body = body, platform = "X / Twitter", status = status)

    @Test
    fun `save stores a new draft and returns its id`() = runBlocking {
        val repository = DraftRepository(FakeDraftDao())
        val result = repository.save(draft())
        assertTrue(result is JarvisResult.Success)
        val id = (result as JarvisResult.Success).value
        assertTrue(id > 0)
        val stored = repository.getById(id)
        assertEquals("Title", stored?.title)
        assertEquals(DraftStatus.DRAFT, stored?.status)
    }

    @Test
    fun `save updates an existing draft by id`() = runBlocking {
        val repository = DraftRepository(FakeDraftDao())
        val id = (repository.save(draft()) as JarvisResult.Success).value
        repository.save(draft(id = id, body = "Edited text."))
        assertEquals(1, repository.count())
        assertEquals("Edited text.", repository.getById(id)?.body)
    }

    @Test
    fun `save refuses a blank title or body`() = runBlocking {
        val repository = DraftRepository(FakeDraftDao())
        assertTrue(repository.save(draft(title = "  ")) is JarvisResult.Failure)
        assertTrue(repository.save(draft(body = "")) is JarvisResult.Failure)
        assertEquals(0, repository.count())
    }

    @Test
    fun `save refuses PUBLISHED — publishing is phase 8`() = runBlocking {
        val repository = DraftRepository(FakeDraftDao())
        val result = repository.save(draft(status = DraftStatus.PUBLISHED))
        assertTrue(result is JarvisResult.Failure)
        assertEquals(0, repository.count())
    }

    @Test
    fun `approve moves DRAFT to APPROVED`() = runBlocking {
        val repository = DraftRepository(FakeDraftDao())
        val id = (repository.save(draft()) as JarvisResult.Success).value
        val result = repository.approve(id)
        assertTrue(result is JarvisResult.Success)
        assertEquals(DraftStatus.APPROVED, repository.getById(id)?.status)
    }

    @Test
    fun `approving an already-approved draft is a harmless no-op`() = runBlocking {
        val repository = DraftRepository(FakeDraftDao())
        val id = (repository.save(draft()) as JarvisResult.Success).value
        repository.approve(id)
        assertTrue(repository.approve(id) is JarvisResult.Success)
        assertEquals(DraftStatus.APPROVED, repository.getById(id)?.status)
    }

    @Test
    fun `approve on a missing draft fails`() = runBlocking {
        val repository = DraftRepository(FakeDraftDao())
        assertTrue(repository.approve(999L) is JarvisResult.Failure)
    }

    @Test
    fun `unknown status strings read back as DRAFT`() = runBlocking {
        val dao = FakeDraftDao()
        val repository = DraftRepository(dao)
        dao.upsert(
            ContentDraftEntity(
                title = "Mystery",
                body = "Body.",
                platform = "X / Twitter",
                status = "SOMETHING_NEW",
                createdAtMillis = 0L,
                updatedAtMillis = 0L,
            ),
        )
        val stored = repository.getById(1L)
        assertEquals(DraftStatus.DRAFT, stored?.status)
    }

    @Test
    fun `editing an approved draft keeps it approved`() = runBlocking {
        val repository = DraftRepository(FakeDraftDao())
        val id = (repository.save(draft()) as JarvisResult.Success).value
        repository.approve(id)
        repository.save(draft(id = id, status = DraftStatus.APPROVED, body = "Fixed a typo."))
        assertEquals(DraftStatus.APPROVED, repository.getById(id)?.status)
        assertEquals("Fixed a typo.", repository.getById(id)?.body)
    }

    // ── Phase 8: markPublished + approval content binding ────────────

    @Test
    fun `markPublished moves APPROVED to PUBLISHED`() = runBlocking {
        val repository = DraftRepository(FakeDraftDao())
        val id = (repository.save(draft()) as JarvisResult.Success).value
        repository.approve(id)
        val result = repository.markPublished(id)
        assertTrue(result is JarvisResult.Success)
        assertEquals(DraftStatus.PUBLISHED, repository.getById(id)?.status)
    }

    @Test
    fun `markPublished refuses a DRAFT`() = runBlocking {
        val repository = DraftRepository(FakeDraftDao())
        val id = (repository.save(draft()) as JarvisResult.Success).value
        val result = repository.markPublished(id)
        assertTrue(result is JarvisResult.Failure)
        assertEquals(DraftStatus.DRAFT, repository.getById(id)?.status)
    }

    @Test
    fun `markPublished refuses an already-published draft`() = runBlocking {
        val repository = DraftRepository(FakeDraftDao())
        val id = (repository.save(draft()) as JarvisResult.Success).value
        repository.approve(id)
        repository.markPublished(id)
        assertTrue(repository.markPublished(id) is JarvisResult.Failure)
    }

    @Test
    fun `markPublished on a missing draft fails`() = runBlocking {
        val repository = DraftRepository(FakeDraftDao())
        assertTrue(repository.markPublished(999L) is JarvisResult.Failure)
    }

    @Test
    fun `approve records the content hash of the current body`() = runBlocking {
        val repository = DraftRepository(FakeDraftDao())
        val id = (repository.save(draft()) as JarvisResult.Success).value
        repository.approve(id)
        val stored = repository.getById(id)
        assertEquals(
            com.zaid.jarvis.core.confirmation.sha256Hex("Body text."),
            stored?.approvedBodyHash,
        )
        assertEquals(false, stored?.editedSinceApproval())
    }

    @Test
    fun `editing an approved draft invalidates the approval hash`() = runBlocking {
        val repository = DraftRepository(FakeDraftDao())
        val id = (repository.save(draft()) as JarvisResult.Success).value
        repository.approve(id)
        repository.save(draft(id = id, status = DraftStatus.APPROVED, body = "Fixed a typo."))
        assertEquals(true, repository.getById(id)?.editedSinceApproval())
    }

    @Test
    fun `re-approving an edited draft records the new hash`() = runBlocking {
        val repository = DraftRepository(FakeDraftDao())
        val id = (repository.save(draft()) as JarvisResult.Success).value
        repository.approve(id)
        repository.save(draft(id = id, status = DraftStatus.APPROVED, body = "Fixed a typo."))
        repository.approve(id)
        assertEquals(false, repository.getById(id)?.editedSinceApproval())
        assertEquals(
            com.zaid.jarvis.core.confirmation.sha256Hex("Fixed a typo."),
            repository.getById(id)?.approvedBodyHash,
        )
    }

    @Test
    fun `markPublished refuses a draft edited since approval`() = runBlocking {
        val repository = DraftRepository(FakeDraftDao())
        val id = (repository.save(draft()) as JarvisResult.Success).value
        repository.approve(id)
        repository.save(draft(id = id, status = DraftStatus.APPROVED, body = "Fixed a typo."))
        assertEquals(true, repository.getById(id)?.editedSinceApproval())
        val result = repository.markPublished(id)
        assertTrue(result is JarvisResult.Failure)
        // The draft stays APPROVED, not PUBLISHED — re-approval is required.
        assertEquals(DraftStatus.APPROVED, repository.getById(id)?.status)
    }

    @Test
    fun `markPublished succeeds after re-approving an edited draft`() = runBlocking {
        val repository = DraftRepository(FakeDraftDao())
        val id = (repository.save(draft()) as JarvisResult.Success).value
        repository.approve(id)
        repository.save(draft(id = id, status = DraftStatus.APPROVED, body = "Fixed a typo."))
        repository.approve(id)
        assertTrue(repository.markPublished(id) is JarvisResult.Success)
        assertEquals(DraftStatus.PUBLISHED, repository.getById(id)?.status)
    }

    @Test
    fun `approve refuses a published draft`() = runBlocking {
        val repository = DraftRepository(FakeDraftDao())
        val id = (repository.save(draft()) as JarvisResult.Success).value
        repository.approve(id)
        repository.markPublished(id)
        assertTrue(repository.approve(id) is JarvisResult.Failure)
    }
}
