package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.backup.BackupData
import com.zaid.jarvis.core.backup.BackupFocusSession
import com.zaid.jarvis.core.backup.BackupFormat
import com.zaid.jarvis.core.backup.BackupMacro
import com.zaid.jarvis.core.backup.BackupNote
import com.zaid.jarvis.core.backup.BackupScheduledPost
import com.zaid.jarvis.core.backup.BackupTask
import com.zaid.jarvis.core.confirmation.InMemoryTrustedActionStore
import com.zaid.jarvis.core.model.JarvisSettings
import com.zaid.jarvis.core.model.ThemeMode
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.db.AuditLogDao
import com.zaid.jarvis.data.db.AuditLogEntryEntity
import com.zaid.jarvis.data.db.ContentDraftDao
import com.zaid.jarvis.data.db.ContentDraftEntity
import com.zaid.jarvis.data.db.FocusSessionDao
import com.zaid.jarvis.data.db.FocusSessionEntity
import com.zaid.jarvis.data.db.MacroDao
import com.zaid.jarvis.data.db.MacroEntity
import com.zaid.jarvis.data.db.MemoryDao
import com.zaid.jarvis.data.db.MemoryItem
import com.zaid.jarvis.data.db.NoteDao
import com.zaid.jarvis.data.db.NoteEntity
import com.zaid.jarvis.data.db.ResearchDao
import com.zaid.jarvis.data.db.ResearchEntity
import com.zaid.jarvis.data.db.ScheduledPostDao
import com.zaid.jarvis.data.db.ScheduledPostEntity
import com.zaid.jarvis.data.db.TaskDao
import com.zaid.jarvis.data.db.TaskEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Backup & restore (Phase 10) with fake DAOs: export round-trip,
 * merge-by-id, preview counts, scheduled-post/focus-session restore
 * rules, macro name dedupe, reminder re-enqueue list, no-secrets,
 * and transaction rollback on failure.
 */
class BackupServiceTest {

    // ── Fake DAOs (in-memory row lists, same upsert semantics as Room) ──

    private class FakeTaskDao : TaskDao {
        val rows = mutableListOf<TaskEntity>()
        override fun observeAll(limit: Int): Flow<List<TaskEntity>> =
            flowOf(rows.toList().take(limit))
        override suspend fun getAll(): List<TaskEntity> = rows.toList()
        override suspend fun getAllIds(): List<Long> = rows.map { it.id }
        override suspend fun getById(id: Long): TaskEntity? = rows.find { it.id == id }
        override suspend fun getOpen(limit: Int): List<TaskEntity> =
            rows.filter { it.status != "DONE" }.take(limit)
        override suspend fun getOverdue(nowMillis: Long, limit: Int): List<TaskEntity> =
            rows.filter {
                val due = it.dueAtMillis
                it.status != "DONE" && due != null && due < nowMillis
            }.take(limit)
        override suspend fun getDueBetween(
            startMillis: Long,
            endMillis: Long,
            limit: Int,
        ): List<TaskEntity> =
            rows.filter {
                val due = it.dueAtMillis
                it.status != "DONE" && due != null &&
                    due >= startMillis && due < endMillis
            }.take(limit)
        override suspend fun upsert(entity: TaskEntity): Long {
            rows.removeAll { it.id == entity.id }
            rows += entity
            return entity.id
        }

        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
        }

        override suspend fun deleteAll() = rows.clear()
        override suspend fun count(): Int = rows.size
    }

    private class FakeNoteDao(var failOnUpsert: Boolean = false) : NoteDao {
        val rows = mutableListOf<NoteEntity>()
        override fun observeAll(limit: Int): Flow<List<NoteEntity>> =
            flowOf(rows.toList().take(limit))
        override suspend fun getAll(): List<NoteEntity> = rows.toList()
        override suspend fun getAllIds(): List<Long> = rows.map { it.id }
        override suspend fun getById(id: Long): NoteEntity? = rows.find { it.id == id }
        override suspend fun search(query: String, limit: Int): List<NoteEntity> = rows.filter {
            it.title.contains(query, ignoreCase = true) || it.body.contains(query, ignoreCase = true)
        }.take(limit)

        override suspend fun upsert(entity: NoteEntity): Long {
            if (failOnUpsert) throw IllegalStateException("simulated database failure")
            rows.removeAll { it.id == entity.id }
            rows += entity
            return entity.id
        }

        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
        }

        override suspend fun deleteAll() = rows.clear()
        override suspend fun count(): Int = rows.size
    }

    private class FakeMacroDao : MacroDao {
        val rows = mutableListOf<MacroEntity>()
        override fun observeAll(limit: Int): Flow<List<MacroEntity>> =
            flowOf(rows.toList().take(limit))
        override suspend fun getAll(): List<MacroEntity> = rows.toList()
        override suspend fun getAllIds(): List<Long> = rows.map { it.id }
        override fun observeCount(): Flow<Int> = flowOf(rows.size)
        override suspend fun getByName(name: String): MacroEntity? = rows.find { it.name == name }
        override suspend fun getById(id: Long): MacroEntity? = rows.find { it.id == id }
        override suspend fun upsert(entity: MacroEntity): Long {
            rows.removeAll { it.id == entity.id }
            rows += entity
            return entity.id
        }

        override suspend fun markRun(id: Long, timestampMillis: Long) = Unit
        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
        }

        override suspend fun deleteAll() = rows.clear()
        override suspend fun count(): Int = rows.size
    }

    private class FakeDraftDao : ContentDraftDao {
        val rows = mutableListOf<ContentDraftEntity>()
        override fun observeAll(limit: Int): Flow<List<ContentDraftEntity>> =
            flowOf(rows.toList().take(limit))
        override suspend fun getAll(): List<ContentDraftEntity> = rows.toList()
        override suspend fun getAllIds(): List<Long> = rows.map { it.id }
        override suspend fun getById(id: Long): ContentDraftEntity? = rows.find { it.id == id }
        override suspend fun upsert(entity: ContentDraftEntity): Long {
            rows.removeAll { it.id == entity.id }
            rows += entity
            return entity.id
        }

        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
        }

        override suspend fun deleteAll() = rows.clear()
        override suspend fun count(): Int = rows.size
    }

    private class FakeResearchDao : ResearchDao {
        val rows = mutableListOf<ResearchEntity>()
        override fun observeAll(limit: Int): Flow<List<ResearchEntity>> =
            flowOf(rows.toList().take(limit))
        override suspend fun getAll(): List<ResearchEntity> = rows.toList()
        override suspend fun getAllIds(): List<Long> = rows.map { it.id }
        override suspend fun getById(id: Long): ResearchEntity? = rows.find { it.id == id }
        override suspend fun insert(entity: ResearchEntity): Long {
            rows.removeAll { it.id == entity.id }
            rows += entity
            return entity.id
        }

        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
        }

        override suspend fun deleteAll() = rows.clear()
        override suspend fun count(): Int = rows.size
    }

    private class FakeMemoryDao : MemoryDao {
        val rows = mutableListOf<MemoryItem>()
        override fun observeAll(limit: Int): Flow<List<MemoryItem>> =
            flowOf(rows.toList().take(limit))
        override suspend fun getAll(): List<MemoryItem> = rows.toList()
        override suspend fun getAllIds(): List<Long> = rows.map { it.id }
        override suspend fun search(query: String, limit: Int): List<MemoryItem> = rows.filter {
            it.key.contains(query, ignoreCase = true) || it.value.contains(query, ignoreCase = true)
        }.take(limit)

        override suspend fun getByKind(kind: String, limit: Int): List<MemoryItem> =
            rows.filter { it.kind == kind }.take(limit)
        override suspend fun upsert(item: MemoryItem): Long {
            rows.removeAll { it.id == item.id }
            rows += item
            return item.id
        }

        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
        }

        override suspend fun deleteAll() = rows.clear()
    }

    private class FakeScheduledPostDao : ScheduledPostDao {
        val rows = mutableListOf<ScheduledPostEntity>()
        override fun observeAll(limit: Int): Flow<List<ScheduledPostEntity>> =
            flowOf(rows.toList().take(limit))
        override suspend fun getAll(): List<ScheduledPostEntity> = rows.toList()
        override suspend fun getAllIds(): List<Long> = rows.map { it.id }
        override suspend fun getById(id: Long): ScheduledPostEntity? = rows.find { it.id == id }
        override suspend fun upsert(entity: ScheduledPostEntity): Long {
            rows.removeAll { it.id == entity.id }
            rows += entity
            return entity.id
        }

        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
        }

        override suspend fun deleteAll() = rows.clear()
        override suspend fun count(): Int = rows.size
    }

    private class FakeFocusSessionDao : FocusSessionDao {
        val rows = mutableListOf<FocusSessionEntity>()
        override fun observeAll(limit: Int): Flow<List<FocusSessionEntity>> =
            flowOf(rows.toList().take(limit))
        override suspend fun getAll(): List<FocusSessionEntity> = rows.toList()
        override suspend fun getAllIds(): List<Long> = rows.map { it.id }
        override suspend fun getRecent(limit: Int): List<FocusSessionEntity> =
            rows.sortedByDescending { it.startedAtMillis }.take(limit)
        override suspend fun getById(id: Long): FocusSessionEntity? = rows.find { it.id == id }
        override suspend fun getRunning(): FocusSessionEntity? = rows.find { it.status == "RUNNING" }
        override suspend fun upsert(entity: FocusSessionEntity): Long {
            rows.removeAll { it.id == entity.id }
            rows += entity
            return entity.id
        }

        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
        }

        override suspend fun deleteAll() = rows.clear()
    }

    private class FakeAuditLogDao : AuditLogDao {
        val rows = mutableListOf<AuditLogEntryEntity>()
        override fun observeAll(limit: Int): Flow<List<AuditLogEntryEntity>> =
            flowOf(rows.toList().take(limit))
        override suspend fun getAll(): List<AuditLogEntryEntity> = rows.toList()
        override suspend fun getAllIds(): List<Long> = rows.map { it.id }
        override suspend fun search(query: String, limit: Int): List<AuditLogEntryEntity> = rows.filter {
            it.toolName.contains(query, ignoreCase = true)
        }.take(limit)

        override suspend fun getById(id: Long): AuditLogEntryEntity? = rows.find { it.id == id }
        override suspend fun count(): Int = rows.size
        override suspend fun deleteBeyondNewest(keepCount: Int): Int {
            val keep = rows.sortedByDescending { it.timestampMillis }.take(keepCount)
                .map { it.id }.toSet()
            val removed = rows.count { it.id !in keep }
            rows.removeAll { it.id !in keep }
            return removed
        }
        override suspend fun insert(entry: AuditLogEntryEntity): Long {
            rows.removeAll { it.id == entry.id }
            rows += entry
            return entry.id
        }

        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
        }

        override suspend fun deleteAll() = rows.clear()
        override suspend fun markUndone(id: Long) = Unit
    }

    private class FakeSettingsPort(var settings: JarvisSettings = JarvisSettings()) : BackupSettingsPort {
        override suspend fun current(): JarvisSettings = settings
        override suspend fun replace(settings: JarvisSettings) {
            this.settings = settings
        }
    }

    /** A transaction runner that snapshots every table and restores it on failure. */
    private class SnapshotTransactionRunner(private val db: FakeDb) : TransactionRunner {
        override suspend fun <T> run(block: suspend () -> T): T {
            val snapshots = db.snapshot()
            return try {
                block()
            } catch (e: Exception) {
                db.restore(snapshots)
                throw e
            }
        }
    }

    private class FakeDb {
        val taskDao = FakeTaskDao()
        val noteDao = FakeNoteDao()
        val macroDao = FakeMacroDao()
        val draftDao = FakeDraftDao()
        val researchDao = FakeResearchDao()
        val memoryDao = FakeMemoryDao()
        val scheduledPostDao = FakeScheduledPostDao()
        val focusSessionDao = FakeFocusSessionDao()
        val auditLogDao = FakeAuditLogDao()
        val settingsPort = FakeSettingsPort()
        val trustedStore = InMemoryTrustedActionStore()
        val service = BackupService(
            taskDao = taskDao,
            noteDao = noteDao,
            macroDao = macroDao,
            draftDao = draftDao,
            researchDao = researchDao,
            memoryDao = memoryDao,
            scheduledPostDao = scheduledPostDao,
            focusSessionDao = focusSessionDao,
            auditLogDao = auditLogDao,
            settingsPort = settingsPort,
            trustedStore = trustedStore,
            transactionRunner = SnapshotTransactionRunner(this),
        )

        data class Snapshot(
            val tasks: List<TaskEntity>,
            val notes: List<NoteEntity>,
            val macros: List<MacroEntity>,
            val drafts: List<ContentDraftEntity>,
            val research: List<ResearchEntity>,
            val memory: List<MemoryItem>,
            val posts: List<ScheduledPostEntity>,
            val focus: List<FocusSessionEntity>,
            val audit: List<AuditLogEntryEntity>,
        )

        fun snapshot() = Snapshot(
            tasks = taskDao.rows.toList(),
            notes = noteDao.rows.toList(),
            macros = macroDao.rows.toList(),
            drafts = draftDao.rows.toList(),
            research = researchDao.rows.toList(),
            memory = memoryDao.rows.toList(),
            posts = scheduledPostDao.rows.toList(),
            focus = focusSessionDao.rows.toList(),
            audit = auditLogDao.rows.toList(),
        )

        fun restore(snapshot: Snapshot) {
            taskDao.rows.clear(); taskDao.rows += snapshot.tasks
            noteDao.rows.clear(); noteDao.rows += snapshot.notes
            macroDao.rows.clear(); macroDao.rows += snapshot.macros
            draftDao.rows.clear(); draftDao.rows += snapshot.drafts
            researchDao.rows.clear(); researchDao.rows += snapshot.research
            memoryDao.rows.clear(); memoryDao.rows += snapshot.memory
            scheduledPostDao.rows.clear(); scheduledPostDao.rows += snapshot.posts
            focusSessionDao.rows.clear(); focusSessionDao.rows += snapshot.focus
            auditLogDao.rows.clear(); auditLogDao.rows += snapshot.audit
        }
    }

    private fun taskEntity(id: Long, title: String) = TaskEntity(
        id = id,
        title = title,
        priority = "MEDIUM",
        status = "OPEN",
        createdAtMillis = 1000,
        updatedAtMillis = 1000,
    )

    private fun noteEntity(id: Long, title: String) = NoteEntity(
        id = id,
        title = title,
        body = "body $title",
        createdAtMillis = 1000,
        updatedAtMillis = 1000,
    )

    @Test
    fun `export then import round-trips the data into an empty database`() = runBlocking {
        val source = FakeDb()
        source.taskDao.rows += taskEntity(1, "Buy milk")
        source.noteDao.rows += noteEntity(2, "Groceries")
        source.macroDao.rows += MacroEntity(id = 3, name = "Morning", stepsJson = "[]", createdAtMillis = 1000)
        source.settingsPort.settings = JarvisSettings(themeMode = ThemeMode.DARK)
        source.trustedStore.trust("get_time")

        val data = source.service.export()
        val target = FakeDb()
        val result = target.service.import(data)
        assertTrue(result is JarvisResult.Success)
        assertEquals("Buy milk", target.taskDao.rows.single().title)
        assertEquals("Groceries", target.noteDao.rows.single().title)
        assertEquals("Morning", target.macroDao.rows.single().name)
        assertEquals(ThemeMode.DARK, target.settingsPort.settings.themeMode)
        assertTrue(target.trustedStore.isTrusted("get_time"))
    }

    @Test
    fun `import skips existing ids and never overwrites`() = runBlocking {
        val db = FakeDb()
        db.taskDao.rows += taskEntity(1, "Current title")
        val data = BackupData(
            tasks = listOf(
                BackupTask(
                    id = 1, title = "Old title from backup", priority = "MEDIUM",
                    status = "OPEN", createdAtMillis = 1000, updatedAtMillis = 1000,
                ),
                BackupTask(
                    id = 2, title = "New task", priority = "LOW",
                    status = "OPEN", createdAtMillis = 1000, updatedAtMillis = 1000,
                ),
            ),
        )
        val result = db.service.import(data)
        assertTrue(result is JarvisResult.Success)
        val report = (result as JarvisResult.Success).value
        assertEquals(1, report.imported["Tasks"])
        assertEquals(1, report.skipped["Tasks"])
        assertEquals("Current title", db.taskDao.getById(1)?.title)
        assertEquals("New task", db.taskDao.getById(2)?.title)
    }

    @Test
    fun `preview counts new vs skipped per section without writing`() = runBlocking {
        val db = FakeDb()
        db.noteDao.rows += noteEntity(5, "Existing")
        val data = BackupData(
            notes = listOf(
                BackupNote(id = 5, title = "Existing", body = "b", createdAtMillis = 1, updatedAtMillis = 1),
                BackupNote(id = 6, title = "New", body = "b", createdAtMillis = 1, updatedAtMillis = 1),
            ),
            tasks = listOf(
                BackupTask(
                    id = 1, title = "T", priority = "MEDIUM", status = "OPEN",
                    createdAtMillis = 1, updatedAtMillis = 1,
                ),
            ),
        )
        val preview = db.service.preview(data)
        val notes = preview.sections.single { it.section == "Notes" }
        assertEquals(2, notes.incoming)
        assertEquals(1, notes.toImport)
        assertEquals(1, notes.skipped)
        val tasks = preview.sections.single { it.section == "Tasks" }
        assertEquals(1, tasks.toImport)
        assertEquals(0, tasks.skipped)
        // Preview wrote nothing.
        assertEquals(1, db.noteDao.rows.size)
        assertEquals(0, db.taskDao.rows.size)
    }

    @Test
    fun `a restored scheduled post comes back cancelled, history keeps its status`() = runBlocking {
        val db = FakeDb()
        val scheduled = BackupScheduledPost(
            id = 1, draftId = 9, platform = "X", accountHandle = "@zaid",
            scheduledAtMillis = 9_999_999_999L, contentHash = "abc", status = "SCHEDULED",
            createdAtMillis = 1, updatedAtMillis = 1,
        )
        val history = scheduled.copy(id = 2, status = "PUBLISHED", postUrl = "https://x.example/1")
        val result = db.service.import(
            BackupData(scheduledPosts = listOf(scheduled), scheduledPostHistory = listOf(history)),
        )
        assertTrue(result is JarvisResult.Success)
        assertEquals(1, (result as JarvisResult.Success).value.cancelledScheduledPosts)
        val restored = db.scheduledPostDao.getById(1)
        assertEquals("CANCELLED", restored?.status)
        assertTrue(restored?.failureReason?.contains("not resumed") == true)
        assertEquals("PUBLISHED", db.scheduledPostDao.getById(2)?.status)
    }

    @Test
    fun `a running focus session comes back cancelled`() = runBlocking {
        val db = FakeDb()
        val result = db.service.import(
            BackupData(
                focusSessions = listOf(
                    BackupFocusSession(
                        id = 1, startedAtMillis = 1000, durationMinutes = 25,
                        status = "RUNNING",
                    ),
                    BackupFocusSession(
                        id = 2, startedAtMillis = 1000, durationMinutes = 25,
                        endedAtMillis = 2000, status = "COMPLETED",
                    ),
                ),
            ),
        )
        assertTrue(result is JarvisResult.Success)
        assertEquals("CANCELLED", db.focusSessionDao.getById(1)?.status)
        assertEquals("COMPLETED", db.focusSessionDao.getById(2)?.status)
    }

    @Test
    fun `a macro with a colliding name is skipped even with a new id`() = runBlocking {
        val db = FakeDb()
        db.macroDao.rows += MacroEntity(id = 1, name = "Morning", stepsJson = "[]", createdAtMillis = 1000)
        val result = db.service.import(
            BackupData(
                macros = listOf(
                    BackupMacro(id = 99, name = "morning", stepsJson = "[]", createdAtMillis = 1000),
                    BackupMacro(id = 100, name = "Evening", stepsJson = "[]", createdAtMillis = 1000),
                ),
            ),
        )
        assertTrue(result is JarvisResult.Success)
        val report = (result as JarvisResult.Success).value
        assertEquals(1, report.imported["Macros"])
        assertEquals(1, report.skipped["Macros"])
        assertEquals(2, db.macroDao.rows.size)
        assertEquals("Evening", db.macroDao.getById(100)?.name)
    }

    @Test
    fun `imported tasks with future reminders are listed for re-enqueue`() = runBlocking {
        val db = FakeDb()
        val now = 10_000L
        val result = db.service.import(
            BackupData(
                tasks = listOf(
                    BackupTask(
                        id = 1, title = "Future", priority = "MEDIUM", status = "OPEN",
                        reminderAtMillis = now + 60_000, createdAtMillis = 1, updatedAtMillis = 1,
                    ),
                    BackupTask(
                        id = 2, title = "Past", priority = "MEDIUM", status = "OPEN",
                        reminderAtMillis = now - 60_000, createdAtMillis = 1, updatedAtMillis = 1,
                    ),
                    BackupTask(
                        id = 3, title = "No reminder", priority = "MEDIUM", status = "OPEN",
                        createdAtMillis = 1, updatedAtMillis = 1,
                    ),
                ),
            ),
            nowMillis = now,
        )
        assertTrue(result is JarvisResult.Success)
        val reminders = (result as JarvisResult.Success).value.remindersToReschedule
        assertEquals(listOf(1L), reminders.map { it.id })
        // The reminder time survives import; the WorkManager job id does not.
        assertEquals(now + 60_000, db.taskDao.getById(1)?.reminderAtMillis)
        assertEquals(null, db.taskDao.getById(1)?.reminderWorkId)
    }

    @Test
    fun `a failure mid-import leaves the database unchanged`() = runBlocking {
        val db = FakeDb()
        db.taskDao.rows += taskEntity(7, "Pre-existing")
        db.noteDao.failOnUpsert = true
        val data = BackupData(
            tasks = listOf(
                BackupTask(
                    id = 8, title = "Would import first", priority = "MEDIUM",
                    status = "OPEN", createdAtMillis = 1, updatedAtMillis = 1,
                ),
            ),
            notes = listOf(
                BackupNote(id = 9, title = "Boom", body = "b", createdAtMillis = 1, updatedAtMillis = 1),
            ),
        )
        val result = db.service.import(data)
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("Nothing was changed"))
        // The task written before the failure was rolled back.
        assertEquals(listOf(7L), db.taskDao.rows.map { it.id })
        assertEquals(0, db.noteDao.rows.size)
        // Settings were not replaced either (applied only after the transaction).
        assertEquals(JarvisSettings(), db.settingsPort.settings)
    }

    @Test
    fun `export JSON contains no secret field names`() = runBlocking {
        val db = FakeDb()
        db.taskDao.rows += taskEntity(1, "Call the bank about my password reset")
        db.noteDao.rows += noteEntity(2, "My secret recipe")
        val json = BackupFormat.encode(db.service.export(), "0.10.0-phase10", 12345L)
        assertTrue(BackupFormat.secretFieldNamesPresent(json).isEmpty())
        // And the round-trip still works through the file format.
        val decoded = BackupFormat.decode(json)
        assertTrue(decoded is JarvisResult.Success)
    }

    @Test
    fun `export splits scheduled posts from history`() = runBlocking {
        val db = FakeDb()
        db.scheduledPostDao.rows += ScheduledPostEntity(
            id = 1, draftId = 1, platform = "X", accountHandle = "@zaid",
            scheduledAtMillis = 9999, contentHash = "a", status = "SCHEDULED",
            createdAtMillis = 1, updatedAtMillis = 1,
        )
        db.scheduledPostDao.rows += ScheduledPostEntity(
            id = 2, draftId = 2, platform = "X", accountHandle = "@zaid",
            scheduledAtMillis = 9999, contentHash = "b", status = "PUBLISHED",
            postUrl = "https://x.example/2", createdAtMillis = 1, updatedAtMillis = 1,
        )
        val data = db.service.export()
        assertEquals(listOf(1L), data.scheduledPosts.map { it.id })
        assertEquals(listOf(2L), data.scheduledPostHistory.map { it.id })
    }
}
