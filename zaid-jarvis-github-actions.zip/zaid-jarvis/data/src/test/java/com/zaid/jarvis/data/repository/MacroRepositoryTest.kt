package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.automation.Macro
import com.zaid.jarvis.core.automation.MacroAction
import com.zaid.jarvis.core.automation.MacroStep
import com.zaid.jarvis.core.automation.NodeSelector
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.db.MacroDao
import com.zaid.jarvis.data.db.MacroEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Macro CRUD through [MacroRepository] with an in-memory fake DAO
 * (no Room database on the JVM test classpath).
 */
class MacroRepositoryTest {

    private class FakeMacroDao : MacroDao {
        private val items = mutableListOf<MacroEntity>()
        private val flow = MutableStateFlow<List<MacroEntity>>(emptyList())
        private var nextId = 1L

        private fun refresh() {
            flow.value = items.sortedBy { it.name.lowercase() }
        }

        override fun observeAll(limit: Int): Flow<List<MacroEntity>> = flow.map { it.take(limit) }

        override suspend fun getAll(): List<MacroEntity> = items.toList()

        override suspend fun getAllIds(): List<Long> = items.map { it.id }

        override fun observeCount(): Flow<Int> = flow.map { it.size }

        override suspend fun getByName(name: String): MacroEntity? =
            items.firstOrNull { it.name.equals(name, ignoreCase = true) }

        override suspend fun getById(id: Long): MacroEntity? =
            items.firstOrNull { it.id == id }

        override suspend fun upsert(entity: MacroEntity): Long {
            return if (entity.id == 0L) {
                val saved = entity.copy(id = nextId++)
                items += saved
                refresh()
                saved.id
            } else {
                items.removeAll { it.id == entity.id }
                items += entity
                refresh()
                entity.id
            }
        }

        override suspend fun markRun(id: Long, timestampMillis: Long) {
            val index = items.indexOfFirst { it.id == id }
            if (index >= 0) {
                items[index] = items[index].copy(lastRunAtMillis = timestampMillis)
                refresh()
            }
        }

        override suspend fun deleteById(id: Long) {
            items.removeAll { it.id == id }
            refresh()
        }

        override suspend fun deleteAll() {
            items.clear()
            refresh()
        }

        override suspend fun count(): Int = items.size
    }

    private val tap = MacroStep(MacroAction.TAP, NodeSelector(text = "Search"))
    private val type = MacroStep(
        MacroAction.TYPE_TEXT,
        NodeSelector(viewId = "com.example:id/box"),
        text = "hello",
    )

    @Test
    fun `save and getByName round-trips steps as JSON`() = runBlocking {
        val repo = MacroRepository(FakeMacroDao())
        val id = repo.save(Macro(name = "Morning", steps = listOf(tap, type)))
        assertTrue(id is JarvisResult.Success)
        val loaded = repo.getByName("morning") // Case-insensitive.
        assertEquals("Morning", loaded?.name)
        assertEquals(listOf(tap, type), loaded?.steps)
        assertEquals((id as JarvisResult.Success).value, loaded?.id)
    }

    @Test
    fun `observeAll lists macros alphabetically`() = runBlocking {
        val repo = MacroRepository(FakeMacroDao())
        repo.save(Macro(name = "Zebra", steps = listOf(tap)))
        repo.save(Macro(name = "Apple", steps = listOf(tap)))
        val names = repo.observeAll().first().map { it.name }
        assertEquals(listOf("Apple", "Zebra"), names)
    }

    @Test
    fun `a duplicate name is refused`() = runBlocking {
        val repo = MacroRepository(FakeMacroDao())
        repo.save(Macro(name = "Morning", steps = listOf(tap)))
        val result = repo.save(Macro(name = "morning", steps = listOf(tap)))
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("already exists"))
        assertEquals(1, repo.count())
    }

    @Test
    fun `an invalid macro is refused and not stored`() = runBlocking {
        val repo = MacroRepository(FakeMacroDao())
        val result = repo.save(Macro(name = "Empty", steps = emptyList()))
        assertTrue(result is JarvisResult.Failure)
        assertEquals(0, repo.count())
    }

    @Test
    fun `rename works and enforces uniqueness`() = runBlocking {
        val repo = MacroRepository(FakeMacroDao())
        val id = (repo.save(Macro(name = "Old", steps = listOf(tap))) as JarvisResult.Success).value
        repo.save(Macro(name = "Taken", steps = listOf(tap)))
        assertTrue(repo.rename(id, "New") is JarvisResult.Success)
        assertEquals("New", repo.getById(id)?.name)
        val conflict = repo.rename(id, "Taken")
        assertTrue(conflict is JarvisResult.Failure)
        assertEquals("New", repo.getById(id)?.name)
    }

    @Test
    fun `delete removes the macro and markRun records the run time`() = runBlocking {
        val repo = MacroRepository(FakeMacroDao())
        val id = (repo.save(Macro(name = "M", steps = listOf(tap))) as JarvisResult.Success).value
        assertNull(repo.getById(id)?.lastRunAtMillis)
        repo.markRun(id)
        assertTrue((repo.getById(id)?.lastRunAtMillis ?: 0L) > 0L)
        repo.delete(id)
        assertNull(repo.getById(id))
        assertEquals(0, repo.count())
    }

    @Test
    fun `deleteAll clears everything`() = runBlocking {
        val repo = MacroRepository(FakeMacroDao())
        repo.save(Macro(name = "A", steps = listOf(tap)))
        repo.save(Macro(name = "B", steps = listOf(tap)))
        repo.deleteAll()
        assertEquals(0, repo.count())
        assertTrue(repo.observeAll().first().isEmpty())
    }
}
