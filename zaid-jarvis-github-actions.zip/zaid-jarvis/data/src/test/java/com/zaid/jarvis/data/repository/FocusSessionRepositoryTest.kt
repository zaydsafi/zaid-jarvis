package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.productivity.FocusSession
import com.zaid.jarvis.core.productivity.FocusSessionStatus
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.db.FocusSessionDao
import com.zaid.jarvis.data.db.FocusSessionEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Focus-session repository (Phase 9) with a fake DAO. */
class FocusSessionRepositoryTest {

    private class FakeFocusSessionDao : FocusSessionDao {
        val rows = mutableListOf<FocusSessionEntity>()
        private var nextId = 1L

        override fun observeAll(limit: Int): Flow<List<FocusSessionEntity>> =
            flowOf(rows.sortedByDescending { it.startedAtMillis }.take(limit))
        override suspend fun getAll(): List<FocusSessionEntity> =
            rows.sortedByDescending { it.startedAtMillis }

        override suspend fun getAllIds(): List<Long> = rows.map { it.id }

        override suspend fun getRecent(limit: Int): List<FocusSessionEntity> =
            rows.sortedByDescending { it.startedAtMillis }.take(limit)

        override suspend fun getById(id: Long): FocusSessionEntity? = rows.find { it.id == id }
        override suspend fun getRunning(): FocusSessionEntity? =
            rows.filter { it.status == FocusSessionStatus.RUNNING.name }
                .maxByOrNull { it.startedAtMillis }

        override suspend fun upsert(entity: FocusSessionEntity): Long {
            return if (entity.id == 0L) {
                val id = nextId++
                rows += entity.copy(id = id)
                id
            } else {
                rows.removeAll { it.id == entity.id }
                rows += entity
                entity.id
            }
        }

        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
        }

        override suspend fun deleteAll() = rows.clear()
    }

    private fun session(startedAtMillis: Long = 1_700_000_000_000L) = FocusSession(
        startedAtMillis = startedAtMillis,
        durationMinutes = 25,
        previousDndMode = "OFF",
    )

    @Test
    fun `save stores a session and getRunning finds it`() = runBlocking {
        val repository = FocusSessionRepository(FakeFocusSessionDao())
        assertNull(repository.getRunning())
        val id = (repository.save(session()) as JarvisResult.Success).value
        assertTrue(id > 0)
        assertEquals(id, repository.getRunning()?.id)
        assertEquals("OFF", repository.getRunning()?.previousDndMode)
    }

    @Test
    fun `finish completes a running session and is idempotent`() = runBlocking {
        val repository = FocusSessionRepository(FakeFocusSessionDao())
        val id = (repository.save(session()) as JarvisResult.Success).value
        // First finish wins (the service or the worker — whichever is first).
        assertTrue(repository.finish(id, FocusSessionStatus.COMPLETED, 1_700_000_100_000L))
        assertEquals(FocusSessionStatus.COMPLETED, repository.getById(id)?.status)
        assertEquals(1_700_000_100_000L, repository.getById(id)?.endedAtMillis)
        // Second finish is a no-op — DND must not be restored twice.
        assertFalse(repository.finish(id, FocusSessionStatus.COMPLETED, 1_700_000_200_000L))
        assertEquals(1_700_000_100_000L, repository.getById(id)?.endedAtMillis)
        assertNull(repository.getRunning())
    }

    @Test
    fun `finish on an unknown id returns false`() = runBlocking {
        val repository = FocusSessionRepository(FakeFocusSessionDao())
        assertFalse(repository.finish(99L, FocusSessionStatus.CANCELLED, 0L))
    }

    @Test
    fun `an unknown status string maps to CANCELLED, never RUNNING`() = runBlocking {
        val dao = FakeFocusSessionDao()
        dao.rows += FocusSessionEntity(
            id = 1,
            startedAtMillis = 1_700_000_000_000L,
            durationMinutes = 25,
            status = "PAUSED",
        )
        val repository = FocusSessionRepository(dao)
        assertEquals(FocusSessionStatus.CANCELLED, repository.getById(1L)?.status)
        assertNull(repository.getRunning())
    }

    @Test
    fun `getRecent returns newest first, capped`() = runBlocking {
        val repository = FocusSessionRepository(FakeFocusSessionDao())
        repository.save(session(1_700_000_000_000L))
        repository.save(session(1_700_000_100_000L))
        repository.save(session(1_700_000_200_000L))
        val recent = repository.getRecent(2)
        assertEquals(2, recent.size)
        assertEquals(1_700_000_200_000L, recent[0].startedAtMillis)
        assertEquals(1_700_000_100_000L, recent[1].startedAtMillis)
    }

    @Test
    fun `setEndWorkId records the worker id`() = runBlocking {
        val repository = FocusSessionRepository(FakeFocusSessionDao())
        val id = (repository.save(session()) as JarvisResult.Success).value
        repository.setEndWorkId(id, "work-uuid-9")
        assertEquals("work-uuid-9", repository.getById(id)?.endWorkId)
    }
}
