package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.productivity.TaskStatus
import com.zaid.jarvis.data.db.AnalyticsEventDao
import com.zaid.jarvis.data.db.AnalyticsEventEntity
import com.zaid.jarvis.data.db.AuditLogDao
import com.zaid.jarvis.data.db.AuditLogEntryEntity
import com.zaid.jarvis.data.db.FocusSessionDao
import com.zaid.jarvis.data.db.FocusSessionEntity
import com.zaid.jarvis.data.db.ListLimits
import com.zaid.jarvis.data.db.MacroDao
import com.zaid.jarvis.data.db.MacroEntity
import com.zaid.jarvis.data.db.MemoryDao
import com.zaid.jarvis.data.db.MemoryItem
import com.zaid.jarvis.data.db.NoteDao
import com.zaid.jarvis.data.db.NoteEntity
import com.zaid.jarvis.data.db.ScheduledPostDao
import com.zaid.jarvis.data.db.ScheduledPostEntity
import com.zaid.jarvis.data.db.TaskDao
import com.zaid.jarvis.data.db.TaskEntity
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * List caps (Phase 11): every list query Jarvis runs is bounded.
 * These tests assert, via recording fake DAOs, that the repositories
 * pass the documented caps to SQL — and that the reads that used to
 * load a whole table and filter in memory (focus history, the planner
 * memory summary, task filters) now filter in SQL.
 */
class ListLimitsTest {

    // ── Recording fakes (only the methods under test are implemented) ──

    private class RecordingAuditLogDao : AuditLogDao {
        var observeAllLimit: Int? = null
        var searchLimit: Int? = null

        override fun observeAll(limit: Int): Flow<List<AuditLogEntryEntity>> {
            observeAllLimit = limit
            return flowOf(emptyList())
        }

        override suspend fun search(query: String, limit: Int): List<AuditLogEntryEntity> {
            searchLimit = limit
            return emptyList()
        }

        override suspend fun getAll(): List<AuditLogEntryEntity> = TODO()
        override suspend fun getAllIds(): List<Long> = TODO()
        override suspend fun getById(id: Long): AuditLogEntryEntity? = TODO()
        override suspend fun count(): Int = TODO()
        override suspend fun deleteBeyondNewest(keepCount: Int): Int = TODO()
        override suspend fun insert(entry: AuditLogEntryEntity): Long = TODO()
        override suspend fun deleteById(id: Long) = TODO()
        override suspend fun deleteAll() = TODO()
        override suspend fun markUndone(id: Long) = TODO()
    }

    private class RecordingAnalyticsDao : AnalyticsEventDao {
        var getSinceLimit: Int? = null

        override suspend fun getSince(sinceMillis: Long, limit: Int): List<AnalyticsEventEntity> {
            getSinceLimit = limit
            return emptyList()
        }

        override suspend fun insert(event: AnalyticsEventEntity): Long = TODO()
        override suspend fun count(): Int = TODO()
        override suspend fun deleteOlderThan(cutoffMillis: Long): Int = TODO()
        override suspend fun deleteAll() = TODO()
    }

    private class RecordingTaskDao(private val rowCount: Int = 0) : TaskDao {
        var getAllCalls: Int = 0
        var getOpenLimit: Int? = null
        var getOverdueArgs: Pair<Long, Int>? = null
        var getDueBetweenArgs: Triple<Long, Long, Int>? = null

        override suspend fun getAll(): List<TaskEntity> {
            getAllCalls++
            return (1..rowCount).map {
                TaskEntity(
                    id = it.toLong(),
                    title = "Task $it",
                    priority = "MEDIUM",
                    status = TaskStatus.OPEN.name,
                    createdAtMillis = 1L,
                    updatedAtMillis = 1L,
                )
            }
        }

        override suspend fun getOpen(limit: Int): List<TaskEntity> {
            getOpenLimit = limit
            return emptyList()
        }

        override suspend fun getOverdue(nowMillis: Long, limit: Int): List<TaskEntity> {
            getOverdueArgs = nowMillis to limit
            return emptyList()
        }

        override suspend fun getDueBetween(
            startMillis: Long,
            endMillis: Long,
            limit: Int,
        ): List<TaskEntity> {
            getDueBetweenArgs = Triple(startMillis, endMillis, limit)
            return emptyList()
        }

        override fun observeAll(limit: Int): Flow<List<TaskEntity>> = TODO()
        override suspend fun getAllIds(): List<Long> = TODO()
        override suspend fun getById(id: Long): TaskEntity? = TODO()
        override suspend fun upsert(entity: TaskEntity): Long = TODO()
        override suspend fun deleteById(id: Long) = TODO()
        override suspend fun deleteAll() = TODO()
        override suspend fun count(): Int = TODO()
    }

    private class RecordingFocusDao : FocusSessionDao {
        var getAllCalls: Int = 0
        var getRecentLimit: Int? = null

        override suspend fun getAll(): List<FocusSessionEntity> {
            getAllCalls++
            return emptyList()
        }

        override suspend fun getRecent(limit: Int): List<FocusSessionEntity> {
            getRecentLimit = limit
            return emptyList()
        }

        override fun observeAll(limit: Int): Flow<List<FocusSessionEntity>> = TODO()
        override suspend fun getAllIds(): List<Long> = TODO()
        override suspend fun getById(id: Long): FocusSessionEntity? = TODO()
        override suspend fun getRunning(): FocusSessionEntity? = TODO()
        override suspend fun upsert(entity: FocusSessionEntity): Long = TODO()
        override suspend fun deleteById(id: Long) = TODO()
        override suspend fun deleteAll() = TODO()
    }

    private class RecordingMemoryDao : MemoryDao {
        var searchLimit: Int? = null

        override suspend fun search(query: String, limit: Int): List<MemoryItem> {
            searchLimit = limit
            return emptyList()
        }

        override fun observeAll(limit: Int): Flow<List<MemoryItem>> = TODO()
        override suspend fun getAll(): List<MemoryItem> = TODO()
        override suspend fun getAllIds(): List<Long> = TODO()
        override suspend fun getByKind(kind: String, limit: Int): List<MemoryItem> = TODO()
        override suspend fun upsert(item: MemoryItem): Long = TODO()
        override suspend fun deleteById(id: Long) = TODO()
        override suspend fun deleteAll() = TODO()
    }

    private class RecordingNoteDao(private val rowCount: Int) : NoteDao {
        override suspend fun getAll(): List<NoteEntity> =
            (1..rowCount).map {
                NoteEntity(
                    id = it.toLong(),
                    title = "Note $it",
                    body = "body",
                    createdAtMillis = 1L,
                    updatedAtMillis = 1L,
                )
            }

        override fun observeAll(limit: Int): Flow<List<NoteEntity>> = TODO()
        override suspend fun getAllIds(): List<Long> = TODO()
        override suspend fun getById(id: Long): NoteEntity? = TODO()
        override suspend fun search(query: String, limit: Int): List<NoteEntity> = TODO()
        override suspend fun upsert(entity: NoteEntity): Long = TODO()
        override suspend fun deleteById(id: Long) = TODO()
        override suspend fun deleteAll() = TODO()
        override suspend fun count(): Int = TODO()
    }

    private class RecordingScheduledPostDao(private val rowCount: Int) : ScheduledPostDao {
        override suspend fun getAll(): List<ScheduledPostEntity> =
            (1..rowCount).map {
                ScheduledPostEntity(
                    id = it.toLong(),
                    draftId = 1L,
                    platform = "X",
                    accountHandle = "zaid",
                    scheduledAtMillis = 1L,
                    contentHash = "hash",
                    status = "SCHEDULED",
                    createdAtMillis = 1L,
                    updatedAtMillis = 1L,
                )
            }

        override fun observeAll(limit: Int): Flow<List<ScheduledPostEntity>> = TODO()
        override suspend fun getAllIds(): List<Long> = TODO()
        override suspend fun getById(id: Long): ScheduledPostEntity? = TODO()
        override suspend fun upsert(entity: ScheduledPostEntity): Long = TODO()
        override suspend fun deleteById(id: Long) = TODO()
        override suspend fun deleteAll() = TODO()
        override suspend fun count(): Int = TODO()
    }

    private class RecordingMacroDao : MacroDao {
        var observeAllCalls: Int = 0
        var observeCountCalls: Int = 0

        override fun observeAll(limit: Int): Flow<List<MacroEntity>> {
            observeAllCalls++
            return flowOf(emptyList())
        }

        override fun observeCount(): Flow<Int> {
            observeCountCalls++
            return flowOf(7)
        }

        override suspend fun getAll(): List<MacroEntity> = TODO()
        override suspend fun getAllIds(): List<Long> = TODO()
        override suspend fun getByName(name: String): MacroEntity? = TODO()
        override suspend fun getById(id: Long): MacroEntity? = TODO()
        override suspend fun upsert(entity: MacroEntity): Long = TODO()
        override suspend fun markRun(id: Long, timestampMillis: Long) = TODO()
        override suspend fun deleteById(id: Long) = TODO()
        override suspend fun deleteAll() = TODO()
        override suspend fun count(): Int = TODO()
    }

    // ── The caps ──

    @Test
    fun `audit log list is capped at 1000 rows`() = runBlocking {
        val dao = RecordingAuditLogDao()
        RoomAuditLog(dao).observeAll().first()
        assertEquals(ListLimits.AUDIT_LOG_LIST, dao.observeAllLimit)
        assertEquals(1_000, dao.observeAllLimit)
    }

    @Test
    fun `audit log search is capped at 500 rows`() = runBlocking {
        val dao = RecordingAuditLogDao()
        RoomAuditLog(dao).search("volume")
        assertEquals(ListLimits.AUDIT_LOG_SEARCH, dao.searchLimit)
        assertEquals(500, dao.searchLimit)
    }

    @Test
    fun `analytics events are capped at 10000 rows per range`() = runBlocking {
        val dao = RecordingAnalyticsDao()
        AnalyticsRepository(dao) { true }.eventsSince(0L)
        assertEquals(ListLimits.ANALYTICS_EVENTS, dao.getSinceLimit)
        assertEquals(10_000, dao.getSinceLimit)
    }

    @Test
    fun `task bulk reads are capped at 5000 rows`() = runBlocking {
        val repository = TaskRepository(RecordingTaskDao(rowCount = 6_000))
        assertEquals(ListLimits.TASK_BULK, repository.getAll().size)
        assertEquals(5_000, repository.getAll().size)
    }

    @Test
    fun `note bulk reads are capped at 5000 rows`() = runBlocking {
        val repository = NoteRepository(RecordingNoteDao(rowCount = 6_000))
        assertEquals(5_000, repository.getAll().size)
    }

    @Test
    fun `scheduled-post bulk reads are capped at 5000 rows`() = runBlocking {
        val repository = ScheduledPostRepository(RecordingScheduledPostDao(rowCount = 6_000))
        assertEquals(5_000, repository.getAll().size)
    }

    // ── SQL filtering (regressions: these used to load the whole table) ──

    @Test
    fun `focus history reads the limit in SQL instead of loading all sessions`() = runBlocking {
        val dao = RecordingFocusDao()
        FocusSessionRepository(dao).getRecent(20)
        assertEquals(20, dao.getRecentLimit)
        assertEquals(0, dao.getAllCalls)
    }

    @Test
    fun `planner memory summary reads only maxItems rows in SQL`() = runBlocking {
        val dao = RecordingMemoryDao()
        MemoryRepository(dao).summaryForPrompt(maxItems = 10)
        assertEquals(10, dao.searchLimit)
    }

    @Test
    fun `open tasks are filtered in SQL`() = runBlocking {
        val dao = RecordingTaskDao()
        TaskRepository(dao).getOpen()
        assertEquals(ListLimits.TASK_FILTERED, dao.getOpenLimit)
        assertEquals(0, dao.getAllCalls)
    }

    @Test
    fun `overdue tasks are filtered in SQL`() = runBlocking {
        val dao = RecordingTaskDao()
        val now = 1_800_000_000_000L
        TaskRepository(dao).getOverdue(now)
        assertEquals(now to ListLimits.TASK_FILTERED, dao.getOverdueArgs)
        assertEquals(0, dao.getAllCalls)
    }

    @Test
    fun `due-today tasks are filtered in SQL with day boundaries`() = runBlocking {
        val dao = RecordingTaskDao()
        // 2026-06-15T12:00:00Z — no DST transition anywhere near it.
        val now = 1_781_510_400_000L
        TaskRepository(dao).getDueToday(now)
        val (start, end, limit) = dao.getDueBetweenArgs
            ?: error("getDueBetween was not called")
        val zone = ZoneId.systemDefault()
        val today = LocalDate.ofInstant(Instant.ofEpochMilli(now), zone)
        assertEquals(today.atStartOfDay(zone).toInstant().toEpochMilli(), start)
        assertEquals(today.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli(), end)
        assertEquals(24L * 60L * 60L * 1000L, end - start)
        assertTrue(start <= now && now < end)
        assertEquals(ListLimits.TASK_FILTERED, limit)
        assertEquals(0, dao.getAllCalls)
    }

    @Test
    fun `macro count does not load any rows`() = runBlocking {
        val dao = RecordingMacroDao()
        val count = MacroRepository(dao).observeCount().first()
        assertEquals(7, count)
        assertEquals(1, dao.observeCountCalls)
        assertEquals(0, dao.observeAllCalls)
        assertFalse(dao.observeAllCalls > 0)
    }
}
