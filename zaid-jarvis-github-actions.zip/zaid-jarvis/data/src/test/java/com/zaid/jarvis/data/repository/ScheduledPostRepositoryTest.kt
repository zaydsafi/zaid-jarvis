package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.social.ScheduledPost
import com.zaid.jarvis.core.social.ScheduledPostStatus
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.db.ScheduledPostDao
import com.zaid.jarvis.data.db.ScheduledPostEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Scheduled-post repository (Phase 8) with a fake DAO. */
class ScheduledPostRepositoryTest {

    private class FakeScheduledPostDao : ScheduledPostDao {
        val rows = mutableListOf<ScheduledPostEntity>()
        private var nextId = 1L

        override fun observeAll(limit: Int): Flow<List<ScheduledPostEntity>> =
            flowOf(rows.sortedByDescending { it.scheduledAtMillis }.take(limit))
        override suspend fun getAll(): List<ScheduledPostEntity> = rows.toList()
        override suspend fun getAllIds(): List<Long> = rows.map { it.id }
        override suspend fun getById(id: Long): ScheduledPostEntity? = rows.find { it.id == id }
        override suspend fun upsert(entity: ScheduledPostEntity): Long {
            return if (entity.id == 0L) {
                val id = nextId++
                rows += entity.copy(id = id)
                id
            } else {
                rows.removeAll { it.id == entity.id }
                rows += entity
                entity.id
            }
        }

        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
        }

        override suspend fun deleteAll() = rows.clear()
        override suspend fun count(): Int = rows.size
    }

    private fun post(
        platform: SocialPlatform = SocialPlatform.X,
        status: ScheduledPostStatus = ScheduledPostStatus.SCHEDULED,
        imageUrl: String? = null,
    ) = ScheduledPost(
        draftId = 5L,
        platform = platform,
        accountHandle = "zaid",
        scheduledAtMillis = 1_700_000_000_000L,
        contentHash = "abc123",
        imageUrl = imageUrl,
        status = status,
    )

    @Test
    fun `save stores a post and returns its id`() = runBlocking {
        val repository = ScheduledPostRepository(FakeScheduledPostDao())
        val result = repository.save(post())
        assertTrue(result is JarvisResult.Success)
        val id = (result as JarvisResult.Success).value
        assertTrue(id > 0)
        val saved = repository.getById(id)
        assertEquals(5L, saved?.draftId)
        assertEquals(SocialPlatform.X, saved?.platform)
        assertEquals("abc123", saved?.contentHash)
        assertEquals(ScheduledPostStatus.SCHEDULED, saved?.status)
    }

    @Test
    fun `save preserves the image URL`() = runBlocking {
        val dao = FakeScheduledPostDao()
        val repository = ScheduledPostRepository(dao)
        val id = (repository.save(post(imageUrl = "https://example.com/p.jpg")) as JarvisResult.Success).value
        assertEquals("https://example.com/p.jpg", repository.getById(id)?.imageUrl)
    }

    @Test
    fun `updateStatus changes the status and records the reason`() = runBlocking {
        val repository = ScheduledPostRepository(FakeScheduledPostDao())
        val id = (repository.save(post()) as JarvisResult.Success).value
        val result = repository.updateStatus(
            id,
            ScheduledPostStatus.FAILED,
            failureReason = "X is down.",
        )
        assertTrue(result is JarvisResult.Success)
        val updated = repository.getById(id)
        assertEquals(ScheduledPostStatus.FAILED, updated?.status)
        assertEquals("X is down.", updated?.failureReason)
    }

    @Test
    fun `updateStatus records the post URL on success`() = runBlocking {
        val repository = ScheduledPostRepository(FakeScheduledPostDao())
        val id = (repository.save(post()) as JarvisResult.Success).value
        repository.updateStatus(
            id,
            ScheduledPostStatus.PUBLISHED,
            postUrl = "https://x.com/zaid/status/1",
        )
        val updated = repository.getById(id)
        assertEquals(ScheduledPostStatus.PUBLISHED, updated?.status)
        assertEquals("https://x.com/zaid/status/1", updated?.postUrl)
    }

    @Test
    fun `updateStatus on an unknown id fails`() = runBlocking {
        val repository = ScheduledPostRepository(FakeScheduledPostDao())
        val result = repository.updateStatus(99L, ScheduledPostStatus.CANCELLED)
        assertTrue(result is JarvisResult.Failure)
    }

    @Test
    fun `an unknown status string maps to CANCELLED, never to SCHEDULED`() = runBlocking {
        val dao = FakeScheduledPostDao()
        dao.rows += ScheduledPostEntity(
            id = 1,
            draftId = 5,
            platform = "X",
            accountHandle = "zaid",
            scheduledAtMillis = 1_700_000_000_000L,
            contentHash = "abc",
            status = "BOGUS_STATUS",
            createdAtMillis = 0L,
            updatedAtMillis = 0L,
        )
        val repository = ScheduledPostRepository(dao)
        assertEquals(ScheduledPostStatus.CANCELLED, repository.getById(1L)?.status)
    }

    @Test
    fun `an unknown platform name skips the row`() = runBlocking {
        val dao = FakeScheduledPostDao()
        dao.rows += ScheduledPostEntity(
            id = 1,
            draftId = 5,
            platform = "TIKTOK",
            accountHandle = "zaid",
            scheduledAtMillis = 1_700_000_000_000L,
            contentHash = "abc",
            status = "SCHEDULED",
            createdAtMillis = 0L,
            updatedAtMillis = 0L,
        )
        val repository = ScheduledPostRepository(dao)
        assertNull(repository.getById(1L))
        assertTrue(repository.getAll().isEmpty())
    }

    @Test
    fun `work request id is stored and read back`() = runBlocking {
        val repository = ScheduledPostRepository(FakeScheduledPostDao())
        val id = (repository.save(post()) as JarvisResult.Success).value
        assertNull(repository.workRequestIdFor(id))
        repository.setWorkRequestId(id, "work-uuid-1")
        assertEquals("work-uuid-1", repository.workRequestIdFor(id))
    }

    @Test
    fun `delete removes the row`() = runBlocking {
        val repository = ScheduledPostRepository(FakeScheduledPostDao())
        val id = (repository.save(post()) as JarvisResult.Success).value
        repository.deleteById(id)
        assertNull(repository.getById(id))
    }
}
