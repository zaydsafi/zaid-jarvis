package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.db.NoteDao
import com.zaid.jarvis.data.db.NoteEntity
import com.zaid.jarvis.plugins.notes.Note
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Notes repository (Phase 10) with a fake DAO. */
class NoteRepositoryTest {

    private class FakeNoteDao : NoteDao {
        val rows = mutableListOf<NoteEntity>()
        private var nextId = 1L

        override fun observeAll(limit: Int): Flow<List<NoteEntity>> =
            flowOf(rows.sortedByDescending { it.updatedAtMillis }.take(limit))
        override suspend fun getAll(): List<NoteEntity> = rows.toList()
        override suspend fun getAllIds(): List<Long> = rows.map { it.id }
        override suspend fun getById(id: Long): NoteEntity? = rows.find { it.id == id }
        override suspend fun search(query: String, limit: Int): List<NoteEntity> = rows.filter {
            it.title.contains(query, ignoreCase = true) ||
                it.body.contains(query, ignoreCase = true)
        }.take(limit)

        override suspend fun upsert(entity: NoteEntity): Long {
            return if (entity.id == 0L) {
                val id = nextId++
                rows += entity.copy(id = id)
                id
            } else {
                rows.removeAll { it.id == entity.id }
                rows += entity
                entity.id
            }
        }

        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
        }

        override suspend fun deleteAll() = rows.clear()
        override suspend fun count(): Int = rows.size
    }

    @Test
    fun `save stores a note and returns its id`() = runBlocking {
        val repository = NoteRepository(FakeNoteDao())
        val result = repository.save(Note(title = "Groceries", body = "Milk, eggs"))
        assertTrue(result is JarvisResult.Success)
        val id = (result as JarvisResult.Success).value
        assertTrue(id > 0)
        assertEquals("Groceries", repository.getById(id)?.title)
        assertEquals("Milk, eggs", repository.getById(id)?.body)
    }

    @Test
    fun `save refuses a blank title or body`() = runBlocking {
        val repository = NoteRepository(FakeNoteDao())
        assertTrue(repository.save(Note(title = "  ", body = "text")) is JarvisResult.Failure)
        assertTrue(repository.save(Note(title = "T", body = "  ")) is JarvisResult.Failure)
        assertEquals(0, repository.count())
    }

    @Test
    fun `saving an existing note updates it`() = runBlocking {
        val repository = NoteRepository(FakeNoteDao())
        val id = (repository.save(Note(title = "Old", body = "old")) as JarvisResult.Success).value
        repository.save(Note(id = id, title = "New", body = "new"))
        assertEquals(1, repository.count())
        assertEquals("New", repository.getById(id)?.title)
    }

    @Test
    fun `search matches title and body`() = runBlocking {
        val repository = NoteRepository(FakeNoteDao())
        repository.save(Note(title = "Shopping", body = "buy milk"))
        repository.save(Note(title = "Ideas", body = "treehouse"))
        val found = repository.search("MILK")
        assertEquals(1, found.size)
        assertEquals("Shopping", found.single().title)
    }

    @Test
    fun `delete removes the note`() = runBlocking {
        val repository = NoteRepository(FakeNoteDao())
        val id = (repository.save(Note(title = "Temp", body = "x")) as JarvisResult.Success).value
        repository.deleteById(id)
        assertNull(repository.getById(id))
        assertEquals(0, repository.count())
    }
}
