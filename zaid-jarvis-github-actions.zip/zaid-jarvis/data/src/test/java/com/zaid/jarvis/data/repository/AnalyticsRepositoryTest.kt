package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.analytics.AnalyticsEvents
import com.zaid.jarvis.data.db.AnalyticsEventDao
import com.zaid.jarvis.data.db.AnalyticsEventEntity
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Analytics repository (Phase 10): opt-out respected, invalid payloads dropped. */
class AnalyticsRepositoryTest {

    private class FakeAnalyticsEventDao : AnalyticsEventDao {
        val rows = mutableListOf<AnalyticsEventEntity>()
        private var nextId = 1L

        override suspend fun insert(event: AnalyticsEventEntity): Long {
            val id = nextId++
            rows += event.copy(id = id)
            return id
        }

        override suspend fun getSince(sinceMillis: Long, limit: Int): List<AnalyticsEventEntity> =
            rows.filter { it.timestampMillis >= sinceMillis }
                .sortedByDescending { it.timestampMillis }
                .take(limit)

        override suspend fun count(): Int = rows.size

        override suspend fun deleteOlderThan(cutoffMillis: Long): Int {
            val removed = rows.count { it.timestampMillis < cutoffMillis }
            rows.removeAll { it.timestampMillis < cutoffMillis }
            return removed
        }

        override suspend fun deleteAll() = rows.clear()
    }

    @Test
    fun `a valid event is recorded`() = runBlocking {
        val dao = FakeAnalyticsEventDao()
        val repository = AnalyticsRepository(dao) { true }
        repository.record(
            AnalyticsEvents.TOOL_EXECUTED,
            mapOf("tool" to "get_time", "tier" to "READ_ONLY", "outcome" to "success"),
        )
        assertEquals(1, repository.count())
        val event = repository.eventsSince(0).single()
        assertEquals(AnalyticsEvents.TOOL_EXECUTED, event.eventName)
        assertEquals("get_time", event.payload["tool"])
    }

    @Test
    fun `nothing is recorded when insights are off`() = runBlocking {
        val dao = FakeAnalyticsEventDao()
        val repository = AnalyticsRepository(dao) { false }
        repository.record(
            AnalyticsEvents.TOOL_EXECUTED,
            mapOf("tool" to "get_time", "tier" to "READ_ONLY", "outcome" to "success"),
        )
        assertEquals(0, repository.count())
    }

    @Test
    fun `a free-text payload is dropped, never recorded`() = runBlocking {
        val dao = FakeAnalyticsEventDao()
        val repository = AnalyticsRepository(dao) { true }
        repository.record(
            AnalyticsEvents.TOOL_EXECUTED,
            mapOf("tool" to "call mom now", "tier" to "READ_ONLY", "outcome" to "success"),
        )
        assertEquals(0, repository.count())
    }

    @Test
    fun `an unknown event name is dropped`() = runBlocking {
        val dao = FakeAnalyticsEventDao()
        val repository = AnalyticsRepository(dao) { true }
        repository.record("message_sent", mapOf("text" to "hello"))
        assertEquals(0, repository.count())
    }

    @Test
    fun `eventsSince returns only events in range, newest first`() = runBlocking {
        val dao = FakeAnalyticsEventDao()
        dao.insert(
            AnalyticsEventEntity(
                eventName = AnalyticsEvents.TOOL_EXECUTED,
                timestampMillis = 1000,
                payloadJson = """{"tool":"get_time","tier":"READ_ONLY","outcome":"success"}""",
            ),
        )
        dao.insert(
            AnalyticsEventEntity(
                eventName = AnalyticsEvents.TOOL_EXECUTED,
                timestampMillis = 2000,
                payloadJson = """{"tool":"calculator","tier":"READ_ONLY","outcome":"success"}""",
            ),
        )
        val repository = AnalyticsRepository(dao) { true }
        val events = repository.eventsSince(1500)
        assertEquals(1, events.size)
        assertEquals("calculator", events.single().payload["tool"])
    }

    @Test
    fun `clearAll wipes the events table`() = runBlocking {
        val dao = FakeAnalyticsEventDao()
        val repository = AnalyticsRepository(dao) { true }
        repository.record(
            AnalyticsEvents.PUBLISH,
            mapOf("platform" to "X", "outcome" to "success"),
        )
        assertEquals(1, repository.count())
        repository.clearAll()
        assertEquals(0, repository.count())
    }

    @Test
    fun `pruneOlderThan deletes only events before the cutoff`() = runBlocking {
        val dao = FakeAnalyticsEventDao()
        dao.insert(
            AnalyticsEventEntity(
                eventName = AnalyticsEvents.TOOL_EXECUTED,
                timestampMillis = 1000,
                payloadJson = """{"tool":"get_time","tier":"READ_ONLY","outcome":"success"}""",
            ),
        )
        dao.insert(
            AnalyticsEventEntity(
                eventName = AnalyticsEvents.TOOL_EXECUTED,
                timestampMillis = 2000,
                payloadJson = """{"tool":"calculator","tier":"READ_ONLY","outcome":"success"}""",
            ),
        )
        val repository = AnalyticsRepository(dao) { true }
        assertEquals(1, repository.pruneOlderThan(1500))
        assertEquals(1, repository.count())
        assertEquals("calculator", repository.eventsSince(0).single().payload["tool"])
    }
}
