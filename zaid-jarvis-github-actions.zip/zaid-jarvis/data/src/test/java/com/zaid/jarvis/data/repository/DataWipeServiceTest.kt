package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.repository.DataWipeService.WipeStep
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Delete-all-data coordination (Phase 11) with fake wipe steps: every
 * store's clear is called, in order, and a failing store is reported
 * honestly instead of stopping the wipe or being hidden.
 */
class DataWipeServiceTest {

    @Test
    fun `wipe runs every step in order`() = runBlocking {
        val order = mutableListOf<String>()
        val service = DataWipeService(
            listOf(
                WipeStep("Database") { order += "Database" },
                WipeStep("Settings") { order += "Settings" },
                WipeStep("Secrets") { order += "Secrets" },
                WipeStep("Files") { order += "Files" },
            ),
        )
        val result = service.wipeAll()
        assertTrue(result is JarvisResult.Success)
        assertEquals(listOf("Database", "Settings", "Secrets", "Files"), order)
        val report = (result as JarvisResult.Success).value
        assertEquals(listOf("Database", "Settings", "Secrets", "Files"), report.wiped)
        assertTrue(report.failed.isEmpty())
    }

    @Test
    fun `the database step runs before the secrets step`() = runBlocking {
        // Order is part of the contract: the database file must be
        // deleted while the passphrase still exists (see
        // DataWipeService). This test pins the production order as
        // assembled in AppModule.
        val order = mutableListOf<String>()
        val service = DataWipeService(
            listOf(
                WipeStep("Database") { order += "Database" },
                WipeStep("Settings") { order += "Settings" },
                WipeStep("Proactive state") { order += "Proactive state" },
                WipeStep("Plugin state") { order += "Plugin state" },
                WipeStep("Trusted actions") { order += "Trusted actions" },
                WipeStep("Last answer") { order += "Last answer" },
                WipeStep("Social accounts") { order += "Social accounts" },
                WipeStep("API keys") { order += "API keys" },
                WipeStep("Secrets") { order += "Secrets" },
                WipeStep("Files") { order += "Files" },
            ),
        )
        service.wipeAll()
        assertTrue(order.indexOf("Database") < order.indexOf("Secrets"))
        assertTrue(order.indexOf("API keys") < order.indexOf("Secrets"))
        assertEquals(10, order.size)
    }

    @Test
    fun `one failing step does not stop the others and is reported`() = runBlocking {
        val ran = mutableListOf<String>()
        val service = DataWipeService(
            listOf(
                WipeStep("Database") { ran += "Database" },
                WipeStep("Settings") { throw IllegalStateException("DataStore unavailable") },
                WipeStep("Secrets") { ran += "Secrets" },
            ),
        )
        val result = service.wipeAll()
        // The later step still ran.
        assertEquals(listOf("Database", "Secrets"), ran)
        // But the wipe as a whole failed, naming the broken store.
        assertTrue(result is JarvisResult.Failure)
        val message = (result as JarvisResult.Failure).message
        assertTrue(message.contains("Settings"))
    }

    @Test
    fun `a wipe with no steps succeeds`() = runBlocking {
        val result = DataWipeService(emptyList()).wipeAll()
        assertTrue(result is JarvisResult.Success)
    }
}
