package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.productivity.Task
import com.zaid.jarvis.core.productivity.TaskPriority
import com.zaid.jarvis.core.productivity.TaskStatus
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.data.db.TaskDao
import com.zaid.jarvis.data.db.TaskEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Task repository (Phase 9) with a fake DAO. */
class TaskRepositoryTest {

    private class FakeTaskDao : TaskDao {
        val rows = mutableListOf<TaskEntity>()
        private var nextId = 1L

        override fun observeAll(limit: Int): Flow<List<TaskEntity>> =
            flowOf(rows.sortedByDescending { it.updatedAtMillis }.take(limit))
        override suspend fun getAll(): List<TaskEntity> = rows.toList()
        override suspend fun getAllIds(): List<Long> = rows.map { it.id }
        override suspend fun getById(id: Long): TaskEntity? = rows.find { it.id == id }
        override suspend fun getOpen(limit: Int): List<TaskEntity> =
            rows.filter { it.status != TaskStatus.DONE.name }
                .sortedWith(
                    compareBy<TaskEntity> { it.dueAtMillis ?: Long.MAX_VALUE }
                        .thenBy { it.updatedAtMillis },
                ).take(limit)

        override suspend fun getOverdue(nowMillis: Long, limit: Int): List<TaskEntity> =
            rows.filter {
                val due = it.dueAtMillis
                it.status != TaskStatus.DONE.name && due != null && due < nowMillis
            }.sortedBy { it.dueAtMillis }.take(limit)

        override suspend fun getDueBetween(
            startMillis: Long,
            endMillis: Long,
            limit: Int,
        ): List<TaskEntity> =
            rows.filter {
                val due = it.dueAtMillis
                it.status != TaskStatus.DONE.name && due != null &&
                    due >= startMillis && due < endMillis
            }.sortedBy { it.dueAtMillis }.take(limit)
        override suspend fun upsert(entity: TaskEntity): Long {
            return if (entity.id == 0L) {
                val id = nextId++
                rows += entity.copy(id = id)
                id
            } else {
                rows.removeAll { it.id == entity.id }
                rows += entity
                entity.id
            }
        }

        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
        }

        override suspend fun deleteAll() = rows.clear()
        override suspend fun count(): Int = rows.size
    }

    private fun task(
        title: String = "Buy milk",
        dueAtMillis: Long? = null,
        priority: TaskPriority = TaskPriority.MEDIUM,
        status: TaskStatus = TaskStatus.OPEN,
    ) = Task(
        title = title,
        dueAtMillis = dueAtMillis,
        priority = priority,
        status = status,
    )

    @Test
    fun `save stores a task and returns its id`() = runBlocking {
        val repository = TaskRepository(FakeTaskDao())
        val result = repository.save(task())
        assertTrue(result is JarvisResult.Success)
        val id = (result as JarvisResult.Success).value
        assertTrue(id > 0)
        val saved = repository.getById(id)
        assertEquals("Buy milk", saved?.title)
        assertEquals(TaskPriority.MEDIUM, saved?.priority)
        assertEquals(TaskStatus.OPEN, saved?.status)
    }

    @Test
    fun `save refuses a blank title`() = runBlocking {
        val repository = TaskRepository(FakeTaskDao())
        val result = repository.save(task(title = "   "))
        assertTrue(result is JarvisResult.Failure)
    }

    @Test
    fun `complete marks a task done`() = runBlocking {
        val repository = TaskRepository(FakeTaskDao())
        val id = (repository.save(task()) as JarvisResult.Success).value
        val result = repository.complete(id)
        assertTrue(result is JarvisResult.Success)
        assertEquals(TaskStatus.DONE, (result as JarvisResult.Success).value.status)
        assertEquals(TaskStatus.DONE, repository.getById(id)?.status)
    }

    @Test
    fun `complete on an unknown id fails`() = runBlocking {
        val repository = TaskRepository(FakeTaskDao())
        assertTrue(repository.complete(99L) is JarvisResult.Failure)
    }

    @Test
    fun `getOverdue returns only open tasks past their due time`() = runBlocking {
        val repository = TaskRepository(FakeTaskDao())
        val now = System.currentTimeMillis()
        repository.save(task(title = "overdue", dueAtMillis = now - 1000))
        repository.save(task(title = "future", dueAtMillis = now + 100_000))
        repository.save(task(title = "undated"))
        val doneId = (repository.save(task(title = "done overdue", dueAtMillis = now - 1000))
            as JarvisResult.Success).value
        repository.complete(doneId)
        val overdue = repository.getOverdue(now)
        assertEquals(listOf("overdue"), overdue.map { it.title })
    }

    @Test
    fun `getOpen sorts earliest due first, undated last`() = runBlocking {
        val repository = TaskRepository(FakeTaskDao())
        val now = System.currentTimeMillis()
        repository.save(task(title = "undated"))
        repository.save(task(title = "later", dueAtMillis = now + 200_000))
        repository.save(task(title = "sooner", dueAtMillis = now + 100_000))
        val open = repository.getOpen()
        assertEquals(listOf("sooner", "later", "undated"), open.map { it.title })
    }

    @Test
    fun `setReminder and clearReminder round-trip`() = runBlocking {
        val repository = TaskRepository(FakeTaskDao())
        val id = (repository.save(task()) as JarvisResult.Success).value
        val reminded = repository.setReminder(id, 1_700_000_000_000L, "work-1")
        assertTrue(reminded is JarvisResult.Success)
        assertEquals(1_700_000_000_000L, repository.getById(id)?.reminderAtMillis)
        assertEquals("work-1", repository.getById(id)?.reminderWorkId)
        repository.clearReminder(id)
        assertNull(repository.getById(id)?.reminderAtMillis)
        assertNull(repository.getById(id)?.reminderWorkId)
    }

    @Test
    fun `markOverdueNotified records the day`() = runBlocking {
        val repository = TaskRepository(FakeTaskDao())
        val id = (repository.save(task()) as JarvisResult.Success).value
        repository.markOverdueNotified(id, 20_000L)
        assertEquals(20_000L, repository.getById(id)?.overdueNotifiedDay)
    }

    @Test
    fun `unknown priority and status strings map to safe defaults`() = runBlocking {
        val dao = FakeTaskDao()
        dao.rows += TaskEntity(
            id = 1,
            title = "mystery",
            priority = "CRITICAL",
            status = "ARCHIVED",
            createdAtMillis = 0L,
            updatedAtMillis = 0L,
        )
        val repository = TaskRepository(dao)
        val loaded = repository.getById(1L)
        assertEquals(TaskPriority.MEDIUM, loaded?.priority)
        assertEquals(TaskStatus.OPEN, loaded?.status)
    }

    @Test
    fun `delete removes the row`() = runBlocking {
        val repository = TaskRepository(FakeTaskDao())
        val id = (repository.save(task()) as JarvisResult.Success).value
        repository.deleteById(id)
        assertNull(repository.getById(id))
    }
}
