package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.confirmation.AuditDecision
import com.zaid.jarvis.core.confirmation.AuditEntry
import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.data.db.AuditLogDao
import com.zaid.jarvis.data.db.AuditLogEntryEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Audit-log persistence through [RoomAuditLog] with an in-memory fake
 * DAO (no Room database on the JVM test classpath). Covers the Phase 5
 * undo-data round-trip: the JSON payload a tool captured at execution
 * must survive the entity mapping unchanged.
 */
class RoomAuditLogTest {

    private class FakeAuditLogDao : AuditLogDao {
        private val rows = mutableListOf<AuditLogEntryEntity>()
        private val flow = MutableStateFlow<List<AuditLogEntryEntity>>(emptyList())
        private var nextId = 1L

        private fun refresh() {
            flow.value = rows.sortedByDescending { it.timestampMillis }
        }

        override fun observeAll(limit: Int): Flow<List<AuditLogEntryEntity>> =
            flow.map { it.take(limit) }

        override suspend fun getAll(): List<AuditLogEntryEntity> = rows.toList()

        override suspend fun getAllIds(): List<Long> = rows.map { it.id }

        override suspend fun search(query: String, limit: Int): List<AuditLogEntryEntity> =
            rows.filter {
                it.toolName.contains(query, ignoreCase = true) ||
                    it.action.contains(query, ignoreCase = true)
            }.sortedByDescending { it.timestampMillis }.take(limit)

        override suspend fun getById(id: Long): AuditLogEntryEntity? =
            rows.firstOrNull { it.id == id }

        override suspend fun count(): Int = rows.size

        override suspend fun deleteBeyondNewest(keepCount: Int): Int {
            val sorted = rows.sortedWith(
                compareByDescending<AuditLogEntryEntity> { it.timestampMillis }
                    .thenByDescending { it.id },
            )
            val keep = sorted.take(keepCount).map { it.id }.toSet()
            val removed = rows.count { it.id !in keep }
            rows.removeAll { it.id !in keep }
            refresh()
            return removed
        }

        override suspend fun insert(entry: AuditLogEntryEntity): Long {
            val saved = entry.copy(id = nextId++)
            rows += saved
            refresh()
            return saved.id
        }

        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
            refresh()
        }

        override suspend fun deleteAll() {
            rows.clear()
            refresh()
        }

        override suspend fun markUndone(id: Long) {
            val index = rows.indexOfFirst { it.id == id }
            if (index >= 0) {
                rows[index] = rows[index].copy(undone = true)
                refresh()
            }
        }
    }

    private fun entry() = AuditEntry(
        timestampMillis = 1_000L,
        toolName = "set_volume",
        tier = RiskTier.REVERSIBLE,
        action = "Set the volume",
        target = "set_volume",
        paramsSummary = "{\"stream\":\"media\",\"level\":7}",
        decision = AuditDecision.ALLOWED,
        resultSummary = "OK: Media volume set to 7/15 (was 4/15).",
        undoable = true,
        undoDescription = "Restore media volume to 4/15.",
        undoData = "{\"stream\":\"MUSIC\",\"previousLevel\":4}",
        undone = false,
    )

    @Test
    fun `undo data round-trips through the entity mapping`() = runBlocking {
        val log = RoomAuditLog(FakeAuditLogDao())
        val id = log.record(entry())
        val loaded = log.get(id)
        assertEquals("{\"stream\":\"MUSIC\",\"previousLevel\":4}", loaded?.undoData)
        assertEquals("Restore media volume to 4/15.", loaded?.undoDescription)
        assertTrue(loaded?.undoable == true)
        assertFalse(loaded?.undone == true)
    }

    @Test
    fun `markUndone flips only the undone flag`() = runBlocking {
        val log = RoomAuditLog(FakeAuditLogDao())
        val id = log.record(entry())
        log.markUndone(id)
        val loaded = log.get(id)
        assertTrue(loaded?.undone == true)
        assertEquals("{\"stream\":\"MUSIC\",\"previousLevel\":4}", loaded?.undoData)
        assertTrue(loaded?.undoable == true)
    }

    @Test
    fun `a non-undoable entry has null undo data`() = runBlocking {
        val log = RoomAuditLog(FakeAuditLogDao())
        val id = log.record(entry().copy(undoable = false, undoDescription = null, undoData = null))
        val loaded = log.get(id)
        assertFalse(loaded?.undoable == true)
        assertNull(loaded?.undoData)
    }

    @Test
    fun `search and delete still work`() = runBlocking {
        val log = RoomAuditLog(FakeAuditLogDao())
        val id = log.record(entry())
        assertEquals(1, log.search("volume").size)
        assertTrue(log.search("nothing").isEmpty())
        log.delete(id)
        assertTrue(log.observeAll().first().isEmpty())
    }

    @Test
    fun `pruneToNewest keeps only the newest entries`() = runBlocking {
        val log = RoomAuditLog(FakeAuditLogDao())
        repeat(5) { i ->
            log.record(entry().copy(timestampMillis = 1_000L + i, toolName = "tool_$i"))
        }
        assertEquals(5, log.count())
        assertEquals(2, log.pruneToNewest(3))
        assertEquals(3, log.count())
        val remaining = log.observeAll().first()
        assertEquals(listOf("tool_4", "tool_3", "tool_2"), remaining.map { it.toolName })
    }

    @Test
    fun `pruneToNewest deletes nothing when the table is within the cap`() = runBlocking {
        val log = RoomAuditLog(FakeAuditLogDao())
        log.record(entry())
        assertEquals(0, log.pruneToNewest(10_000))
        assertEquals(1, log.count())
    }
}
