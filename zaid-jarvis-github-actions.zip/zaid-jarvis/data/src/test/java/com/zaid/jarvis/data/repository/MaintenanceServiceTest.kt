package com.zaid.jarvis.data.repository

import com.zaid.jarvis.data.db.RetentionPolicy
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Data maintenance (Phase 11) with fake pruners: the weekly prune
 * deletes analytics events older than 90 days, trims the audit log
 * to its newest 10,000 entries, and reports what it did — one failing
 * step never stops the other.
 */
class MaintenanceServiceTest {

    private class FakeAnalyticsPruner(
        var fail: Boolean = false,
    ) : AnalyticsPruner {
        var lastCutoff: Long? = null
        var deleted: Int = 0

        override suspend fun pruneOlderThan(cutoffMillis: Long): Int {
            if (fail) throw IllegalStateException("simulated analytics failure")
            lastCutoff = cutoffMillis
            return deleted
        }
    }

    private class FakeAuditLogPruner(
        var fail: Boolean = false,
    ) : AuditLogPruner {
        var lastKeepCount: Int? = null
        var deleted: Int = 0
        var remaining: Int = 0

        override suspend fun pruneToNewest(keepCount: Int): Int {
            if (fail) throw IllegalStateException("simulated audit failure")
            lastKeepCount = keepCount
            return deleted
        }

        override suspend fun count(): Int = remaining
    }

    @Test
    fun `prune deletes analytics older than 90 days`() = runBlocking {
        val analytics = FakeAnalyticsPruner()
        val audit = FakeAuditLogPruner()
        val service = MaintenanceService(analytics, audit)
        val now = 1_800_000_000_000L
        service.prune(now)
        assertEquals(now - 90L * 24L * 60L * 60L * 1000L, analytics.lastCutoff)
        assertEquals(RetentionPolicy.analyticsCutoffMillis(now), analytics.lastCutoff)
    }

    @Test
    fun `prune keeps the newest 10000 audit entries`() = runBlocking {
        val analytics = FakeAnalyticsPruner()
        val audit = FakeAuditLogPruner()
        val service = MaintenanceService(analytics, audit)
        service.prune(1_800_000_000_000L)
        assertEquals(10_000, audit.lastKeepCount)
        assertEquals(RetentionPolicy.AUDIT_LOG_KEEP_COUNT, audit.lastKeepCount)
    }

    @Test
    fun `report counts deletions and remaining audit rows`() = runBlocking {
        val analytics = FakeAnalyticsPruner().apply { deleted = 42 }
        val audit = FakeAuditLogPruner().apply {
            deleted = 7
            remaining = 10_000
        }
        val service = MaintenanceService(analytics, audit)
        val report = service.prune(1_800_000_000_000L)
        assertEquals(42, report.analyticsDeleted)
        assertEquals(7, report.auditDeleted)
        assertEquals(10_000, report.auditRemaining)
        assertTrue(report.failures.isEmpty())
    }

    @Test
    fun `a failing analytics prune does not stop the audit prune`() = runBlocking {
        val analytics = FakeAnalyticsPruner(fail = true)
        val audit = FakeAuditLogPruner().apply { deleted = 3 }
        val service = MaintenanceService(analytics, audit)
        val report = service.prune(1_800_000_000_000L)
        assertEquals(3, report.auditDeleted)
        assertEquals(listOf("analytics"), report.failures)
    }

    @Test
    fun `a failing audit prune is reported and analytics still runs`() = runBlocking {
        val analytics = FakeAnalyticsPruner().apply { deleted = 11 }
        val audit = FakeAuditLogPruner(fail = true)
        val service = MaintenanceService(analytics, audit)
        val report = service.prune(1_800_000_000_000L)
        assertEquals(11, report.analyticsDeleted)
        assertEquals(listOf("audit log"), report.failures)
    }

    @Test
    fun `prune never throws even when both steps fail`() = runBlocking {
        val service = MaintenanceService(
            FakeAnalyticsPruner(fail = true),
            FakeAuditLogPruner(fail = true),
        )
        val report = service.prune(1_800_000_000_000L)
        assertEquals(listOf("analytics", "audit log"), report.failures)
    }
}
