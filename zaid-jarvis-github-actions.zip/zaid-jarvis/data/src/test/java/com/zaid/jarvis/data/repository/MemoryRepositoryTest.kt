package com.zaid.jarvis.data.repository

import com.zaid.jarvis.data.db.MemoryDao
import com.zaid.jarvis.data.db.MemoryItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Memory CRUD through [MemoryRepository] with an in-memory fake DAO
 * (no Room database on the JVM test classpath).
 */
class MemoryRepositoryTest {

    private class FakeMemoryDao : MemoryDao {
        private val items = mutableListOf<MemoryItem>()
        private val flow = MutableStateFlow<List<MemoryItem>>(emptyList())
        private var nextId = 1L

        private fun refresh() {
            flow.value = items.sortedByDescending { it.updatedAtMillis }
        }

        override fun observeAll(limit: Int): Flow<List<MemoryItem>> = flow.map { it.take(limit) }

        override suspend fun getAll(): List<MemoryItem> = items.toList()

        override suspend fun getAllIds(): List<Long> = items.map { it.id }

        override suspend fun search(query: String, limit: Int): List<MemoryItem> =
            items.filter {
                it.kind.contains(query, ignoreCase = true) ||
                    it.key.contains(query, ignoreCase = true) ||
                    it.value.contains(query, ignoreCase = true)
            }.sortedByDescending { it.updatedAtMillis }.take(limit)

        override suspend fun getByKind(kind: String, limit: Int): List<MemoryItem> =
            items.filter { it.kind == kind }.take(limit)

        override suspend fun upsert(item: MemoryItem): Long {
            return if (item.id == 0L) {
                val saved = item.copy(id = nextId++)
                items += saved
                refresh()
                saved.id
            } else {
                items.removeAll { it.id == item.id }
                items += item
                refresh()
                item.id
            }
        }

        override suspend fun deleteById(id: Long) {
            items.removeAll { it.id == id }
            refresh()
        }

        override suspend fun deleteAll() {
            items.clear()
            refresh()
        }
    }

    private fun repository(): Pair<MemoryRepository, FakeMemoryDao> {
        val dao = FakeMemoryDao()
        return MemoryRepository(dao) to dao
    }

    @Test
    fun `save then observe returns the item`() = runBlocking {
        val (repo, _) = repository()
        repo.save(MemoryItem(kind = "preference", key = "coffee", value = "black, no sugar"))
        val items = repo.observeAll().first()
        assertEquals(1, items.size)
        assertEquals("black, no sugar", items[0].value)
    }

    @Test
    fun `save with an existing id updates the item`() = runBlocking {
        val (repo, _) = repository()
        val id = repo.save(MemoryItem(kind = "nickname", key = "brother", value = "Ali"))
        repo.save(MemoryItem(id = id, kind = "nickname", key = "brother", value = "Ahmad"))
        val items = repo.observeAll().first()
        assertEquals(1, items.size)
        assertEquals("Ahmad", items[0].value)
    }

    @Test
    fun `search finds by value`() = runBlocking {
        val (repo, _) = repository()
        repo.save(MemoryItem(kind = "preference", key = "coffee", value = "black"))
        repo.save(MemoryItem(kind = "preference", key = "tea", value = "green"))
        val found = repo.search("green")
        assertEquals(1, found.size)
        assertEquals("tea", found[0].key)
    }

    @Test
    fun `delete removes one item, deleteAll removes everything`() = runBlocking {
        val (repo, _) = repository()
        val id = repo.save(MemoryItem(kind = "a", key = "k1", value = "v1"))
        repo.save(MemoryItem(kind = "a", key = "k2", value = "v2"))
        repo.delete(id)
        assertEquals(1, repo.observeAll().first().size)
        repo.deleteAll()
        assertTrue(repo.observeAll().first().isEmpty())
    }

    @Test
    fun `summaryForPrompt is empty with no memory`() = runBlocking {
        val (repo, _) = repository()
        assertEquals("", repo.summaryForPrompt())
    }

    @Test
    fun `summaryForPrompt lists items one per line`() = runBlocking {
        val (repo, _) = repository()
        repo.save(MemoryItem(kind = "preference", key = "coffee", value = "black"))
        val summary = repo.summaryForPrompt()
        assertTrue(summary.contains("preference / coffee: black"))
    }
}
