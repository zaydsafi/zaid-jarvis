package com.zaid.jarvis.data.repository

import com.zaid.jarvis.core.research.ResearchBrief
import com.zaid.jarvis.core.research.ResearchFact
import com.zaid.jarvis.core.research.ResearchSource
import com.zaid.jarvis.data.db.ResearchDao
import com.zaid.jarvis.data.db.ResearchEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Research repository (Phase 7) with a fake DAO — the brief is stored
 * as JSON, so the round-trip and the unreadable-JSON behaviour matter.
 */
class ResearchRepositoryTest {

    private class FakeResearchDao : ResearchDao {
        val rows = mutableListOf<ResearchEntity>()
        private var nextId = 1L

        override fun observeAll(limit: Int): Flow<List<ResearchEntity>> =
            flowOf(rows.sortedByDescending { it.createdAtMillis }.take(limit))
        override suspend fun getAll(): List<ResearchEntity> = rows.toList()
        override suspend fun getAllIds(): List<Long> = rows.map { it.id }
        override suspend fun getById(id: Long): ResearchEntity? = rows.find { it.id == id }
        override suspend fun insert(entity: ResearchEntity): Long {
            val id = nextId++
            rows += entity.copy(id = id)
            return id
        }

        override suspend fun deleteById(id: Long) {
            rows.removeAll { it.id == id }
        }

        override suspend fun deleteAll() = rows.clear()
        override suspend fun count(): Int = rows.size
    }

    private val brief = ResearchBrief(
        topic = "quantum computing",
        summary = "Quantum computers are getting faster.",
        keyFacts = listOf(
            ResearchFact("A new chip reached 1000 qubits.", "https://example.com/chip"),
        ),
        openQuestions = listOf("When will it be practical?"),
        confidenceNotes = "Sources agree.",
        sources = listOf(ResearchSource("Chip News", "https://example.com/chip")),
    )

    @Test
    fun `save and getById round-trips the brief json`() = runBlocking {
        val dao = FakeResearchDao()
        val repository = ResearchRepository(dao)
        val id = repository.save("quantum computing", brief)

        val record = repository.getById(id)
        assertEquals("quantum computing", record?.topic)
        assertEquals("Quantum computers are getting faster.", record?.brief?.summary)
        assertEquals(1, record?.brief?.keyFacts?.size)
        assertEquals("https://example.com/chip", record?.brief?.keyFacts?.first()?.sourceUrl)
        assertEquals("Sources agree.", record?.brief?.confidenceNotes)
        assertEquals(1, repository.count())
    }

    @Test
    fun `observeAll lists saved records`() = runBlocking {
        val dao = FakeResearchDao()
        val repository = ResearchRepository(dao)
        repository.save("a", brief)
        repository.save("b", brief.copy(topic = "b"))
        // The fake DAO's flow is a snapshot, so observe a fresh repository view.
        val records = ResearchRepository(dao).observeAll().first()
        assertEquals(2, records.size)
    }

    @Test
    fun `unreadable brief json is skipped instead of crashing`() = runBlocking {
        val dao = FakeResearchDao()
        val repository = ResearchRepository(dao)
        val id = dao.insert(
            ResearchEntity(topic = "broken", briefJson = "{not valid json", createdAtMillis = 0L),
        )
        assertNull(repository.getById(id))
        assertTrue(ResearchRepository(dao).observeAll().first().isEmpty())
        // The row can still be deleted.
        repository.delete(id)
        assertEquals(0, repository.count())
    }

    @Test
    fun `delete and deleteAll remove records`() = runBlocking {
        val dao = FakeResearchDao()
        val repository = ResearchRepository(dao)
        val id1 = repository.save("a", brief)
        repository.save("b", brief)
        repository.delete(id1)
        assertEquals(1, repository.count())
        repository.deleteAll()
        assertEquals(0, repository.count())
    }
}
