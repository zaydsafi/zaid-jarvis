#!/usr/bin/env bash
# Zaid Jarvis — generate the release keystore (Phase 12).
#
# Usage: ./scripts/make_keystore.sh
#
# - Prompts for the keystore password and key password (never on the
#   command line, never committed to the repo).
# - Writes release.keystore into the project root (git-ignored).
# - Keep the passwords in a password manager. If they are lost, the app
#   cannot be updated on Google Play under the same signing key.
#
# After generating, create keystore.properties (also git-ignored):
#   storeFile=release.keystore
#   storePassword=<the password you entered>
#   keyAlias=zaid-jarvis
#   keyPassword=<the password you entered>
#
# Phase 1 note: release signing is wired in Phase 12. This script is
# provided now so the workflow exists from the start.

set -euo pipefail

cd "$(dirname "$0")/.."

if [ -f release.keystore ]; then
  echo "release.keystore already exists. Refusing to overwrite."
  echo "Delete it first if you really want a new one (old signatures break)."
  exit 1
fi

read -r -s -p "Keystore password: " STORE_PASS
echo
read -r -s -p "Key password: " KEY_PASS
echo

keytool -genkeypair \
  -keystore release.keystore \
  -alias zaid-jarvis \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000 \
  -storepass "$STORE_PASS" \
  -keypass "$KEY_PASS" \
  -dname "CN=Zaid Jarvis, OU=Personal, O=Zaid, C=US"

echo "Done. release.keystore created (git-ignored)."
echo "Save both passwords in a password manager — they cannot be recovered."
