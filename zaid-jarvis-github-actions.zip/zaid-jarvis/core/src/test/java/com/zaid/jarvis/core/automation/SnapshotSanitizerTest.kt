package com.zaid.jarvis.core.automation

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SnapshotSanitizerTest {

    private val button = ScreenNode(
        text = "Search",
        className = "Button",
        clickable = true,
    )
    private val field = ScreenNode(
        contentDescription = "Search box",
        className = "EditText",
        clickable = true,
        editable = true,
    )
    private val label = ScreenNode(text = "Welcome back", className = "TextView")
    private val passwordField = ScreenNode(
        text = "hunter2-should-never-appear",
        contentDescription = "Password",
        className = "EditText",
        clickable = true,
        editable = true,
        isPassword = true,
    )

    @Test
    fun `format lists interactive nodes numbered with their labels`() {
        val text = SnapshotSanitizer.format(
            ScreenSnapshot("com.example", listOf(button, field, label)),
        )
        assertTrue(text.contains("1. [Button] “Search” (tappable)"))
        assertTrue(text.contains("2. [EditText] “Search box” (tappable, editable)"))
        // Static labels are not interactive: not listed.
        assertFalse(text.contains("Welcome back"))
    }

    @Test
    fun `password nodes are excluded even if one slips into a snapshot`() {
        val text = SnapshotSanitizer.format(
            ScreenSnapshot(
                "com.example",
                listOf(button, passwordField),
                hasPasswordField = true,
            ),
        )
        assertFalse(text.contains("hunter2"))
        assertFalse(text.contains("Password"))
        assertTrue(text.contains("password field"))
    }

    @Test
    fun `long labels are truncated`() {
        val longText = "x".repeat(200)
        val text = SnapshotSanitizer.format(
            ScreenSnapshot("com.example", listOf(ScreenNode(text = longText, className = "Button", clickable = true))),
        )
        assertFalse(text.contains(longText))
        assertTrue(text.contains("…"))
    }

    @Test
    fun `only the first maxNodes nodes are listed and the rest are counted`() {
        val nodes = (1..15).map {
            ScreenNode(text = "Item $it", className = "Button", clickable = true)
        }
        val text = SnapshotSanitizer.format(
            ScreenSnapshot("com.example", nodes),
            maxNodes = 10,
        )
        assertTrue(text.contains("Item 10"))
        assertFalse(text.contains("Item 11"))
        assertTrue(text.contains("5 more element(s)"))
    }

    @Test
    fun `an empty screen says so plainly`() {
        val text = SnapshotSanitizer.format(
            ScreenSnapshot("com.example", listOf(label)),
        )
        assertTrue(text.contains("no tappable or editable elements"))
        assertTrue(text.contains("com.example"))
    }

    @Test
    fun `describeNode shows class label and abilities`() {
        assertTrue(SnapshotSanitizer.describeNode(button).contains("[Button] “Search” (tappable)"))
        assertTrue(
            SnapshotSanitizer.describeNode(field).contains("[EditText] “Search box” (tappable, editable)"),
        )
    }
}
