package com.zaid.jarvis.core.research

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Research brief formatting (Phase 7): citations and sources are always shown. */
class ResearchBriefFormatTest {

    private fun sampleBrief() = ResearchBrief(
        topic = "quantum computing",
        summary = "Quantum computers are getting faster.",
        keyFacts = listOf(
            ResearchFact(
                claim = "A new chip reached 1000 qubits.",
                sourceUrl = "https://example.com/chip",
            ),
            ResearchFact(
                claim = "Error rates dropped 40%.",
                sourceUrl = "https://example.com/errors",
            ),
        ),
        openQuestions = listOf("When will it be practical?"),
        confidenceNotes = "Sources agree on the trend.",
        sources = listOf(
            ResearchSource(title = "Chip News", url = "https://example.com/chip"),
            ResearchSource(title = "Error Report", url = "https://example.com/errors"),
        ),
    )

    @Test
    fun `format includes summary facts with citations and sources`() {
        val text = formatBrief(sampleBrief())
        assertTrue(text.contains("Quantum computers are getting faster."))
        // Facts cite their source by number, bound to the Sources list.
        assertTrue(text.contains("A new chip reached 1000 qubits. [1]"))
        assertTrue(text.contains("Error rates dropped 40%. [2]"))
        assertTrue(text.contains("https://example.com/chip"))
        assertTrue(text.contains("https://example.com/errors"))
        assertTrue(text.contains("When will it be practical?"))
        assertTrue(text.contains("Sources agree on the trend."))
    }

    @Test
    fun `empty brief formats without crashing`() {
        val text = formatBrief(ResearchBrief(topic = "x", summary = "Nothing found."))
        assertTrue(text.contains("Nothing found."))
        assertFalse(text.contains("Key facts"))
    }
}
