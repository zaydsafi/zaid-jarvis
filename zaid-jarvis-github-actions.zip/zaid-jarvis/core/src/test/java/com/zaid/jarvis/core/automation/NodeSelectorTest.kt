package com.zaid.jarvis.core.automation

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NodeSelectorTest {

    private val searchButton = ScreenNode(
        text = "Search",
        contentDescription = "Search the store",
        viewId = "com.example:id/search_button",
        className = "Button",
        clickable = true,
        bounds = NodeBounds(100, 200, 300, 260),
    )

    private val passwordField = ScreenNode(
        text = null,
        contentDescription = "Password",
        viewId = "com.example:id/password",
        className = "EditText",
        clickable = true,
        editable = true,
        isPassword = true,
        bounds = NodeBounds(100, 400, 900, 460),
    )

    @Test
    fun `text matches case-insensitively by substring`() {
        assertTrue(NodeSelector(text = "search").matches(searchButton))
        assertTrue(NodeSelector(text = "EAR").matches(searchButton))
        assertFalse(NodeSelector(text = "settings").matches(searchButton))
    }

    @Test
    fun `content description matches case-insensitively`() {
        assertTrue(NodeSelector(contentDescription = "search the store").matches(searchButton))
        assertTrue(NodeSelector(contentDescription = "STORE").matches(searchButton))
        assertFalse(NodeSelector(contentDescription = "cart").matches(searchButton))
    }

    @Test
    fun `view id must match exactly`() {
        assertTrue(NodeSelector(viewId = "com.example:id/search_button").matches(searchButton))
        assertFalse(NodeSelector(viewId = "search_button").matches(searchButton))
        assertFalse(NodeSelector(viewId = "com.example:id/other").matches(searchButton))
    }

    @Test
    fun `class name matches the simple name`() {
        assertTrue(NodeSelector(className = "Button").matches(searchButton))
        assertFalse(NodeSelector(className = "TextView").matches(searchButton))
    }

    @Test
    fun `coordinates match when the point is inside the bounds`() {
        assertTrue(NodeSelector(x = 200, y = 230).matches(searchButton))
        assertFalse(NodeSelector(x = 50, y = 230).matches(searchButton))
        assertFalse(NodeSelector(x = 200, y = 999).matches(searchButton))
    }

    @Test
    fun `all non-null fields must match`() {
        assertTrue(
            NodeSelector(text = "Search", className = "Button").matches(searchButton),
        )
        assertFalse(
            NodeSelector(text = "Search", className = "TextView").matches(searchButton),
        )
    }

    @Test
    fun `an empty selector matches nothing`() {
        assertFalse(NodeSelector().matches(searchButton))
        assertTrue(NodeSelector().isEmpty)
    }

    @Test
    fun `password nodes never match any selector`() {
        assertFalse(NodeSelector(text = "Password").matches(passwordField))
        assertFalse(NodeSelector(contentDescription = "Password").matches(passwordField))
        assertFalse(NodeSelector(viewId = "com.example:id/password").matches(passwordField))
        assertFalse(NodeSelector(x = 200, y = 430).matches(passwordField))
    }

    @Test
    fun `describe names the selector plainly`() {
        assertEquals("text “Search”", NodeSelector(text = "Search").describe())
        assertEquals("the point (200, 230)", NodeSelector(x = 200, y = 230).describe())
        assertEquals(
            "text “Search”, a Button",
            NodeSelector(text = "Search", className = "Button").describe(),
        )
        assertEquals("id “search_button”", NodeSelector(viewId = "com.example:id/search_button").describe())
    }

    @Test
    fun `snapshot find prefers interactive matches`() {
        val label = ScreenNode(text = "Search", className = "TextView")
        val snapshot = ScreenSnapshot(
            packageName = "com.example",
            nodes = listOf(label, searchButton),
        )
        assertEquals(searchButton, snapshot.find(NodeSelector(text = "Search")))
        assertEquals(null, snapshot.find(NodeSelector(text = "Nothing")))
    }
}
