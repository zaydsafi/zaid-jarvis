package com.zaid.jarvis.core.research

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Platform length limits for drafts (Phase 7). */
class DraftLimitsTest {

    @Test
    fun `limits match the platform presets`() {
        assertEquals(280, DraftLimits.limitFor("X / Twitter"))
        assertEquals(500, DraftLimits.limitFor("Threads"))
        assertEquals(2200, DraftLimits.limitFor("Instagram"))
        assertEquals(3000, DraftLimits.limitFor("LinkedIn"))
        assertEquals(10000, DraftLimits.limitFor("Blog"))
        assertEquals(2000, DraftLimits.limitFor("Other"))
    }

    @Test
    fun `unknown platform falls back to other`() {
        assertEquals(2000, DraftLimits.limitFor("MySpace"))
        assertEquals(2000, DraftLimits.limitFor(""))
    }

    @Test
    fun `lookup is case insensitive`() {
        assertEquals(280, DraftLimits.limitFor("x / twitter"))
        assertEquals(2200, DraftLimits.limitFor("instagram"))
    }

    @Test
    fun `text within the limit passes unchanged`() {
        val result = DraftLimits.enforce("Short post", DraftLimits.limitFor("X / Twitter"))
        assertEquals("Short post", result.text)
        assertFalse(result.truncated)
    }

    @Test
    fun `text exactly at the limit passes unchanged`() {
        val text = "a".repeat(280)
        val result = DraftLimits.enforce(text, DraftLimits.limitFor("X / Twitter"))
        assertEquals(text, result.text)
        assertFalse(result.truncated)
    }

    @Test
    fun `over-limit text is truncated to the limit with an ellipsis`() {
        val text = "a".repeat(300)
        val result = DraftLimits.enforce(text, DraftLimits.limitFor("X / Twitter"))
        assertTrue(result.truncated)
        assertEquals(280, result.text.length)
        assertTrue(result.text.endsWith("…"))
    }

    @Test
    fun `fromName finds presets and defaults to other`() {
        assertEquals(PlatformPreset.INSTAGRAM, PlatformPreset.fromName("Instagram"))
        assertEquals(PlatformPreset.OTHER, PlatformPreset.fromName("Unknown"))
    }
}
