package com.zaid.jarvis.core.productivity

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** ScreenTime aggregation + continuous-session detection (Phase 9). */
class ScreenTimeTest {

    @Test
    fun `aggregate totals time and keeps the top 5 apps`() {
        val entries = listOf(
            UsageEntry("com.a", 60_000L),
            UsageEntry("com.b", 300_000L),
            UsageEntry("com.c", 120_000L),
            UsageEntry("com.d", 0L), // No foreground time — dropped.
            UsageEntry("com.e", 240_000L),
            UsageEntry("com.f", 180_000L),
            UsageEntry("com.g", 30_000L),
        )
        val summary = ScreenTime.aggregate(entries)
        assertEquals(930_000L, summary.totalMillis)
        assertEquals(5, summary.topApps.size)
        assertEquals("com.b", summary.topApps[0].packageName)
        assertEquals("com.e", summary.topApps[1].packageName)
        assertEquals("com.f", summary.topApps[2].packageName)
        assertEquals("com.c", summary.topApps[3].packageName)
        assertEquals("com.a", summary.topApps[4].packageName)
    }

    @Test
    fun `aggregate of an empty list is zero`() {
        val summary = ScreenTime.aggregate(emptyList())
        assertEquals(0L, summary.totalMillis)
        assertTrue(summary.topApps.isEmpty())
    }

    @Test
    fun `formatDuration labels hours minutes and seconds`() {
        assertEquals("2h 15m", formatDuration(2 * 3_600_000L + 15 * 60_000L))
        assertEquals("45m", formatDuration(45 * 60_000L))
        assertEquals("30s", formatDuration(30_000L))
        assertEquals("0s", formatDuration(0L))
        assertEquals("1h 0m", formatDuration(3_600_000L))
    }

    @Test
    fun `continuous session is zero when the screen is not in use`() {
        val now = 10_000_000L
        // Last event is a background move.
        val events = listOf(
            UsageEvent(now - 600_000L, isForeground = true),
            UsageEvent(now - 300_000L, isForeground = false),
        )
        assertEquals(0L, ScreenTime.currentContinuousMillis(events, now))
        assertEquals(0L, ScreenTime.currentContinuousMillis(emptyList(), now))
    }

    @Test
    fun `continuous session runs from the last foreground move`() {
        val now = 10_000_000L
        val events = listOf(
            UsageEvent(now - 3_600_000L, isForeground = true),
            UsageEvent(now - 3_000_000L, isForeground = false),
            UsageEvent(now - 45 * 60_000L, isForeground = true),
        )
        // The 15-minute gap (background at -50min, foreground at -45min)
        // breaks the session: current session is 45 minutes.
        assertEquals(45 * 60_000L, ScreenTime.currentContinuousMillis(events, now))
    }

    @Test
    fun `a short app-switch gap does not break the session`() {
        val now = 10_000_000L
        val events = listOf(
            UsageEvent(now - 90 * 60_000L, isForeground = true),
            UsageEvent(now - 30 * 60_000L, isForeground = false),
            // Back 2 minutes later — under the 5-minute tolerance.
            UsageEvent(now - 28 * 60_000L, isForeground = true),
        )
        assertEquals(90 * 60_000L, ScreenTime.currentContinuousMillis(events, now))
    }

    @Test
    fun `a long gap breaks the session even with later app switches`() {
        val now = 10_000_000L
        val events = listOf(
            UsageEvent(now - 4 * 3_600_000L, isForeground = true),
            UsageEvent(now - 3 * 3_600_000L, isForeground = false),
            // Back 10 minutes later — over the tolerance: new session.
            UsageEvent(now - 170 * 60_000L, isForeground = true),
            UsageEvent(now - 60 * 60_000L, isForeground = false),
            // Back 1 minute later — same session.
            UsageEvent(now - 59 * 60_000L, isForeground = true),
        )
        assertEquals(170 * 60_000L, ScreenTime.currentContinuousMillis(events, now))
    }
}
