package com.zaid.jarvis.core.productivity

import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** ProactiveRules (Phase 9): dedupe, throttling, digest timing. */
class ProactiveRulesTest {

    private val zone: ZoneId = ZoneId.of("Asia/Kabul")

    /** Sunday 2026-11-15 10:30 Kabul. */
    private val now: Long = ZonedDateTime.of(
        LocalDate.of(2026, 11, 15),
        LocalTime.of(10, 30),
        zone,
    ).toInstant().toEpochMilli()

    private fun task(dueAtMillis: Long?, status: TaskStatus = TaskStatus.OPEN, notifiedDay: Long? = null) =
        Task(
            id = 1,
            title = "Buy milk",
            dueAtMillis = dueAtMillis,
            status = status,
            overdueNotifiedDay = notifiedDay,
        )

    @Test
    fun `overdue task with no nudge yet today should notify`() {
        assertTrue(ProactiveRules.shouldNotifyOverdue(task(now - 60_000L), now))
    }

    @Test
    fun `overdue task already nudged today must not notify again`() {
        val today = ProactiveRules.epochDay(now)
        assertFalse(
            ProactiveRules.shouldNotifyOverdue(task(now - 60_000L, notifiedDay = today), now),
        )
    }

    @Test
    fun `overdue task nudged yesterday may notify again today`() {
        val yesterday = ProactiveRules.epochDay(now) - 1
        assertTrue(
            ProactiveRules.shouldNotifyOverdue(task(now - 60_000L, notifiedDay = yesterday), now),
        )
    }

    @Test
    fun `not-yet-due and done tasks never notify`() {
        assertFalse(ProactiveRules.shouldNotifyOverdue(task(now + 60_000L), now))
        assertFalse(ProactiveRules.shouldNotifyOverdue(task(null), now))
        assertFalse(
            ProactiveRules.shouldNotifyOverdue(task(now - 60_000L, status = TaskStatus.DONE), now),
        )
    }

    @Test
    fun `break reminder needs the interval of continuous screen time`() {
        // 59 minutes of continuous use, 60-minute interval: no.
        assertFalse(
            ProactiveRules.shouldNotifyBreak(
                continuousScreenMillis = 59 * 60_000L,
                intervalMinutes = 60,
                lastBreakNotifiedMillis = null,
                nowMillis = now,
            ),
        )
        // Exactly 60 minutes: yes.
        assertTrue(
            ProactiveRules.shouldNotifyBreak(
                continuousScreenMillis = 60 * 60_000L,
                intervalMinutes = 60,
                lastBreakNotifiedMillis = null,
                nowMillis = now,
            ),
        )
    }

    @Test
    fun `break reminder is throttled to once per hour`() {
        val ninetyMinutes = 90 * 60_000L
        // Last reminder 30 minutes ago: no.
        assertFalse(
            ProactiveRules.shouldNotifyBreak(
                continuousScreenMillis = ninetyMinutes,
                intervalMinutes = 60,
                lastBreakNotifiedMillis = now - 30 * 60_000L,
                nowMillis = now,
            ),
        )
        // Last reminder 61 minutes ago: yes.
        assertTrue(
            ProactiveRules.shouldNotifyBreak(
                continuousScreenMillis = ninetyMinutes,
                intervalMinutes = 60,
                lastBreakNotifiedMillis = now - 61 * 60_000L,
                nowMillis = now,
            ),
        )
    }

    @Test
    fun `wind-down fires inside the bedtime window, once per day`() {
        // Bedtime 23:00; now 23:10 — inside the 30-minute window.
        val bedtime = ZonedDateTime.of(
            LocalDate.of(2026, 11, 15),
            LocalTime.of(23, 10),
            zone,
        ).toInstant().toEpochMilli()
        assertTrue(
            ProactiveRules.shouldNotifyWindDown(
                bedtimeHour = 23,
                bedtimeMinute = 0,
                lastWindDownDay = null,
                nowMillis = bedtime,
                zone = zone,
            ),
        )
        // Already notified today: no.
        assertFalse(
            ProactiveRules.shouldNotifyWindDown(
                bedtimeHour = 23,
                bedtimeMinute = 0,
                lastWindDownDay = ProactiveRules.epochDay(bedtime),
                nowMillis = bedtime,
                zone = zone,
            ),
        )
        // Before bedtime: no.
        assertFalse(
            ProactiveRules.shouldNotifyWindDown(
                bedtimeHour = 23,
                bedtimeMinute = 0,
                lastWindDownDay = null,
                nowMillis = now,
                zone = zone,
            ),
        )
        // 23:45 — past the 30-minute window: no.
        val late = ZonedDateTime.of(
            LocalDate.of(2026, 11, 15),
            LocalTime.of(23, 45),
            zone,
        ).toInstant().toEpochMilli()
        assertFalse(
            ProactiveRules.shouldNotifyWindDown(
                bedtimeHour = 23,
                bedtimeMinute = 0,
                lastWindDownDay = null,
                nowMillis = late,
                zone = zone,
            ),
        )
    }

    @Test
    fun `next daily time is today when still ahead, tomorrow when passed`() {
        // Digest at 08:00, now 10:30 → tomorrow 08:00.
        val tomorrowEight = ZonedDateTime.of(
            LocalDate.of(2026, 11, 16),
            LocalTime.of(8, 0),
            zone,
        ).toInstant().toEpochMilli()
        assertEquals(
            tomorrowEight,
            ProactiveRules.nextDailyTimeMillis(8, 0, now, zone),
        )
        // Digest at 12:00, now 10:30 → today 12:00.
        val todayNoon = ZonedDateTime.of(
            LocalDate.of(2026, 11, 15),
            LocalTime.of(12, 0),
            zone,
        ).toInstant().toEpochMilli()
        assertEquals(
            todayNoon,
            ProactiveRules.nextDailyTimeMillis(12, 0, now, zone),
        )
    }
}
