package com.zaid.jarvis.core.confirmation

import com.zaid.jarvis.core.util.JarvisResult
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Confirmation Engine tests (Master Prompt §8): tier routing, approval
 * expiry, content binding, single-use approvals, trusted actions, and
 * the kill switch. Time is a fake clock so expiry is deterministic.
 */
class ConfirmationEngineTest {

    private class Fixture {
        var nowMillis: Long = 1_000_000L
        val auditLog = InMemoryAuditLog()
        val trustedStore = InMemoryTrustedActionStore()
        val killSwitch = KillSwitch()
        val engine = ConfirmationEngine(
            auditLog = auditLog,
            trustedStore = trustedStore,
            killSwitch = killSwitch,
            clock = { nowMillis },
        )

        /** Runs execute() in a child coroutine and returns its Deferred. */
        fun executeAsync(
            toolName: String = "get_time",
            tier: RiskTier = RiskTier.READ_ONLY,
            exactContent: String = "Current time",
            alwaysAskReadOnly: Boolean = false,
            block: suspend (String) -> JarvisResult<String> = { JarvisResult.Success("ran:$it") },
        ) = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Unconfined).async {
            engine.execute(
                toolName = toolName,
                tier = tier,
                action = "Test action",
                target = "Test target",
                dataUsed = "Test data",
                exactContent = exactContent,
                paramsJson = "{}",
                alwaysAskReadOnly = alwaysAskReadOnly,
                block = block,
            )
        }

        suspend fun pending(): ApprovalRequest {
            // Wait briefly for the request to appear.
            repeat(50) {
                engine.pendingRequest.value?.let { return it }
                delay(10)
            }
            error("No pending request appeared")
        }

        suspend fun auditEntries(): List<AuditEntry> = auditLog.observeAll().first()
    }

    @Test
    fun `consumed approval ids are bounded and old ids are evicted (Phase 11)`() = runBlocking {
        // Tiny bound so the test doesn't need 1,000 approvals.
        val engine = ConfirmationEngine(
            auditLog = InMemoryAuditLog(),
            trustedStore = InMemoryTrustedActionStore(),
            killSwitch = KillSwitch(),
            clock = { 1_000_000L },
            maxConsumedApprovalIds = 3,
        )
        repeat(5) { index ->
            val deferred = kotlinx.coroutines.CoroutineScope(
                kotlinx.coroutines.Dispatchers.Unconfined,
            ).async {
                engine.execute(
                    toolName = "set_flashlight",
                    tier = RiskTier.REVERSIBLE,
                    action = "Test action $index",
                    target = "Test target",
                    dataUsed = "Test data",
                    exactContent = "Content $index",
                    paramsJson = "{}",
                ) { JarvisResult.Success("ran") }
            }
            var request: ApprovalRequest? = null
            var attempts = 0
            while (request == null && attempts < 50) {
                request = engine.pendingRequest.value
                if (request == null) delay(10)
                attempts++
            }
            val pending = request ?: error("No pending request appeared (iteration $index)")
            assertTrue(engine.resolve(pending.id, ApprovalDecision.Allow))
            assertTrue(deferred.await() is ExecutionOutcome.Executed)
        }
        // 5 approvals ran through a bound of 3: the set evicted the eldest.
        assertEquals(3, engine.consumedApprovalCount())
    }

    @Test
    fun `tier 0 asks once per session then auto-allows`() = runBlocking {
        val f = Fixture()
        val first = f.executeAsync()
        val request = f.pending()
        assertTrue(f.engine.resolve(request.id, ApprovalDecision.Allow))
        assertTrue(first.await() is ExecutionOutcome.Executed)

        // Second call in the same session: no card, runs immediately.
        val second = f.executeAsync()
        assertTrue(second.await() is ExecutionOutcome.Executed)
        assertEquals(null, f.engine.pendingRequest.value)

        val decisions = f.auditEntries().map { it.decision }
        assertTrue(decisions.contains(AuditDecision.ALLOWED))
        assertTrue(decisions.contains(AuditDecision.AUTO_ALLOWED_SESSION))
    }

    @Test
    fun `tier 0 always-ask mode asks every time`() = runBlocking {
        val f = Fixture()
        val first = f.executeAsync(alwaysAskReadOnly = true)
        f.engine.resolve(f.pending().id, ApprovalDecision.Allow)
        assertTrue(first.await() is ExecutionOutcome.Executed)

        val second = f.executeAsync(alwaysAskReadOnly = true)
        val request = f.pending() // A card appears again.
        assertTrue(f.engine.resolve(request.id, ApprovalDecision.Deny))
        assertTrue(second.await() is ExecutionOutcome.Denied)
    }

    @Test
    fun `tier 1 asks every time`() = runBlocking {
        val f = Fixture()
        repeat(2) {
            val job = f.executeAsync(toolName = "toggle_wifi", tier = RiskTier.REVERSIBLE)
            val request = f.pending()
            assertEquals(RiskTier.REVERSIBLE, request.tier)
            assertTrue(f.engine.resolve(request.id, ApprovalDecision.Allow))
            assertTrue(job.await() is ExecutionOutcome.Executed)
        }
    }

    @Test
    fun `tier 2 needs a second confirmation after allow`() = runBlocking {
        val f = Fixture()
        val job = f.executeAsync(toolName = "send_sms", tier = RiskTier.EXTERNAL)
        val request = f.pending()
        assertTrue(request.requiresSecondConfirmation)
        assertTrue(f.engine.resolve(request.id, ApprovalDecision.Allow))

        // Still waiting: the second confirmation has not happened yet.
        delay(50)
        assertFalse(job.isCompleted)
        assertEquals(
            ApprovalState.AWAITING_SECOND_CONFIRMATION,
            f.engine.pendingRequest.value?.state,
        )
        assertTrue(f.engine.resolve(request.id, ApprovalDecision.ConfirmSecond))
        assertTrue(job.await() is ExecutionOutcome.Executed)
    }

    @Test
    fun `tier 2 second-confirmation cancel denies the action`() = runBlocking {
        val f = Fixture()
        val job = f.executeAsync(toolName = "send_sms", tier = RiskTier.EXTERNAL)
        val request = f.pending()
        f.engine.resolve(request.id, ApprovalDecision.Allow)
        delay(20)
        assertTrue(f.engine.resolve(request.id, ApprovalDecision.CancelSecond))
        assertTrue(job.await() is ExecutionOutcome.Denied)
    }

    @Test
    fun `tier 3 needs biometrics after allow`() = runBlocking {
        val f = Fixture()
        val job = f.executeAsync(toolName = "open_banking", tier = RiskTier.SENSITIVE)
        val request = f.pending()
        assertTrue(request.requiresBiometric)
        assertTrue(f.engine.resolve(request.id, ApprovalDecision.Allow))

        delay(50)
        assertFalse(job.isCompleted)
        assertEquals(
            ApprovalState.AWAITING_BIOMETRIC,
            f.engine.pendingRequest.value?.state,
        )
        assertTrue(f.engine.resolve(request.id, ApprovalDecision.BiometricOk))
        assertTrue(job.await() is ExecutionOutcome.Executed)
    }

    @Test
    fun `tier 3 biometric failure blocks execution`() = runBlocking {
        val f = Fixture()
        val job = f.executeAsync(toolName = "open_banking", tier = RiskTier.SENSITIVE)
        val request = f.pending()
        f.engine.resolve(request.id, ApprovalDecision.Allow)
        delay(20)
        assertTrue(f.engine.resolve(request.id, ApprovalDecision.BiometricFailed))
        assertTrue(job.await() is ExecutionOutcome.BiometricFailed)
    }

    @Test
    fun `approval expires after 2 minutes`() = runBlocking {
        val f = Fixture()
        val job = f.executeAsync(tier = RiskTier.REVERSIBLE)
        val request = f.pending()

        // 119 seconds: still valid.
        f.nowMillis += 119_000
        assertFalse(request.isExpired(f.nowMillis))

        // 121 seconds: expired; resolving now is rejected and the run expires.
        f.nowMillis += 2_000
        assertFalse(f.engine.resolve(request.id, ApprovalDecision.Allow))
        assertTrue(job.await() is ExecutionOutcome.Expired)
        assertTrue(f.auditEntries().any { it.decision == AuditDecision.EXPIRED })
    }

    @Test
    fun `expireStaleRequests expires a pending request`() = runBlocking {
        val f = Fixture()
        val job = f.executeAsync(tier = RiskTier.REVERSIBLE)
        f.pending()
        f.nowMillis += 130_000
        f.engine.expireStaleRequests()
        assertTrue(job.await() is ExecutionOutcome.Expired)
    }

    @Test
    fun `edit creates a new request and executes the edited content`() = runBlocking {
        val f = Fixture()
        var executedContent: String? = null
        val job = f.executeAsync(exactContent = "Hello") { content ->
            executedContent = content
            JarvisResult.Success("ok")
        }
        val first = f.pending()
        assertTrue(f.engine.resolve(first.id, ApprovalDecision.Edit("Hello, edited")))

        // The old request is superseded; a new one appears for the new content.
        val second = f.pending()
        assertNotEquals(first.id, second.id)
        assertEquals("Hello, edited", second.exactContent)
        assertTrue(f.engine.resolve(second.id, ApprovalDecision.Allow))
        assertTrue(job.await() is ExecutionOutcome.Executed)
        assertEquals("Hello, edited", executedContent)

        // The old approval id can never be used again.
        assertFalse(f.engine.resolve(first.id, ApprovalDecision.Allow))
        assertTrue(f.auditEntries().any { it.decision == AuditDecision.EDITED })
    }

    @Test
    fun `content hash binds the approval to the exact content shown`() {
        val request = ApprovalRequest.create(
            id = "1",
            toolName = "send_sms",
            tier = RiskTier.EXTERNAL,
            action = "Send SMS",
            target = "+15550100",
            dataUsed = "Contacts",
            exactContent = "Meet at 5",
            paramsJson = "{}",
            createdAtMillis = 0L,
            timeoutMillis = 120_000L,
        )
        val changed = request.copy(exactContent = "Meet at 6")
        assertNotEquals(request.contentHash, sha256Hex(changed.canonicalContent()))
        assertEquals(request.contentHash, sha256Hex(request.canonicalContent()))
    }

    @Test
    fun `an approval cannot be reused`() = runBlocking {
        val f = Fixture()
        val job = f.executeAsync(tier = RiskTier.REVERSIBLE)
        val request = f.pending()
        assertTrue(f.engine.resolve(request.id, ApprovalDecision.Allow))
        assertTrue(job.await() is ExecutionOutcome.Executed)
        // The same id, resolved again, is rejected.
        assertFalse(f.engine.resolve(request.id, ApprovalDecision.Allow))
    }

    @Test
    fun `resolving an unknown request id is rejected`() {
        val f = Fixture()
        assertFalse(f.engine.resolve("no-such-id", ApprovalDecision.Allow))
    }

    @Test
    fun `trusted tier 1 action auto-allows, and revoke restores asking`() = runBlocking {
        val f = Fixture()
        f.engine.trust("toggle_wifi")
        val first = f.executeAsync(toolName = "toggle_wifi", tier = RiskTier.REVERSIBLE)
        assertTrue(first.await() is ExecutionOutcome.Executed)
        assertEquals(null, f.engine.pendingRequest.value)
        assertTrue(f.auditEntries().any { it.decision == AuditDecision.AUTO_ALLOWED_TRUSTED })

        f.engine.revokeTrust("toggle_wifi")
        val second = f.executeAsync(toolName = "toggle_wifi", tier = RiskTier.REVERSIBLE)
        val request = f.pending() // Asking again after revoke.
        assertTrue(f.engine.resolve(request.id, ApprovalDecision.Deny))
        assertTrue(second.await() is ExecutionOutcome.Denied)
    }

    @Test
    fun `tier 2 and tier 3 can never be trusted`() = runBlocking {
        val f = Fixture()
        f.engine.trust("send_sms") // Stored, but the engine must ignore it.
        val job = f.executeAsync(toolName = "send_sms", tier = RiskTier.EXTERNAL)
        val request = f.pending() // A card still appears.
        assertTrue(f.engine.resolve(request.id, ApprovalDecision.Deny))
        assertTrue(job.await() is ExecutionOutcome.Denied)
    }

    @Test
    fun `kill switch cancels a pending approval`() = runBlocking {
        val f = Fixture()
        val job = f.executeAsync(tier = RiskTier.REVERSIBLE)
        f.pending()
        f.killSwitch.cancelAll()
        assertTrue(job.await() is ExecutionOutcome.Cancelled)
        assertEquals(null, f.engine.pendingRequest.value)
        assertTrue(f.auditEntries().any { it.decision == AuditDecision.CANCELLED })
    }

    @Test
    fun `deny is audited and the action does not run`() = runBlocking {
        val f = Fixture()
        var ran = false
        val job = f.executeAsync(toolName = "toggle_wifi", tier = RiskTier.REVERSIBLE) {
            ran = true
            JarvisResult.Success("should not happen")
        }
        val request = f.pending()
        assertTrue(f.engine.resolve(request.id, ApprovalDecision.Deny))
        assertTrue(job.await() is ExecutionOutcome.Denied)
        assertFalse(ran)
        val entry = f.auditEntries().single()
        assertEquals(AuditDecision.DENIED, entry.decision)
        assertEquals("toggle_wifi", entry.toolName)
    }

    @Test
    fun `second confirmation cannot be resolved before allow`() = runBlocking {
        val f = Fixture()
        val job = f.executeAsync(toolName = "send_sms", tier = RiskTier.EXTERNAL)
        val request = f.pending()
        // ConfirmSecond is invalid while still awaiting the first decision.
        assertFalse(f.engine.resolve(request.id, ApprovalDecision.ConfirmSecond))
        assertTrue(f.engine.resolve(request.id, ApprovalDecision.Allow))
        delay(20)
        assertTrue(f.engine.resolve(request.id, ApprovalDecision.ConfirmSecond))
        assertTrue(job.await() is ExecutionOutcome.Executed)
    }

    @Test
    fun `endSession clears tier 0 session approval`() = runBlocking {
        val f = Fixture()
        val first = f.executeAsync()
        f.engine.resolve(f.pending().id, ApprovalDecision.Allow)
        assertTrue(first.await() is ExecutionOutcome.Executed)
        f.engine.endSession()
        val second = f.executeAsync()
        val request = f.pending() // Asking again after the session ended.
        assertTrue(f.engine.resolve(request.id, ApprovalDecision.Deny))
        assertTrue(second.await() is ExecutionOutcome.Denied)
    }

    @Test
    fun `undo info is recorded when the action runs`() = runBlocking {
        val f = Fixture()
        val job = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Unconfined).async {
            f.engine.execute(
                toolName = "set_volume",
                tier = RiskTier.REVERSIBLE,
                action = "Set volume",
                target = "set_volume",
                dataUsed = "Test data",
                exactContent = "Set media volume to 7/15 (was 4/15).",
                paramsJson = "{\"stream\":\"media\",\"level\":7}",
                undoInfoProvider = {
                    UndoInfo(
                        description = "Restore media volume to 4/15.",
                        data = "{\"stream\":\"MUSIC\",\"previousLevel\":4}",
                    )
                },
            ) { JarvisResult.Success("ran") }
        }
        f.engine.resolve(f.pending().id, ApprovalDecision.Allow)
        assertTrue(job.await() is ExecutionOutcome.Executed)

        val entry = f.auditEntries().single()
        assertTrue(entry.undoable)
        assertEquals("Restore media volume to 4/15.", entry.undoDescription)
        assertEquals("{\"stream\":\"MUSIC\",\"previousLevel\":4}", entry.undoData)
        assertEquals(AuditDecision.ALLOWED, entry.decision)
    }

    @Test
    fun `no undo info is recorded when the action is denied or fails`() = runBlocking {
        val f = Fixture()
        // Denied: the provider is never consulted.
        val denied = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Unconfined).async {
            f.engine.execute(
                toolName = "set_volume",
                tier = RiskTier.REVERSIBLE,
                action = "Set volume",
                target = "set_volume",
                dataUsed = "Test data",
                exactContent = "Set media volume to 7/15.",
                paramsJson = "{}",
                undoInfoProvider = { UndoInfo("Restore volume.", "{}") },
            ) { JarvisResult.Success("should not run") }
        }
        f.engine.resolve(f.pending().id, ApprovalDecision.Deny)
        assertTrue(denied.await() is ExecutionOutcome.Denied)
        val deniedEntry = f.auditEntries().single()
        assertFalse(deniedEntry.undoable)
        assertEquals(null, deniedEntry.undoData)

        // Failed: the action ran but changed nothing.
        val f2 = Fixture()
        val failed = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Unconfined).async {
            f2.engine.execute(
                toolName = "set_volume",
                tier = RiskTier.REVERSIBLE,
                action = "Set volume",
                target = "set_volume",
                dataUsed = "Test data",
                exactContent = "Set media volume to 99/15.",
                paramsJson = "{}",
                undoInfoProvider = { UndoInfo("Restore volume.", "{}") },
            ) { JarvisResult.Failure("out of range") }
        }
        f2.engine.resolve(f2.pending().id, ApprovalDecision.Allow)
        assertTrue(failed.await() is ExecutionOutcome.Executed)
        val failedEntry = f2.auditEntries().single()
        assertFalse(failedEntry.undoable)
        assertEquals(null, failedEntry.undoData)
    }
}
