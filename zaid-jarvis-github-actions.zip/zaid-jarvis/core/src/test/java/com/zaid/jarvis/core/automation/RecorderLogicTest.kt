package com.zaid.jarvis.core.automation

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class RecorderLogicTest {

    private val selector = NodeSelector(text = "Search")

    @Test
    fun `a click becomes a tap step`() {
        val step = RecorderLogic.eventToStep(
            ObservedUiEvent(
                kind = ObservedEventKind.CLICKED,
                packageName = "com.example",
                selector = selector,
            ),
        )
        assertEquals(MacroStep(MacroAction.TAP, selector), step)
    }

    @Test
    fun `a text change becomes a type step`() {
        val step = RecorderLogic.eventToStep(
            ObservedUiEvent(
                kind = ObservedEventKind.TEXT_CHANGED,
                packageName = "com.example",
                selector = NodeSelector(viewId = "com.example:id/box"),
                text = "hello",
            ),
        )
        assertEquals(
            MacroStep(
                MacroAction.TYPE_TEXT,
                NodeSelector(viewId = "com.example:id/box"),
                text = "hello",
            ),
            step,
        )
    }

    @Test
    fun `password text is never recorded`() {
        assertNull(
            RecorderLogic.eventToStep(
                ObservedUiEvent(
                    kind = ObservedEventKind.TEXT_CHANGED,
                    packageName = "com.example",
                    selector = NodeSelector(viewId = "com.example:id/password"),
                    text = null,
                    isPassword = true,
                ),
            ),
        )
        assertNull(
            RecorderLogic.eventToStep(
                ObservedUiEvent(
                    kind = ObservedEventKind.CLICKED,
                    packageName = "com.example",
                    selector = selector,
                    isPassword = true,
                ),
            ),
        )
    }

    @Test
    fun `events from Jarvis itself are never recorded`() {
        assertNull(
            RecorderLogic.eventToStep(
                ObservedUiEvent(
                    kind = ObservedEventKind.CLICKED,
                    packageName = RecorderLogic.OWN_PACKAGE,
                    selector = selector,
                ),
            ),
        )
    }

    @Test
    fun `scrolls become scroll steps`() {
        assertEquals(
            MacroStep(MacroAction.SCROLL_FORWARD),
            RecorderLogic.eventToStep(
                ObservedUiEvent(
                    kind = ObservedEventKind.SCROLLED_FORWARD,
                    packageName = "com.example",
                ),
            ),
        )
        assertEquals(
            MacroStep(MacroAction.SCROLL_BACK),
            RecorderLogic.eventToStep(
                ObservedUiEvent(
                    kind = ObservedEventKind.SCROLLED_BACK,
                    packageName = "com.example",
                ),
            ),
        )
    }

    @Test
    fun `clicks without a selector and empty text changes are skipped`() {
        assertNull(
            RecorderLogic.eventToStep(
                ObservedUiEvent(
                    kind = ObservedEventKind.CLICKED,
                    packageName = "com.example",
                    selector = null,
                ),
            ),
        )
        assertNull(
            RecorderLogic.eventToStep(
                ObservedUiEvent(
                    kind = ObservedEventKind.TEXT_CHANGED,
                    packageName = "com.example",
                    selector = selector,
                    text = "  ",
                ),
            ),
        )
    }

    @Test
    fun `consecutive keystrokes for one field coalesce into one step`() {
        val field = NodeSelector(viewId = "com.example:id/box")
        var steps = emptyList<MacroStep>()
        steps = RecorderLogic.appendStep(
            steps,
            MacroStep(MacroAction.TYPE_TEXT, field, text = "h"),
        )
        steps = RecorderLogic.appendStep(
            steps,
            MacroStep(MacroAction.TYPE_TEXT, field, text = "he"),
        )
        steps = RecorderLogic.appendStep(
            steps,
            MacroStep(MacroAction.TYPE_TEXT, field, text = "hello"),
        )
        assertEquals(1, steps.size)
        assertEquals("hello", steps.single().text)
    }

    @Test
    fun `typing in a different field starts a new step`() {
        val steps = RecorderLogic.appendStep(
            listOf(
                MacroStep(
                    MacroAction.TYPE_TEXT,
                    NodeSelector(viewId = "com.example:id/a"),
                    text = "x",
                ),
            ),
            MacroStep(
                MacroAction.TYPE_TEXT,
                NodeSelector(viewId = "com.example:id/b"),
                text = "y",
            ),
        )
        assertEquals(2, steps.size)
    }

    @Test
    fun `a tap after typing is not coalesced`() {
        val steps = RecorderLogic.appendStep(
            listOf(MacroStep(MacroAction.TYPE_TEXT, selector, text = "hello")),
            MacroStep(MacroAction.TAP, selector),
        )
        assertEquals(2, steps.size)
    }
}
