package com.zaid.jarvis.core.backup

import com.zaid.jarvis.core.model.JarvisSettings
import com.zaid.jarvis.core.util.JarvisResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Backup format (Phase 10): round-trip, checksum, version, size, merge plan, no-secrets. */
class BackupFormatTest {

    private fun sampleData() = BackupData(
        settings = JarvisSettings(),
        tasks = listOf(
            BackupTask(
                id = 1,
                title = "Buy milk",
                priority = "MEDIUM",
                status = "OPEN",
                createdAtMillis = 1000,
                updatedAtMillis = 1000,
            ),
        ),
        notes = listOf(
            BackupNote(
                id = 2,
                title = "Groceries",
                body = "Milk, eggs",
                createdAtMillis = 1000,
                updatedAtMillis = 1000,
            ),
        ),
        trustedActions = listOf("get_time"),
    )

    @Test
    fun `encode then decode round-trips the data`() {
        val json = BackupFormat.encode(sampleData(), "0.10.0-phase10", 12345L)
        val decoded = BackupFormat.decode(json)
        assertTrue(decoded is JarvisResult.Success)
        val envelope = (decoded as JarvisResult.Success).value
        assertEquals(BackupFormat.CURRENT_FORMAT_VERSION, envelope.formatVersion)
        assertEquals("0.10.0-phase10", envelope.appVersion)
        assertEquals(12345L, envelope.exportedAtMillis)
        assertEquals(sampleData(), envelope.data)
    }

    @Test
    fun `a tampered payload fails the checksum`() {
        val json = BackupFormat.encode(sampleData(), "0.10.0-phase10", 12345L)
        val tampered = json.replace("Buy milk", "Buy wine")
        val decoded = BackupFormat.decode(tampered)
        assertTrue(decoded is JarvisResult.Failure)
        assertTrue((decoded as JarvisResult.Failure).message.contains("checksum"))
    }

    @Test
    fun `an unknown format version is refused`() {
        val json = BackupFormat.encode(sampleData(), "0.10.0-phase10", 12345L)
        val wrongVersion = json.replace(
            "\"formatVersion\":1",
            "\"formatVersion\":99",
        )
        val decoded = BackupFormat.decode(wrongVersion)
        assertTrue(decoded is JarvisResult.Failure)
        assertTrue((decoded as JarvisResult.Failure).message.contains("format version 99"))
    }

    @Test
    fun `malformed JSON is refused`() {
        val decoded = BackupFormat.decode("{not json at all")
        assertTrue(decoded is JarvisResult.Failure)
    }

    @Test
    fun `an empty file is refused`() {
        assertTrue(BackupFormat.decode("") is JarvisResult.Failure)
    }

    @Test
    fun `an oversized file is refused`() {
        val tooBig = " ".repeat((BackupFormat.MAX_BACKUP_BYTES + 1).toInt())
        val decoded = BackupFormat.decode(tooBig)
        assertTrue(decoded is JarvisResult.Failure)
        assertTrue((decoded as JarvisResult.Failure).message.contains("too large"))
    }

    @Test
    fun `unknown fields are ignored on import`() {
        val json = BackupFormat.encode(sampleData(), "0.10.0-phase10", 12345L)
        // Add an unknown top-level field the lenient reader must ignore.
        val withExtra = json.replaceFirst("{", "{\"futureField\":42,")
        val decoded = BackupFormat.decode(withExtra)
        assertTrue(decoded is JarvisResult.Success)
        assertEquals(sampleData(), (decoded as JarvisResult.Success).value.data)
    }

    @Test
    fun `merge plan counts new vs existing ids`() {
        val plan = BackupMerge.planSection(
            section = "Tasks",
            existingIds = setOf(1L, 2L),
            incomingIds = listOf(2L, 3L, 3L),
        )
        assertEquals(3, plan.incoming)
        assertEquals(1, plan.toImport) // Only id 3 is new (counted once).
        assertEquals(2, plan.skipped)
    }

    @Test
    fun `export JSON contains no secret field names`() {
        val json = BackupFormat.encode(sampleData(), "0.10.0-phase10", 12345L)
        assertTrue(BackupFormat.secretFieldNamesPresent(json).isEmpty())
    }

    @Test
    fun `the secret scanner catches credential field names`() {
        val found = BackupFormat.secretFieldNamesPresent(
            """{"apiKey":"sk-123","settings":{"themeMode":"DARK"},"token":"abc"}""",
        )
        assertTrue("apiKey" in found)
        assertTrue("token" in found)
    }

    @Test
    fun `the secret scanner ignores secret words in values`() {
        // A task titled "password" is user content, not a credential field.
        val found = BackupFormat.secretFieldNamesPresent(
            """{"tasks":[{"id":1,"title":"reset my password","priority":"LOW","status":"OPEN","createdAtMillis":1,"updatedAtMillis":1}]}""",
        )
        assertTrue(found.isEmpty())
    }
}
