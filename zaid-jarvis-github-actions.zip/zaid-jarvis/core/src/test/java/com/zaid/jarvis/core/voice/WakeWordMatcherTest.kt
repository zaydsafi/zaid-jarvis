package com.zaid.jarvis.core.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WakeWordMatcherTest {

    @Test fun matchesPlainHeyJarvis() {
        assertTrue(WakeWordMatcher.matches("Hey Jarvis"))
    }

    @Test fun matchesCaseAndPunctuationInsensitive() {
        assertTrue(WakeWordMatcher.matches("HEY JARVIS!"))
        assertTrue(WakeWordMatcher.matches("hey jarvis, what time is it?"))
    }

    @Test fun matchesCommonMishearings() {
        assertTrue(WakeWordMatcher.matches("hey jar vis"))
        assertTrue(WakeWordMatcher.matches("hey jar viss"))
        assertTrue(WakeWordMatcher.matches("a jarvis"))
        assertTrue(WakeWordMatcher.matches("ok jarvis"))
        assertTrue(WakeWordMatcher.matches("okay jarvis"))
    }

    @Test fun matchesBareJarvisAlone() {
        assertTrue(WakeWordMatcher.matches("Jarvis"))
    }

    @Test fun doesNotMatchJarvisMentionedInSentence() {
        // "I asked Jarvis yesterday" is about Jarvis, not a wake word.
        assertFalse(WakeWordMatcher.matches("I asked Jarvis yesterday"))
        assertFalse(WakeWordMatcher.matches("what time is it"))
        assertFalse(WakeWordMatcher.matches(""))
        assertFalse(WakeWordMatcher.matches("hey"))
    }

    @Test fun doesNotMatchSubstring() {
        assertFalse(WakeWordMatcher.matches("hey jarvison"))
    }

    @Test fun stripWakeWordRemovesLeadingWakeWord() {
        assertEquals(
            "what time is it?",
            WakeWordMatcher.stripWakeWord("Hey Jarvis, what time is it?"),
        )
        assertEquals(
            "calculate 12 times 8",
            WakeWordMatcher.stripWakeWord("hey jar vis calculate 12 times 8"),
        )
    }

    @Test fun stripWakeWordLeavesPlainRequestAlone() {
        assertEquals("what time is it?", WakeWordMatcher.stripWakeWord("what time is it?"))
    }
}
