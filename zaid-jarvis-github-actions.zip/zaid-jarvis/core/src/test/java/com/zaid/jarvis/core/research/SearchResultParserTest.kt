package com.zaid.jarvis.core.research

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Search-result parsing from recorded fixtures (Phase 7).
 * No real network — these are the exact shapes DuckDuckGo lite and
 * Tavily return, captured once and pasted here.
 */
class SearchResultParserTest {

    @Test
    fun `parses duckduckgo lite html`() {
        val html = """
            <html><body>
            <a class="result-link" href="https://example.com/first">First Result</a>
            <td class="result-snippet">The first snippet &amp; more.</td>
            <a class="result-link" href="https://kotlinlang.org/docs">Kotlin Docs</a>
            <td class="result-snippet">Kotlin documentation.</td>
            </body></html>
        """.trimIndent()
        val results = SearchResultParser.parseDuckDuckGoLite(html, 10, 0L)
        assertEquals(2, results.size)
        assertEquals("First Result", results[0].title)
        assertEquals("https://example.com/first", results[0].url)
        assertEquals("The first snippet & more.", results[0].snippet)
        assertEquals("example.com", results[0].domain)
        assertEquals("kotlinlang.org", results[1].domain)
    }

    @Test
    fun `duckduckgo parser unwraps uddg redirect links`() {
        val html = """
            <a class="result-link" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Freal-site.com%2Fpage&amp;rut=abc">Real</a>
            <td class="result-snippet">Snippet.</td>
        """.trimIndent()
        val results = SearchResultParser.parseDuckDuckGoLite(html, 10, 0L)
        assertEquals(1, results.size)
        assertEquals("https://real-site.com/page", results[0].url)
        assertEquals("real-site.com", results[0].domain)
    }

    @Test
    fun `duckduckgo parser respects the cap and drops empty rows`() {
        val html = """
            <a class="result-link" href="https://a.com">A</a>
            <td class="result-snippet">a</td>
            <a class="result-link" href="https://b.com">B</a>
            <td class="result-snippet">b</td>
            <a class="result-link" href="https://c.com">C</a>
            <td class="result-snippet">c</td>
        """.trimIndent()
        val results = SearchResultParser.parseDuckDuckGoLite(html, 2, 0L)
        assertEquals(2, results.size)
    }

    @Test
    fun `parses tavily json`() {
        val json = """
            {
              "query": "quantum",
              "results": [
                {"title": "Quantum Leap", "url": "https://quantum.example.org/a", "content": "A breakthrough in qubits.", "score": 0.9},
                {"title": "Qubits 101", "url": "https://learn.example.com/qubits", "content": "An introduction.", "score": 0.7}
              ]
            }
        """.trimIndent()
        val results = SearchResultParser.parseTavilyJson(json, 10, 0L)
        assertEquals(2, results.size)
        assertEquals("Quantum Leap", results[0].title)
        assertEquals("https://quantum.example.org/a", results[0].url)
        assertEquals("A breakthrough in qubits.", results[0].snippet)
        assertEquals("quantum.example.org", results[0].domain)
    }

    @Test
    fun `tavily parser decodes escaped quotes`() {
        val json = """
            {"results": [{"title": "Say \"Hello\"", "url": "https://x.com", "content": "Line1\nLine2"}]}
        """.trimIndent()
        val results = SearchResultParser.parseTavilyJson(json, 10, 0L)
        assertEquals(1, results.size)
        assertEquals("Say \"Hello\"", results[0].title)
        assertTrue(results[0].snippet.contains("Line1"))
    }

    @Test
    fun `tavily parser returns empty list for empty results`() {
        assertTrue(SearchResultParser.parseTavilyJson("""{"results": []}""", 10, 0L).isEmpty())
        assertTrue(SearchResultParser.parseTavilyJson("not json", 10, 0L).isEmpty())
    }

    @Test
    fun `domain extraction strips www and port`() {
        assertEquals("example.com", domainOf("https://www.example.com/path"))
        assertEquals("example.com", domainOf("http://example.com:8080/"))
        assertEquals("", domainOf("not a url"))
    }
}
