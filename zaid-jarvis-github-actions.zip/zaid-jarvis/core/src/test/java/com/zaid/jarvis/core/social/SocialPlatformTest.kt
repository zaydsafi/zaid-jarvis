package com.zaid.jarvis.core.social

import com.zaid.jarvis.core.confirmation.sha256Hex
import com.zaid.jarvis.core.research.ContentDraft
import com.zaid.jarvis.core.research.DraftStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Platform resolution, character limits, and approval content binding (Phase 8). */
class SocialPlatformTest {

    @Test
    fun `fromName resolves every publishable platform`() {
        assertEquals(SocialPlatform.X, SocialPlatform.fromName("X"))
        assertEquals(SocialPlatform.X, SocialPlatform.fromName("twitter"))
        assertEquals(SocialPlatform.X, SocialPlatform.fromName("X / Twitter"))
        assertEquals(SocialPlatform.THREADS, SocialPlatform.fromName("Threads"))
        assertEquals(SocialPlatform.LINKEDIN, SocialPlatform.fromName("LinkedIn"))
        assertEquals(SocialPlatform.INSTAGRAM, SocialPlatform.fromName("instagram"))
        assertEquals(SocialPlatform.INSTAGRAM, SocialPlatform.fromName("IG"))
    }

    @Test
    fun `fromName returns null for non-social platforms`() {
        assertNull(SocialPlatform.fromName("Blog"))
        assertNull(SocialPlatform.fromName("Other"))
        assertNull(SocialPlatform.fromName("TikTok"))
        assertNull(SocialPlatform.fromName(null))
        assertNull(SocialPlatform.fromName(""))
    }

    @Test
    fun `character limits match the Phase 7 presets`() {
        assertEquals(280, SocialPlatform.X.charLimit)
        assertEquals(500, SocialPlatform.THREADS.charLimit)
        assertEquals(3000, SocialPlatform.LINKEDIN.charLimit)
        assertEquals(2200, SocialPlatform.INSTAGRAM.charLimit)
    }

    @Test
    fun `every platform has OAuth endpoints, scopes, and a docs URL`() {
        for (platform in SocialPlatform.entries) {
            assertTrue(platform.authorizeUrl.startsWith("https://"))
            assertTrue(platform.tokenUrl.startsWith("https://"))
            assertTrue(platform.scopes.isNotEmpty())
            assertTrue(platform.docsUrl.startsWith("https://"))
        }
    }

    @Test
    fun `an unedited approved draft is not flagged as edited`() {
        val body = "Hello world"
        val draft = ContentDraft(
            title = "T",
            body = body,
            platform = "X",
            status = DraftStatus.APPROVED,
            approvedBodyHash = sha256Hex(body),
        )
        assertFalse(draft.editedSinceApproval())
    }

    @Test
    fun `an edited approved draft is flagged`() {
        val draft = ContentDraft(
            title = "T",
            body = "Hello world, edited",
            platform = "X",
            status = DraftStatus.APPROVED,
            approvedBodyHash = sha256Hex("Hello world"),
        )
        assertTrue(draft.editedSinceApproval())
    }

    @Test
    fun `a draft without a recorded hash is not flagged (pre-Phase-8 approvals)`() {
        val draft = ContentDraft(
            title = "T",
            body = "Hello world",
            platform = "X",
            status = DraftStatus.APPROVED,
            approvedBodyHash = null,
        )
        assertFalse(draft.editedSinceApproval())
    }

    @Test
    fun `a DRAFT is never flagged as edited-since-approval`() {
        val draft = ContentDraft(
            title = "T",
            body = "Hello world, edited",
            platform = "X",
            status = DraftStatus.DRAFT,
            approvedBodyHash = sha256Hex("Hello world"),
        )
        assertFalse(draft.editedSinceApproval())
    }

    @Test
    fun `expired tokens are detected with the 60-second margin`() {
        val now = 1_700_000_000_000L
        val expired = OAuthTokens("a", expiresAtMillis = now - 1_000L)
        assertTrue(expired.isExpired(now))
        val expiringSoon = OAuthTokens("a", expiresAtMillis = now + 30_000L)
        assertTrue(expiringSoon.isExpired(now))
        val fresh = OAuthTokens("a", expiresAtMillis = now + 3_600_000L)
        assertFalse(fresh.isExpired(now))
        val unknown = OAuthTokens("a", expiresAtMillis = 0L)
        assertFalse(unknown.isExpired(now))
    }
}
