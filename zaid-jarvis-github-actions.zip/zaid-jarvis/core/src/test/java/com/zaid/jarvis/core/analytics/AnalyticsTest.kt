package com.zaid.jarvis.core.analytics

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Analytics payload rules (Phase 10): only non-personal tokens may be recorded. */
class AnalyticsTest {

    @Test
    fun `valid tool payload is accepted`() {
        assertTrue(
            AnalyticsPayload.isValid(
                AnalyticsEvents.TOOL_EXECUTED,
                mapOf("tool" to "get_time", "tier" to "READ_ONLY", "outcome" to "success"),
            ),
        )
    }

    @Test
    fun `valid publish payload is accepted`() {
        assertTrue(
            AnalyticsPayload.isValid(
                AnalyticsEvents.PUBLISH,
                mapOf("platform" to "X", "outcome" to "failure"),
            ),
        )
    }

    @Test
    fun `valid focus payload is accepted`() {
        assertTrue(
            AnalyticsPayload.isValid(
                AnalyticsEvents.FOCUS_SESSION,
                mapOf("duration_bucket" to "15_30", "outcome" to "completed"),
            ),
        )
    }

    @Test
    fun `free text with spaces is rejected`() {
        assertFalse(
            AnalyticsPayload.isValid(
                AnalyticsEvents.TOOL_EXECUTED,
                mapOf("tool" to "call mom", "tier" to "READ_ONLY", "outcome" to "success"),
            ),
        )
    }

    @Test
    fun `a sentence as a value is rejected`() {
        assertFalse(
            AnalyticsPayload.isValid(
                AnalyticsEvents.PUBLISH,
                mapOf("platform" to "posted to X today", "outcome" to "success"),
            ),
        )
    }

    @Test
    fun `a URL as a value is rejected`() {
        assertFalse(
            AnalyticsPayload.isValid(
                AnalyticsEvents.PUBLISH,
                mapOf("platform" to "https://x.com/post/123", "outcome" to "success"),
            ),
        )
    }

    @Test
    fun `unknown keys are rejected`() {
        assertFalse(
            AnalyticsPayload.isValid(
                AnalyticsEvents.TOOL_EXECUTED,
                mapOf(
                    "tool" to "get_time",
                    "tier" to "READ_ONLY",
                    "outcome" to "success",
                    "message" to "hello",
                ),
            ),
        )
    }

    @Test
    fun `missing keys are rejected`() {
        assertFalse(
            AnalyticsPayload.isValid(
                AnalyticsEvents.TOOL_EXECUTED,
                mapOf("tool" to "get_time", "outcome" to "success"),
            ),
        )
    }

    @Test
    fun `unknown event names are rejected`() {
        assertFalse(
            AnalyticsPayload.isValid("message_sent", mapOf("text" to "hi")),
        )
    }

    @Test
    fun `empty and over-long values are rejected`() {
        assertFalse(
            AnalyticsPayload.isValid(
                AnalyticsEvents.TOOL_EXECUTED,
                mapOf("tool" to "", "tier" to "READ_ONLY", "outcome" to "success"),
            ),
        )
        assertFalse(
            AnalyticsPayload.isValid(
                AnalyticsEvents.TOOL_EXECUTED,
                mapOf("tool" to "a".repeat(65), "tier" to "READ_ONLY", "outcome" to "success"),
            ),
        )
    }

    @Test
    fun `validate explains the problem`() {
        val errors = AnalyticsPayload.validate(
            AnalyticsEvents.TOOL_EXECUTED,
            mapOf("tool" to "two words", "tier" to "READ_ONLY"),
        )
        assertTrue(errors.any { it.contains("free text") })
        assertTrue(errors.any { it.contains("Missing") })
    }

    @Test
    fun `duration buckets have the documented boundaries`() {
        assertEquals("under_15", AnalyticsPayload.durationBucket(0))
        assertEquals("under_15", AnalyticsPayload.durationBucket(14))
        assertEquals("15_30", AnalyticsPayload.durationBucket(15))
        assertEquals("15_30", AnalyticsPayload.durationBucket(30))
        assertEquals("30_60", AnalyticsPayload.durationBucket(31))
        assertEquals("30_60", AnalyticsPayload.durationBucket(60))
        assertEquals("over_60", AnalyticsPayload.durationBucket(61))
        assertEquals("over_60", AnalyticsPayload.durationBucket(240))
    }
}
