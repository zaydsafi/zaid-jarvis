package com.zaid.jarvis.core.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PricingTest {

    @Test
    fun `known model cost uses its own rates`() {
        // Sonnet 5.5: $3 / $15 per 1M. 1M in + 1M out = $18.
        val cost = PricingTable.estimateCostUsd("claude-sonnet-5-5", 1_000_000, 1_000_000)
        assertEquals(18.0, cost, 0.000001)
    }

    @Test
    fun `cheap model costs less than flagship`() {
        val cheap = PricingTable.estimateCostUsd("claude-haiku-5-5", 100_000, 100_000)
        val flagship = PricingTable.estimateCostUsd("claude-sonnet-5-5", 100_000, 100_000)
        assertTrue(cheap < flagship)
    }

    @Test
    fun `unknown model falls back to the default rate`() {
        val cost = PricingTable.estimateCostUsd("some-future-model-9", 1_000_000, 0)
        assertEquals(PricingTable.DEFAULT_RATE.inputPerMillion, cost, 0.000001)
    }

    @Test
    fun `zero usage costs zero`() {
        assertEquals(0.0, PricingTable.estimateCostUsd("gpt-5", 0, 0), 0.0)
    }

    @Test
    fun `negative tokens are clamped, never negative cost`() {
        assertTrue(PricingTable.estimateCostUsd("gpt-5", -5, -5) >= 0.0)
    }
}
