package com.zaid.jarvis.core.confirmation

import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AuditLogTest {

    private fun entry(tool: String, action: String = "Test action") = AuditEntry(
        timestampMillis = 1_000L,
        toolName = tool,
        tier = RiskTier.REVERSIBLE,
        action = action,
        target = "target",
        paramsSummary = "{}",
        decision = AuditDecision.ALLOWED,
        resultSummary = "OK",
    )

    @Test
    fun `record and observe returns newest first`() = runBlocking {
        val log = InMemoryAuditLog()
        log.record(entry("a").copy(timestampMillis = 100L))
        log.record(entry("b").copy(timestampMillis = 200L))
        val all = log.observeAll().first()
        assertEquals(listOf("b", "a"), all.map { it.toolName })
    }

    @Test
    fun `search matches tool, action, target and params`() = runBlocking {
        val log = InMemoryAuditLog()
        log.record(entry("send_sms", "Send SMS"))
        log.record(entry("toggle_wifi", "Toggle Wi-Fi"))
        assertEquals(listOf("send_sms"), log.search("sms").map { it.toolName })
        assertEquals(listOf("toggle_wifi"), log.search("WI-FI").map { it.toolName })
        assertEquals(2, log.search("").size)
        assertTrue(log.search("nothing matches").isEmpty())
    }

    @Test
    fun `delete and clear remove entries`() = runBlocking {
        val log = InMemoryAuditLog()
        val id = log.record(entry("a"))
        log.record(entry("b"))
        log.delete(id)
        assertEquals(listOf("b"), log.observeAll().first().map { it.toolName })
        log.clear()
        assertTrue(log.observeAll().first().isEmpty())
    }

    @Test
    fun `markUndone flags the entry`() = runBlocking {
        val log = InMemoryAuditLog()
        val id = log.record(entry("a", "Toggle"))
        log.markUndone(id)
        assertEquals(true, log.get(id)?.undone)
    }

    @Test
    fun `csv export quotes commas and quotes`() {
        val csv = AuditLogExporter.toCsv(
            listOf(
                entry("send_sms", "Send, SMS").copy(
                    resultSummary = "said \"hi\"",
                    paramsSummary = "a,b",
                ),
            ),
        )
        val lines = csv.lines()
        assertEquals(2, lines.size)
        assertTrue(lines[0].startsWith("id,timestamp,tool,"))
        assertTrue(lines[1].contains("\"Send, SMS\""))
        assertTrue(lines[1].contains("\"said \"\"hi\"\"\""))
        assertTrue(lines[1].contains("\"a,b\""))
    }
}
