package com.zaid.jarvis.core.automation

import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BlockedAppsTest {

    @Test
    fun `well-known banking and payment packages are blocked`() {
        assertTrue(BlockedApps.isBlocked("com.paypal.android.p2pmobile"))
        assertTrue(BlockedApps.isBlocked("com.venmo"))
        assertTrue(BlockedApps.isBlocked("com.squareup.cash"))
        assertTrue(BlockedApps.isBlocked("com.google.android.apps.walletnfcrel"))
        assertTrue(BlockedApps.isBlocked("com.revolut.revolut"))
        assertTrue(BlockedApps.isBlocked("com.transferwise.android"))
        assertTrue(BlockedApps.isBlocked("com.chase.sig.android"))
        assertTrue(BlockedApps.isBlocked("co.uk.getmondo"))
        assertTrue(BlockedApps.isBlocked("com.starlingbank.android"))
    }

    @Test
    fun `banking segments block unknown bank apps too`() {
        assertTrue(BlockedApps.isBlocked("com.example.bank"))
        assertTrue(BlockedApps.isBlocked("com.example.bank.mobile"))
        assertTrue(BlockedApps.isBlocked("com.example.pay"))
        assertTrue(BlockedApps.isBlocked("com.example.wallet"))
        assertTrue(BlockedApps.isBlocked("com.foo.barclays.app"))
        assertTrue(BlockedApps.isBlocked("com.foo.hsbc.app"))
        assertTrue(BlockedApps.isBlocked("com.foo.coinbase.app"))
    }

    @Test
    fun `ordinary apps are not blocked`() {
        assertFalse(BlockedApps.isBlocked("com.google.android.apps.messaging"))
        assertFalse(BlockedApps.isBlocked("com.whatsapp"))
        assertFalse(BlockedApps.isBlocked("com.google.android.apps.maps"))
        assertFalse(BlockedApps.isBlocked("com.zaid.jarvis"))
        assertFalse(BlockedApps.isBlocked("com.android.settings"))
        assertFalse(BlockedApps.isBlocked(""))
    }

    @Test
    fun `matching is by segment not substring`() {
        // "display" contains "pay" — but it is not the "pay" segment.
        assertFalse(BlockedApps.isBlocked("com.example.display"))
        // "paper" contains "pay" as a prefix — still not the segment.
        assertFalse(BlockedApps.isBlocked("com.example.paper"))
        // "payback" is not "pay".
        assertFalse(BlockedApps.isBlocked("com.example.payback"))
    }

    @Test
    fun `blockReason explains the block or returns null`() {
        assertNotNull(BlockedApps.blockReason("com.paypal.android.p2pmobile"))
        assertTrue(
            BlockedApps.blockReason("com.paypal.android.p2pmobile")!!
                .contains("banking or payment app"),
        )
        assertNull(BlockedApps.blockReason("com.whatsapp"))
    }
}
