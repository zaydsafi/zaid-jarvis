package com.zaid.jarvis.core.productivity

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Task / FocusSession model helpers + the plain briefing format (Phase 9). */
class TaskModelsTest {

    private val zone: ZoneId = ZoneId.of("Asia/Kabul")
    private val now: Long = ZonedDateTime.of(2026, 11, 15, 10, 30, 0, 0, zone)
        .toInstant().toEpochMilli()

    @Test
    fun `isOverdue needs an open task past its due time`() {
        assertTrue(Task(title = "x", dueAtMillis = now - 1).isOverdue(now))
        assertFalse(Task(title = "x", dueAtMillis = now + 1).isOverdue(now))
        assertFalse(Task(title = "x", dueAtMillis = null).isOverdue(now))
        assertFalse(
            Task(title = "x", dueAtMillis = now - 1, status = TaskStatus.DONE).isOverdue(now),
        )
    }

    @Test
    fun `isDueToday matches the calendar day in the device zone`() {
        val laterToday = ZonedDateTime.of(2026, 11, 15, 23, 0, 0, 0, zone)
            .toInstant().toEpochMilli()
        val tomorrow = ZonedDateTime.of(2026, 11, 16, 9, 0, 0, 0, zone)
            .toInstant().toEpochMilli()
        assertTrue(Task(title = "x", dueAtMillis = laterToday).isDueToday(now, zone))
        assertFalse(Task(title = "x", dueAtMillis = tomorrow).isDueToday(now, zone))
        assertFalse(Task(title = "x", dueAtMillis = null).isDueToday(now, zone))
        assertFalse(
            Task(title = "x", dueAtMillis = laterToday, status = TaskStatus.DONE)
                .isDueToday(now, zone),
        )
    }

    @Test
    fun `priority parses LLM names with aliases`() {
        assertEquals(TaskPriority.HIGH, TaskPriority.fromName("high"))
        assertEquals(TaskPriority.HIGH, TaskPriority.fromName("Urgent"))
        assertEquals(TaskPriority.MEDIUM, TaskPriority.fromName("normal"))
        assertEquals(TaskPriority.LOW, TaskPriority.fromName("LOW"))
        assertEquals(null, TaskPriority.fromName("critical"))
    }

    @Test
    fun `focus session ends at start plus duration`() {
        val session = FocusSession(startedAtMillis = now, durationMinutes = 25)
        assertEquals(now + 25 * 60_000L, session.endsAtMillis())
        assertEquals(25 * 60_000L, session.remainingMillis(now))
        assertEquals(5 * 60_000L, session.remainingMillis(now + 20 * 60_000L))
        assertEquals(0L, session.remainingMillis(now + 30 * 60_000L))
        assertFalse(session.isDueToEnd(now))
        assertTrue(session.isDueToEnd(now + 25 * 60_000L))
        assertFalse(
            session.copy(status = FocusSessionStatus.COMPLETED)
                .isDueToEnd(now + 25 * 60_000L),
        )
    }
}

/** BriefingFormat (Phase 9): the plain fallback text never fails. */
class BriefingFormatTest {

    private val zone: ZoneId = ZoneId.of("Asia/Kabul")

    private fun event(title: String, startHour: Int, endHour: Int, location: String = "") =
        CalendarEvent(
            id = 1,
            title = title,
            startMillis = ZonedDateTime.of(2026, 11, 15, startHour, 0, 0, 0, zone)
                .toInstant().toEpochMilli(),
            endMillis = ZonedDateTime.of(2026, 11, 15, endHour, 0, 0, 0, zone)
                .toInstant().toEpochMilli(),
            location = location,
        )

    @Test
    fun `plain briefing lists events, due tasks, and overdue tasks`() {
        val data = BriefingData(
            date = LocalDate.of(2026, 11, 15),
            events = listOf(event("Team standup", 9, 10, "Office"), event("Lunch", 12, 13)),
            tasksDueToday = listOf(Task(title = "Buy milk", priority = TaskPriority.HIGH)),
            overdueTasks = listOf(Task(title = "Pay rent")),
        )
        val text = BriefingFormat.formatPlain(data, zone)
        assertTrue(text.contains("Team standup"))
        assertTrue(text.contains("09:00–10:00"))
        assertTrue(text.contains("Office"))
        assertTrue(text.contains("Buy milk"))
        assertTrue(text.contains("high priority"))
        assertTrue(text.contains("Pay rent"))
        assertTrue(text.contains("Overdue"))
    }

    @Test
    fun `plain briefing handles an empty day`() {
        val data = BriefingData(
            date = LocalDate.of(2026, 11, 15),
            events = emptyList(),
            tasksDueToday = emptyList(),
            overdueTasks = emptyList(),
        )
        val text = BriefingFormat.formatPlain(data, zone)
        assertTrue(text.contains("No events"))
        assertTrue(text.contains("clear day"))
    }

    @Test
    fun `plain briefing explains a missing calendar permission`() {
        val data = BriefingData(
            date = LocalDate.of(2026, 11, 15),
            events = emptyList(),
            tasksDueToday = emptyList(),
            overdueTasks = emptyList(),
            calendarUnavailable = true,
        )
        val text = BriefingFormat.formatPlain(data, zone)
        assertTrue(text.contains("can't see your calendar"))
        assertTrue(text.contains("App permissions"))
    }

    @Test
    fun `LLM prompt contains the facts and the no-invention rule`() {
        val data = BriefingData(
            date = LocalDate.of(2026, 11, 15),
            events = listOf(event("Dentist", 15, 16)),
            tasksDueToday = listOf(Task(title = "Call Ali")),
            overdueTasks = emptyList(),
        )
        val prompt = BriefingFormat.buildLlmPrompt(data)
        assertTrue(prompt.contains("Dentist"))
        assertTrue(prompt.contains("Call Ali"))
        assertTrue(prompt.contains("never invent"))
    }
}
