package com.zaid.jarvis.core.automation

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MacroValidationTest {

    private val tap = MacroStep(MacroAction.TAP, NodeSelector(text = "Search"))
    private val type = MacroStep(
        MacroAction.TYPE_TEXT,
        NodeSelector(viewId = "com.example:id/box"),
        text = "hello",
    )
    private val scroll = MacroStep(MacroAction.SCROLL_FORWARD)
    private val back = MacroStep(MacroAction.BACK)
    private val wait = MacroStep(MacroAction.WAIT, waitMillis = 1_000)

    @Test
    fun `a well-formed macro validates`() {
        assertTrue(
            MacroValidation.validate(Macro(name = "Morning", steps = listOf(tap, type, scroll)))
                .isEmpty(),
        )
    }

    @Test
    fun `blank name is rejected`() {
        val errors = MacroValidation.validate(Macro(name = "  ", steps = listOf(tap)))
        assertEquals(1, errors.size)
        assertTrue(errors.single().contains("name"))
    }

    @Test
    fun `an over-long name is rejected`() {
        val errors = MacroValidation.validate(
            Macro(name = "x".repeat(MacroLimits.MAX_NAME_LENGTH + 1), steps = listOf(tap)),
        )
        assertTrue(errors.any { it.contains("too long") })
    }

    @Test
    fun `an empty macro is rejected`() {
        val errors = MacroValidation.validate(Macro(name = "Empty", steps = emptyList()))
        assertTrue(errors.any { it.contains("no steps") })
    }

    @Test
    fun `more than the max steps is rejected`() {
        val errors = MacroValidation.validate(
            Macro(name = "Too long", steps = List(MacroLimits.MAX_STEPS + 1) { back }),
        )
        assertTrue(errors.any { it.contains("max ${MacroLimits.MAX_STEPS}") })
    }

    @Test
    fun `a tap without a target is rejected`() {
        val errors = MacroValidation.validate(
            Macro(name = "Bad tap", steps = listOf(MacroStep(MacroAction.TAP))),
        )
        assertTrue(errors.any { it.contains("Step 1") && it.contains("target") })
    }

    @Test
    fun `a tap-at-point without coordinates is rejected`() {
        val errors = MacroValidation.validate(
            Macro(
                name = "Bad tap",
                steps = listOf(MacroStep(MacroAction.TAP_AT, NodeSelector(text = "x"))),
            ),
        )
        assertTrue(errors.any { it.contains("coordinates") })
        assertTrue(
            MacroValidation.validate(
                Macro(
                    name = "Good tap",
                    steps = listOf(MacroStep(MacroAction.TAP_AT, NodeSelector(x = 10, y = 20))),
                ),
            ).isEmpty(),
        )
    }

    @Test
    fun `typing without text is rejected and over-long text is rejected`() {
        val blank = MacroValidation.validate(
            Macro(name = "Bad type", steps = listOf(MacroStep(MacroAction.TYPE_TEXT))),
        )
        assertTrue(blank.any { it.contains("needs text") })
        val long = MacroValidation.validate(
            Macro(
                name = "Long type",
                steps = listOf(
                    MacroStep(MacroAction.TYPE_TEXT, text = "x".repeat(MacroLimits.MAX_TEXT_LENGTH + 1)),
                ),
            ),
        )
        assertTrue(long.any { it.contains("too long") })
    }

    @Test
    fun `a wait must be positive and within the cap`() {
        val zero = MacroValidation.validate(
            Macro(name = "Zero wait", steps = listOf(MacroStep(MacroAction.WAIT, waitMillis = 0))),
        )
        assertTrue(zero.any { it.contains("wait") })
        val huge = MacroValidation.validate(
            Macro(
                name = "Huge wait",
                steps = listOf(
                    MacroStep(MacroAction.WAIT, waitMillis = MacroLimits.MAX_WAIT_MILLIS + 1),
                ),
            ),
        )
        assertTrue(huge.any { it.contains("wait") })
        assertTrue(
            MacroValidation.validate(Macro(name = "Ok wait", steps = listOf(wait))).isEmpty(),
        )
    }

    @Test
    fun `isExternal is true for tap and type steps only`() {
        assertTrue(Macro(name = "T", steps = listOf(tap)).isExternal)
        assertTrue(Macro(name = "T", steps = listOf(type)).isExternal)
        assertTrue(
            Macro(name = "T", steps = listOf(MacroStep(MacroAction.TAP_AT, NodeSelector(x = 1, y = 2))))
                .isExternal,
        )
        assertFalse(Macro(name = "T", steps = listOf(scroll, back, wait)).isExternal)
    }

    @Test
    fun `describeSteps numbers every step`() {
        val text = Macro(name = "M", steps = listOf(tap, scroll)).describeSteps()
        assertEquals("1. Tap text “Search”\n2. Scroll down", text)
    }

    @Test
    fun `step descriptions read plainly`() {
        assertEquals("Tap text “Search”", tap.describe())
        assertEquals("Type “hello” into id “box”", type.describe())
        assertEquals("Type “hi” into the focused field", MacroStep(MacroAction.TYPE_TEXT, text = "hi").describe())
        assertEquals("Wait 1000ms", wait.describe())
        assertEquals("Press Back", back.describe())
    }
}
