package com.zaid.jarvis.core.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CustomProviderConfigTest {

    @Test
    fun `valid config has no errors`() {
        val config = CustomProviderConfig(
            id = "1",
            name = "My server",
            baseUrl = "https://api.example.com/v1",
            modelId = "llama-3.3-70b",
        )
        assertTrue(config.isValid)
        assertTrue(config.validationErrors().isEmpty())
    }

    @Test
    fun `blank name, url, and model are all reported`() {
        val config = CustomProviderConfig(id = "1", name = "", baseUrl = "", modelId = "")
        assertFalse(config.isValid)
        assertEquals(3, config.validationErrors().size)
    }

    @Test
    fun `base url without a scheme is rejected`() {
        val config = CustomProviderConfig(
            id = "1",
            name = "X",
            baseUrl = "api.example.com/v1",
            modelId = "m",
        )
        assertFalse(config.isValid)
        assertTrue(config.validationErrors().any { it.contains("https://") })
    }

    @Test
    fun `http urls are refused - the key would travel in clear text`() {
        // Phase 11: the Phase 3 "http:// allowed for local servers"
        // behaviour is deliberately removed — plain HTTP would send
        // the API key (and the conversation) in clear text.
        val config = CustomProviderConfig(
            id = "1",
            name = "Local",
            baseUrl = "http://192.168.1.10:1234/v1",
            modelId = "local-model",
        )
        assertFalse(config.isValid)
        assertTrue(
            config.validationErrors().any {
                it.contains("https://") && it.contains("clear text")
            },
        )
    }

    @Test
    fun `http localhost urls are refused too`() {
        val config = CustomProviderConfig(
            id = "1",
            name = "Local",
            baseUrl = "http://localhost:11434/v1",
            modelId = "local-model",
        )
        assertFalse(config.isValid)
    }

    @Test
    fun `https urls with a trailing slash stay valid`() {
        val config = CustomProviderConfig(
            id = "1",
            name = "Vendor",
            baseUrl = "https://api.example.com/v1/",
            modelId = "model",
        )
        assertTrue(config.isValid)
    }

    @Test
    fun `normalized base url always ends with one slash`() {
        val withSlash = CustomProviderConfig("1", "X", "https://a.example/v1/", "m")
        val withoutSlash = CustomProviderConfig("1", "X", "https://a.example/v1", "m")
        assertEquals("https://a.example/v1/", withSlash.normalizedBaseUrl())
        assertEquals("https://a.example/v1/", withoutSlash.normalizedBaseUrl())
    }
}
