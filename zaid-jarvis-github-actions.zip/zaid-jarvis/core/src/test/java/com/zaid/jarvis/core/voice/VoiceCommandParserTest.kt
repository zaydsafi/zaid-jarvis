package com.zaid.jarvis.core.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceCommandParserTest {

    @Test fun detectsJarvisStop() {
        assertTrue(VoiceCommandParser.isStopCommand("Jarvis stop"))
        assertTrue(VoiceCommandParser.isStopCommand("stop Jarvis"))
        assertTrue(VoiceCommandParser.isStopCommand("Hey Jarvis stop"))
        assertTrue(VoiceCommandParser.isStopCommand("jarvis stop now"))
    }

    @Test fun detectsStopMidSentence() {
        // Partial transcripts arrive mid-sentence; a stop must still land.
        assertTrue(VoiceCommandParser.isStopCommand("please jarvis stop doing that"))
    }

    @Test fun doesNotMistakeStopForStopCommand() {
        assertFalse(VoiceCommandParser.isStopCommand("stop"))
        assertFalse(VoiceCommandParser.isStopCommand("please stop the music"))
        assertFalse(VoiceCommandParser.isStopCommand("what time is it"))
        assertFalse(VoiceCommandParser.isStopCommand(""))
    }

    @Test fun parseReturnsStop() {
        assertEquals(
            VoiceCommandParser.VoiceCommand.Stop,
            VoiceCommandParser.parse("Jarvis stop"),
        )
    }

    @Test fun parseReturnsRequestWithoutWakeWord() {
        assertEquals(
            VoiceCommandParser.VoiceCommand.Request("what time is it?"),
            VoiceCommandParser.parse("Hey Jarvis, what time is it?"),
        )
    }

    @Test fun parseReturnsPlainRequestUnchanged() {
        assertEquals(
            VoiceCommandParser.VoiceCommand.Request("calculate 12 times 8"),
            VoiceCommandParser.parse("calculate 12 times 8"),
        )
    }
}
