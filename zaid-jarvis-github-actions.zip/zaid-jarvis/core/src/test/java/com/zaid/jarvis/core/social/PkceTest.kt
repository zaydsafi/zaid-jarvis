package com.zaid.jarvis.core.social

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * PKCE helpers (Phase 8): the S256 challenge is checked against the
 * RFC 7636 Appendix B test vector, so the OAuth flow can be trusted
 * before it ever talks to a real platform.
 */
class PkceTest {

    @Test
    fun `S256 challenge matches the RFC 7636 test vector`() {
        val verifier = "dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk"
        val expectedChallenge = "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM"
        assertEquals(expectedChallenge, Pkce.codeChallengeS256(verifier))
    }

    @Test
    fun `challenge is deterministic for the same verifier`() {
        val verifier = Pkce.generateCodeVerifier()
        assertEquals(Pkce.codeChallengeS256(verifier), Pkce.codeChallengeS256(verifier))
    }

    @Test
    fun `different verifiers give different challenges`() {
        assertNotEquals(
            Pkce.codeChallengeS256(Pkce.generateCodeVerifier()),
            Pkce.codeChallengeS256(Pkce.generateCodeVerifier()),
        )
    }

    @Test
    fun `generated verifier is base64url, 43 chars, no padding`() {
        val verifier = Pkce.generateCodeVerifier()
        assertEquals(43, verifier.length)
        assertTrue(verifier.matches(Regex("[A-Za-z0-9_-]+")))
    }

    @Test
    fun `generated state values are unique and base64url`() {
        val first = Pkce.generateState()
        val second = Pkce.generateState()
        assertNotEquals(first, second)
        assertTrue(first.matches(Regex("[A-Za-z0-9_-]+")))
    }

    @Test
    fun `base64url encoding has no padding characters`() {
        val encoded = Pkce.base64UrlEncode(ByteArray(32) { it.toByte() })
        assertTrue(!encoded.contains('='))
        assertTrue(!encoded.contains('+'))
        assertTrue(!encoded.contains('/'))
    }
}
