package com.zaid.jarvis.core.social

import com.zaid.jarvis.core.util.JarvisResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Scheduler validation rules (Phase 8). */
class ScheduleValidationTest {

    private val now = 1_700_000_000_000L

    @Test
    fun `a past time is refused`() {
        val result = ScheduleValidation.validateScheduledTime(now - 1_000L, now)
        assertTrue(result is JarvisResult.Failure)
    }

    @Test
    fun `the current time is refused`() {
        val result = ScheduleValidation.validateScheduledTime(now, now)
        assertTrue(result is JarvisResult.Failure)
    }

    @Test
    fun `less than 5 minutes ahead is refused`() {
        val result = ScheduleValidation.validateScheduledTime(now + 4 * 60_000L, now)
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("5 minutes"))
    }

    @Test
    fun `exactly 5 minutes ahead is allowed`() {
        val result = ScheduleValidation.validateScheduledTime(now + 5 * 60_000L, now)
        assertTrue(result is JarvisResult.Success)
    }

    @Test
    fun `an hour ahead is allowed`() {
        val result = ScheduleValidation.validateScheduledTime(now + 60 * 60_000L, now)
        assertTrue(result is JarvisResult.Success)
    }

    @Test
    fun `a delay under 5 minutes is refused`() {
        val result = ScheduleValidation.validateDelayMinutes(4, now)
        assertTrue(result is JarvisResult.Failure)
    }

    @Test
    fun `a 5-minute delay resolves to now plus 5 minutes`() {
        val result = ScheduleValidation.validateDelayMinutes(5, now)
        assertTrue(result is JarvisResult.Success)
        assertEquals(now + 5 * 60_000L, (result as JarvisResult.Success).value)
    }

    @Test
    fun `a 60-minute delay resolves to now plus an hour`() {
        val result = ScheduleValidation.validateDelayMinutes(60, now)
        assertTrue(result is JarvisResult.Success)
        assertEquals(now + 60 * 60_000L, (result as JarvisResult.Success).value)
    }

    @Test
    fun `draft content hash is deterministic and changes with the text`() {
        val first = ScheduleValidation.draftContentHash("Hello world")
        assertEquals(first, ScheduleValidation.draftContentHash("Hello world"))
        assertTrue(first != ScheduleValidation.draftContentHash("Hello world!"))
        assertEquals(64, first.length) // SHA-256 hex
    }
}
