package com.zaid.jarvis.core.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SpeechTextSanitizerTest {

    @Test fun stripsBoldAndHeadings() {
        assertEquals(
            "Hello there",
            SpeechTextSanitizer.sanitize("## **Hello** there"),
        )
    }

    @Test fun stripsCodeFencesAndInlineCode() {
        assertEquals(
            "Use code and println here.",
            SpeechTextSanitizer.sanitize("Use ```kotlin\nprintln()\n``` and `println` here."),
        )
    }

    @Test fun stripsLinksAndUrls() {
        assertEquals(
            "See the docs and link for details.",
            SpeechTextSanitizer.sanitize(
                "See [the docs](https://example.com) and https://example.com/x for details.",
            ),
        )
    }

    @Test fun stripsBulletsAndEmoji() {
        assertEquals(
            "First item Second item",
            SpeechTextSanitizer.sanitize("- First item\n- Second item 🙂"),
        )
    }

    @Test fun leavesPlainTextAlone() {
        assertEquals(
            "It is 3:45 in the afternoon.",
            SpeechTextSanitizer.sanitize("It is 3:45 in the afternoon."),
        )
    }

    @Test fun truncatesOverlongAnswers() {
        val long = "word ".repeat(1_000)
        val sanitized = SpeechTextSanitizer.sanitize(long)
        assertTrue(sanitized.length <= SpeechTextSanitizer.MAX_SPOKEN_CHARS)
    }
}
