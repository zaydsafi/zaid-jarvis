package com.zaid.jarvis.core.confirmation

import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class KillSwitchTest {

    @Test
    fun `cancelAll cancels registered jobs`() = runBlocking {
        val killSwitch = KillSwitch()
        val job = Job()
        killSwitch.register(job)
        assertFalse(job.isCancelled)
        killSwitch.cancelAll()
        assertTrue(job.isCancelled)
    }

    @Test
    fun `cancelAll bumps the generation and notifies listeners`() {
        val killSwitch = KillSwitch()
        var notified = 0
        killSwitch.addOnCancelListener { notified++ }
        assertEquals(0, killSwitch.currentGeneration())
        killSwitch.cancelAll()
        assertEquals(1, killSwitch.currentGeneration())
        assertEquals(1, notified)
        killSwitch.cancelAll()
        assertEquals(2, killSwitch.currentGeneration())
        assertEquals(2, notified)
    }

    @Test
    fun `cancelAll is safe with nothing registered`() {
        val killSwitch = KillSwitch()
        killSwitch.cancelAll() // Must not throw.
        assertEquals(1, killSwitch.currentGeneration())
    }

    @Test
    fun `generation is exposed as a flow`() = runBlocking {
        val killSwitch = KillSwitch()
        assertEquals(0, killSwitch.generation.first())
        killSwitch.cancelAll()
        assertEquals(1, killSwitch.generation.first())
    }
}
