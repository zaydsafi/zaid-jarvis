package com.zaid.jarvis.core.productivity

import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Quiet hours (Phase 9), including the wrap-around-midnight case. */
class QuietHoursTest {

    private val zone: ZoneId = ZoneId.of("Asia/Kabul")

    @Test
    fun `default window is 22 00 to 07 00`() {
        assertEquals(22 * 60, QuietHours.DEFAULT.startMinute)
        assertEquals(7 * 60, QuietHours.DEFAULT.endMinute)
    }

    @Test
    fun `evening and night are quiet`() {
        val quiet = QuietHours.DEFAULT
        assertTrue(quiet.isQuietAt(LocalTime.of(22, 0)))
        assertTrue(quiet.isQuietAt(LocalTime.of(23, 59)))
        assertTrue(quiet.isQuietAt(LocalTime.of(0, 30)))
        assertTrue(quiet.isQuietAt(LocalTime.of(3, 0)))
        assertTrue(quiet.isQuietAt(LocalTime.of(6, 59)))
    }

    @Test
    fun `daytime is not quiet`() {
        val quiet = QuietHours.DEFAULT
        assertFalse(quiet.isQuietAt(LocalTime.of(7, 0)))
        assertFalse(quiet.isQuietAt(LocalTime.of(12, 0)))
        assertFalse(quiet.isQuietAt(LocalTime.of(21, 59)))
    }

    @Test
    fun `a window that does not wrap midnight`() {
        val quiet = QuietHours(startMinute = 13 * 60, endMinute = 14 * 60)
        assertFalse(quiet.isQuietAt(LocalTime.of(12, 59)))
        assertTrue(quiet.isQuietAt(LocalTime.of(13, 0)))
        assertTrue(quiet.isQuietAt(LocalTime.of(13, 59)))
        assertFalse(quiet.isQuietAt(LocalTime.of(14, 0)))
        assertFalse(quiet.isQuietAt(LocalTime.of(23, 0)))
    }

    @Test
    fun `equal start and end disables quiet hours`() {
        val quiet = QuietHours(startMinute = 480, endMinute = 480)
        assertTrue(quiet.isDisabled())
        assertFalse(quiet.isQuietAt(LocalTime.of(8, 0)))
        assertFalse(quiet.isQuietAt(LocalTime.of(23, 0)))
        assertEquals("Off", quiet.displayLabel())
    }

    @Test
    fun `epoch-millis check respects the zone`() {
        val quiet = QuietHours.DEFAULT
        // 2026-11-15 23:30 Kabul.
        val night = ZonedDateTime.of(2026, 11, 15, 23, 30, 0, 0, zone)
            .toInstant().toEpochMilli()
        assertTrue(quiet.isQuietAt(night, zone))
        // 2026-11-15 10:30 Kabul.
        val day = ZonedDateTime.of(2026, 11, 15, 10, 30, 0, 0, zone)
            .toInstant().toEpochMilli()
        assertFalse(quiet.isQuietAt(day, zone))
    }

    @Test
    fun `display label formats the window`() {
        assertEquals("22:00 – 07:00", QuietHours.DEFAULT.displayLabel())
        assertEquals("13:00 – 14:00", QuietHours(13 * 60, 14 * 60).displayLabel())
    }
}
