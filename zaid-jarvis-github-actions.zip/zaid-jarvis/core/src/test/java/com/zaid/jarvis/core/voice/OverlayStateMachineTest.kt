package com.zaid.jarvis.core.voice

import com.zaid.jarvis.core.voice.OverlayStateMachine.Event
import com.zaid.jarvis.core.voice.OverlayStateMachine.State
import org.junit.Assert.assertEquals
import org.junit.Test

class OverlayStateMachineTest {

    @Test fun showFromHiddenCollapses() {
        assertEquals(State.Collapsed, OverlayStateMachine.transition(State.Hidden, Event.Show))
    }

    @Test fun tapCollapsedExpands() {
        assertEquals(State.Expanded, OverlayStateMachine.transition(State.Collapsed, Event.Tap))
    }

    @Test fun closeExpandedCollapses() {
        assertEquals(State.Collapsed, OverlayStateMachine.transition(State.Expanded, Event.Close))
    }

    @Test fun dragEndsCollapsedAndTapDoesNotExpand() {
        assertEquals(State.Dragging, OverlayStateMachine.transition(State.Collapsed, Event.DragStart))
        // A tap that ends a drag must not expand the bubble.
        assertEquals(State.Dragging, OverlayStateMachine.transition(State.Dragging, Event.Tap))
        assertEquals(State.Collapsed, OverlayStateMachine.transition(State.Dragging, Event.DragEnd))
    }

    @Test fun longPressDismissHidesFromAnyVisibleState() {
        assertEquals(State.Hidden, OverlayStateMachine.transition(State.Collapsed, Event.LongPressDismiss))
        assertEquals(State.Hidden, OverlayStateMachine.transition(State.Expanded, Event.LongPressDismiss))
        assertEquals(State.Hidden, OverlayStateMachine.transition(State.Dragging, Event.LongPressDismiss))
    }

    @Test fun hiddenIgnoresTapAndClose() {
        assertEquals(State.Hidden, OverlayStateMachine.transition(State.Hidden, Event.Tap))
        assertEquals(State.Hidden, OverlayStateMachine.transition(State.Hidden, Event.Close))
    }
}
