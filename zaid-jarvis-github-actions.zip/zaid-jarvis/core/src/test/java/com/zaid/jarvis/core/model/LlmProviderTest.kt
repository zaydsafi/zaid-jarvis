package com.zaid.jarvis.core.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LlmProviderTest {

    @Test
    fun `every provider has a default model of its own`() {
        LlmProvider.entries.forEach { provider ->
            val model = LlmModel.defaultFor(provider)
            assertEquals(provider, model.provider)
        }
    }

    @Test
    fun `openrouter presets use vendor slash model ids`() {
        val presets = LlmModel.forProvider(LlmProvider.OPENROUTER)
        assertTrue(presets.isNotEmpty())
        assertTrue(presets.all { it.apiId.contains("/") })
    }

    @Test
    fun `openrouter free-text model id wins over the preset`() {
        val settings = JarvisSettings(
            llmProvider = LlmProvider.OPENROUTER,
            llmModel = LlmModel.OPENROUTER_GPT_5,
            customModelId = "anthropic/claude-opus-4.5",
        )
        assertEquals("anthropic/claude-opus-4.5", settings.resolvedModelApiId())
    }

    @Test
    fun `openrouter without free-text id uses the preset`() {
        val settings = JarvisSettings(
            llmProvider = LlmProvider.OPENROUTER,
            llmModel = LlmModel.OPENROUTER_GPT_5,
        )
        assertEquals("openai/gpt-5", settings.resolvedModelApiId())
    }

    @Test
    fun `custom provider resolves to its configured model id`() {
        val config = CustomProviderConfig(
            id = "abc",
            name = "Local",
            baseUrl = "http://localhost:1234/v1",
            modelId = "local-model",
        )
        val settings = JarvisSettings(
            llmProvider = LlmProvider.CUSTOM,
            llmModel = LlmModel.CUSTOM_MODEL,
            customProviders = listOf(config),
            selectedCustomProviderId = "abc",
        )
        assertEquals("local-model", settings.resolvedModelApiId())
        assertEquals(config, settings.selectedCustomProvider())
    }

    @Test
    fun `custom provider with nothing selected resolves to blank`() {
        val settings = JarvisSettings(
            llmProvider = LlmProvider.CUSTOM,
            llmModel = LlmModel.CUSTOM_MODEL,
        )
        assertEquals("", settings.resolvedModelApiId())
        assertNull(settings.selectedCustomProvider())
    }

    @Test
    fun `cheap models exist for the built-in providers`() {
        assertEquals(LlmModel.CLAUDE_HAIKU_5_5, LlmModel.cheapFor(LlmProvider.CLAUDE))
        assertEquals(LlmModel.GPT_5_MINI, LlmModel.cheapFor(LlmProvider.OPENAI))
        assertEquals(LlmModel.GEMINI_3_FLASH, LlmModel.cheapFor(LlmProvider.GEMINI))
        assertEquals(LlmModel.OPENROUTER_LLAMA_CHEAP, LlmModel.cheapFor(LlmProvider.OPENROUTER))
    }
}
