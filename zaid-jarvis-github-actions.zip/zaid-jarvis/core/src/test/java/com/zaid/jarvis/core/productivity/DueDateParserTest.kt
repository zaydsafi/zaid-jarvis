package com.zaid.jarvis.core.productivity

import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** DueDateParser (Phase 9): every supported phrase + unparseable input. */
class DueDateParserTest {

    // A fixed "now": Sunday 2026-11-15, 10:30 Asia/Kabul.
    private val zone: ZoneId = ZoneId.of("Asia/Kabul")
    private val now: ZonedDateTime = ZonedDateTime.of(
        LocalDate.of(2026, 11, 15),
        LocalTime.of(10, 30),
        zone,
    )

    private fun at(date: LocalDate, time: LocalTime): Long =
        ZonedDateTime.of(date, time, zone).toInstant().toEpochMilli()

    private fun parse(text: String): Long? = DueDateParser.parse(text, now, zone)

    @Test
    fun `today resolves to end of day`() {
        assertEquals(
            at(LocalDate.of(2026, 11, 15), LocalTime.of(23, 59)),
            parse("today"),
        )
    }

    @Test
    fun `tomorrow resolves to end of tomorrow`() {
        assertEquals(
            at(LocalDate.of(2026, 11, 16), LocalTime.of(23, 59)),
            parse("tomorrow"),
        )
    }

    @Test
    fun `tonight is today at 20 00`() {
        assertEquals(
            at(LocalDate.of(2026, 11, 15), LocalTime.of(20, 0)),
            parse("tonight"),
        )
    }

    @Test
    fun `tomorrow morning and evening`() {
        assertEquals(
            at(LocalDate.of(2026, 11, 16), LocalTime.of(9, 0)),
            parse("tomorrow morning"),
        )
        assertEquals(
            at(LocalDate.of(2026, 11, 16), LocalTime.of(19, 0)),
            parse("tomorrow evening"),
        )
    }

    @Test
    fun `this evening and end of day`() {
        assertEquals(
            at(LocalDate.of(2026, 11, 15), LocalTime.of(19, 0)),
            parse("this evening"),
        )
        assertEquals(
            at(LocalDate.of(2026, 11, 15), LocalTime.of(23, 59)),
            parse("end of day"),
        )
        assertEquals(
            at(LocalDate.of(2026, 11, 15), LocalTime.of(23, 59)),
            parse("eod"),
        )
    }

    @Test
    fun `in N days hours minutes weeks`() {
        assertEquals(now.plusDays(3).toInstant().toEpochMilli(), parse("in 3 days"))
        assertEquals(now.plusHours(2).toInstant().toEpochMilli(), parse("in 2 hours"))
        assertEquals(now.plusMinutes(30).toInstant().toEpochMilli(), parse("in 30 minutes"))
        assertEquals(now.plusWeeks(1).toInstant().toEpochMilli(), parse("in a week"))
        assertEquals(now.plusHours(1).toInstant().toEpochMilli(), parse("in an hour"))
        assertEquals(now.plusDays(1).toInstant().toEpochMilli(), parse("in 1 day"))
    }

    @Test
    fun `next week and next month`() {
        assertEquals(now.plusWeeks(1).toInstant().toEpochMilli(), parse("next week"))
        assertEquals(now.plusMonths(1).toInstant().toEpochMilli(), parse("next month"))
    }

    @Test
    fun `weekday names resolve to the next occurrence`() {
        // Now is Sunday 2026-11-15. Monday is tomorrow; Friday is 5 days out.
        assertEquals(
            at(LocalDate.of(2026, 11, 16), LocalTime.of(23, 59)),
            parse("monday"),
        )
        assertEquals(
            at(LocalDate.of(2026, 11, 20), LocalTime.of(23, 59)),
            parse("friday"),
        )
        // "sunday" today is Sunday — must be NEXT Sunday, never today.
        assertEquals(
            at(LocalDate.of(2026, 11, 22), LocalTime.of(23, 59)),
            parse("sunday"),
        )
        assertEquals(
            at(LocalDate.of(2026, 11, 16), LocalTime.of(23, 59)),
            parse("next monday"),
        )
    }

    @Test
    fun `day phrase at time`() {
        assertEquals(
            at(LocalDate.of(2026, 11, 16), LocalTime.of(17, 0)),
            parse("tomorrow at 5pm"),
        )
        assertEquals(
            at(LocalDate.of(2026, 11, 20), LocalTime.of(9, 30)),
            parse("friday at 9:30am"),
        )
        assertEquals(
            at(LocalDate.of(2026, 11, 15), LocalTime.of(14, 0)),
            parse("today at 14:00"),
        )
        assertEquals(
            at(LocalDate.of(2026, 11, 18), LocalTime.of(10, 0)),
            parse("in 3 days at 10am"),
        )
    }

    @Test
    fun `12-hour times handle noon and midnight`() {
        assertEquals(
            at(LocalDate.of(2026, 11, 16), LocalTime.of(12, 0)),
            parse("tomorrow at 12pm"),
        )
        assertEquals(
            at(LocalDate.of(2026, 11, 16), LocalTime.of(0, 0)),
            parse("tomorrow at 12am"),
        )
        assertEquals(
            at(LocalDate.of(2026, 11, 16), LocalTime.of(0, 30)),
            parse("tomorrow at 12:30am"),
        )
    }

    @Test
    fun `ISO dates with and without time`() {
        assertEquals(
            at(LocalDate.of(2026, 11, 20), LocalTime.of(23, 59)),
            parse("2026-11-20"),
        )
        assertEquals(
            at(LocalDate.of(2026, 11, 20), LocalTime.of(15, 30)),
            parse("2026-11-20 15:30"),
        )
    }

    @Test
    fun `case and extra spaces are tolerated`() {
        assertEquals(parse("tomorrow"), parse("  Tomorrow  "))
        assertEquals(parse("friday at 5pm"), parse("Friday   AT   5PM"))
    }

    @Test
    fun `unparseable input returns null, never a guess`() {
        assertNull(parse(""))
        assertNull(parse("someday"))
        assertNull(parse("whenever"))
        assertNull(parse("next tuesdayish"))
        assertNull(parse("tomorrow at teatime"))
        assertNull(parse("in five days"))
        assertNull(parse("tomorrow at 25:00"))
        assertNull(parse("tomorrow at 13pm"))
        assertNull(parse("2026-13-40"))
        assertNull(parse("friday the 13th"))
    }

    @Test
    fun `parseTime accepts 12h, 24h, and hour-only times`() {
        assertEquals(LocalTime.of(17, 0), DueDateParser.parseTime("5pm"))
        assertEquals(LocalTime.of(9, 30), DueDateParser.parseTime("9:30am"))
        assertEquals(LocalTime.of(14, 0), DueDateParser.parseTime("14:00"))
        assertEquals(LocalTime.of(9, 0), DueDateParser.parseTime("9"))
        assertNull(DueDateParser.parseTime("25:00"))
        assertNull(DueDateParser.parseTime("13pm"))
        assertNull(DueDateParser.parseTime("noon"))
    }
}
