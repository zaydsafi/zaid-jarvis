package com.zaid.jarvis.core.research

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** HTML → readable text extraction (Phase 7, `fetch_page`). */
class HtmlTextExtractorTest {

    @Test
    fun `strips scripts styles and nav but keeps headings and paragraphs`() {
        val html = """
            <html><head><title>Test Page</title>
            <style>body { color: red; }</style>
            <script>var secret = 1;</script></head>
            <body>
            <nav><a href="/menu">Menu item</a></nav>
            <h1>Main Heading</h1>
            <p>First paragraph.</p>
            <p>Second paragraph with <b>bold</b> text.</p>
            <footer>Footer text</footer>
            </body></html>
        """.trimIndent()
        val page = HtmlTextExtractor.extract("https://example.com", html)
        assertEquals("Test Page", page.title)
        assertTrue(page.text.contains("Main Heading"))
        assertTrue(page.text.contains("First paragraph."))
        assertTrue(page.text.contains("Second paragraph with bold text."))
        assertFalse(page.text.contains("secret"))
        assertFalse(page.text.contains("color: red"))
        assertFalse(page.text.contains("Menu item"))
        assertFalse(page.text.contains("Footer text"))
        assertFalse(page.text.contains("<"))
    }

    @Test
    fun `decodes html entities`() {
        val html = "<p>Fish &amp; Chips &lt;tag&gt; &quot;quoted&quot; &#39;apos&#39; &#65; &#x42;</p>"
        val page = HtmlTextExtractor.extract("https://example.com", html)
        assertEquals("Fish & Chips <tag> \"quoted\" 'apos' A B", page.text)
    }

    @Test
    fun `list items become separate lines`() {
        val html = "<ul><li>One</li><li>Two</li><li>Three</li></ul>"
        val page = HtmlTextExtractor.extract("https://example.com", html)
        assertEquals("One\nTwo\nThree", page.text)
    }

    @Test
    fun `truncates long text and flags it`() {
        val html = "<p>${"a".repeat(100)}</p>"
        val page = HtmlTextExtractor.extract("https://example.com", html, maxChars = 10)
        assertEquals(10, page.text.length)
        assertTrue(page.truncated)
    }

    @Test
    fun `short text is not flagged as truncated`() {
        val page = HtmlTextExtractor.extract("https://example.com", "<p>Short</p>", maxChars = 100)
        assertEquals("Short", page.text)
        assertFalse(page.truncated)
    }

    @Test
    fun `empty html gives empty text`() {
        val page = HtmlTextExtractor.extract("https://example.com", "")
        assertEquals("", page.text)
        assertEquals("", page.title)
    }
}
