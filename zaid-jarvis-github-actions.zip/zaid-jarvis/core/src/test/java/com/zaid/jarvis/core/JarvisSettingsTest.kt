package com.zaid.jarvis.core

import com.zaid.jarvis.core.model.JarvisSettings
import com.zaid.jarvis.core.model.LlmModel
import com.zaid.jarvis.core.model.LlmProvider
import org.junit.Assert.assertEquals
import org.junit.Test

class JarvisSettingsTest {

    @Test
    fun `switching provider resets model to provider default`() {
        val settings = JarvisSettings()
            .withProvider(LlmProvider.OPENAI)

        assertEquals(LlmProvider.OPENAI, settings.llmProvider)
        assertEquals(LlmModel.GPT_5_MINI, settings.llmModel)
    }

    @Test
    fun `picking a model switches provider to match`() {
        val settings = JarvisSettings()
            .withModel(LlmModel.GEMINI_3_PRO)

        assertEquals(LlmProvider.GEMINI, settings.llmProvider)
        assertEquals(LlmModel.GEMINI_3_PRO, settings.llmModel)
    }

    @Test
    fun `each provider exposes its own models`() {
        assertEquals(
            listOf(LlmModel.CLAUDE_SONNET_5_5, LlmModel.CLAUDE_HAIKU_5_5),
            LlmModel.forProvider(LlmProvider.CLAUDE),
        )
        assertEquals(2, LlmModel.forProvider(LlmProvider.OPENAI).size)
        assertEquals(2, LlmModel.forProvider(LlmProvider.GEMINI).size)
    }

    @Test
    fun `defaults are Claude Sonnet with system theme`() {
        val defaults = JarvisSettings()
        assertEquals(LlmProvider.CLAUDE, defaults.llmProvider)
        assertEquals(LlmModel.CLAUDE_SONNET_5_5, defaults.llmModel)
        assertEquals(1.0f, defaults.voiceSpeed, 0.001f)
    }
}
