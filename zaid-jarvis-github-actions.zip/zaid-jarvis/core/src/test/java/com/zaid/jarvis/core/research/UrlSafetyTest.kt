package com.zaid.jarvis.core.research

import com.zaid.jarvis.core.util.JarvisResult
import java.net.InetAddress
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** SSRF guard for `fetch_page` (Phase 7). */
class UrlSafetyTest {

    private fun isAllowed(url: String): Boolean =
        UrlSafety.validateUrl(url) is JarvisResult.Success

    @Test
    fun `public http and https urls are allowed`() {
        assertTrue(isAllowed("https://example.com/page"))
        assertTrue(isAllowed("http://example.com/"))
        assertTrue(isAllowed("https://sub.example.co.uk/path?q=1#frag"))
        assertTrue(isAllowed("https://8.8.8.8/dns"))
        assertTrue(isAllowed("https://1.1.1.1/"))
    }

    @Test
    fun `non-http schemes are refused`() {
        assertFalse(isAllowed("ftp://example.com/file"))
        assertFalse(isAllowed("file:///etc/passwd"))
        assertFalse(isAllowed("content://com.example/data"))
        assertFalse(isAllowed("intent://example.com#Intent;scheme=https;end"))
        assertFalse(isAllowed("example.com/no-scheme"))
        assertFalse(isAllowed(""))
    }

    @Test
    fun `localhost is refused`() {
        assertFalse(isAllowed("http://localhost/"))
        assertFalse(isAllowed("http://localhost:8080/admin"))
        assertFalse(isAllowed("https://foo.localhost/"))
    }

    @Test
    fun `loopback and private ipv4 ranges are refused`() {
        assertFalse(isAllowed("http://127.0.0.1/"))
        assertFalse(isAllowed("http://127.1.2.3:3000/"))
        assertFalse(isAllowed("http://10.0.0.1/router"))
        assertFalse(isAllowed("http://10.255.255.255/"))
        assertFalse(isAllowed("http://172.16.0.5/"))
        assertFalse(isAllowed("http://172.31.255.1/"))
        assertFalse(isAllowed("http://192.168.1.1/"))
        assertFalse(isAllowed("http://192.168.0.100:8080/"))
    }

    @Test
    fun `link-local and special ranges are refused`() {
        assertFalse(isAllowed("http://169.254.169.254/latest/meta-data/"))
        assertFalse(isAllowed("http://0.0.0.0/"))
        assertFalse(isAllowed("http://100.64.0.1/"))
        assertFalse(isAllowed("http://224.0.0.1/"))
    }

    @Test
    fun `public ips just outside the private ranges are allowed`() {
        assertTrue(isAllowed("http://172.32.0.1/"))
        assertTrue(isAllowed("http://172.15.0.1/"))
        assertTrue(isAllowed("http://192.169.1.1/"))
        assertTrue(isAllowed("http://11.0.0.1/"))
    }

    @Test
    fun `ipv6 loopback and link-local are refused`() {
        assertFalse(isAllowed("http://[::1]/"))
        assertFalse(isAllowed("http://[fe80::1]/"))
        assertFalse(isAllowed("http://[fd00::1]/"))
    }

    @Test
    fun `userinfo tricks do not hide the real host`() {
        // "example.com@127.0.0.1" — the real host is 127.0.0.1.
        assertFalse(isAllowed("http://example.com@127.0.0.1/"))
        assertTrue(isAllowed("http://user:pass@example.com/"))
    }

    @Test
    fun `leading-zero octets are refused`() {
        // "010.0.0.1" is ambiguous (some stacks read it as octal 8) — fail closed.
        assertFalse(isAllowed("http://010.0.0.1/"))
    }

    @Test
    fun `host extraction handles ports and paths`() {
        assertTrue(UrlSafety.extractHost("https://example.com:8443/a/b") == "example.com")
        assertTrue(UrlSafety.extractHost("https://[2001:db8::1]:443/") == "2001:db8::1")
    }

    // ── Phase 11: IPv4-mapped / IPv4-compatible IPv6 literals ─────────

    @Test
    fun `ipv4-mapped ipv6 literals embedding private ips are refused`() {
        // Phase 11: these used to return false (no checked IPv6 prefix
        // matches) even though the OS connects to the embedded IPv4.
        assertFalse(isAllowed("http://[::ffff:127.0.0.1]/"))
        assertFalse(isAllowed("http://[::ffff:192.168.1.1]/"))
        assertFalse(isAllowed("http://[::ffff:10.0.0.5]/"))
        assertFalse(isAllowed("http://[0:0:0:0:0:ffff:172.16.0.1]/"))
    }

    @Test
    fun `ipv4-compatible ipv6 literals embedding private ips are refused`() {
        assertFalse(isAllowed("http://[::127.0.0.1]/"))
        assertFalse(isAllowed("http://[::192.168.0.5]/"))
        assertFalse(isAllowed("http://[0:0:0:0:0:0:10.1.2.3]/"))
    }

    @Test
    fun `ipv4-mapped literals embedding public ips are allowed`() {
        assertTrue(isAllowed("https://[::ffff:8.8.8.8]/"))
        assertTrue(isAllowed("https://[::8.8.4.4]/"))
    }

    // ── Phase 11: resolved-address checks (the ValidatingDns layer) ───

    private fun isNonPublic(address: String): Boolean =
        UrlSafety.isNonPublicAddress(InetAddress.getByName(address))

    /** Builds a genuine 16-byte IPv4-mapped address (::ffff:a.b.c.d). */
    private fun mappedAddress(a: Int, b: Int, c: Int, d: Int): InetAddress =
        // getByName() normalizes mapped literals to Inet4Address on
        // this JDK, so the 16-byte form is built explicitly — it is
        // what a DNS AAAA answer can return.
        InetAddress.getByAddress(
            byteArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xFF.toByte(), 0xFF.toByte(), a.toByte(), b.toByte(), c.toByte(), d.toByte()),
        )

    @Test
    fun `resolved private and loopback ipv4 addresses are non-public`() {
        assertTrue(isNonPublic("127.0.0.1"))
        assertTrue(isNonPublic("10.1.2.3"))
        assertTrue(isNonPublic("172.16.0.9"))
        assertTrue(isNonPublic("192.168.0.1"))
        assertTrue(isNonPublic("169.254.169.254"))
        assertTrue(isNonPublic("100.64.0.1")) // CGNAT — the stdlib predicates miss this.
        assertTrue(isNonPublic("0.0.0.0"))
    }

    @Test
    fun `resolved public ipv4 addresses are public`() {
        assertFalse(isNonPublic("8.8.8.8"))
        assertFalse(isNonPublic("1.1.1.1"))
        assertFalse(isNonPublic("93.184.216.34"))
    }

    @Test
    fun `integer-form ipv4 resolves to the loopback address and is refused`() {
        // The literal check cannot see this spelling (no dotted quad),
        // but resolution normalizes 2130706433 to 127.0.0.1 — the Dns
        // guard catches it.
        assertTrue(isNonPublic("2130706433"))
    }

    @Test
    fun `resolved non-public ipv6 addresses are refused`() {
        assertTrue(isNonPublic("::1"))
        assertTrue(isNonPublic("::"))
        assertTrue(isNonPublic("fe80::1"))
        assertTrue(isNonPublic("fd00::1")) // unique-local — isSiteLocalAddress misses this.
        assertTrue(isNonPublic("ff02::1"))
        assertFalse(isNonPublic("2001:db8::1"))
        assertFalse(isNonPublic("2606:4700:4700::1111"))
    }

    @Test
    fun `resolved ipv4-mapped addresses validate the embedded ipv4`() {
        assertTrue(UrlSafety.isNonPublicAddress(mappedAddress(127, 0, 0, 1)))
        assertTrue(UrlSafety.isNonPublicAddress(mappedAddress(192, 168, 0, 5)))
        assertTrue(UrlSafety.isNonPublicAddress(mappedAddress(10, 0, 0, 1)))
        assertFalse(UrlSafety.isNonPublicAddress(mappedAddress(8, 8, 8, 8)))
    }

    @Test
    fun `resolved ipv4-compatible addresses validate the embedded ipv4`() {
        // ::a.b.c.d stays a 16-byte Inet6Address, and the stdlib
        // predicates report it as neither loopback nor site-local.
        assertTrue(isNonPublic("::127.0.0.1"))
        assertTrue(isNonPublic("::192.168.0.5"))
        assertFalse(isNonPublic("::8.8.8.8"))
    }
}
