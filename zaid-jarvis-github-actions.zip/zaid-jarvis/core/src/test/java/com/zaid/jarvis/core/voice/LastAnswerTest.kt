package com.zaid.jarvis.core.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LastAnswerTest {

    @Test fun shortAnswerUnchanged() {
        assertEquals("It is 3:45 PM.", LastAnswer.formatForWidget("It is 3:45 PM."))
    }

    @Test fun blankAnswerShowsEmptyText() {
        assertEquals(LastAnswer.EMPTY_TEXT, LastAnswer.formatForWidget("   "))
        assertEquals(LastAnswer.EMPTY_TEXT, LastAnswer.formatForWidget(""))
    }

    @Test fun multilineAnswerFlattensToOneLine() {
        assertEquals(
            "Line one Line two Line three",
            LastAnswer.formatForWidget("Line one\nLine two\nLine three"),
        )
    }

    @Test fun longAnswerTruncatesWithEllipsis() {
        val long = "word ".repeat(30)
        val formatted = LastAnswer.formatForWidget(long)
        assertTrue(formatted.endsWith("…"))
        assertTrue(formatted.length <= LastAnswer.MAX_WIDGET_CHARS + 1)
    }
}
