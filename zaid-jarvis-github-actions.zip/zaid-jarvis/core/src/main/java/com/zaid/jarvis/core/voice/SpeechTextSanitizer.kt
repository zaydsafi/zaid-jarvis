package com.zaid.jarvis.core.voice

/**
 * Makes LLM answers speakable (Master Prompt §5.2). Pure Kotlin,
 * unit-tested.
 *
 * Text-to-speech reads text literally, so markdown, code fences, URLs,
 * and emoji come out garbled ("asterisk asterisk"). This strips them
 * before speaking — the chat bubble keeps the original text; only the
 * spoken copy is sanitized.
 */
object SpeechTextSanitizer {

    /** Maximum characters spoken in one utterance (overlong answers are cut). */
    const val MAX_SPOKEN_CHARS: Int = 2_000

    fun sanitize(text: String): String {
        var out = text
        // Code fences (```…```) and inline code (`…`) — spoken as "code".
        out = out.replace(Regex("```[\\s\\S]*?```"), " code ")
        out = out.replace(Regex("`([^`]*)`"), "$1")
        // Images ![alt](url) → alt; links [text](url) → text.
        out = out.replace(Regex("!\\[([^]]*)]\\([^)]*\\)"), "$1")
        out = out.replace(Regex("\\[([^]]*)]\\([^)]*\\)"), "$1")
        // Bare URLs → "link".
        out = out.replace(Regex("https?://\\S+"), "link")
        // Headings, bold, italic, strikethrough markers.
        out = out.replace(Regex("(?m)^#{1,6}\\s*"), "")
        out = out.replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")
        out = out.replace(Regex("__([^_]+)__"), "$1")
        out = out.replace(Regex("(?<!\\w)\\*([^*\n]+)\\*(?!\\w)"), "$1")
        out = out.replace(Regex("~~([^~]+)~~"), "$1")
        // List bullets → pauses.
        out = out.replace(Regex("(?m)^\\s*[-*+]\\s+"), "")
        out = out.replace(Regex("(?m)^\\s*\\d+[.)]\\s+"), "")
        // Emoji and other pictographs.
        out = out.replace(Regex("[\\p{So}\\p{Sk}]+"), "")
        // Leftover markdown/punctuation noise.
        out = out.replace(Regex("[*_#>|~]+"), "")
        // Collapse whitespace; keep sentence punctuation.
        out = out.replace(Regex("\\s+"), " ").trim()
        if (out.length > MAX_SPOKEN_CHARS) {
            out = out.take(MAX_SPOKEN_CHARS).substringBeforeLast(' ', "")
                .ifBlank { out.take(MAX_SPOKEN_CHARS) }
        }
        return out
    }
}
