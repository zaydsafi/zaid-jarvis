package com.zaid.jarvis.core.confirmation

import java.util.Collections
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * The kill switch (Master Prompt §2.4): one tap — or the voice command
 * "Jarvis stop" (Phase 4) — cancels all running and queued automation
 * immediately.
 *
 * How it works:
 * - [cancelAll] bumps a generation counter, cancels every registered [Job],
 *   and notifies listeners (the Confirmation Engine cancels its pending
 *   request). Executions capture the generation at start and refuse to
 *   proceed if it changed, so a stop issued while Zaid is reading an
 *   approval card still prevents the action.
 * - The latch is per-run, not permanent: after a stop, new requests work
 *   normally. There is no "resume" — a cancelled run is never resumed,
 *   Zaid starts a fresh request instead.
 *
 * Full automation wiring (agent loop, accessibility runs) registers its
 * jobs here in Phases 3 and 6; the engine + UI control exist from Phase 2.
 */
class KillSwitch {
    private val _generation = MutableStateFlow(0)
    /** Increments on every [cancelAll]; the UI uses it to show feedback. */
    val generation: StateFlow<Int> = _generation.asStateFlow()

    private val jobs = Collections.synchronizedSet(mutableSetOf<Job>())
    private val listeners = Collections.synchronizedList(mutableListOf<() -> Unit>())

    fun currentGeneration(): Int = _generation.value

    /** Registers a running job so [cancelAll] cancels it. */
    fun register(job: Job) {
        jobs += job
        job.invokeOnCompletion { jobs -= job }
    }

    /** Listeners are called (synchronously) on every [cancelAll]. */
    fun addOnCancelListener(listener: () -> Unit) {
        listeners += listener
    }

    /** Cancels everything running or queued. Safe to call repeatedly. */
    fun cancelAll() {
        _generation.value = _generation.value + 1
        jobs.toList().forEach { it.cancel() }
        jobs.clear()
        listeners.toList().forEach { it() }
    }
}
