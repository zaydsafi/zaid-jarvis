package com.zaid.jarvis.core.productivity

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * The "never nag" rules (Phase 9, Master Prompt §9.9).
 *
 * Every proactive feature funnels through these pure functions so the
 * throttling is testable without WorkManager, notifications, or a
 * device:
 * - **Smart overdue reminders**: one gentle nudge per task per day.
 * - **Break reminders**: at most once per hour, only after the
 *   configured interval of continuous screen time.
 * - **Daily digest**: next run time for a configured hour/minute.
 * - **Wind-down**: once per day, only inside the bedtime window.
 *
 * All "day" values are epoch days (days since 1970-01-01, UTC) so the
 * dedupe key is one stable number.
 */
object ProactiveRules {

    /** Minimum gap between two break reminders: 60 minutes. */
    const val MIN_BREAK_GAP_MINUTES: Long = 60

    /** How long after bedtime a wind-down nudge is still due (the worker runs every 15 min). */
    const val WIND_DOWN_WINDOW_MINUTES: Long = 30

    /** Epoch day (UTC) for [epochMillis]. */
    fun epochDay(epochMillis: Long): Long =
        Instant.ofEpochMilli(epochMillis).atZone(ZoneId.of("UTC")).toLocalDate().toEpochDay()

    /**
     * Should Jarvis nudge about this overdue task right now?
     * True only when the task is open, overdue, and has not been
     * nudged yet today ([lastNotifiedDay] is null or a different day).
     * The caller also checks quiet hours separately.
     */
    fun shouldNotifyOverdue(task: Task, nowMillis: Long): Boolean {
        if (!task.isOverdue(nowMillis)) return false
        return task.overdueNotifiedDay != epochDay(nowMillis)
    }

    /**
     * Should Jarvis send a break reminder right now?
     * True only when the current continuous screen session is at least
     * [intervalMinutes] long AND the last break reminder was at least
     * [MIN_BREAK_GAP_MINUTES] ago (or never sent). The caller also
     * checks quiet hours and that no focus session is running.
     */
    fun shouldNotifyBreak(
        continuousScreenMillis: Long,
        intervalMinutes: Int,
        lastBreakNotifiedMillis: Long?,
        nowMillis: Long,
    ): Boolean {
        if (continuousScreenMillis < intervalMinutes * 60_000L) return false
        val last = lastBreakNotifiedMillis ?: return true
        return nowMillis - last >= MIN_BREAK_GAP_MINUTES * 60_000L
    }

    /**
     * Should Jarvis send the wind-down nudge right now?
     * True only when the current time is inside the window
     * [bedtime, bedtime + WIND_DOWN_WINDOW_MINUTES) and no wind-down
     * nudge has been sent yet today. Wind-down is exempt from quiet
     * hours by design — bedtime (default 23:00) is normally *inside*
     * quiet hours (default 22:00–07:00), the user explicitly opted in,
     * and they chose the time.
     */
    fun shouldNotifyWindDown(
        bedtimeHour: Int,
        bedtimeMinute: Int,
        lastWindDownDay: Long?,
        nowMillis: Long,
        zone: ZoneId = ZoneId.systemDefault(),
    ): Boolean {
        if (lastWindDownDay == epochDay(nowMillis)) return false
        val now = ZonedDateTime.ofInstant(Instant.ofEpochMilli(nowMillis), zone)
        val bedtime = now.toLocalDate().atTime(bedtimeHour, bedtimeMinute).atZone(zone)
        val windowEnd = bedtime.plusMinutes(WIND_DOWN_WINDOW_MINUTES)
        return !now.isBefore(bedtime) && now.isBefore(windowEnd)
    }

    /**
     * Next occurrence of [hour]:[minute] strictly after [nowMillis]
     * (tomorrow when today's time has already passed). Used to
     * schedule the daily digest chain.
     */
    fun nextDailyTimeMillis(
        hour: Int,
        minute: Int,
        nowMillis: Long,
        zone: ZoneId = ZoneId.systemDefault(),
    ): Long {
        val now = ZonedDateTime.ofInstant(Instant.ofEpochMilli(nowMillis), zone)
        var next = now.toLocalDate().atTime(hour, minute).atZone(zone)
        if (next.toInstant().toEpochMilli() <= nowMillis) {
            next = next.plusDays(1)
        }
        return next.toInstant().toEpochMilli()
    }

    /** Today's date (device zone), for the briefing header. */
    fun todayDate(nowMillis: Long, zone: ZoneId = ZoneId.systemDefault()): LocalDate =
        LocalDate.ofInstant(Instant.ofEpochMilli(nowMillis), zone)
}
