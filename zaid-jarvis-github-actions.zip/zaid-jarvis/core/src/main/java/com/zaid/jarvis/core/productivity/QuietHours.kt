package com.zaid.jarvis.core.productivity

import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * Quiet hours (Phase 9): the one shared rule every proactive notifier
 * obeys. During quiet hours Jarvis posts NO proactive notification —
 * except the Phase 8 publish/schedule results and user-set task
 * reminders, which are explicit requests, not nudges.
 *
 * Times are minutes since midnight (0–1439). The default window
 * 22:00–07:00 wraps around midnight, so the check is not a simple
 * range test: when start > end, quiet time is [start, 24:00) ∪
 * [00:00, end). When start == end, quiet hours are disabled (an
 * empty window — the UI treats equal start/end as "off").
 */
data class QuietHours(
    /** Start of quiet time, minutes since midnight (default 22:00 = 1320). */
    val startMinute: Int,
    /** End of quiet time, minutes since midnight (default 07:00 = 420). */
    val endMinute: Int,
) {
    companion object {
        /** Default quiet hours: 22:00–07:00. */
        val DEFAULT: QuietHours = QuietHours(startMinute = 22 * 60, endMinute = 7 * 60)

        /** Quiet hours disabled (empty window). */
        val DISABLED: QuietHours = QuietHours(startMinute = 0, endMinute = 0)
    }

    /** True when the window is empty (start == end) — quiet hours off. */
    fun isDisabled(): Boolean = startMinute == endMinute

    /** True when [time] falls inside the quiet window. */
    fun isQuietAt(time: LocalTime): Boolean {
        if (isDisabled()) return false
        val minute = time.hour * 60 + time.minute
        return if (startMinute < endMinute) {
            minute in startMinute until endMinute
        } else {
            // Wraps midnight: quiet from start to midnight, and from
            // midnight to end.
            minute >= startMinute || minute < endMinute
        }
    }

    /** True when the instant (in [zone]) falls inside the quiet window. */
    fun isQuietAt(
        epochMillis: Long,
        zone: ZoneId = ZoneId.systemDefault(),
    ): Boolean {
        val time = ZonedDateTime.ofInstant(Instant.ofEpochMilli(epochMillis), zone).toLocalTime()
        return isQuietAt(time)
    }

    /** "22:00 – 07:00" style label for Settings. */
    fun displayLabel(): String {
        if (isDisabled()) return "Off"
        return "${formatMinute(startMinute)} – ${formatMinute(endMinute)}"
    }

    private fun formatMinute(minute: Int): String {
        val hour = (minute / 60).coerceIn(0, 23)
        val min = (minute % 60).coerceIn(0, 59)
        return "%02d:%02d".format(hour, min)
    }
}
