package com.zaid.jarvis.core.model

/**
 * A snapshot of on-device context the planner may include in its system
 * prompt (Master Prompt §4: "context providers (opt-in)").
 *
 * Phase 3 wires only time, battery, and network state. Calendar, location,
 * foreground app, and notification digest arrive in later phases — each
 * behind its own opt-in.
 *
 * This is pure data (no Android APIs) so the planner and its tests can
 * build snapshots without a device.
 */
data class ContextSnapshot(
    /** Human-readable local date/time, e.g. "Sun 2026-11-15 19:47". */
    val localDateTime: String,
    /** Battery percentage 0–100, or null when unknown. */
    val batteryPercent: Int? = null,
    val isCharging: Boolean = false,
    /** Whether the device currently has a usable network connection. */
    val isOnline: Boolean = true,
) {
    /** Short context block for the LLM system prompt. */
    fun formatForPrompt(): String = buildString {
        append("Current date and time: $localDateTime.")
        batteryPercent?.let { append(" Battery: $it%${if (isCharging) " (charging)" else ""}.") }
        if (!isOnline) append(" The device is OFFLINE.")
    }
}
