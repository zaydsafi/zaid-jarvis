package com.zaid.jarvis.core.productivity

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/**
 * Tasks & focus sessions (Phase 9: productivity core + wellness).
 *
 * Everything here is pure Kotlin: no Android, no database, no network.
 * Storage lives in :data (TaskRepository / FocusSessionRepository);
 * the planner tools in :tools program against the TaskStore /
 * FocusSessionManager interfaces.
 */

/** Task priority. */
enum class TaskPriority(val displayName: String) {
    LOW("Low"),
    MEDIUM("Medium"),
    HIGH("High"),
    ;

    companion object {
        /** Parses an LLM-supplied priority (case-insensitive). Null when unknown. */
        fun fromName(name: String): TaskPriority? = when (name.trim().lowercase()) {
            "low" -> LOW
            "medium", "normal" -> MEDIUM
            "high", "urgent" -> HIGH
            else -> null
        }
    }
}

/** Task status. */
enum class TaskStatus {
    OPEN,
    DONE,
}

/**
 * One task. [dueAtMillis] and [reminderAtMillis] are epoch millis (null
 * = no due date / no reminder). [overdueNotifiedDay] is the epoch day
 * (days since 1970-01-01, UTC) on which Jarvis last sent an overdue
 * nudge for this task — the smart-reminder dedupe key (one nudge per
 * task per day, see [ProactiveRules]). [reminderWorkId] is the
 * WorkManager job id for the reminder, so cancelling the reminder also
 * cancels the job.
 */
data class Task(
    val id: Long = 0,
    val title: String,
    val notes: String = "",
    val dueAtMillis: Long? = null,
    val priority: TaskPriority = TaskPriority.MEDIUM,
    val status: TaskStatus = TaskStatus.OPEN,
    val reminderAtMillis: Long? = null,
    val reminderWorkId: String? = null,
    val overdueNotifiedDay: Long? = null,
    val createdAtMillis: Long = 0,
    val updatedAtMillis: Long = 0,
) {
    /** True when the task is open and its due time has passed. */
    fun isOverdue(nowMillis: Long = System.currentTimeMillis()): Boolean =
        status == TaskStatus.OPEN && dueAtMillis != null && dueAtMillis < nowMillis

    /** True when the task is open and due today (device time zone). */
    fun isDueToday(
        nowMillis: Long = System.currentTimeMillis(),
        zone: ZoneId = ZoneId.systemDefault(),
    ): Boolean {
        if (status != TaskStatus.OPEN || dueAtMillis == null) return false
        val today = LocalDate.ofInstant(Instant.ofEpochMilli(nowMillis), zone)
        val dueDay = LocalDate.ofInstant(Instant.ofEpochMilli(dueAtMillis), zone)
        return dueDay == today
    }
}

/** Focus-session status. */
enum class FocusSessionStatus {
    /** In progress (or scheduled to end — the end worker/service finishes it). */
    RUNNING,

    /** Ended on time (timer ran out, DND restored). */
    COMPLETED,

    /** Stopped early by Zaid (DND restored). */
    CANCELLED,
}

/**
 * One focus session. [previousDndMode] is the [DndMode] name Jarvis
 * restores when the session ends (null when DND was already in the
 * focus mode, so there is nothing to restore). Sessions are
 * append-only history once finished — the Wellness screen lists them.
 */
data class FocusSession(
    val id: Long = 0,
    val startedAtMillis: Long,
    /** Planned length in minutes (25 / 50 / 90 presets, or custom 5–240). */
    val durationMinutes: Int,
    /** When the session actually ended (null while running). */
    val endedAtMillis: Long? = null,
    val status: FocusSessionStatus = FocusSessionStatus.RUNNING,
    /** DndMode name to restore at the end (null = nothing to restore). */
    val previousDndMode: String? = null,
    /** WorkManager job id for the end-of-session worker (null until enqueued). */
    val endWorkId: String? = null,
) {
    /** Epoch millis when the session is due to end. */
    fun endsAtMillis(): Long = startedAtMillis + durationMinutes * 60_000L

    /** Milliseconds remaining, 0 when the session is over. */
    fun remainingMillis(nowMillis: Long = System.currentTimeMillis()): Long =
        (endsAtMillis() - nowMillis).coerceAtLeast(0L)

    /** True when a RUNNING session's timer has run out. */
    fun isDueToEnd(nowMillis: Long = System.currentTimeMillis()): Boolean =
        status == FocusSessionStatus.RUNNING && nowMillis >= endsAtMillis()
}
