package com.zaid.jarvis.core.util

/**
 * A simple typed result for operations that can fail without throwing.
 * Used across modules so the UI can show honest errors (Master Prompt §2.6).
 */
sealed interface JarvisResult<out T> {
    data class Success<T>(val value: T) : JarvisResult<T>
    data class Failure(val message: String, val cause: Throwable? = null) : JarvisResult<Nothing>

    val isSuccess: Boolean get() = this is Success
}

/** Runs [block], converting exceptions into [JarvisResult.Failure]. */
inline fun <T> runCatchingJarvis(block: () -> T): JarvisResult<T> =
    try {
        JarvisResult.Success(block())
    } catch (e: Exception) {
        JarvisResult.Failure(e.message ?: e::class.simpleName ?: "Unknown error", e)
    }
