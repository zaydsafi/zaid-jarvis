package com.zaid.jarvis.core.voice

/**
 * Parses voice transcripts for built-in commands (Master Prompt §2.4,
 * §5.2). Pure Kotlin, unit-tested.
 *
 * The only built-in voice command in Phase 4 is the kill switch:
 * "Jarvis stop" / "Stop Jarvis" cancels all running automation via the
 * Phase 2 [com.zaid.jarvis.core.confirmation.KillSwitch]. It is checked
 * against partial transcripts too, so a stop lands fast — even
 * mid-sentence, even while Jarvis is speaking.
 *
 * Everything else is a plain request for the planner.
 */
object VoiceCommandParser {

    /** What a transcript means to the voice layer. */
    sealed interface VoiceCommand {
        /** "Jarvis stop" / "Stop Jarvis" — cancel everything, now. */
        data object Stop : VoiceCommand

        /** Ordinary request text for the planner. */
        data class Request(val text: String) : VoiceCommand
    }

    private val STOP_SEQUENCES: List<List<String>> = listOf(
        listOf("jarvis", "stop"),
        listOf("stop", "jarvis"),
        listOf("jarvis", "stop", "now"),
        listOf("stop", "jarvis", "now"),
        listOf("hey", "jarvis", "stop"),
    )

    /** True when [transcript] contains a stop command. */
    fun isStopCommand(transcript: String): Boolean {
        val words = WakeWordMatcher.normalize(transcript)
        if (words.isEmpty()) return false
        return STOP_SEQUENCES.any { sequence ->
            sequence.size <= words.size &&
                (0..words.size - sequence.size).any { start ->
                    words.subList(start, start + sequence.size) == sequence
                }
        }
    }

    /** Parses [transcript] into a [VoiceCommand]. */
    fun parse(transcript: String): VoiceCommand {
        val trimmed = transcript.trim()
        return if (isStopCommand(trimmed)) {
            VoiceCommand.Stop
        } else {
            VoiceCommand.Request(WakeWordMatcher.stripWakeWord(trimmed))
        }
    }
}
