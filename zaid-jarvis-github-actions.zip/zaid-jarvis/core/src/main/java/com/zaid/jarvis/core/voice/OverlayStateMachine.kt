package com.zaid.jarvis.core.voice

/**
 * The overlay bubble's state machine (Master Prompt §5.3). Pure Kotlin,
 * unit-tested — the :app BubbleService applies the transitions to the
 * real WindowManager views.
 *
 * States:
 * - [Hidden] — no bubble on screen (service stopped or dismissed).
 * - [Collapsed] — the small floating orb; draggable, tap to expand.
 * - [Dragging] — the orb is being moved; a tap must not expand it.
 * - [Expanded] — the mini chat window is open (with the approval card
 *   when a tool call is awaiting a decision).
 */
object OverlayStateMachine {

    sealed interface State {
        data object Hidden : State
        data object Collapsed : State
        data object Dragging : State
        data object Expanded : State
    }

    sealed interface Event {
        data object Show : Event
        data object Tap : Event
        data object DragStart : Event
        data object DragEnd : Event
        data object Close : Event
        data object LongPressDismiss : Event
    }

    /** Pure transition function: (state, event) → new state. */
    fun transition(state: State, event: Event): State = when (state) {
        State.Hidden -> when (event) {
            Event.Show -> State.Collapsed
            else -> State.Hidden
        }
        State.Collapsed -> when (event) {
            Event.Tap -> State.Expanded
            Event.DragStart -> State.Dragging
            Event.LongPressDismiss, Event.Close -> State.Hidden
            else -> State.Collapsed
        }
        State.Dragging -> when (event) {
            Event.DragEnd -> State.Collapsed
            Event.LongPressDismiss, Event.Close -> State.Hidden
            // A tap that ends a drag must NOT expand the bubble.
            Event.Tap -> State.Dragging
            else -> State.Dragging
        }
        State.Expanded -> when (event) {
            Event.Close, Event.Tap -> State.Collapsed
            Event.LongPressDismiss -> State.Hidden
            else -> State.Expanded
        }
    }
}
