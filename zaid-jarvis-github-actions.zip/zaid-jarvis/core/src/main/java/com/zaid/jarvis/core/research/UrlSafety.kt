package com.zaid.jarvis.core.research

import com.zaid.jarvis.core.util.JarvisResult
import java.net.InetAddress

/**
 * SSRF guard for `fetch_page` (Phase 7, hardened in Phase 11).
 *
 * Jarvis fetches URLs the LLM (or Zaid) asks for, so a malicious page
 * or prompt could try to make it fetch internal addresses — the router
 * admin page, a local service, cloud metadata endpoints. This guard
 * refuses anything that isn't a plain public http(s) URL:
 *
 * - scheme must be http or https (no file:, content:, intent:, …),
 * - host must be present and must not be localhost (incl. *.localhost),
 * - literal IP hosts in private, loopback, link-local, or otherwise
 *   non-public ranges are refused — including IPv4-mapped and
 *   IPv4-compatible IPv6 literals (`::ffff:127.0.0.1`, `::127.0.0.1`),
 *   whose embedded IPv4 is what the OS actually connects to.
 *
 * Two layers, defense in depth:
 * - [validateUrl] / [isNonPublicIp] check the host *as written* — the
 *   first line, before any request is built. They cannot catch every
 *   spelling: a hex-form mapped address (`::ffff:7f00:1`) or an
 *   integer-form IPv4 (`http://2130706433/`) looks like an ordinary
 *   hostname here.
 * - [isNonPublicAddress] checks a *resolved* [InetAddress] (used by
 *   the OkHttp `ValidatingDns` in :agent, which validates every
 *   address DNS returns before OkHttp connects to it). Resolution
 *   normalizes all spellings to the same bytes, so this layer catches
 *   what the literal check misses — including a hostname that
 *   *resolves* to a private IP (DNS rebinding). See ValidatingDns for
 *   the precise guarantees and limits.
 *
 * The risk is bounded in both layers: `fetch_page` only reads text,
 * never sends credentials, and never follows redirects to a new host
 * without re-checking (see OkHttpPageFetcher).
 */
object UrlSafety {

    /** Validates [rawUrl]; returns the trimmed URL or a Failure with the reason. */
    fun validateUrl(rawUrl: String): JarvisResult<String> {
        val url = rawUrl.trim()
        if (url.isEmpty()) {
            return JarvisResult.Failure("No URL given.")
        }
        val scheme = url.substringBefore("://", "").lowercase()
        if (scheme != "http" && scheme != "https") {
            return JarvisResult.Failure(
                "Only http:// and https:// URLs can be fetched (got “${scheme.ifEmpty { "(no scheme)" }}”).",
            )
        }
        val host = extractHost(url)
            ?: return JarvisResult.Failure("That URL has no host to fetch from.")
        if (host.isEmpty()) {
            return JarvisResult.Failure("That URL has no host to fetch from.")
        }
        val lowerHost = host.lowercase()
        if (lowerHost == "localhost" || lowerHost.endsWith(".localhost")) {
            return JarvisResult.Failure(
                "Refusing to fetch localhost — Jarvis only fetches public web pages.",
            )
        }
        if (isNonPublicIp(lowerHost)) {
            return JarvisResult.Failure(
                "Refusing to fetch a private or local network address ($host). " +
                    "Jarvis only fetches public web pages.",
            )
        }
        return JarvisResult.Success(url)
    }

    /** Host part of a URL (without port, userinfo, or IPv6 brackets), or null. */
    fun extractHost(url: String): String? {
        val afterScheme = url.substringAfter("://", "")
        if (afterScheme.isEmpty()) return null
        var authority = afterScheme.substringBefore("/").substringBefore("?").substringBefore("#")
        // Strip userinfo ("user:pass@host").
        authority = authority.substringAfterLast("@", authority)
        if (authority.isEmpty()) return null
        return if (authority.startsWith("[")) {
            // IPv6 literal: [::1] or [::1]:8080.
            val closing = authority.indexOf(']')
            if (closing < 0) null else authority.substring(1, closing)
        } else {
            authority.substringBefore(":")
        }
    }

    /** True when [host] is a literal IP in a non-public range. Hostnames return false. */
    fun isNonPublicIp(host: String): Boolean {
        val ipv4 = parseIpv4(host)
        if (ipv4 != null) {
            return isNonPublicIpv4(ipv4.first, ipv4.second)
        }
        // IPv6 literals (only checked when the host looks like one).
        if (host.contains(":")) {
            val lower = host.lowercase()
            // IPv4-mapped / IPv4-compatible literals embed a dotted-quad
            // IPv4 (::ffff:127.0.0.1, ::127.0.0.1, and their uncompressed
            // forms). The OS connects to the embedded IPv4, so validate
            // it as IPv4 — the prefix checks below would miss it.
            embeddedIpv4(lower)?.let { return isNonPublicIp(it) }
            return when {
                lower == "::1" || lower == "0:0:0:0:0:0:0:1" -> true // loopback
                lower == "::" -> true // unspecified
                lower.startsWith("fe8") || lower.startsWith("fe9") ||
                    lower.startsWith("fea") || lower.startsWith("feb") -> true // fe80::/10 link-local
                lower.startsWith("fc") || lower.startsWith("fd") -> true // fc00::/7 unique-local
                lower.startsWith("ff") -> true // ff00::/8 multicast
                else -> false
            }
        }
        return false
    }

    /**
     * True when a *resolved* [address] is in a non-public range
     * (Phase 11 — the DNS-rebinding layer, used by `ValidatingDns`).
     *
     * This works on the raw address bytes, not on the stdlib
     * predicates, because those miss cases that matter here:
     * `isSiteLocalAddress()` is false for unique-local IPv6
     * (fc00::/7) and for CGNAT (100.64.0.0/10), and both it and
     * `isLoopbackAddress()` are false for IPv4-mapped
     * (`::ffff:127.0.0.1`) and IPv4-compatible (`::127.0.0.1`) IPv6
     * addresses, whose embedded IPv4 is what the OS connects to.
     * An address of an unknown length fails closed (treated as
     * non-public).
     *
     * IPv6 transition mechanisms (6to4 `2002::/16`, Teredo
     * `2001::/32`) also embed an IPv4, but the packet goes to a
     * public relay, not to the embedded address directly, so they are
     * deliberately not unwrapped here.
     */
    fun isNonPublicAddress(address: InetAddress): Boolean {
        val bytes = address.address
        return when (bytes.size) {
            4 -> isNonPublicIpv4(bytes[0].toInt() and 0xFF, bytes[1].toInt() and 0xFF)
            16 -> isNonPublicIpv6(bytes)
            else -> true // Unknown address family — fail closed.
        }
    }

    /** True when the first two octets [a].[b] put an IPv4 in a non-public range. */
    private fun isNonPublicIpv4(a: Int, b: Int): Boolean = when {
        a == 0 -> true // 0.0.0.0/8 — "this network"
        a == 10 -> true // 10.0.0.0/8 — private
        a == 100 && b in 64..127 -> true // 100.64.0.0/10 — CGNAT
        a == 127 -> true // 127.0.0.0/8 — loopback
        a == 169 && b == 254 -> true // 169.254.0.0/16 — link-local
        a == 172 && b in 16..31 -> true // 172.16.0.0/12 — private
        a == 192 && b == 0 -> true // 192.0.0.0/24 — IANA special (incl. 192.0.0.170/171)
        a == 192 && b == 168 -> true // 192.168.0.0/16 — private
        a == 198 && b in 18..19 -> true // 198.18.0.0/15 — benchmarking
        a >= 224 -> true // 224.0.0.0/4 multicast + 240.0.0.0/4 reserved
        else -> false
    }

    /** Byte-level non-public check for a 16-byte IPv6 address. */
    private fun isNonPublicIpv6(bytes: ByteArray): Boolean {
        val b = { i: Int -> bytes[i].toInt() and 0xFF }
        // ::1 loopback, :: unspecified.
        if ((0..14).all { bytes[it] == 0.toByte() } && (b(15) == 0 || b(15) == 1)) return true
        // IPv4-mapped ::ffff:a.b.c.d — bytes 0–9 zero, bytes 10–11 0xFF.
        // The OS connects to the embedded IPv4, so validate it as IPv4.
        if ((0..9).all { bytes[it] == 0.toByte() } && b(10) == 0xFF && b(11) == 0xFF) {
            return isNonPublicIpv4(b(12), b(13))
        }
        // IPv4-compatible ::a.b.c.d (deprecated form) — same treatment.
        if ((0..11).all { bytes[it] == 0.toByte() }) {
            return isNonPublicIpv4(b(12), b(13))
        }
        // fe80::/10 link-local.
        if (b(0) == 0xFE && (b(1) and 0xC0) == 0x80) return true
        // fc00::/7 unique-local.
        if ((b(0) and 0xFE) == 0xFC) return true
        // ff00::/8 multicast.
        if (b(0) == 0xFF) return true
        return false
    }

    /**
     * The dotted-quad IPv4 embedded in an IPv4-mapped or
     * IPv4-compatible IPv6 literal (`::ffff:127.0.0.1`,
     * `::127.0.0.1`, and their uncompressed forms), or null when
     * [lowerHost] (already lowercased) isn't one. The mapped prefix
     * must be checked before the bare `::` prefix.
     */
    private fun embeddedIpv4(lowerHost: String): String? {
        val rest = when {
            lowerHost.startsWith("::ffff:") -> lowerHost.removePrefix("::ffff:")
            lowerHost.startsWith("0:0:0:0:0:ffff:") -> lowerHost.removePrefix("0:0:0:0:0:ffff:")
            lowerHost.startsWith("::") -> lowerHost.removePrefix("::")
            lowerHost.startsWith("0:0:0:0:0:0:") -> lowerHost.removePrefix("0:0:0:0:0:0:")
            else -> return null
        }
        // Only a dotted quad counts as an embedded IPv4 — anything
        // else (e.g. "::ffff:example.com", "::1") is not a mapped
        // address and falls through to the normal checks.
        return rest.takeIf { parseIpv4(it) != null }
    }

    /** Parses "a.b.c.d" into (a, b), or null when [host] isn't a dotted-quad IPv4 literal. */
    private fun parseIpv4(host: String): Pair<Int, Int>? {
        val parts = host.split(".")
        if (parts.size != 4) return null
        val octets = parts.map { it.toIntOrNull() ?: return null }
        if (octets.any { it !in 0..255 }) return null
        // Reject leading-zero octets ("010.0.0.1") — some stacks read them as octal.
        if (parts.any { it.length > 1 && it.startsWith("0") }) return Pair(0, 0)
        return Pair(octets[0], octets[1])
    }
}
