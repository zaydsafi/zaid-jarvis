package com.zaid.jarvis.core.social

import com.zaid.jarvis.core.research.PlatformPreset

/**
 * Social platforms Jarvis can publish to (Phase 8), via their OFFICIAL
 * APIs only — no scraping, no automation of social apps, no unofficial
 * endpoints (Master Prompt §2.2, §9.8).
 *
 * Each platform carries its OAuth endpoints, scopes, character limit
 * (re-used from the Phase 7 [PlatformPreset] so the two phases can
 * never disagree), and the docs URL for its publish flow. Endpoints
 * are the best-known documented flow as of the build date — PHASE8.md
 * marks each one "verify against current docs before first use",
 * because platform APIs change.
 */
enum class SocialPlatform(
    val displayName: String,
    /** Character limit for a single text post, from the Phase 7 preset. */
    val charLimit: Int,
    /** OAuth 2.0 authorization endpoint (browser / Custom Tab). */
    val authorizeUrl: String,
    /** OAuth 2.0 token endpoint (code exchange + refresh). */
    val tokenUrl: String,
    /** OAuth scopes requested at connect time. */
    val scopes: List<String>,
    /** Where the publish flow is documented. */
    val docsUrl: String,
    /** Plain-language note about what the account needs. */
    val accountRequirement: String,
) {
    X(
        displayName = "X / Twitter",
        charLimit = PlatformPreset.X.charLimit,
        authorizeUrl = "https://twitter.com/i/oauth2/authorize",
        tokenUrl = "https://api.twitter.com/2/oauth2/token",
        scopes = listOf("tweet.read", "tweet.write", "users.read", "offline.access"),
        docsUrl = "https://developer.x.com/en/docs/x-api/tweets/manage-tweets/introduction",
        accountRequirement = "A free X developer account and a project/app with OAuth 2.0 enabled. " +
            "Read + Write permissions, and the app type must allow PKCE (native app / public client).",
    ),
    THREADS(
        displayName = "Threads",
        charLimit = PlatformPreset.THREADS.charLimit,
        authorizeUrl = "https://threads.net/oauth/authorize",
        tokenUrl = "https://graph.threads.net/oauth/access_token",
        scopes = listOf("threads_basic", "threads_content_publish"),
        docsUrl = "https://developers.facebook.com/docs/threads/posts",
        accountRequirement = "A Threads account and a Meta developer app with the Threads API " +
            "product added. Short-lived tokens are exchanged for 60-day long-lived tokens at connect time.",
    ),
    LINKEDIN(
        displayName = "LinkedIn",
        charLimit = PlatformPreset.LINKEDIN.charLimit,
        authorizeUrl = "https://www.linkedin.com/oauth/v2/authorization",
        tokenUrl = "https://www.linkedin.com/oauth/v2/accessToken",
        scopes = listOf("openid", "profile", "w_member_social"),
        docsUrl = "https://learn.microsoft.com/en-us/linkedin/marketing/community-management/shares/posts-api",
        accountRequirement = "A LinkedIn developer app with the \"Share on LinkedIn\" and " +
            "\"Sign In with LinkedIn using OpenID Connect\" products enabled.",
    ),
    INSTAGRAM(
        displayName = "Instagram",
        charLimit = PlatformPreset.INSTAGRAM.charLimit,
        authorizeUrl = "https://www.facebook.com/v21.0/dialog/oauth",
        tokenUrl = "https://graph.facebook.com/v21.0/oauth/access_token",
        scopes = listOf("instagram_basic", "instagram_content_publish", "pages_show_list"),
        docsUrl = "https://developers.facebook.com/docs/instagram-platform/content-publishing",
        accountRequirement = "An Instagram Business or Creator account LINKED to a Facebook Page, " +
            "plus a Meta developer app with the Instagram API product. Personal Instagram accounts " +
            "cannot publish via the API, and every Instagram post needs a photo — a public image URL " +
            "is required at publish time.",
    );

    companion object {
        /**
         * Resolves a draft's free-text platform to a publishable
         * [SocialPlatform], or null when the draft's platform isn't one
         * Jarvis can publish to (Blog / Other / unknown).
         */
        fun fromName(name: String?): SocialPlatform? {
            val normalized = name?.trim()?.lowercase() ?: ""
            return when (normalized) {
                "x", "twitter", "x / twitter" -> X
                "threads" -> THREADS
                "linkedin" -> LINKEDIN
                "instagram", "ig" -> INSTAGRAM
                else -> null
            }
        }
    }
}
