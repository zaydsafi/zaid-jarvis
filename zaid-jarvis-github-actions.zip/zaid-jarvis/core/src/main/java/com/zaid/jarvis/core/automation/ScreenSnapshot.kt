package com.zaid.jarvis.core.automation

import kotlinx.serialization.Serializable

/**
 * A rectangle on screen, in pixels (Master Prompt §3: in-app actions).
 * Used to describe where a node is and whether a tap point falls inside it.
 */
@Serializable
data class NodeBounds(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
    val centerX: Int get() = (left + right) / 2
    val centerY: Int get() = (top + bottom) / 2

    fun contains(x: Int, y: Int): Boolean =
        x in left..right && y in top..bottom
}

/**
 * One element of a screen, as Jarvis sees it (Phase 6).
 *
 * This is a **sanitized** view of an AccessibilityNodeInfo: password
 * fields are removed before a snapshot is built (see
 * JarvisAccessibilityService), so a [ScreenNode] never carries password
 * text — and [isPassword] is always false here. It exists on the type so
 * the sanitizer can defensively drop password nodes even if one ever
 * slipped through, and so tests can prove the exclusion works.
 *
 * Snapshots live only for the current run: they are never persisted,
 * never logged in full, and never sent anywhere except to the LLM the
 * user chose — as the tool result of `find_on_screen`, where the
 * planner's InjectionGuard (Phase 3) scans the text before acting on it.
 */
@Serializable
data class ScreenNode(
    /** Visible text, truncated at capture time (null when the node has none). */
    val text: String? = null,
    /** Accessibility content description (null when the node has none). */
    val contentDescription: String? = null,
    /** Fully-qualified view id, e.g. "com.example:id/search" (null when absent). */
    val viewId: String? = null,
    /** Simple class name, e.g. "Button" (never the full package path). */
    val className: String = "",
    val clickable: Boolean = false,
    val editable: Boolean = false,
    /** Always false in a real snapshot — see the class doc. */
    val isPassword: Boolean = false,
    val bounds: NodeBounds = NodeBounds(0, 0, 0, 0),
) {
    /** True when Jarvis can interact with this node at all. */
    val isInteractive: Boolean get() = clickable || editable

    /** The label Jarvis shows for this node: text first, then description. */
    val label: String? get() = text?.takeIf { it.isNotBlank() } ?: contentDescription
}

/**
 * A snapshot of the current screen: the foreground app plus the
 * interactive (and labelled) nodes on it, sanitized as described in
 * [ScreenNode].
 *
 * [hasPasswordField] is recorded during traversal — the service *sees*
 * password fields (so it can refuse to act on the screen) but never
 * includes them in [nodes]. A snapshot therefore proves a password
 * field exists without ever exposing its content.
 */
@Serializable
data class ScreenSnapshot(
    val packageName: String,
    val nodes: List<ScreenNode>,
    val hasPasswordField: Boolean = false,
    val capturedAtMillis: Long = 0L,
) {
    /** Only the nodes Jarvis can tap or type into. */
    fun interactiveNodes(): List<ScreenNode> = nodes.filter { it.isInteractive }

    /** First node matching [selector], preferring interactive matches. */
    fun find(selector: NodeSelector): ScreenNode? {
        val matches = nodes.filter { selector.matches(it) }
        return matches.firstOrNull { it.isInteractive } ?: matches.firstOrNull()
    }
}

/**
 * How Jarvis finds a node on screen: any combination of text, content
 * description, view id, class name, or a tap point. All non-null fields
 * must match (AND). This is the selector stored in macro steps, so it
 * is serializable and has no Android dependency.
 *
 * Matching is deliberately forgiving about text (case-insensitive
 * substring) because app UIs change wording between versions, but
 * strict about view ids (exact match) because those are stable.
 * Coordinates match when the point falls inside the node's bounds.
 */
@Serializable
data class NodeSelector(
    val text: String? = null,
    val contentDescription: String? = null,
    val viewId: String? = null,
    val className: String? = null,
    val x: Int? = null,
    val y: Int? = null,
) {
    /** A selector that matches by tap point rather than by node content. */
    val isCoordinate: Boolean get() = x != null && y != null

    /** True when no field is set — matches nothing. */
    val isEmpty: Boolean
        get() = text == null && contentDescription == null && viewId == null &&
            className == null && x == null && y == null

    fun matches(node: ScreenNode): Boolean {
        if (isEmpty) return false
        if (node.isPassword) return false // Password nodes are never matchable.
        text?.let {
            if (node.text?.contains(it, ignoreCase = true) != true) return false
        }
        contentDescription?.let {
            if (node.contentDescription?.contains(it, ignoreCase = true) != true) return false
        }
        viewId?.let {
            if (node.viewId != it) return false
        }
        className?.let {
            val simple = node.className.substringAfterLast('.')
            if (simple != it && node.className != it) return false
        }
        if (x != null && y != null) {
            if (!node.bounds.contains(x, y)) return false
        }
        return true
    }

    /** Plain-language description for approval cards and macro step lists. */
    fun describe(): String {
        if (isCoordinate) return "the point ($x, $y)"
        val parts = mutableListOf<String>()
        text?.let { parts += "text “$it”" }
        contentDescription?.let { parts += "description “$it”" }
        viewId?.let { parts += "id “${it.substringAfterLast('/')}”" }
        className?.let { parts += "a $it" }
        return if (parts.isEmpty()) "an element on screen" else parts.joinToString(", ")
    }
}
