package com.zaid.jarvis.core.model

/**
 * Approximate per-model pricing in USD per 1M tokens (Master Prompt §4:
 * "token and cost counter in Settings").
 *
 * **These rates are approximate and change often.** They exist only so Zaid
 * gets a rough sense of spend; the Settings screen labels the total as an
 * estimate. Unknown models (custom providers, new OpenRouter models) fall
 * back to [DEFAULT_RATE] and are clearly still estimates — Jarvis never
 * presents them as exact billing.
 *
 * Rates last reviewed: November 2026. Update when providers reprice.
 */
object PricingTable {
    /** USD per 1M tokens. */
    data class Rate(val inputPerMillion: Double, val outputPerMillion: Double)

    /** Fallback for unknown / custom models. */
    val DEFAULT_RATE: Rate = Rate(inputPerMillion = 3.0, outputPerMillion = 12.0)

    private val rates: Map<String, Rate> = mapOf(
        // Claude
        "claude-sonnet-5-5" to Rate(3.0, 15.0),
        "claude-haiku-5-5" to Rate(0.8, 4.0),
        // OpenAI
        "gpt-5" to Rate(5.0, 15.0),
        "gpt-5-mini" to Rate(0.6, 2.4),
        // Gemini
        "gemini-3-pro" to Rate(2.5, 10.0),
        "gemini-3-flash" to Rate(0.3, 1.2),
        // OpenRouter presets (priced as their underlying models)
        "anthropic/claude-sonnet-4.5" to Rate(3.0, 15.0),
        "openai/gpt-5" to Rate(5.0, 15.0),
        "google/gemini-3-pro" to Rate(2.5, 10.0),
        "meta-llama/llama-4-scout" to Rate(0.2, 0.8),
    )

    fun rateFor(modelApiId: String): Rate = rates[modelApiId] ?: DEFAULT_RATE

    /** Estimated USD cost for one response. Never negative; rounds to 6dp. */
    fun estimateCostUsd(modelApiId: String, inputTokens: Long, outputTokens: Long): Double {
        val rate = rateFor(modelApiId)
        val cost = (inputTokens.coerceAtLeast(0) * rate.inputPerMillion +
            outputTokens.coerceAtLeast(0) * rate.outputPerMillion) / 1_000_000.0
        return String.format(java.util.Locale.US, "%.6f", cost).toDouble()
    }
}
