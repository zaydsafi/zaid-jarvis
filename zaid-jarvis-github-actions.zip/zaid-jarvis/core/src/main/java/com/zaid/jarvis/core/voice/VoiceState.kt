package com.zaid.jarvis.core.voice

/**
 * Voice state shared by the chat UI, the overlay bubble, and the Quick
 * Settings tile (Master Prompt §5). Pure Kotlin — the Android
 * implementations (SpeechRecognizer / TextToSpeech) live in :app.
 */
sealed interface VoiceState {
    /** Mic is off and Jarvis is not speaking. */
    data object Idle : VoiceState

    /** Listening, with the latest partial transcript ("" until the first). */
    data class Listening(val partialTranscript: String = "") : VoiceState

    /** A final transcript was captured; the planner is working on it. */
    data object Processing : VoiceState

    /** Jarvis is speaking the answer aloud. */
    data object Speaking : VoiceState

    /** Something went wrong (no mic, no recognizer, network error…). */
    data class Error(val message: String) : VoiceState
}

/** Events a speech recognizer produces, in platform-neutral form. */
sealed interface SpeechInputState {
    data object Idle : SpeechInputState
    data class Listening(val partialTranscript: String = "") : SpeechInputState
    data class Final(val text: String) : SpeechInputState
    data class Error(val message: String) : SpeechInputState
}
