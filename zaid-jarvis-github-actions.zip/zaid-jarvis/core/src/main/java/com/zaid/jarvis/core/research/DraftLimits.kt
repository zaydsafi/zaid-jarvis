package com.zaid.jarvis.core.research

/**
 * Platform character limits for drafts (Phase 7).
 *
 * The LLM is *asked* to stay under the limit, but the limit is also
 * enforced in code — a model that rambles gets one rewrite request,
 * and if it still exceeds the limit the draft is hard-truncated and
 * flagged, never silently published over-length (and nothing is
 * published in Phase 7 at all).
 */
object DraftLimits {

    /** Character limit for [platformName] (preset or free text). */
    fun limitFor(platformName: String): Int =
        PlatformPreset.fromName(platformName).charLimit

    /** Result of enforcing a limit on draft text. */
    data class Enforcement(
        /** Text within the limit (truncated when [truncated] is true). */
        val text: String,
        val truncated: Boolean,
        val charCount: Int,
    )

    /**
     * Enforces [limit] on [text]. Text within the limit passes through
     * untouched; longer text is cut to exactly [limit] characters
     * (with a trailing "…" replacing the last character so the cut is
     * visible) and flagged.
     */
    fun enforce(text: String, limit: Int): Enforcement {
        if (text.length <= limit) {
            return Enforcement(text = text, truncated = false, charCount = text.length)
        }
        val cut = if (limit > 1) text.take(limit - 1) + "…" else text.take(limit)
        return Enforcement(text = cut, truncated = true, charCount = cut.length)
    }
}
