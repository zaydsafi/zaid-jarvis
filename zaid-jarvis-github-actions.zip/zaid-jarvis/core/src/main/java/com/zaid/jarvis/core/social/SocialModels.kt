package com.zaid.jarvis.core.social

import kotlinx.serialization.Serializable

/**
 * Social publishing models (Phase 8). Tokens are deliberately NOT part
 * of these models except for the in-memory [OAuthTokens] transport
 * object: tokens live only in Keystore-encrypted EncryptedSharedPreferences
 * ([com.zaid.jarvis.data.security.SecureKeyStore]), never in Room, never
 * in DataStore, never in logs.
 */

/**
 * A connected social account's public metadata (stored in DataStore,
 * no secrets). Fetched from the platform's /me endpoint at connect
 * time and refreshed when the token is refreshed.
 */
@Serializable
data class SocialAccount(
    val platform: SocialPlatform,
    /** Platform-side user id (X user id, Threads user id, LinkedIn person id, Instagram user id). */
    val accountId: String,
    /** Handle/username as shown on the platform ("@zaid" without the @ is stored; UI adds it). */
    val handle: String,
    val displayName: String,
    /** When the current access token expires (epoch millis, 0 = unknown). */
    val tokenExpiresAtMillis: Long = 0L,
    val connectedAtMillis: Long = 0L,
)

/**
 * OAuth 2.0 tokens for one platform. In-memory transport only — created
 * by the token exchange, held briefly while being saved to the secure
 * store, never persisted to Room/DataStore and never logged.
 */
data class OAuthTokens(
    val accessToken: String,
    val refreshToken: String? = null,
    /** Epoch millis when [accessToken] expires (0 = unknown / non-expiring). */
    val expiresAtMillis: Long = 0L,
) {
    /** True when the token is expired or expires within [marginMillis]. */
    fun isExpired(nowMillis: Long, marginMillis: Long = 60_000L): Boolean =
        expiresAtMillis > 0 && nowMillis + marginMillis >= expiresAtMillis
}

/** OAuth client credentials for one platform (entered by Zaid in Settings). */
data class OAuthClientCredentials(
    val clientId: String,
    /** Some platforms (X public clients) need no secret; null = PKCE-only. */
    val clientSecret: String? = null,
)

/** A request to publish text to one platform. */
data class PublishRequest(
    val platform: SocialPlatform,
    val text: String,
    /**
     * Public image URL. Required for Instagram (the API cannot publish
     * text-only posts); ignored by the other platforms in Phase 8
     * (media upload is a future addition).
     */
    val imageUrl: String? = null,
)

/** The publish report: what was published, where, and when. */
data class PublishResult(
    val platform: SocialPlatform,
    val postId: String,
    /** Public URL of the published post, or null when the platform doesn't return one. */
    val postUrl: String?,
    val publishedAtMillis: Long,
)

/** Lifecycle of a scheduled post (Phase 8 scheduler). */
@Serializable
enum class ScheduledPostStatus {
    SCHEDULED,
    PUBLISHED,
    FAILED,
    CANCELLED,
}

/**
 * A post scheduled for later publication. The [contentHash] is the
 * SHA-256 of the draft body at schedule time — the worker refuses to
 * publish if the draft text has changed since (Phase 2-style content
 * binding), and cancels the post instead.
 */
@Serializable
data class ScheduledPost(
    val id: Long = 0,
    val draftId: Long,
    val platform: SocialPlatform,
    /** Handle the post will publish as (for display on the Scheduled screen). */
    val accountHandle: String,
    val scheduledAtMillis: Long,
    /** SHA-256 hex of the draft body at schedule time. */
    val contentHash: String,
    /**
     * Public image URL for the post (Instagram only — the API has no
     * text-only posts). Recorded at schedule time so the worker can
     * publish without asking again.
     */
    val imageUrl: String? = null,
    val status: ScheduledPostStatus = ScheduledPostStatus.SCHEDULED,
    /** Why a post failed or was cancelled (null otherwise). */
    val failureReason: String? = null,
    /** Public URL of the published post (on success). */
    val postUrl: String? = null,
    val createdAtMillis: Long = 0L,
    val updatedAtMillis: Long = 0L,
)
