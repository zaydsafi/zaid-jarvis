package com.zaid.jarvis.core.backup

import com.zaid.jarvis.core.confirmation.sha256Hex
import com.zaid.jarvis.core.model.JarvisSettings
import com.zaid.jarvis.core.util.JarvisResult
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject

/**
 * Backup & restore format (Phase 10) — pure Kotlin, no Android, no
 * database. The JSON file a backup produces is a [BackupEnvelope]:
 * a format version, the app version, an export timestamp, a SHA-256
 * checksum over the payload, and the [BackupData] itself.
 *
 * What is included: settings (non-secret — [JarvisSettings] never
 * holds API keys), tasks, notes, macros, drafts, research records,
 * memory entries, scheduled posts, focus-session history, trusted
 * actions, and the audit log.
 *
 * What is NEVER included: API keys, OAuth tokens (access or refresh),
 * client secrets, and the Room encryption passphrase. Those live in
 * Keystore-backed storage and are never written to a file — a backup
 * taken on one device restores data, not credentials. The
 * no-secrets guarantee is asserted by unit tests (see BackupFormatTest
 * and BackupServiceTest) via [secretFieldNamesPresent].
 *
 * Import strategy (see :data BackupService): merge by id — rows whose
 * id already exists are SKIPPED, never overwritten. There is
 * deliberately no "replace all" mode in Phase 10.
 */
object BackupFormat {

    /** The only format version this build reads and writes. */
    const val CURRENT_FORMAT_VERSION: Int = 1

    /** Backups larger than this are refused on import (10 MB). */
    const val MAX_BACKUP_BYTES: Long = 10L * 1024L * 1024L

    /** Canonical JSON: deterministic, so the checksum is reproducible. */
    private val canonicalJson = Json {
        encodeDefaults = true
        explicitNulls = true
    }

    /** Lenient JSON for reading: unknown fields are ignored. */
    private val lenientJson = Json { ignoreUnknownKeys = true }

    /**
     * Serializes [data] into a complete backup file (envelope +
     * checksum). [appVersion] is informational only (shown in the
     * import preview); [exportedAtMillis] is the export time.
     */
    fun encode(data: BackupData, appVersion: String, exportedAtMillis: Long): String {
        val payloadJson = canonicalJson.encodeToString(BackupData.serializer(), data)
        val envelope = BackupEnvelope(
            formatVersion = CURRENT_FORMAT_VERSION,
            appVersion = appVersion,
            exportedAtMillis = exportedAtMillis,
            checksum = sha256Hex(payloadJson),
            data = data,
        )
        return canonicalJson.encodeToString(BackupEnvelope.serializer(), envelope)
    }

    /**
     * Parses and validates a backup file. Refuses (with a plain
     * message) files that are too large, malformed, of an unknown
     * format version, or whose checksum does not match — a damaged
     * file never reaches the import preview, let alone the database.
     * Returns the whole envelope (the preview shows its header; the
     * import uses its [BackupEnvelope.data]).
     */
    fun decode(text: String): JarvisResult<BackupEnvelope> {
        if (text.toByteArray(Charsets.UTF_8).size > MAX_BACKUP_BYTES) {
            return JarvisResult.Failure(
                "This backup file is too large (over 10 MB) — it may not be a Zaid Jarvis backup.",
            )
        }
        val envelope = runCatching {
            lenientJson.decodeFromString(BackupEnvelope.serializer(), text)
        }.getOrNull()
            ?: return JarvisResult.Failure(
                "This file is not a valid Zaid Jarvis backup.",
            )
        if (envelope.formatVersion != CURRENT_FORMAT_VERSION) {
            return JarvisResult.Failure(
                "This backup was made with format version ${envelope.formatVersion}; " +
                    "this version of Jarvis reads format version $CURRENT_FORMAT_VERSION only.",
            )
        }
        val payloadJson = canonicalJson.encodeToString(BackupData.serializer(), envelope.data)
        if (sha256Hex(payloadJson) != envelope.checksum) {
            return JarvisResult.Failure(
                "This backup's checksum does not match — the file may be damaged or edited. " +
                    "Nothing was imported.",
            )
        }
        return JarvisResult.Success(envelope)
    }

    /**
     * Scans a backup file's JSON for secret field names (keys, not
     * values — user content may legitimately contain the word
     * "password" in a task title, but no *field* may ever be a
     * credential). Returns the offending key names, empty when clean.
     * Used by the no-secrets tests.
     */
    fun secretFieldNamesPresent(jsonText: String): List<String> {
        val element = runCatching {
            lenientJson.parseToJsonElement(jsonText)
        }.getOrNull() ?: return listOf("<unparseable>")
        val found = mutableSetOf<String>()
        fun walk(element: JsonElement) {
            when (element) {
                is JsonObject -> element.forEach { (key, value) ->
                    if (key.lowercase().replace("_", "") in FORBIDDEN_FIELD_NAMES) {
                        found += key
                    }
                    walk(value)
                }
                is JsonArray -> element.forEach { walk(it) }
                else -> Unit
            }
        }
        walk(element)
        return found.sorted()
    }

    private val FORBIDDEN_FIELD_NAMES: Set<String> = setOf(
        "apikey",
        "accesstoken",
        "refreshtoken",
        "clientsecret",
        "clientid", // Client IDs are not secrets, but they belong with credentials, not in a backup.
        "passphrase",
        "dbpassphrase",
        "secretkey",
        "privatekey",
        "token",
        "secret",
    )
}

/** The whole backup file: header + checksum + payload. */
@Serializable
data class BackupEnvelope(
    val formatVersion: Int,
    val appVersion: String,
    val exportedAtMillis: Long,
    /** SHA-256 hex of the canonical JSON of [data]. */
    val checksum: String,
    val data: BackupData,
)

/**
 * Everything a backup carries. Each section is a list of plain data
 * transfer objects mirroring one Room table (field for field, except
 * WorkManager job ids, which are meaningless on another device and
 * are dropped — see [BackupTask.reminderWorkId] and
 * [BackupScheduledPost]).
 */
@Serializable
data class BackupData(
    /** Non-secret settings ([JarvisSettings] never holds API keys). */
    val settings: JarvisSettings = JarvisSettings(),
    val tasks: List<BackupTask> = emptyList(),
    val notes: List<BackupNote> = emptyList(),
    val macros: List<BackupMacro> = emptyList(),
    val drafts: List<BackupDraft> = emptyList(),
    val researchRecords: List<BackupResearchRecord> = emptyList(),
    val memoryItems: List<BackupMemoryItem> = emptyList(),
    /** Posts still SCHEDULED at export time (full rows, minus the WorkManager job id). */
    val scheduledPosts: List<BackupScheduledPost> = emptyList(),
    /** Already published / failed / cancelled posts — history metadata only. */
    val scheduledPostHistory: List<BackupScheduledPost> = emptyList(),
    val focusSessions: List<BackupFocusSession> = emptyList(),
    /** Trusted tool names (tiers 0–1 only, as always). */
    val trustedActions: List<String> = emptyList(),
    val auditLog: List<BackupAuditEntry> = emptyList(),
)

@Serializable
data class BackupTask(
    val id: Long,
    val title: String,
    val notes: String = "",
    val dueAtMillis: Long? = null,
    val priority: String,
    val status: String,
    /** The reminder time is kept; the WorkManager job is NOT — the Backup screen re-enqueues it on restore. */
    val reminderAtMillis: Long? = null,
    val overdueNotifiedDay: Long? = null,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
)

@Serializable
data class BackupNote(
    val id: Long,
    val title: String,
    val body: String,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
)

@Serializable
data class BackupMacro(
    val id: Long,
    val name: String,
    val stepsJson: String,
    val createdAtMillis: Long,
    val lastRunAtMillis: Long? = null,
)

@Serializable
data class BackupDraft(
    val id: Long,
    val title: String,
    val body: String,
    val platform: String,
    val status: String,
    val researchId: Long? = null,
    val approvedBodyHash: String? = null,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
)

@Serializable
data class BackupResearchRecord(
    val id: Long,
    val topic: String,
    val briefJson: String,
    val createdAtMillis: Long,
)

@Serializable
data class BackupMemoryItem(
    val id: Long,
    val kind: String,
    val key: String,
    val value: String,
    val updatedAtMillis: Long,
)

@Serializable
data class BackupScheduledPost(
    val id: Long,
    val draftId: Long,
    val platform: String,
    val accountHandle: String,
    val scheduledAtMillis: Long,
    val contentHash: String,
    val imageUrl: String? = null,
    val status: String,
    val failureReason: String? = null,
    val postUrl: String? = null,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
)

@Serializable
data class BackupFocusSession(
    val id: Long,
    val startedAtMillis: Long,
    val durationMinutes: Int,
    val endedAtMillis: Long? = null,
    val status: String,
    val previousDndMode: String? = null,
)

@Serializable
data class BackupAuditEntry(
    val id: Long,
    val timestampMillis: Long,
    val toolName: String,
    val tier: String,
    val action: String,
    val target: String,
    val paramsSummary: String,
    val decision: String,
    val resultSummary: String? = null,
    val undoable: Boolean,
    val undoDescription: String? = null,
    val undoData: String? = null,
    val undone: Boolean,
)

/**
 * Merge-by-id planning (pure): given the ids already in the database
 * and the ids in the backup, how many rows would be imported and how
 * many skipped. Existing rows are never overwritten.
 */
object BackupMerge {
    /** One section of the import preview. */
    data class SectionPlan(
        val section: String,
        val incoming: Int,
        val toImport: Int,
        val skipped: Int,
    )

    fun planSection(
        section: String,
        existingIds: Set<Long>,
        incomingIds: List<Long>,
    ): SectionPlan {
        val distinctIncoming = incomingIds.distinct()
        val toImport = distinctIncoming.count { it !in existingIds }
        return SectionPlan(
            section = section,
            incoming = incomingIds.size,
            toImport = toImport,
            skipped = incomingIds.size - toImport,
        )
    }
}
