package com.zaid.jarvis.core.confirmation

/**
 * Risk tiers from Master Prompt §6 — the canonical tier definition.
 * Higher tiers need stronger approval. Every [com.zaid.jarvis.tools.JarvisTool]
 * declares one, and the Confirmation Engine routes on it.
 *
 * Phase 1 defined this enum in :tools; Phase 2 moved it to :core so the
 * engine (pure Kotlin, unit-tested on the JVM) can use it without an
 * Android dependency. `:tools` keeps the `ToolRiskTier` name as a typealias.
 */
enum class RiskTier(
    /** Numeric level from the master prompt (0–3). */
    val level: Int,
    val displayName: String,
    val description: String,
) {
    /** Read-only: time, weather, search. Ask once per session, then allow. */
    READ_ONLY(
        level = 0,
        displayName = "Read-only",
        description = "Reads only — time, weather, search. Ask once per session.",
    ),

    /** Reversible: toggles, open app, set alarm. Approval card each time. */
    REVERSIBLE(
        level = 1,
        displayName = "Reversible",
        description = "Can be undone — toggles, open app, set alarm. Approval card each time.",
    ),

    /** External or visible: SMS, call, post, email, delete. Preview + 2nd confirm. */
    EXTERNAL(
        level = 2,
        displayName = "External / visible",
        description = "Leaves the device or is visible — SMS, call, post, email, delete. " +
            "Approval card with full preview plus a second confirm.",
    ),

    /** Sensitive: payments, banking, passwords. Biometric; Jarvis only assists. */
    SENSITIVE(
        level = 3,
        displayName = "Sensitive",
        description = "Payments, banking, passwords, account changes. " +
            "Biometric required; Jarvis only assists, never completes silently.",
    );

    /** Tier 2 requires a second confirmation after the first Allow. */
    val requiresSecondConfirmation: Boolean get() = this == EXTERNAL

    /** Tier 3 requires a biometric (or device-credential) check after Allow. */
    val requiresBiometric: Boolean get() = this == SENSITIVE

    /**
     * Only tiers 0–1 may be marked trusted by the user ("always allow this
     * action"). Tiers 2–3 can never be trusted — they always ask.
     */
    val canBeTrusted: Boolean get() = level <= 1

    companion object {
        fun fromLevel(level: Int): RiskTier =
            entries.firstOrNull { it.level == level } ?: REVERSIBLE
    }
}
