package com.zaid.jarvis.core.automation

import kotlinx.serialization.Serializable

/**
 * One step of a macro (Phase 6): what to do, where, and with what text.
 * Macros are stored as JSON in the encrypted Room DB, so steps are
 * serializable and carry no Android types.
 *
 * A step's [text] is only used by [MacroAction.TYPE_TEXT] and is never
 * a password: the recorder never records text typed into a password
 * field, and playback refuses to type into one (password fields are
 * invisible in snapshots, so the target simply is not found).
 */
@Serializable
data class MacroStep(
    val action: MacroAction,
    /** Target node (TAP, TYPE_TEXT) or tap point (TAP_AT). */
    val selector: NodeSelector? = null,
    /** Text to type (TYPE_TEXT only). */
    val text: String? = null,
    /** Milliseconds to wait (WAIT only). */
    val waitMillis: Long = 0L,
) {
    /** Plain-language description for approval cards and the Macros screen. */
    fun describe(): String = when (action) {
        MacroAction.TAP -> "Tap ${selector?.describe() ?: "an element on screen"}"
        MacroAction.TAP_AT -> "Tap ${selector?.describe() ?: "a point on screen"}"
        MacroAction.TYPE_TEXT -> "Type “${text ?: ""}”" +
            (selector?.let { " into ${it.describe()}" } ?: " into the focused field")
        MacroAction.SCROLL_FORWARD -> "Scroll down"
        MacroAction.SCROLL_BACK -> "Scroll up"
        MacroAction.BACK -> "Press Back"
        MacroAction.HOME -> "Press Home"
        MacroAction.WAIT -> "Wait ${waitMillis}ms"
    }
}

/** The actions a macro step can perform. */
@Serializable
enum class MacroAction(val displayName: String) {
    TAP("Tap"),
    TAP_AT("Tap at point"),
    TYPE_TEXT("Type text"),
    SCROLL_FORWARD("Scroll down"),
    SCROLL_BACK("Scroll up"),
    BACK("Back"),
    HOME("Home"),
    WAIT("Wait"),
}

/**
 * A saved macro: a named, ordered list of steps recorded from Zaid's own
 * taps (or built by hand later). Stored in the encrypted Room DB.
 *
 * [isExternal] drives the approval tier for `run_macro` (see
 * RunMacroTool): a macro that taps or types in another app can cause
 * visible, external effects (a tap can press Send), so it needs Tier 2
 * (card + second confirm). A macro that only scrolls, navigates, or
 * waits is Tier 1.
 */
@Serializable
data class Macro(
    val id: Long = 0,
    val name: String,
    val steps: List<MacroStep>,
    val createdAtMillis: Long = 0L,
    val lastRunAtMillis: Long? = null,
) {
    val isExternal: Boolean
        get() = steps.any {
            it.action == MacroAction.TAP ||
                it.action == MacroAction.TAP_AT ||
                it.action == MacroAction.TYPE_TEXT
        }

    /** Numbered step list for the approval card ("Run macro" preview). */
    fun describeSteps(): String =
        steps.mapIndexed { index, step -> "${index + 1}. ${step.describe()}" }
            .joinToString("\n")
}

/** Guards against runaway macros (Master Prompt §3: macros are bounded). */
object MacroLimits {
    /** Most steps a macro may contain. */
    const val MAX_STEPS: Int = 50

    /** Per-step timeout during playback — a step that hangs this long fails the run. */
    const val STEP_TIMEOUT_MILLIS: Long = 10_000L

    /** Longest single WAIT step. */
    const val MAX_WAIT_MILLIS: Long = 30_000L

    /** Longest macro name. */
    const val MAX_NAME_LENGTH: Int = 60

    /** Longest text a TYPE_TEXT step may type. */
    const val MAX_TEXT_LENGTH: Int = 500
}

/** Pure validation for macros and steps — used by the recorder, the repository, and playback. */
object MacroValidation {

    /** Returns a list of problems; empty means the macro is valid. */
    fun validate(macro: Macro): List<String> {
        val errors = mutableListOf<String>()
        if (macro.name.isBlank()) errors += "The macro needs a name."
        if (macro.name.length > MacroLimits.MAX_NAME_LENGTH) {
            errors += "The macro name is too long (max ${MacroLimits.MAX_NAME_LENGTH} characters)."
        }
        if (macro.steps.isEmpty()) errors += "The macro has no steps."
        if (macro.steps.size > MacroLimits.MAX_STEPS) {
            errors += "The macro has ${macro.steps.size} steps (max ${MacroLimits.MAX_STEPS})."
        }
        macro.steps.forEachIndexed { index, step ->
            validateStep(step, index + 1).let { errors += it }
        }
        return errors
    }

    /** Returns a list of problems with one step (numbered [stepNumber] for messages). */
    fun validateStep(step: MacroStep, stepNumber: Int): List<String> {
        val prefix = "Step $stepNumber"
        return when (step.action) {
            MacroAction.TAP ->
                if (step.selector == null || step.selector.isEmpty) {
                    listOf("$prefix: a tap needs a target (text, description, or id).")
                } else {
                    emptyList()
                }
            MacroAction.TAP_AT ->
                if (step.selector?.isCoordinate != true) {
                    listOf("$prefix: a tap-at-point needs x and y coordinates.")
                } else {
                    emptyList()
                }
            MacroAction.TYPE_TEXT -> buildList {
                if (step.text.isNullOrBlank()) add("$prefix: typing needs text.")
                if ((step.text?.length ?: 0) > MacroLimits.MAX_TEXT_LENGTH) {
                    add(
                        "$prefix: the text is too long " +
                            "(max ${MacroLimits.MAX_TEXT_LENGTH} characters).",
                    )
                }
            }
            MacroAction.WAIT ->
                if (step.waitMillis <= 0 || step.waitMillis > MacroLimits.MAX_WAIT_MILLIS) {
                    listOf(
                        "$prefix: a wait must be between 1ms and " +
                            "${MacroLimits.MAX_WAIT_MILLIS}ms.",
                    )
                } else {
                    emptyList()
                }
            MacroAction.SCROLL_FORWARD, MacroAction.SCROLL_BACK,
            MacroAction.BACK, MacroAction.HOME,
            -> emptyList()
        }
    }
}
