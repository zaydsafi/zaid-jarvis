package com.zaid.jarvis.core.productivity

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

/**
 * Calendar events + the morning briefing (Phase 9).
 *
 * Calendar access is READ-ONLY in Phase 9 (CalendarContract, no event
 * creation — a future addition). The briefing is the one place Jarvis
 * summarizes Zaid's day: today's events + tasks due today + overdue
 * tasks. No weather in Phase 9 — no weather API is wired.
 *
 * The briefing text has two sources: the LLM (via BriefingService in
 * :agent, when an LLM is configured and reachable) or the plain
 * templated summary below. The templated version is the fallback —
 * the briefing never fails just because the LLM is unavailable.
 */

/** One device-calendar event (read-only). */
data class CalendarEvent(
    val id: Long,
    val title: String,
    val startMillis: Long,
    val endMillis: Long,
    /** Location, or "" when the event has none. */
    val location: String = "",
    /** True when the event spans the whole day. */
    val allDay: Boolean = false,
)

/** Everything one briefing needs. */
data class BriefingData(
    /** The day this briefing is about (device zone). */
    val date: LocalDate,
    /** Today's calendar events, earliest first (empty when no access / none). */
    val events: List<CalendarEvent>,
    /** Open tasks due today. */
    val tasksDueToday: List<Task>,
    /** Open tasks whose due time has passed. */
    val overdueTasks: List<Task>,
    /** True when Jarvis could not read the calendar (permission not granted). */
    val calendarUnavailable: Boolean = false,
)

object BriefingFormat {

    /**
     * The plain templated briefing — used when no LLM is configured,
     * when offline, or when the LLM call fails. Never fails itself.
     */
    fun formatPlain(
        data: BriefingData,
        zone: ZoneId = ZoneId.systemDefault(),
    ): String = buildString {
        val dateLabel = data.date.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL))
        append("Good morning — $dateLabel.\n")
        // Calendar.
        if (data.calendarUnavailable) {
            append("\nI can't see your calendar — grant calendar access in " +
                "Settings → App permissions to include your schedule here.\n")
        } else if (data.events.isEmpty()) {
            append("\nNo events on your calendar today.\n")
        } else {
            append("\nToday's schedule:\n")
            data.events.forEach { event ->
                val time = if (event.allDay) {
                    "All day"
                } else {
                    val start = Instant.ofEpochMilli(event.startMillis).atZone(zone)
                        .format(DateTimeFormatter.ofPattern("HH:mm"))
                    val end = Instant.ofEpochMilli(event.endMillis).atZone(zone)
                        .format(DateTimeFormatter.ofPattern("HH:mm"))
                    "$start–$end"
                }
                val location = event.location.takeIf { it.isNotBlank() }?.let { " ($it)" } ?: ""
                append("• $time — ${event.title}$location\n")
            }
        }
        // Tasks.
        if (data.overdueTasks.isNotEmpty()) {
            append("\nOverdue:\n")
            data.overdueTasks.forEach { task ->
                append("• ${task.title}\n")
            }
        }
        if (data.tasksDueToday.isNotEmpty()) {
            append("\nDue today:\n")
            data.tasksDueToday.forEach { task ->
                val priority = if (task.priority == TaskPriority.HIGH) " (high priority)" else ""
                append("• ${task.title}$priority\n")
            }
        }
        if (data.overdueTasks.isEmpty() && data.tasksDueToday.isEmpty()) {
            append("\nNothing due today — a clear day.\n")
        }
    }

    /**
     * The prompt the LLM version is built from (see BriefingService):
     * the same facts, as structured input. The LLM is told to keep it
     * short and to never invent events or tasks.
     */
    fun buildLlmPrompt(data: BriefingData): String = buildString {
        append("Write a short morning briefing for Zaid (at most 6 lines). ")
        append("Use ONLY the facts below — never invent events, tasks, or times. ")
        append("Keep it warm and brief.\n\n")
        append("Date: ${data.date}\n")
        if (data.events.isEmpty()) {
            append("Calendar events today: none\n")
        } else {
            append("Calendar events today:\n")
            data.events.forEach { event ->
                append("- ${event.title} (${formatEventTime(event)})\n")
            }
        }
        append("Tasks due today: ${data.tasksDueToday.joinToString { it.title }.ifEmpty { "none" }}\n")
        append("Overdue tasks: ${data.overdueTasks.joinToString { it.title }.ifEmpty { "none" }}\n")
    }

    private fun formatEventTime(event: CalendarEvent): String {
        if (event.allDay) return "all day"
        val zone = ZoneId.systemDefault()
        val formatter = DateTimeFormatter.ofPattern("HH:mm")
        val start = Instant.ofEpochMilli(event.startMillis).atZone(zone).format(formatter)
        val end = Instant.ofEpochMilli(event.endMillis).atZone(zone).format(formatter)
        return "$start–$end"
    }
}
