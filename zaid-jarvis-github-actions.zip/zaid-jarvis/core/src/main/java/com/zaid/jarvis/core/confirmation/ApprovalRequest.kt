package com.zaid.jarvis.core.confirmation

import java.security.MessageDigest

/** Lifecycle of one approval request, visible to the UI. */
enum class ApprovalState {
    /** Waiting for Zaid's Allow / Edit / Deny on the approval card. */
    AWAITING_DECISION,

    /** Tier 2: Allow was given; waiting on the second confirmation. */
    AWAITING_SECOND_CONFIRMATION,

    /** Tier 3: Allow was given; waiting on the biometric check. */
    AWAITING_BIOMETRIC,

    /** Approved and (about to be) executed. */
    APPROVED,

    /** Denied by Zaid. */
    DENIED,

    /** The 2-minute approval window elapsed before a decision. */
    EXPIRED,

    /** Cancelled by the kill switch. */
    CANCELLED,

    /** Replaced by a new request after Zaid edited the content. */
    SUPERSEDED,
}

/**
 * One approval request: everything the approval card shows, plus the
 * content-binding hash that ties the approval to the exact content shown.
 *
 * Use [create] to build one — it stamps the creation time, the 2-minute
 * expiry, and the content hash. The hash is stored (not derived) so the
 * engine can detect any content change between approval and execution:
 * if the content is edited, [create] must be called again for a new id.
 */
data class ApprovalRequest(
    val id: String,
    val toolName: String,
    val tier: RiskTier,
    /** Human-readable action, e.g. "Send SMS". */
    val action: String,
    /** Who or what the action touches, e.g. "+1 555 0100" or "Wi-Fi". */
    val target: String,
    /** What data the action uses, e.g. "Contacts: Amira; message body". */
    val dataUsed: String,
    /** The exact content to be sent or shown — what Zaid approved, verbatim. */
    val exactContent: String,
    /** The raw tool parameters as JSON (for the audit log). */
    val paramsJson: String,
    val createdAtMillis: Long,
    val expiresAtMillis: Long,
    /** SHA-256 of [canonicalContent] at creation time. */
    val contentHash: String,
    val state: ApprovalState = ApprovalState.AWAITING_DECISION,
) {
    val requiresSecondConfirmation: Boolean get() = tier.requiresSecondConfirmation
    val requiresBiometric: Boolean get() = tier.requiresBiometric

    fun isExpired(nowMillis: Long): Boolean = nowMillis >= expiresAtMillis

    fun remainingMillis(nowMillis: Long): Long =
        (expiresAtMillis - nowMillis).coerceAtLeast(0)

    /** The canonical string the approval is bound to. */
    fun canonicalContent(): String =
        listOf(toolName, tier.name, action, target, exactContent).joinToString("\n")

    companion object {
        fun create(
            id: String,
            toolName: String,
            tier: RiskTier,
            action: String,
            target: String,
            dataUsed: String,
            exactContent: String,
            paramsJson: String,
            createdAtMillis: Long,
            timeoutMillis: Long,
        ): ApprovalRequest {
            val request = ApprovalRequest(
                id = id,
                toolName = toolName,
                tier = tier,
                action = action,
                target = target,
                dataUsed = dataUsed,
                exactContent = exactContent,
                paramsJson = paramsJson,
                createdAtMillis = createdAtMillis,
                expiresAtMillis = createdAtMillis + timeoutMillis,
                contentHash = "",
            )
            return request.copy(contentHash = sha256Hex(request.canonicalContent()))
        }
    }
}

/** Decisions Zaid (or the engine itself) can resolve a request with. */
sealed interface ApprovalDecision {
    /** Zaid tapped Allow. */
    data object Allow : ApprovalDecision

    /** Zaid tapped Deny. */
    data object Deny : ApprovalDecision

    /** Zaid edited the content; a NEW request is created for the new content. */
    data class Edit(val newContent: String) : ApprovalDecision

    /** Tier 2 second confirmation: yes, really do it. */
    data object ConfirmSecond : ApprovalDecision

    /** Tier 2 second confirmation: no, stop. */
    data object CancelSecond : ApprovalDecision

    /** Tier 3 biometric check passed. */
    data object BiometricOk : ApprovalDecision

    /** Tier 3 biometric check failed or was cancelled. */
    data object BiometricFailed : ApprovalDecision

    /** Internal: the request expired while waiting. */
    data object ExpiredDecision : ApprovalDecision

    /** Internal: the kill switch cancelled the request. */
    data object CancelledDecision : ApprovalDecision
}

/** SHA-256 hex of [input] (UTF-8). Used for content binding. */
fun sha256Hex(input: String): String {
    val digest = MessageDigest.getInstance("SHA-256")
    return digest.digest(input.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
}
