package com.zaid.jarvis.core.productivity

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * Natural-language due-date parser (Phase 9).
 *
 * Parses the common phrases Zaid (or the planner, from Zaid's words)
 * uses for task due dates and reminder times. Anything it cannot parse
 * returns null — the caller must ask, never guess.
 *
 * Supported (case-insensitive, extra spaces tolerated):
 * - "today", "tomorrow", "tonight" (today 20:00), "tomorrow morning"
 *   (09:00), "tomorrow evening" (19:00), "this evening" (19:00),
 *   "end of day" / "eod" (23:59)
 * - "in 3 days", "in 2 hours", "in 30 minutes", "in a week",
 *   "in an hour", "next week" (+7 days), "next month" (+1 month)
 * - Weekdays: "monday" … "sunday", "next monday" — the next occurrence
 *   strictly after today (if today is Monday, "monday" means next
 *   Monday, 7 days away — never "today", which would be in the past
 *   half the time)
 * - Any day phrase + "at <time>": "tomorrow at 5pm", "friday at 9:30am",
 *   "today at 14:00", "in 3 days at 10am". Times: "5pm", "5 pm",
 *   "9:30am", "17:00", "9".
 * - ISO dates: "2026-11-20", "2026-11-20 15:30".
 *
 * Bare day references default to **end of day (23:59)** — the most
 * sensible reading for a due date, and the approval card always shows
 * the resolved time, so Zaid sees exactly what "tomorrow" became and
 * can correct it ("tomorrow at 9am").
 *
 * [now] and [zone] are parameters (not statics) so tests can pin them.
 */
object DueDateParser {

    /** Default time for a bare day reference: end of day. */
    val DEFAULT_DAY_TIME: LocalTime = LocalTime.of(23, 59)

    private val WEEKDAYS: Map<String, DayOfWeek> = mapOf(
        "monday" to DayOfWeek.MONDAY,
        "tuesday" to DayOfWeek.TUESDAY,
        "wednesday" to DayOfWeek.WEDNESDAY,
        "thursday" to DayOfWeek.THURSDAY,
        "friday" to DayOfWeek.FRIDAY,
        "saturday" to DayOfWeek.SATURDAY,
        "sunday" to DayOfWeek.SUNDAY,
        // Short forms.
        "mon" to DayOfWeek.MONDAY,
        "tue" to DayOfWeek.TUESDAY,
        "tues" to DayOfWeek.TUESDAY,
        "wed" to DayOfWeek.WEDNESDAY,
        "thu" to DayOfWeek.THURSDAY,
        "thur" to DayOfWeek.THURSDAY,
        "thurs" to DayOfWeek.THURSDAY,
        "fri" to DayOfWeek.FRIDAY,
        "sat" to DayOfWeek.SATURDAY,
        "sun" to DayOfWeek.SUNDAY,
    )

    private val IN_AMOUNT_REGEX =
        Regex("^in\\s+(\\d+|a|an)\\s+(minute|minutes|min|mins|hour|hours|day|days|week|weeks)\\s*$")
    private val IN_AMOUNT_AT_REGEX =
        Regex("^in\\s+(\\d+|a|an)\\s+(day|days|week|weeks)\\s+at\\s+(.+)$")
    private val TIME_12H_REGEX =
        Regex("^(\\d{1,2})(?::(\\d{2}))?\\s*([ap])\\.?m\\.?$")
    private val TIME_24H_REGEX = Regex("^(\\d{1,2}):(\\d{2})$")
    private val TIME_HOUR_ONLY_REGEX = Regex("^(\\d{1,2})$")
    private val ISO_DATE_REGEX = Regex("^(\\d{4})-(\\d{2})-(\\d{2})(?:[ T](.+))?$")

    /**
     * Parses [text] into epoch millis, or null when it cannot be
     * understood. Never throws.
     */
    fun parse(
        text: String,
        now: ZonedDateTime = ZonedDateTime.now(),
        zone: ZoneId = now.zone,
    ): Long? {
        val cleaned = text.trim().lowercase().replace(Regex("\\s+"), " ")
        if (cleaned.isEmpty()) return null
        val base = now.withZoneSameInstant(zone)
        return runCatching { parseInternal(cleaned, base) }.getOrNull()
            ?.toInstant()?.toEpochMilli()
    }

    private fun parseInternal(cleaned: String, now: ZonedDateTime): ZonedDateTime? {
        // ISO date, with optional time.
        ISO_DATE_REGEX.matchEntire(cleaned)?.let { match ->
            val date = LocalDate.of(
                match.groupValues[1].toInt(),
                match.groupValues[2].toInt(),
                match.groupValues[3].toInt(),
            )
            val timePart = match.groupValues[4]
            val time = if (timePart.isBlank()) DEFAULT_DAY_TIME else parseTime(timePart) ?: return null
            return ZonedDateTime.of(date, time, now.zone)
        }

        // "in 3 days at 10am" — checked before the generic " at " split,
        // because "in 3 days" is not a day name resolveDay() knows.
        IN_AMOUNT_AT_REGEX.matchEntire(cleaned)?.let { match ->
            val amount = parseAmount(match.groupValues[1]) ?: return null
            val unit = match.groupValues[2]
            val time = parseTime(match.groupValues[3]) ?: return null
            val days = if (unit.startsWith("week")) amount * 7L else amount.toLong()
            return now.toLocalDate().plusDays(days).atTime(time).atZone(now.zone)
        }

        // "<day phrase> at <time>" — split on the LAST " at " so
        // "friday at 5pm" and "tomorrow at 9am" both work.
        val atIndex = cleaned.lastIndexOf(" at ")
        if (atIndex > 0) {
            val dayPart = cleaned.substring(0, atIndex).trim()
            val timePart = cleaned.substring(atIndex + 4).trim()
            val time = parseTime(timePart) ?: return null
            val day = resolveDay(dayPart, now) ?: return null
            return day.with(time)
        }

        // Relative amounts: "in 3 days", "in an hour".
        IN_AMOUNT_REGEX.matchEntire(cleaned)?.let { match ->
            val amount = parseAmount(match.groupValues[1]) ?: return null
            return when (val unit = match.groupValues[2]) {
                "minute", "minutes", "min", "mins" -> now.plusMinutes(amount.toLong())
                "hour", "hours" -> now.plusHours(amount.toLong())
                "day", "days" -> now.plusDays(amount.toLong())
                "week", "weeks" -> now.plusWeeks(amount.toLong())
                else -> null
            }
        }

        // Named phrases and weekdays.
        return when (cleaned) {
            "today" -> now.toLocalDate().atTime(DEFAULT_DAY_TIME).atZone(now.zone)
            "tomorrow" -> now.toLocalDate().plusDays(1).atTime(DEFAULT_DAY_TIME).atZone(now.zone)
            "tonight" -> now.toLocalDate().atTime(20, 0).atZone(now.zone)
            "tomorrow morning" -> now.toLocalDate().plusDays(1).atTime(9, 0).atZone(now.zone)
            "tomorrow evening" -> now.toLocalDate().plusDays(1).atTime(19, 0).atZone(now.zone)
            "this evening" -> now.toLocalDate().atTime(19, 0).atZone(now.zone)
            "end of day", "eod" -> now.toLocalDate().atTime(DEFAULT_DAY_TIME).atZone(now.zone)
            "next week" -> now.plusWeeks(1)
            "next month" -> now.plusMonths(1)
            else -> resolveDay(cleaned, now)?.with(DEFAULT_DAY_TIME)
        }
    }

    /**
     * Resolves a day reference ("today", "tomorrow", "friday",
     * "next monday") to the start of that day, or null when the text
     * is not a day reference. Weekdays resolve to the next occurrence
     * strictly after today.
     */
    private fun resolveDay(text: String, now: ZonedDateTime): ZonedDateTime? {
        val today = now.toLocalDate()
        when (text) {
            "today" -> return today.atStartOfDay(now.zone)
            "tomorrow" -> return today.plusDays(1).atStartOfDay(now.zone)
        }
        val weekdayName = text.removePrefix("next ").trim()
        val weekday = WEEKDAYS[weekdayName] ?: return null
        var daysAhead = (weekday.value - today.dayOfWeek.value + 7) % 7
        if (daysAhead == 0) daysAhead = 7 // Never "today" — that would often be in the past.
        return today.plusDays(daysAhead.toLong()).atStartOfDay(now.zone)
    }

    /** Parses "5pm", "9:30am", "17:00", "9" — null when unparseable or out of range. */
    fun parseTime(text: String): LocalTime? {
        val cleaned = text.trim().lowercase().replace(" ", "")
        TIME_12H_REGEX.matchEntire(cleaned)?.let { match ->
            val hour12 = match.groupValues[1].toInt()
            val minute = match.groupValues[2].ifEmpty { "0" }.toInt()
            if (hour12 !in 1..12 || minute !in 0..59) return null
            val isPm = match.groupValues[3] == "p"
            val hour24 = when {
                isPm && hour12 != 12 -> hour12 + 12
                !isPm && hour12 == 12 -> 0
                else -> hour12
            }
            return LocalTime.of(hour24, minute)
        }
        TIME_24H_REGEX.matchEntire(cleaned)?.let { match ->
            val hour = match.groupValues[1].toInt()
            val minute = match.groupValues[2].toInt()
            if (hour !in 0..23 || minute !in 0..59) return null
            return LocalTime.of(hour, minute)
        }
        TIME_HOUR_ONLY_REGEX.matchEntire(cleaned)?.let { match ->
            val hour = match.groupValues[1].toInt()
            if (hour !in 0..23) return null
            return LocalTime.of(hour, 0)
        }
        return null
    }

    private fun parseAmount(text: String): Int? = when (text) {
        "a", "an" -> 1
        else -> text.toIntOrNull()?.takeIf { it in 1..365 }
    }
}
