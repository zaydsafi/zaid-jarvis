package com.zaid.jarvis.core.voice

/**
 * Wake-word matching (Master Prompt §5.2). Pure Kotlin, unit-tested.
 *
 * The wake word is "Hey Jarvis". Speech recognizers mis-hear it in
 * predictable ways ("hey jar vis", "hey jarvis" split across words,
 * "a jarvis"), so matching normalizes the transcript first: lowercase,
 * strip punctuation, collapse whitespace, then look for the wake word
 * as a word sequence — never as a substring, so "jarvis" inside another
 * word (or a sentence merely *about* Jarvis) does not wake the app.
 *
 * Note: this matcher runs on transcripts from the platform
 * SpeechRecognizer (see :app WakeWordService). True always-on hotword
 * detection needs a dedicated keyword-spotting library or OEM support
 * and is out of scope — the service restarts the recognizer in a loop
 * instead, which uses more battery. Wake word is off by default.
 */
object WakeWordMatcher {

    /** Normalized word sequences that count as the wake word. */
    private val WAKE_SEQUENCES: List<List<String>> = listOf(
        listOf("hey", "jarvis"),
        listOf("hey", "jar", "vis"),
        listOf("hey", "jar", "viss"),
        listOf("a", "jarvis"),
        listOf("hey", "jarvis", "please"),
        listOf("ok", "jarvis"),
        listOf("okay", "jarvis"),
    )

    /** Bare "jarvis" on its own also wakes — but only as a whole phrase. */
    private val BARE_WAKE_WORDS: Set<String> = setOf("jarvis")

    /**
     * True when [transcript] contains the wake word. Matching is
     * case-insensitive and punctuation-insensitive.
     */
    fun matches(transcript: String): Boolean {
        val words = normalize(transcript)
        if (words.isEmpty()) return false
        if (words.size == 1 && words.first() in BARE_WAKE_WORDS) return true
        return WAKE_SEQUENCES.any { sequence -> containsSequence(words, sequence) }
    }

    /**
     * Removes a leading wake word from [transcript] so the rest can be
     * sent to the planner as the request ("Hey Jarvis, what time is it?"
     * → "what time is it?"). Returns the original transcript when it
     * does not start with the wake word.
     */
    fun stripWakeWord(transcript: String): String {
        val trimmed = transcript.trim()
        val words = normalize(trimmed)
        if (words.isEmpty()) return trimmed
        // Longest matching leading sequence wins.
        val matchLength = WAKE_SEQUENCES
            .filter { words.size >= it.size && words.subList(0, it.size) == it }
            .maxOfOrNull { it.size }
            ?: if (words.first() in BARE_WAKE_WORDS) 1 else return trimmed
        // Drop the same number of raw words (punctuation attached is fine).
        val rawWords = trimmed.split(Regex("\\s+"))
        return rawWords.drop(matchLength).joinToString(" ").trim()
    }

    /** Lowercase, strip punctuation, split into words. */
    fun normalize(transcript: String): List<String> =
        transcript.lowercase()
            .replace(Regex("[^a-z0-9' ]"), " ")
            .replace("'", "")
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() }

    private fun containsSequence(words: List<String>, sequence: List<String>): Boolean {
        if (sequence.size > words.size) return false
        return (0..words.size - sequence.size).any { start ->
            words.subList(start, start + sequence.size) == sequence
        }
    }
}
