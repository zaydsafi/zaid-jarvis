package com.zaid.jarvis.core.automation

/**
 * Best-effort blocklist of banking / payment / wallet apps (Phase 6).
 *
 * Jarvis **never** performs Accessibility actions in these apps — no
 * taps, no typing, no scrolling, no snapshots returned to the planner.
 * The check runs on the foreground package before every automation
 * action (see JarvisAccessibilityService).
 *
 * **This is a guard, not a guarantee.** A banking app whose package
 * name matches none of these patterns would not be blocked — which is
 * why the password-field rule is the real backstop: Jarvis also refuses
 * to act on *any* screen containing a password field, in *any* app.
 * The two rules together cover the realistic cases; neither alone is
 * treated as sufficient.
 *
 * Matching is by package *segment* (the parts between dots), never by
 * raw substring — so `com.example.display` is NOT blocked just because
 * it contains "pay".
 */
object BlockedApps {

    /** Package segments that mark an app as banking / payment / wallet. */
    private val BLOCKED_SEGMENTS: Set<String> = setOf(
        // Generic finance words.
        "bank", "banking", "pay", "wallet", "finance", "brokerage",
        // Payment apps & wallets.
        "paypal", "venmo", "cashapp", "zelle", "wise", "revolut",
        "klarna", "afterpay", "affirm", "sofi", "chime", "cash",
        // Banks (international, by brand segment).
        "chase", "bofa", "bankofamerica", "wellsfargo", "citi",
        "capitalone", "usbank", "pnc", "ally", "amex", "discover",
        "hsbc", "barclays", "lloyds", "natwest", "santander", "monzo",
        "starling", "n26", "rbc", "scotia", "bmo", "tdbank",
        "goldmansachs", "marcus", "fidelity", "schwab", "robinhood",
        "etrade", "vanguard", "webull", "coinbase", "binance", "kraken",
    )

    /** Full package prefixes of well-known payment apps. */
    private val BLOCKED_PACKAGE_PREFIXES: List<String> = listOf(
        "com.paypal.android.",
        "com.venmo",
        "com.squareup.cash",
        "com.google.android.apps.walletnfcrel",
        "com.google.android.apps.nbu.paisa.user",
        "com.samsung.android.spay",
        "com.revolut.revolut",
        "com.transferwise.android",
        "co.uk.getmondo",
        "com.starlingbank.android",
        "com.chase.sig.android",
    )

    /** True when [packageName] looks like a banking / payment / wallet app. */
    fun isBlocked(packageName: String): Boolean {
        if (packageName.isBlank()) return false
        val lower = packageName.lowercase()
        if (BLOCKED_PACKAGE_PREFIXES.any { lower.startsWith(it) }) return true
        return lower.split('.').any { it in BLOCKED_SEGMENTS }
    }

    /** Plain-language reason for a block, or null when not blocked. */
    fun blockReason(packageName: String): String? =
        if (isBlocked(packageName)) {
            "“$packageName” looks like a banking or payment app, and Jarvis " +
                "never automates banking or payment apps."
        } else {
            null
        }
}
