package com.zaid.jarvis.core.research

import kotlinx.serialization.Serializable

/**
 * Research & content models (Phase 7: research → draft → preview, the
 * first half of the publishing gate; actual publishing is Phase 8).
 *
 * Everything here is pure Kotlin: no Android, no network, no database.
 * Web content that flows through these models is UNTRUSTED DATA —
 * search snippets and fetched pages are scanned by the Phase 3
 * InjectionGuard before the planner or the synthesis prompt ever sees
 * them as anything but quoted source material.
 */

// ── Search ───────────────────────────────────────────────────────────────

/** Which search backend answers `search_web` / `research_topic`. */
enum class SearchBackend(val displayName: String) {
    /** Free, no key. DuckDuckGo's lite HTML endpoint. */
    DUCKDUCKGO("DuckDuckGo (free, no key)"),

    /** Paid/premium, needs a Tavily API key (Settings → Research). */
    TAVILY("Tavily (needs API key)"),
}

/** One web-search result. */
@Serializable
data class SearchResult(
    val title: String,
    val url: String,
    val snippet: String,
    /** Host without a leading "www." (e.g. "example.com"). */
    val domain: String,
    /** When this result was fetched (epoch millis). */
    val fetchedAtMillis: Long,
)

/** A fetched web page, reduced to readable text. */
data class PageContent(
    val url: String,
    val title: String,
    /** Readable text, already truncated to the extraction cap. */
    val text: String,
    /** True when the page text was longer than the cap. */
    val truncated: Boolean,
)

/** Host of [url] without a leading "www.", or "" when unparseable. */
fun domainOf(url: String): String {
    val afterScheme = url.substringAfter("://", "")
    if (afterScheme.isEmpty()) return ""
    val host = afterScheme.substringBefore("/").substringBefore("?").substringBefore("#")
        .substringAfterLast("@")
    val withoutPort = if (host.startsWith("[")) {
        host.substringBefore("]")
    } else {
        host.substringBefore(":")
    }
    return withoutPort.removePrefix("www.").lowercase()
}

// ── Research brief ───────────────────────────────────────────────────────

/** One source a brief cites. */
@Serializable
data class ResearchSource(
    val title: String,
    val url: String,
)

/** One factual claim in a brief, bound to the source it came from. */
@Serializable
data class ResearchFact(
    val claim: String,
    /** The source URL that backs this claim ("" when unknown — such facts are dropped). */
    val sourceUrl: String,
)

/**
 * A structured research brief. Every factual claim carries its source
 * URL — the synthesis prompt demands citations, and the engine drops
 * any fact it cannot bind to a source. A brief with no citable facts
 * still has its summary and sources, and says so in [confidenceNotes].
 */
@Serializable
data class ResearchBrief(
    val topic: String,
    val summary: String,
    val keyFacts: List<ResearchFact> = emptyList(),
    val openQuestions: List<String> = emptyList(),
    val confidenceNotes: String = "",
    val sources: List<ResearchSource> = emptyList(),
    val createdAtMillis: Long = 0L,
)

/** A saved research job: topic + brief + when it ran. */
data class ResearchRecord(
    val id: Long = 0,
    val topic: String,
    val brief: ResearchBrief,
    val createdAtMillis: Long,
)

/** Progress events from a running research job (shown in the UI). */
sealed interface ResearchEvent {
    data class Searching(val query: String) : ResearchEvent
    data class Fetching(val url: String, val index: Int, val total: Int) : ResearchEvent
    data object Synthesizing : ResearchEvent
    data class Done(val brief: ResearchBrief) : ResearchEvent
    data class Failed(val message: String) : ResearchEvent
}

/** Human-readable rendering of a brief (chat answers, history detail). */
fun formatBrief(brief: ResearchBrief): String = buildString {
    append("Research: ${brief.topic}\n\n")
    append(brief.summary.trim())
    if (brief.keyFacts.isNotEmpty()) {
        append("\n\nKey facts:\n")
        brief.keyFacts.forEach { fact ->
            val sourceIndex = brief.sources.indexOfFirst { it.url == fact.sourceUrl }
            val citation = if (sourceIndex >= 0) " [${sourceIndex + 1}]" else ""
            append("• ${fact.claim}$citation\n")
        }
    }
    if (brief.openQuestions.isNotEmpty()) {
        append("\nOpen questions:\n")
        brief.openQuestions.forEach { append("• $it\n") }
    }
    if (brief.confidenceNotes.isNotBlank()) {
        append("\nConfidence: ${brief.confidenceNotes.trim()}\n")
    }
    if (brief.sources.isNotEmpty()) {
        append("\nSources:\n")
        brief.sources.forEachIndexed { index, source ->
            append("[${index + 1}] ${source.title} — ${source.url}\n")
        }
    }
}.trimEnd()
