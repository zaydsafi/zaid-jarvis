package com.zaid.jarvis.core.productivity

/**
 * Screen-time awareness (Phase 9, wellness).
 *
 * All data comes from UsageStats and stays on-device — nothing is
 * uploaded anywhere. The Android side (:app UsageStatsScreenTimeReader)
 * converts UsageStats / UsageEvents into these plain types; the
 * aggregation below is pure Kotlin and tested with fakes.
 */

/** One app's foreground time, from UsageStats. */
data class UsageEntry(
    val packageName: String,
    /** Total time in the foreground, in millis, for the queried window. */
    val totalTimeInForegroundMillis: Long,
)

/** One usage event (foreground / background move), from UsageEvents. */
data class UsageEvent(
    /** Epoch millis of the event. */
    val timestampMillis: Long,
    /** True = moved to foreground, false = moved to background. */
    val isForeground: Boolean,
)

/** Today's screen-time summary for the Wellness screen and the tool. */
data class ScreenTimeSummary(
    /** Total foreground time today, in millis. */
    val totalMillis: Long,
    /** Top apps by foreground time (at most [TOP_APPS_COUNT]). */
    val topApps: List<UsageEntry>,
) {
    companion object {
        /** How many top apps the summary keeps. */
        const val TOP_APPS_COUNT: Int = 5
    }

    /** "2h 15m" style label. */
    fun totalLabel(): String = formatDuration(totalMillis)
}

/** "2h 15m" / "45m" / "30s" label for a duration in millis. */
fun formatDuration(millis: Long): String {
    val totalSeconds = (millis / 1000).coerceAtLeast(0L)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return when {
        hours > 0 -> "${hours}h ${minutes}m"
        minutes > 0 -> "${minutes}m"
        else -> "${seconds}s"
    }
}

object ScreenTime {

    /**
     * Aggregates raw UsageStats entries into a summary: total time
     * plus the top [ScreenTimeSummary.TOP_APPS_COUNT] apps. Entries
     * with no foreground time are dropped; ties break by package
     * name so the order is stable.
     */
    fun aggregate(entries: List<UsageEntry>): ScreenTimeSummary {
        val active = entries.filter { it.totalTimeInForegroundMillis > 0 }
        val total = active.sumOf { it.totalTimeInForegroundMillis }
        val top = active
            .sortedWith(
                compareByDescending<UsageEntry> { it.totalTimeInForegroundMillis }
                    .thenBy { it.packageName },
            )
            .take(ScreenTimeSummary.TOP_APPS_COUNT)
        return ScreenTimeSummary(totalMillis = total, topApps = top)
    }

    /**
     * Length of the current continuous screen session, in millis.
     *
     * Walks the usage events (foreground/background moves) backwards
     * from [nowMillis]: the session starts at the most recent
     * foreground move that was not followed by a background move, and
     * ends at [nowMillis] — but a gap of [GAP_TOLERANCE_MILLIS] or
     * more between the last background move and the next foreground
     * move breaks the session (a quick app switch does not; putting
     * the phone down for five minutes does). Returns 0 when the
     * screen is not currently in use (last event was a background
     * move, or no events at all).
     *
     * This is an approximation: UsageStats events are the only
     * on-device signal for "continuous" use, and the system may
     * coalesce events. The break reminder treats it as a lower bound
     * — it only ever fires late, never early.
     */
    fun currentContinuousMillis(
        events: List<UsageEvent>,
        nowMillis: Long,
    ): Long {
        if (events.isEmpty()) return 0L
        val sorted = events.sortedBy { it.timestampMillis }
        // Currently in use only when the last event is a foreground move.
        if (!sorted.last().isForeground) return 0L
        // Walk backwards: find the start of the current session. A
        // background→foreground gap of GAP_TOLERANCE or more breaks it.
        var sessionStart = sorted.last().timestampMillis
        var i = sorted.size - 1
        while (i > 0) {
            val current = sorted[i]
            val previous = sorted[i - 1]
            if (current.isForeground && !previous.isForeground) {
                // Foreground move after a background move: the gap
                // between them decides whether the session continues.
                val gap = current.timestampMillis - previous.timestampMillis
                if (gap >= GAP_TOLERANCE_MILLIS) {
                    // Long gap — the session starts at this foreground move.
                    sessionStart = current.timestampMillis
                    break
                }
                // Short gap (quick app switch) — session continues.
            }
            sessionStart = previous.timestampMillis
            i--
        }
        return (nowMillis - sessionStart).coerceAtLeast(0L)
    }

    /** A gap of 5 minutes or more breaks a continuous session. */
    const val GAP_TOLERANCE_MILLIS: Long = 5 * 60_000L
}
