package com.zaid.jarvis.core.model

/** Visual theme options (Master Prompt §5.1). */
enum class ThemeMode(val displayName: String) {
    LIGHT("Light"),
    DARK("Dark"),
    AMOLED("AMOLED"),
    SYSTEM("Follow system"),
}

/** Languages Jarvis speaks and listens in (Master Prompt §5.1). */
enum class AppLanguage(
    val displayName: String,
    val localeTag: String,
) {
    ENGLISH("English", "en"),
    URDU("Urdu", "ur"),
    ARABIC("Arabic", "ar"),
}

/** Jarvis's speaking style (Master Prompt §5.1). */
enum class Personality(val displayName: String) {
    FORMAL("Formal"),
    FRIENDLY("Friendly"),
    CONCISE("Concise"),
}
