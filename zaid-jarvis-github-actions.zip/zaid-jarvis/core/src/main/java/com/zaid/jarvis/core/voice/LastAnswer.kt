package com.zaid.jarvis.core.voice

/**
 * The widget's "last answer" line (Master Prompt §5.4). Pure Kotlin,
 * unit-tested.
 *
 * The home-screen widget shows the most recent Jarvis reply in a single
 * small line. Long answers are flattened to one line and truncated with
 * an ellipsis so the widget never overflows its RemoteViews layout.
 */
object LastAnswer {

    /** Longest answer shown on the widget (characters, before the ellipsis). */
    const val MAX_WIDGET_CHARS: Int = 80

    /** Text shown before Jarvis has answered anything. */
    const val EMPTY_TEXT: String = "Tap the mic and ask Jarvis anything."

    /**
     * Flattens [answer] to one line and truncates it for the widget.
     * Blank input → [EMPTY_TEXT].
     */
    fun formatForWidget(answer: String): String {
        val oneLine = answer.replace(Regex("\\s+"), " ").trim()
        if (oneLine.isBlank()) return EMPTY_TEXT
        return if (oneLine.length <= MAX_WIDGET_CHARS) {
            oneLine
        } else {
            oneLine.take(MAX_WIDGET_CHARS).trimEnd() + "…"
        }
    }
}
