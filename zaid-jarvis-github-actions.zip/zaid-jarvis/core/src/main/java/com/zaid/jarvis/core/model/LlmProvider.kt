package com.zaid.jarvis.core.model

/**
 * LLM providers Jarvis can talk to.
 * Phase 1: selection only (Settings UI + key storage). Real API calls land in Phase 3.
 *
 * NOTE: this enum deliberately does NOT reference [LlmModel] (no defaultModel
 * property). The two enums referencing each other caused a circular static
 * initialisation bug — the JVM returned null for not-yet-initialised
 * constants. Default models live in [LlmModel.defaultFor].
 */
enum class LlmProvider(
    val displayName: String,
) {
    CLAUDE("Claude (Anthropic)"),
    OPENAI("OpenAI"),
    GEMINI("Gemini (Google)"),
    /**
     * OpenRouter (https://openrouter.ai) — one key, many models, via an
     * OpenAI-compatible API. Model IDs are strings like
     * "anthropic/claude-sonnet-4.5"; curated presets live in [LlmModel]
     * and Zaid can also type any model ID (Phase 3).
     */
    OPENROUTER("OpenRouter"),
    /**
     * Any other OpenAI-compatible API (local server, another vendor, …).
     * Zaid adds the provider in Settings with a name, base URL, API key,
     * and model ID (Phase 3).
     */
    CUSTOM("Custom provider"),
}

/**
 * Models available per provider. Model IDs are the API-facing identifiers;
 * they are configuration, not secrets — API keys are never stored here.
 */
enum class LlmModel(
    val provider: LlmProvider,
    val apiId: String,
    val displayName: String,
    val isCheapTier: Boolean = false,
) {
    // Claude (default provider)
    CLAUDE_SONNET_5_5(LlmProvider.CLAUDE, "claude-sonnet-5-5", "Claude Sonnet 5.5"),
    CLAUDE_HAIKU_5_5(
        LlmProvider.CLAUDE,
        "claude-haiku-5-5",
        "Claude Haiku 5.5 (simple intents)",
        isCheapTier = true,
    ),

    // OpenAI
    GPT_5(LlmProvider.OPENAI, "gpt-5", "GPT-5"),
    GPT_5_MINI(LlmProvider.OPENAI, "gpt-5-mini", "GPT-5 mini", isCheapTier = true),

    // Gemini
    GEMINI_3_PRO(LlmProvider.GEMINI, "gemini-3-pro", "Gemini 3 Pro"),
    GEMINI_3_FLASH(LlmProvider.GEMINI, "gemini-3-flash", "Gemini 3 Flash", isCheapTier = true),

    // OpenRouter presets (model IDs are OpenRouter-style "vendor/model").
    // Zaid can also type any other OpenRouter model ID in Settings (Phase 3).
    OPENROUTER_CLAUDE_SONNET(
        LlmProvider.OPENROUTER,
        "anthropic/claude-sonnet-4.5",
        "OpenRouter · Claude Sonnet 4.5",
    ),
    OPENROUTER_GPT_5(
        LlmProvider.OPENROUTER,
        "openai/gpt-5",
        "OpenRouter · GPT-5",
    ),
    OPENROUTER_GEMINI_3_PRO(
        LlmProvider.OPENROUTER,
        "google/gemini-3-pro",
        "OpenRouter · Gemini 3 Pro",
    ),
    OPENROUTER_LLAMA_CHEAP(
        LlmProvider.OPENROUTER,
        "meta-llama/llama-4-scout",
        "OpenRouter · Llama 4 Scout (cheap)",
        isCheapTier = true,
    ),

    // Custom provider: apiId is a placeholder — the real model ID comes
    // from the selected CustomProviderConfig (see JarvisSettings).
    CUSTOM_MODEL(LlmProvider.CUSTOM, "", "Custom model"),
    ;

    companion object {
        fun forProvider(provider: LlmProvider): List<LlmModel> =
            entries.filter { it.provider == provider }

        /** The model a provider starts on when the user selects it. */
        fun defaultFor(provider: LlmProvider): LlmModel = when (provider) {
            LlmProvider.CLAUDE -> CLAUDE_SONNET_5_5
            LlmProvider.OPENAI -> GPT_5_MINI
            LlmProvider.GEMINI -> GEMINI_3_FLASH
            LlmProvider.OPENROUTER -> OPENROUTER_CLAUDE_SONNET
            LlmProvider.CUSTOM -> CUSTOM_MODEL
        }

        /** The cheap-tier model for a provider, if it has one. */
        fun cheapFor(provider: LlmProvider): LlmModel? =
            forProvider(provider).firstOrNull { it.isCheapTier }
    }
}
