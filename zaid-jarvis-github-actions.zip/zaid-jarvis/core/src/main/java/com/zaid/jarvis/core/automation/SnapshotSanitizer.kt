package com.zaid.jarvis.core.automation

/**
 * Turns a [ScreenSnapshot] into the text Jarvis (and Zaid) reads —
 * the result of the `find_on_screen` tool and the "what I see now"
 * part of a failed macro step.
 *
 * Privacy rules, enforced here as well as at capture time:
 * - Password nodes are dropped, even if one ever slipped into a snapshot.
 * - Labels are truncated ([MAX_LABEL_CHARS]) so a long text field cannot
 *   flood the LLM context or the chat UI.
 * - Only the first [MAX_NODES] interactive nodes are listed; the rest
 *   are counted, not shown.
 * - The snapshot is never persisted or logged — this text is built fresh
 *   per request and discarded with the run.
 */
object SnapshotSanitizer {

    /** Longest label shown for one node. */
    const val MAX_LABEL_CHARS: Int = 60

    /** Most nodes listed in one formatted snapshot. */
    const val MAX_NODES: Int = 30

    /**
     * Formats [snapshot] as a numbered list of interactive elements.
     * Returns a plain-language message when the screen has nothing
     * Jarvis can interact with.
     */
    fun format(snapshot: ScreenSnapshot, maxNodes: Int = MAX_NODES): String {
        val visible = snapshot.nodes
            .filter { !it.isPassword }
            .filter { it.isInteractive }
        if (visible.isEmpty()) {
            return buildString {
                append("The current screen has no tappable or editable elements I can see")
                if (snapshot.packageName.isNotBlank()) {
                    append(" (app: ${snapshot.packageName})")
                }
                append(".")
                if (snapshot.hasPasswordField) {
                    append(" It contains a password field, which I never read or act on.")
                }
            }
        }
        val shown = visible.take(maxNodes)
        return buildString {
            if (snapshot.packageName.isNotBlank()) {
                appendLine("On screen now (${snapshot.packageName}):")
            } else {
                appendLine("On screen now:")
            }
            shown.forEachIndexed { index, node ->
                appendLine("${index + 1}. ${describeNode(node)}")
            }
            if (visible.size > shown.size) {
                appendLine("… and ${visible.size - shown.size} more element(s).")
            }
            if (snapshot.hasPasswordField) {
                append(
                    "Note: this screen also has a password field — it is not listed " +
                        "and I will not act on this screen.",
                )
            }
        }.trimEnd()
    }

    /** One line for one node: "[Button] “Search” (tappable)". */
    fun describeNode(node: ScreenNode): String {
        val kind = node.className.substringAfterLast('.').ifBlank { "Element" }
        val label = node.label?.let { truncate(it) }?.let { " “$it”" } ?: ""
        val abilities = buildList {
            if (node.clickable) add("tappable")
            if (node.editable) add("editable")
        }.joinToString(", ")
        return "[$kind]$label ($abilities)".trim()
    }

    private fun truncate(text: String): String =
        if (text.length <= MAX_LABEL_CHARS) text else text.take(MAX_LABEL_CHARS) + "…"
}
