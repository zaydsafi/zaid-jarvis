package com.zaid.jarvis.core.analytics

import com.zaid.jarvis.core.confirmation.RiskTier

/**
 * On-device usage analytics (Phase 10) — privacy-first, local only.
 *
 * There is no third-party SDK and nothing ever leaves the device: events
 * are recorded in the encrypted Room database and aggregated on-device
 * for the Insights screen. An event carries only a name, a timestamp,
 * and a small payload of NON-PERSONAL data (a tool name, a tier, an
 * outcome, a platform, a duration bucket).
 *
 * NEVER logged: message content, draft text, note content, contact
 * names, URLs, search queries, or any free text. [AnalyticsPayload]
 * enforces that structurally — payload values may not contain spaces
 * or free text at all, and every event declares exactly which keys it
 * may carry. Anything that fails validation is dropped, never recorded.
 *
 * Recording is controlled by the "Usage insights" toggle in Settings
 * (default ON — the data is the user's own, on their own device; see
 * [com.zaid.jarvis.core.model.JarvisSettings.analyticsEnabled]). When
 * off, [AnalyticsSink] implementations record nothing.
 */
object AnalyticsEvents {
    /** A tool execution finished (via GatedToolExecutor). Payload: tool, tier, outcome. */
    const val TOOL_EXECUTED: String = "tool_executed"

    /** A social publish finished (via PublishService). Payload: platform, outcome. */
    const val PUBLISH: String = "publish"

    /** A focus session ended. Payload: duration_bucket, outcome. */
    const val FOCUS_SESSION: String = "focus_session"

    /** Outcomes recorded for tool executions. */
    const val OUTCOME_SUCCESS: String = "success"
    const val OUTCOME_FAILURE: String = "failure"
    const val OUTCOME_DENIED: String = "denied"
    const val OUTCOME_EXPIRED: String = "expired"
    const val OUTCOME_CANCELLED: String = "cancelled"
    const val OUTCOME_BIOMETRIC_FAILED: String = "biometric_failed"

    /** Outcomes recorded for focus sessions. */
    const val OUTCOME_COMPLETED: String = "completed"
    const val OUTCOME_STOPPED_EARLY: String = "stopped_early"

    /** All known event names. */
    val ALL: Set<String> = setOf(TOOL_EXECUTED, PUBLISH, FOCUS_SESSION)
}

/**
 * Payload rules for analytics events.
 *
 * Each event declares its allowed keys; a payload with any other key is
 * invalid. Values must match [VALUE_PATTERN]: short, single tokens with
 * no spaces — this is what makes free text structurally impossible.
 * A value that looks like free text (spaces, punctuation runs, long
 * strings) is rejected, and the whole event is dropped.
 */
object AnalyticsPayload {

    /** Payload values: one token, 1–64 chars, no spaces, no free text. */
    private val VALUE_PATTERN: Regex = Regex("^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$")

    private val ALLOWED_KEYS: Map<String, Set<String>> = mapOf(
        AnalyticsEvents.TOOL_EXECUTED to setOf("tool", "tier", "outcome"),
        AnalyticsEvents.PUBLISH to setOf("platform", "outcome"),
        AnalyticsEvents.FOCUS_SESSION to setOf("duration_bucket", "outcome"),
    )

    /**
     * Validates a payload for [eventName]. Returns a list of problems;
     * empty means the payload may be recorded.
     */
    fun validate(eventName: String, payload: Map<String, String>): List<String> {
        val errors = mutableListOf<String>()
        val allowed = ALLOWED_KEYS[eventName]
            ?: return listOf("Unknown analytics event: $eventName")
        for (key in payload.keys) {
            if (key !in allowed) errors += "Key '$key' is not allowed for event '$eventName'"
        }
        for ((key, value) in payload) {
            if (!VALUE_PATTERN.matches(value)) {
                errors += "Value for '$key' is not a plain token (free text is never recorded)"
            }
        }
        val missing = allowed - payload.keys
        if (missing.isNotEmpty()) {
            errors += "Missing payload keys for '$eventName': ${missing.joinToString(", ")}"
        }
        return errors
    }

    /** True when the payload is recordable for [eventName]. */
    fun isValid(eventName: String, payload: Map<String, String>): Boolean =
        validate(eventName, payload).isEmpty()

    /**
     * Buckets a focus-session length into a coarse, non-identifying
     * range — the exact duration is never recorded as an event.
     */
    fun durationBucket(durationMinutes: Int): String = when {
        durationMinutes < 15 -> "under_15"
        durationMinutes <= 30 -> "15_30"
        durationMinutes <= 60 -> "30_60"
        else -> "over_60"
    }
}

/**
 * Where analytics events go. Implementations record into the local
 * Room database ([com.zaid.jarvis.data.repository.AnalyticsRepository])
 * and honour the "Usage insights" toggle; [NoOpAnalyticsSink] records
 * nothing (used by tests and by any caller without analytics wired in).
 *
 * Every method is best-effort: recording must never throw into the
 * caller — a failed recording is silently dropped, because analytics
 * must never break the feature it observes.
 */
interface AnalyticsSink {
    suspend fun recordToolExecution(toolName: String, tier: RiskTier, outcome: String)
    suspend fun recordPublish(platform: String, success: Boolean)
    suspend fun recordFocusSession(durationMinutes: Int, completed: Boolean)
}

/** An analytics sink that records nothing. */
object NoOpAnalyticsSink : AnalyticsSink {
    override suspend fun recordToolExecution(toolName: String, tier: RiskTier, outcome: String) = Unit
    override suspend fun recordPublish(platform: String, success: Boolean) = Unit
    override suspend fun recordFocusSession(durationMinutes: Int, completed: Boolean) = Unit
}
