package com.zaid.jarvis.core.confirmation

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Trusted actions (Master Prompt §6): "Always ask" is the default for every
 * tool; Zaid may mark specific low-risk actions as trusted, and can revoke
 * at any time. Only tiers 0–1 can be trusted — the engine enforces that
 * at execution time (see [ConfirmationEngine]).
 *
 * Production implementation is DataStore-backed (:data
 * `TrustedActionRepository`); [InMemoryTrustedActionStore] is for tests.
 */
interface TrustedActionStore {
    suspend fun isTrusted(toolName: String): Boolean
    suspend fun trust(toolName: String)
    suspend fun revoke(toolName: String)
    suspend fun revokeAll()
    fun observeTrusted(): Flow<Set<String>>
}

/** In-memory trusted-action store for tests. Not used in production. */
class InMemoryTrustedActionStore : TrustedActionStore {
    private val trusted = MutableStateFlow<Set<String>>(emptySet())

    override suspend fun isTrusted(toolName: String): Boolean =
        trusted.value.contains(toolName)

    override suspend fun trust(toolName: String) {
        trusted.value = trusted.value + toolName
    }

    override suspend fun revoke(toolName: String) {
        trusted.value = trusted.value - toolName
    }

    override suspend fun revokeAll() {
        trusted.value = emptySet()
    }

    override fun observeTrusted(): Flow<Set<String>> = trusted.asStateFlow()
}
