package com.zaid.jarvis.core.research

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.net.URLDecoder

/**
 * Parses search-backend responses into [SearchResult]s (Phase 7).
 *
 * Two backends, one shape:
 * - **DuckDuckGo (free, default):** `lite.duckduckgo.com/lite/?q=…`
 *   returns plain HTML. Results are `<a class="result-link">` anchors
 *   followed by `<td class="result-snippet">` cells. DuckDuckGo wraps
 *   result URLs in a redirect (`/l/?uddg=<url-encoded target>`); the
 *   parser unwraps the `uddg` parameter so Zaid sees the real URL.
 *   The parser is deliberately tolerant — if DuckDuckGo changes its
 *   markup, search returns fewer (or zero) results instead of crashing,
 *   and the tool says so honestly.
 * - **Tavily (key-based):** JSON `{"results": [{"title", "url",
 *   "content", …}]}`. Parsed with kotlinx.serialization.
 *
 * Pure functions over recorded text — no network here, so tests use
 * fixtures and never touch the internet.
 */
object SearchResultParser {

    private val json = Json { ignoreUnknownKeys = true }

    @Serializable
    private data class TavilyResponse(val results: List<TavilyResult> = emptyList())

    @Serializable
    private data class TavilyResult(
        val title: String = "",
        val url: String = "",
        val content: String = "",
    )

    private val ddgLinkRegex =
        Regex("""(?is)<a\b[^>]*class=["']result-link["'][^>]*href=["']([^"']+)["'][^>]*>(.*?)</a>""")
    private val ddgSnippetRegex =
        Regex("""(?is)<td\b[^>]*class=["']result-snippet["'][^>]*>(.*?)</td>""")
    private val tagRegex = Regex("<[^>]+>")

    /** Parses DuckDuckGo lite HTML into at most [maxResults] results. */
    fun parseDuckDuckGoLite(
        html: String,
        maxResults: Int,
        fetchedAtMillis: Long,
    ): List<SearchResult> {
        val results = mutableListOf<SearchResult>()
        for (linkMatch in ddgLinkRegex.findAll(html)) {
            if (results.size >= maxResults) break
            val rawHref = linkMatch.groupValues[1].trim()
            val url = unwrapDuckDuckGoUrl(rawHref)
            if (url.isBlank() || !url.startsWith("http")) continue
            val title = cleanSnippet(linkMatch.groupValues[2])
            if (title.isBlank()) continue
            // The snippet cell follows the link in the same result block.
            val snippetMatch = ddgSnippetRegex.find(html, linkMatch.range.last + 1)
            val snippet = snippetMatch?.let { cleanSnippet(it.groupValues[1]) } ?: ""
            results += SearchResult(
                title = title,
                url = url,
                snippet = snippet,
                domain = domainOf(url),
                fetchedAtMillis = fetchedAtMillis,
            )
        }
        return results
    }

    /** Parses a Tavily `/search` JSON response into at most [maxResults] results. */
    fun parseTavilyJson(
        jsonText: String,
        maxResults: Int,
        fetchedAtMillis: Long,
    ): List<SearchResult> {
        val response = runCatching { json.decodeFromString<TavilyResponse>(jsonText) }
            .getOrNull() ?: return emptyList()
        return response.results
            .filter { it.url.startsWith("http") && it.title.isNotBlank() }
            .take(maxResults)
            .map { result ->
                SearchResult(
                    title = result.title.trim(),
                    url = result.url.trim(),
                    snippet = result.content.trim(),
                    domain = domainOf(result.url),
                    fetchedAtMillis = fetchedAtMillis,
                )
            }
    }

    /**
     * Unwraps a DuckDuckGo redirect link (`/l/?uddg=<encoded>` or
     * `//duckduckgo.com/l/?uddg=…`) to the real target URL. Returns the
     * input unchanged when it isn't a redirect.
     */
    fun unwrapDuckDuckGoUrl(href: String): String {
        val uddg = Regex("[?&]uddg=([^&]+)").find(href)?.groupValues?.getOrNull(1)
            ?: return HtmlTextExtractor.decodeHtmlEntities(href)
        return runCatching { URLDecoder.decode(uddg, "UTF-8") }.getOrNull() ?: href
    }

    private fun cleanSnippet(raw: String): String =
        HtmlTextExtractor.decodeHtmlEntities(raw.replace(tagRegex, " "))
            .replace(Regex("\\s+"), " ").trim()
}
