package com.zaid.jarvis.core.confirmation

import com.zaid.jarvis.core.util.JarvisResult
import java.util.UUID
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** What happened when a tool call went through the Confirmation Engine. */
sealed interface ExecutionOutcome {
    /** The action ran (with the approved content). */
    data class Executed(val result: JarvisResult<String>) : ExecutionOutcome

    /** Zaid denied it (or cancelled the second confirmation). */
    data object Denied : ExecutionOutcome

    /** The 2-minute approval window elapsed before a decision. */
    data object Expired : ExecutionOutcome

    /** The kill switch cancelled it. */
    data object Cancelled : ExecutionOutcome

    /** Tier 3: the biometric check failed or was cancelled. */
    data object BiometricFailed : ExecutionOutcome
}

/**
 * The Confirmation Engine (Master Prompt §6) — the gate every tool call
 * passes through. No tool executes without going through [execute]; the
 * agent (Phase 3) and [com.zaid.jarvis.tools.GatedToolExecutor] are the
 * only callers, and tools themselves are never invoked directly.
 *
 * Rules enforced here:
 * - **Tier routing** — Tier 0 asks once per session, then auto-allows
 *   (unless `alwaysAskReadOnly`); Tier 1 asks every time; Tier 2 asks
 *   then needs a second confirmation; Tier 3 asks then needs biometrics.
 * - **"Always ask" default** — nothing is auto-allowed except Tier 0
 *   session repeats and explicitly trusted Tier 0/1 actions.
 * - **Expiry** — approvals expire 2 minutes after the request is shown.
 * - **Content binding** — the approval is bound to the exact content
 *   shown (SHA-256). The action runs with the *approved* content, never
 *   with anything else; an edit creates a brand-new request.
 * - **Single use** — an approval id can never be reused.
 * - **Kill switch** — a stop at any point cancels the run, even mid-approval.
 * - **Audit** — every request and outcome is recorded.
 *
 * Pure Kotlin (no Android APIs) so it is fully unit-testable on the JVM.
 * Time is injected via [clock] for deterministic expiry tests.
 */
class ConfirmationEngine(
    private val auditLog: AuditLog,
    private val trustedStore: TrustedActionStore,
    private val killSwitch: KillSwitch,
    private val clock: () -> Long = System::currentTimeMillis,
    private val approvalTimeoutMillis: Long = APPROVAL_TIMEOUT_MILLIS,
    private val maxConsumedApprovalIds: Int = MAX_CONSUMED_APPROVAL_IDS,
) {
    companion object {
        /** Approvals expire 2 minutes after the request is shown (§6). */
        const val APPROVAL_TIMEOUT_MILLIS: Long = 120_000L

        /**
         * Max consumed approval ids kept in memory (Phase 11 hardening).
         * Ids are UUIDs and single-use by construction: an id can only
         * ever be resolved while its request is the currently pending
         * one, so evicting old ids is safe — a completed request's id
         * can never be presented again.
         */
        const val MAX_CONSUMED_APPROVAL_IDS: Int = 1_000
    }

    private val _pendingRequest = MutableStateFlow<ApprovalRequest?>(null)

    /** The request currently shown on the approval card, if any. */
    val pendingRequest: StateFlow<ApprovalRequest?> = _pendingRequest.asStateFlow()

    /** Tier 0 tools approved once this session (session = process lifetime). */
    private val sessionApprovedTier0 = mutableSetOf<String>()

    /** Approval ids that have already been used — never reusable. */
    private val consumedApprovalIds = linkedSetOf<String>()

    private val lock = Any()
    private val awaiting = mutableMapOf<String, CompletableDeferred<ApprovalDecision>>()

    init {
        killSwitch.addOnCancelListener { cancelPending() }
    }

    /**
     * Runs [block] with the content Zaid approved, after gating on [tier].
     *
     * The [block] receives the *approved* content as its argument — for
     * tools whose content is the payload (e.g. an SMS body), the tool must
     * execute with that argument, not with anything else.
     *
     * [undoInfoProvider] (Phase 5) is consulted only after the action has
     * actually run: it returns the undo payload the tool captured during
     * execution, or null when the action is not undoable. The engine
     * stores it on the audit entry so the Audit Log screen can offer a
     * real Undo. Denied, expired, and cancelled actions never get undo
     * data — nothing ran, so there is nothing to reverse.
     *
     * [paramsJsonProvider] (Phase 5) is consulted at audit time so the
     * audit log records the parameters that actually ran — when Zaid
     * edits the content on the approval card, the tool re-derives its
     * parameters from the edited text, and the audit entry must show
     * those, not the originals. Falls back to [paramsJson] when null.
     */
    suspend fun execute(
        toolName: String,
        tier: RiskTier,
        action: String,
        target: String,
        dataUsed: String,
        exactContent: String,
        paramsJson: String,
        alwaysAskReadOnly: Boolean = false,
        undoInfoProvider: (() -> UndoInfo?)? = null,
        paramsJsonProvider: (() -> String)? = null,
        block: suspend (approvedContent: String) -> JarvisResult<String>,
    ): ExecutionOutcome {
        val generation = killSwitch.currentGeneration()

        // ── Fast paths (no card) ──────────────────────────────────────
        if (tier == RiskTier.READ_ONLY &&
            !alwaysAskReadOnly &&
            sessionApprovedTier0.contains(toolName)
        ) {
            return autoExecute(
                toolName, tier, action, target, paramsJson,
                AuditDecision.AUTO_ALLOWED_SESSION, generation, exactContent,
                undoInfoProvider, paramsJsonProvider, block,
            )
        }
        if (tier.canBeTrusted && trustedStore.isTrusted(toolName)) {
            return autoExecute(
                toolName, tier, action, target, paramsJson,
                AuditDecision.AUTO_ALLOWED_TRUSTED, generation, exactContent,
                undoInfoProvider, paramsJsonProvider, block,
            )
        }

        // ── Approval card flow ────────────────────────────────────────
        var request = newRequest(
            toolName, tier, action, target, dataUsed, exactContent, paramsJson,
        )
        setPending(request)

        while (true) {
            val deferred = CompletableDeferred<ApprovalDecision>()
            synchronized(lock) { awaiting[request.id] = deferred }
            val decision = deferred.await()
            synchronized(lock) { awaiting.remove(request.id) }

            if (killSwitch.currentGeneration() != generation) {
                clearPendingIf(request.id)
                audit(request, AuditDecision.CANCELLED, "Cancelled by kill switch")
                return ExecutionOutcome.Cancelled
            }

            when (decision) {
                is ApprovalDecision.CancelledDecision -> {
                    clearPendingIf(request.id)
                    audit(request, AuditDecision.CANCELLED, "Cancelled by kill switch")
                    return ExecutionOutcome.Cancelled
                }
                is ApprovalDecision.ExpiredDecision -> {
                    clearPendingIf(request.id)
                    audit(request, AuditDecision.EXPIRED, "Approval expired after 2 minutes")
                    return ExecutionOutcome.Expired
                }
                is ApprovalDecision.Deny -> {
                    clearPendingIf(request.id)
                    audit(request, AuditDecision.DENIED, "Denied by Zaid")
                    return ExecutionOutcome.Denied
                }
                is ApprovalDecision.Edit -> {
                    audit(request, AuditDecision.EDITED, "Content edited by Zaid")
                    synchronized(lock) { rememberConsumed(request.id) }
                    // A new request for the new content: new id, fresh expiry.
                    request = newRequest(
                        toolName, tier, action, target, dataUsed,
                        decision.newContent, paramsJson,
                    )
                    setPending(request)
                }
                is ApprovalDecision.Allow -> {
                    if (request.isExpired(clock())) {
                        clearPendingIf(request.id)
                        audit(request, AuditDecision.EXPIRED, "Approval expired after 2 minutes")
                        return ExecutionOutcome.Expired
                    }
                    when {
                        request.state == ApprovalState.AWAITING_DECISION &&
                            tier.requiresSecondConfirmation -> {
                            request = request.copy(state = ApprovalState.AWAITING_SECOND_CONFIRMATION)
                            setPending(request)
                        }
                        request.state == ApprovalState.AWAITING_DECISION &&
                            tier.requiresBiometric -> {
                            request = request.copy(state = ApprovalState.AWAITING_BIOMETRIC)
                            setPending(request)
                        }
                        else -> return approveAndRun(request, generation, undoInfoProvider, paramsJsonProvider, block)
                    }
                }
                is ApprovalDecision.ConfirmSecond -> {
                    if (request.state != ApprovalState.AWAITING_SECOND_CONFIRMATION) {
                        continue // Stale decision; keep waiting.
                    }
                    if (request.isExpired(clock())) {
                        clearPendingIf(request.id)
                        audit(request, AuditDecision.EXPIRED, "Approval expired after 2 minutes")
                        return ExecutionOutcome.Expired
                    }
                    return approveAndRun(request, generation, undoInfoProvider, paramsJsonProvider, block)
                }
                is ApprovalDecision.CancelSecond -> {
                    clearPendingIf(request.id)
                    audit(request, AuditDecision.DENIED, "Second confirmation cancelled")
                    return ExecutionOutcome.Denied
                }
                is ApprovalDecision.BiometricOk -> {
                    if (request.state != ApprovalState.AWAITING_BIOMETRIC) {
                        continue // Stale decision; keep waiting.
                    }
                    if (request.isExpired(clock())) {
                        clearPendingIf(request.id)
                        audit(request, AuditDecision.EXPIRED, "Approval expired after 2 minutes")
                        return ExecutionOutcome.Expired
                    }
                    return approveAndRun(request, generation, undoInfoProvider, paramsJsonProvider, block)
                }
                is ApprovalDecision.BiometricFailed -> {
                    clearPendingIf(request.id)
                    audit(request, AuditDecision.DENIED, "Biometric authentication failed")
                    return ExecutionOutcome.BiometricFailed
                }
            }
        }
    }

    /**
     * Resolves the pending request with [decision]. Returns false when the
     * request is unknown, already used, in the wrong state for the
     * decision, or expired (an expired request is expired, not resolved).
     */
    fun resolve(requestId: String, decision: ApprovalDecision): Boolean {
        val request = pendingRequest.value?.takeIf { it.id == requestId } ?: return false
        if (consumedApprovalIds.contains(requestId)) return false

        val validForState = when (decision) {
            is ApprovalDecision.ConfirmSecond, is ApprovalDecision.CancelSecond ->
                request.state == ApprovalState.AWAITING_SECOND_CONFIRMATION
            is ApprovalDecision.BiometricOk, is ApprovalDecision.BiometricFailed ->
                request.state == ApprovalState.AWAITING_BIOMETRIC
            else -> request.state == ApprovalState.AWAITING_DECISION
        }
        if (!validForState) return false

        val deferred = synchronized(lock) { awaiting[requestId] } ?: return false
        if (request.isExpired(clock())) {
            _pendingRequest.value = request.copy(state = ApprovalState.EXPIRED)
            deferred.complete(ApprovalDecision.ExpiredDecision)
            return false
        }
        return deferred.complete(decision)
    }

    /** Expires the pending request if its 2-minute window has elapsed. */
    fun expireStaleRequests() {
        val request = pendingRequest.value ?: return
        if (!request.isExpired(clock())) return
        val deferred = synchronized(lock) { awaiting[request.id] }
        _pendingRequest.value = request.copy(state = ApprovalState.EXPIRED)
        deferred?.complete(ApprovalDecision.ExpiredDecision)
    }

    /** Cancels the pending request (called by the kill switch). */
    fun cancelPending() {
        val request = pendingRequest.value ?: return
        val deferred = synchronized(lock) { awaiting[request.id] }
        _pendingRequest.value = request.copy(state = ApprovalState.CANCELLED)
        deferred?.complete(ApprovalDecision.CancelledDecision)
    }

    /** Marks a low-risk action as trusted (tiers 0–1 only; enforced at execution). */
    suspend fun trust(toolName: String) = trustedStore.trust(toolName)

    /** Revokes trust for one action. */
    suspend fun revokeTrust(toolName: String) = trustedStore.revoke(toolName)

    /** Ends the session: Tier 0 tools will ask again next time. */
    fun endSession() {
        sessionApprovedTier0.clear()
    }

    /**
     * How many consumed approval ids are currently retained (diagnostic,
     * used by tests to verify the [MAX_CONSUMED_APPROVAL_IDS] bound).
     */
    fun consumedApprovalCount(): Int = synchronized(lock) { consumedApprovalIds.size }

    /**
     * Records [id] as consumed. Returns false when the id was already
     * consumed (single-use enforcement). Evicts the eldest ids when the
     * set grows past [maxConsumedApprovalIds] — safe because a consumed
     * id can never be presented again (see [MAX_CONSUMED_APPROVAL_IDS]).
     * Callers must hold [lock].
     */
    private fun rememberConsumed(id: String): Boolean {
        val added = consumedApprovalIds.add(id)
        while (consumedApprovalIds.size > maxConsumedApprovalIds) {
            val eldest = consumedApprovalIds.iterator().next()
            consumedApprovalIds.remove(eldest)
        }
        return added
    }

    private suspend fun autoExecute(
        toolName: String,
        tier: RiskTier,
        action: String,
        target: String,
        paramsJson: String,
        decision: AuditDecision,
        generation: Int,
        exactContent: String,
        undoInfoProvider: (() -> UndoInfo?)?,
        paramsJsonProvider: (() -> String)?,
        block: suspend (approvedContent: String) -> JarvisResult<String>,
    ): ExecutionOutcome {
        if (killSwitch.currentGeneration() != generation) {
            return ExecutionOutcome.Cancelled
        }
        val result = block(exactContent)
        // Only a successful run gets undo data — a failed action changed
        // nothing, so there is nothing to reverse.
        val undoInfo = if (result is JarvisResult.Success) undoInfoProvider?.invoke() else null
        auditLog.record(
            AuditEntry(
                timestampMillis = clock(),
                toolName = toolName,
                tier = tier,
                action = action,
                target = target,
                paramsSummary = summarizeParams(paramsJsonProvider?.invoke() ?: paramsJson),
                decision = decision,
                resultSummary = summarizeResult(result),
                undoable = undoInfo != null,
                undoDescription = undoInfo?.description,
                undoData = undoInfo?.data,
            ),
        )
        return ExecutionOutcome.Executed(result)
    }

    private suspend fun approveAndRun(
        request: ApprovalRequest,
        generation: Int,
        undoInfoProvider: (() -> UndoInfo?)?,
        paramsJsonProvider: (() -> String)?,
        block: suspend (approvedContent: String) -> JarvisResult<String>,
    ): ExecutionOutcome {
        // Single use: an approval id can never execute twice.
        val firstUse = synchronized(lock) { rememberConsumed(request.id) }
        if (!firstUse) {
            clearPendingIf(request.id)
            return ExecutionOutcome.Denied
        }
        // Content binding: the content being executed must hash to the hash
        // recorded when the approval was shown. Any mismatch refuses to run.
        if (sha256Hex(request.canonicalContent()) != request.contentHash) {
            clearPendingIf(request.id)
            audit(request, AuditDecision.DENIED, "Content changed after approval — refused")
            return ExecutionOutcome.Denied
        }
        if (killSwitch.currentGeneration() != generation) {
            clearPendingIf(request.id)
            audit(request, AuditDecision.CANCELLED, "Cancelled by kill switch")
            return ExecutionOutcome.Cancelled
        }
        if (request.tier == RiskTier.READ_ONLY) {
            sessionApprovedTier0.add(request.toolName)
        }
        clearPendingIf(request.id)
        val result = block(request.exactContent)
        // Only a successful run gets undo data — a failed action changed
        // nothing, so there is nothing to reverse.
        val undoInfo = if (result is JarvisResult.Success) undoInfoProvider?.invoke() else null
        audit(
            request, AuditDecision.ALLOWED, summarizeResult(result), undoInfo,
            paramsJsonProvider?.invoke(),
        )
        return ExecutionOutcome.Executed(result)
    }

    private suspend fun audit(
        request: ApprovalRequest,
        decision: AuditDecision,
        resultSummary: String?,
        undoInfo: UndoInfo? = null,
        paramsJsonOverride: String? = null,
    ) {
        auditLog.record(
            AuditEntry(
                timestampMillis = clock(),
                toolName = request.toolName,
                tier = request.tier,
                action = request.action,
                target = request.target,
                paramsSummary = summarizeParams(paramsJsonOverride ?: request.paramsJson),
                decision = decision,
                resultSummary = resultSummary,
                undoable = decision == AuditDecision.ALLOWED && undoInfo != null,
                undoDescription = undoInfo?.description,
                undoData = undoInfo?.data,
            ),
        )
    }

    private fun newRequest(
        toolName: String,
        tier: RiskTier,
        action: String,
        target: String,
        dataUsed: String,
        exactContent: String,
        paramsJson: String,
    ): ApprovalRequest = ApprovalRequest.create(
        id = UUID.randomUUID().toString(),
        toolName = toolName,
        tier = tier,
        action = action,
        target = target,
        dataUsed = dataUsed,
        exactContent = exactContent,
        paramsJson = paramsJson,
        createdAtMillis = clock(),
        timeoutMillis = approvalTimeoutMillis,
    )

    private fun setPending(request: ApprovalRequest) {
        _pendingRequest.value = request
    }

    private fun clearPendingIf(requestId: String) {
        if (_pendingRequest.value?.id == requestId) {
            _pendingRequest.value = null
        }
    }

    /** Short, redacted parameter summary for the audit log (never raw secrets). */
    private fun summarizeParams(paramsJson: String): String {
        val cleaned = paramsJson.replace(Regex("(?i)\"(api[_-]?key|password|token|secret)\"\\s*:\\s*\"[^\"]*\""), "\"$1\":\"[redacted]\"")
        return cleaned.take(500)
    }

    private fun summarizeResult(result: JarvisResult<String>): String =
        when (result) {
            is JarvisResult.Success -> "OK: ${result.value.take(200)}"
            is JarvisResult.Failure -> "Failed: ${result.message.take(200)}"
        }
}
