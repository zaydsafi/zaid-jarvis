package com.zaid.jarvis.core.model

import kotlinx.serialization.Serializable

/**
 * A user-added, OpenAI-compatible LLM provider (Master Prompt §4, Phase 3
 * addition: "OpenRouter and other AI model API key providers").
 *
 * Examples: a vendor with an OpenAI-compatible endpoint or a corporate
 * proxy. The provider speaks the OpenAI Chat Completions API (including
 * `tools` / `tool_calls`) at `[baseUrl]/chat/completions`.
 *
 * The API key is NOT stored here — it lives in Keystore-backed
 * EncryptedSharedPreferences under `api_key_custom_<id>` (see
 * :data ApiKeyRepository). Only non-secret configuration is in this class.
 *
 * https:// only (Phase 11): a plain-http base URL would send the API
 * key — and the whole conversation — in clear text, so `http://` is
 * refused by [validationErrors] and such a provider can never be used
 * (the LLM client factory refuses invalid configs). This deliberately
 * removes the Phase 3 behaviour that allowed `http://` for local
 * servers (Ollama, llama.cpp, vLLM on the LAN): a local server must be
 * put behind https (e.g. a reverse proxy with a certificate) to be
 * usable. The Settings add/edit forms show the refusal and keep the
 * save button disabled; a provider saved before this change simply
 * fails to resolve with the same message.
 */
@Serializable
data class CustomProviderConfig(
    /** Stable id (UUID), used to look up the stored API key. */
    val id: String,
    /** Display name shown in Settings, e.g. "My local server". */
    val name: String,
    /**
     * Base URL of the OpenAI-compatible API, e.g.
     * "https://api.example.com/v1". A trailing slash is tolerated.
     * https:// only — http:// is refused (see [validationErrors]).
     */
    val baseUrl: String,
    /** Model ID to send in requests, e.g. "llama-3.3-70b-instruct". */
    val modelId: String,
) {
    /**
     * Human-readable validation problems, empty when the config is
     * usable. Enforced in two places: the Settings add/edit forms
     * (which show the errors and disable saving) and the LLM client
     * factory in :agent, which refuses to build a client for an
     * invalid config — so an http:// URL can never be used, even if
     * it was saved before this check existed (e.g. imported from a
     * backup, or stored by an older version).
     */
    fun validationErrors(): List<String> {
        val errors = mutableListOf<String>()
        if (name.isBlank()) errors += "Name is required."
        if (modelId.isBlank()) errors += "Model ID is required."
        val url = baseUrl.trim()
        if (url.isBlank()) {
            errors += "Base URL is required."
        } else if (url.startsWith("http://")) {
            errors += "Base URL must use https:// — plain HTTP would send your API key in clear text."
        } else if (!url.startsWith("https://")) {
            errors += "Base URL must start with https://."
        }
        return errors
    }

    /** True when the config is complete enough to attempt a request. */
    val isValid: Boolean get() = validationErrors().isEmpty()

    /** Base URL normalised for Retrofit (must end with a slash). */
    fun normalizedBaseUrl(): String {
        val trimmed = baseUrl.trim().removeSuffix("/")
        return "$trimmed/"
    }
}
