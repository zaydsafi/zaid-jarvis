package com.zaid.jarvis.core.automation

/**
 * What the AccessibilityService observed the user do, in pure-Kotlin form.
 * The service maps AccessibilityEvents to this type — and drops the text
 * of password fields *at the mapping site*, so a password never reaches
 * the recorder at all ([text] is null and [isPassword] is true).
 */
data class ObservedUiEvent(
    val kind: ObservedEventKind,
    /** Package the event came from (own-app events are ignored). */
    val packageName: String,
    /** Selector for the node involved, if it has one. */
    val selector: NodeSelector? = null,
    /** New text (TEXT_CHANGED only); null for password fields. */
    val text: String? = null,
    /** True when the source node is a password field. */
    val isPassword: Boolean = false,
)

enum class ObservedEventKind {
    CLICKED,
    TEXT_CHANGED,
    SCROLLED_FORWARD,
    SCROLLED_BACK,
}

/**
 * Pure recording logic (Phase 6): turns observed UI events into macro
 * steps, and coalesces the keystroke-by-keystroke text events Android
 * sends into one TYPE_TEXT step per field.
 *
 * Skipped (returns null from [eventToStep]):
 * - events from Jarvis's own app (recording taps inside Jarvis is useless),
 * - text typed into password fields (never recorded, counted separately),
 * - clicks with no usable selector (nothing to replay against),
 * - text changes with no text.
 */
object RecorderLogic {

    /** Jarvis's own package — events from it are never recorded. */
    const val OWN_PACKAGE: String = "com.zaid.jarvis"

    /** Converts one observed event into a macro step, or null to skip it. */
    fun eventToStep(event: ObservedUiEvent): MacroStep? {
        if (event.packageName == OWN_PACKAGE) return null
        return when (event.kind) {
            ObservedEventKind.CLICKED -> {
                val selector = event.selector
                if (selector == null || selector.isEmpty) return null
                if (event.isPassword) return null
                MacroStep(action = MacroAction.TAP, selector = selector)
            }
            ObservedEventKind.TEXT_CHANGED -> {
                if (event.isPassword) return null
                val text = event.text?.takeIf { it.isNotBlank() } ?: return null
                MacroStep(
                    action = MacroAction.TYPE_TEXT,
                    selector = event.selector,
                    text = text.take(MacroLimits.MAX_TEXT_LENGTH),
                )
            }
            ObservedEventKind.SCROLLED_FORWARD ->
                MacroStep(action = MacroAction.SCROLL_FORWARD)
            ObservedEventKind.SCROLLED_BACK ->
                MacroStep(action = MacroAction.SCROLL_BACK)
        }
    }

    /**
     * Appends [step] to [steps], coalescing consecutive TYPE_TEXT steps
     * for the same field: Android fires a text-changed event per
     * keystroke, so without this a typed sentence would record as one
     * step per letter. The coalesced step keeps the latest (full) text.
     */
    fun appendStep(steps: List<MacroStep>, step: MacroStep): List<MacroStep> {
        val last = steps.lastOrNull()
        if (last != null &&
            last.action == MacroAction.TYPE_TEXT &&
            step.action == MacroAction.TYPE_TEXT &&
            last.selector == step.selector
        ) {
            return steps.dropLast(1) + step
        }
        return steps + step
    }
}
