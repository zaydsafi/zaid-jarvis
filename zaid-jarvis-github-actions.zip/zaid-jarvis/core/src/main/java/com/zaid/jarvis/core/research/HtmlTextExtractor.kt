package com.zaid.jarvis.core.research

/**
 * Turns raw HTML into readable text (Phase 7, `fetch_page`).
 *
 * Deliberately dependency-free: the project has no HTML parser in its
 * version catalog, and a full parser (Jsoup) would be a new dependency
 * for a narrow job. This is a small, tolerant extractor — scripts,
 * styles, navigation, headers, footers, and forms are dropped;
 * headings, paragraphs, list items, and line breaks become line breaks;
 * everything else is stripped to text and whitespace is collapsed.
 *
 * It is NOT a browser: pages that render their content with JavaScript
 * will come back thin or empty, and the caller says so honestly.
 */
object HtmlTextExtractor {

    /** Default cap for extracted page text (characters). */
    const val DEFAULT_MAX_CHARS: Int = 8000

    /** Extracts [PageContent] from [html] for [url]. */
    fun extract(url: String, html: String, maxChars: Int = DEFAULT_MAX_CHARS): PageContent {
        val title = extractTitle(html)
        var text = html

        // Drop whole blocks that are never readable content. (?s) makes
        // "." match newlines; (?i) makes the tag names case-insensitive.
        val blockTags = listOf("script", "style", "noscript", "nav", "header", "footer", "aside", "form", "svg")
        for (tag in blockTags) {
            text = text.replace(Regex("(?is)<$tag\\b[^>]*>.*?</$tag\\s*>"), " ")
        }

        // Structural tags become line breaks so paragraphs stay separate.
        text = text.replace(Regex("(?i)<(h[1-6]|p|li|div|tr|blockquote|section|article)\\b[^>]*>"), "\n")
        text = text.replace(Regex("(?i)<br\\s*/?>"), "\n")

        // Whatever tags remain are stripped to their text.
        text = text.replace(Regex("<[^>]+>"), " ")

        text = decodeHtmlEntities(text)

        // Collapse whitespace: trim each line, drop empties, re-join.
        text = text.lines()
            .map { it.trim().replace(Regex("\\s+"), " ") }
            .filter { it.isNotEmpty() }
            .joinToString("\n")

        val truncated = text.length > maxChars
        if (truncated) {
            text = text.take(maxChars)
        }
        return PageContent(url = url, title = title, text = text, truncated = truncated)
    }

    private fun extractTitle(html: String): String {
        val match = Regex("(?is)<title\\b[^>]*>(.*?)</title\\s*>").find(html)
            ?: return ""
        return decodeHtmlEntities(match.groupValues[1].replace(Regex("<[^>]+>"), " "))
            .replace(Regex("\\s+"), " ").trim()
    }

    /** Decodes the common named entities plus decimal/hex numeric ones. */
    fun decodeHtmlEntities(text: String): String {
        var result = text
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&apos;", "'")
        result = Regex("&#(\\d+);").replace(result) { match ->
            val code = match.groupValues[1].toIntOrNull()
            if (code != null && code in 1..0x10FFFF) {
                code.toChar().toString()
            } else {
                match.value
            }
        }
        result = Regex("&#[xX]([0-9a-fA-F]+);").replace(result) { match ->
            val code = match.groupValues[1].toIntOrNull(16)
            if (code != null && code in 1..0x10FFFF) {
                code.toChar().toString()
            } else {
                match.value
            }
        }
        return result
    }
}
