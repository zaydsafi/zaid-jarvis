package com.zaid.jarvis.core.social

import com.zaid.jarvis.core.confirmation.sha256Hex
import com.zaid.jarvis.core.util.JarvisResult

/**
 * Scheduler rules (Phase 8), pure Kotlin so they are unit-tested
 * without WorkManager or Room.
 *
 * A scheduled post must be in the future and at least
 * [MIN_SCHEDULE_AHEAD_MILLIS] ahead — the 5-minute floor gives Zaid
 * time to change his mind (and gives the approval card a real
 * purpose), and keeps WorkManager's one-time delay meaningful.
 */
object ScheduleValidation {

    /** Minimum time between scheduling and publishing (5 minutes). */
    const val MIN_SCHEDULE_AHEAD_MILLIS: Long = 5 * 60 * 1000L

    /**
     * Validates a scheduled time. Returns success when the time is at
     * least 5 minutes in the future, otherwise a plain-language failure.
     */
    fun validateScheduledTime(scheduledAtMillis: Long, nowMillis: Long): JarvisResult<Unit> {
        if (scheduledAtMillis <= nowMillis) {
            return JarvisResult.Failure("That time is in the past — pick a future time.")
        }
        if (scheduledAtMillis - nowMillis < MIN_SCHEDULE_AHEAD_MILLIS) {
            return JarvisResult.Failure(
                "Scheduled posts need at least 5 minutes' notice — " +
                    "pick a time 5 minutes or more from now.",
            )
        }
        return JarvisResult.Success(Unit)
    }

    /** Validates a delay in whole minutes (the planner-friendly form). */
    fun validateDelayMinutes(delayMinutes: Long, nowMillis: Long = System.currentTimeMillis()): JarvisResult<Long> {
        if (delayMinutes < 5) {
            return JarvisResult.Failure(
                "Scheduled posts need at least 5 minutes' notice — " +
                    "ask me to schedule it at least 5 minutes ahead.",
            )
        }
        val scheduledAt = nowMillis + delayMinutes * 60 * 1000L
        return when (val check = validateScheduledTime(scheduledAt, nowMillis)) {
            is JarvisResult.Success -> JarvisResult.Success(scheduledAt)
            is JarvisResult.Failure -> check
        }
    }

    /**
     * Content binding for scheduled posts: the SHA-256 of the draft
     * body at schedule time. The worker compares this with the current
     * body and cancels the post instead of publishing stale content.
     */
    fun draftContentHash(body: String): String = sha256Hex(body)
}
