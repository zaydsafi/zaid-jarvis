package com.zaid.jarvis.core.model

import com.zaid.jarvis.core.research.SearchBackend
import kotlinx.serialization.Serializable

/**
 * Everything the Settings screen edits, in one place.
 * Persisted by :data via DataStore (see SettingsRepository).
 * API keys are NOT part of this model — they live in EncryptedSharedPreferences
 * (see :data ApiKeyRepository) and are never held in plain app state longer
 * than needed for a single request.
 */
@Serializable
data class JarvisSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val language: AppLanguage = AppLanguage.ENGLISH,
    /** Text-to-speech speed multiplier, 0.5x–2.0x. */
    val voiceSpeed: Float = 1.0f,
    val personality: Personality = Personality.FRIENDLY,
    val llmProvider: LlmProvider = LlmProvider.CLAUDE,
    val llmModel: LlmModel = LlmModel.CLAUDE_SONNET_5_5,
    /**
     * Free-text model override for OpenRouter: when non-blank, the planner
     * uses this model ID instead of the selected preset (e.g.
     * "anthropic/claude-opus-4.5"). Ignored for other providers.
     */
    val customModelId: String = "",
    /** User-added OpenAI-compatible providers (Phase 3). */
    val customProviders: List<CustomProviderConfig> = emptyList(),
    /** Which custom provider is selected when [llmProvider] is CUSTOM. */
    val selectedCustomProviderId: String? = null,
    /** Use the provider's cheap model for simple intents (e.g. Haiku). */
    val useCheapModelForSimpleIntents: Boolean = true,
    /**
     * Tier 0 (read-only) asks once per session by default; when true, Zaid
     * is asked every time even for read-only actions (Master Prompt §6).
     */
    val alwaysAskReadOnly: Boolean = false,
    /**
     * Wake-word listening ("Hey Jarvis") via a foreground service.
     * Off by default: it holds the microphone and uses battery
     * (Master Prompt §5.2; see WakeWordService for the limits).
     */
    val wakeWordEnabled: Boolean = false,
    /** Speak Jarvis's answers aloud after a voice request. */
    val voiceRepliesEnabled: Boolean = true,
    /** Floating bubble overlay (needs "Display over other apps"). */
    val floatingBubbleEnabled: Boolean = false,
    /**
     * Screen automation (Phase 6): the Accessibility tools (find/tap/
     * type/scroll, macros) only run when this is on AND the
     * Accessibility service is enabled in system Settings. Off by
     * default — automation is never live by accident, and the toggle
     * in Settings stays greyed out until the service is enabled.
     */
    val automationEnabled: Boolean = false,
    /**
     * Web-search backend for `search_web` / `research_topic` (Phase 7).
     * DuckDuckGo is free and needs no key; Tavily needs a Tavily API
     * key (Settings → Research).
     */
    val searchBackend: SearchBackend = SearchBackend.DUCKDUCKGO,
    /** Max search results per query (1–10, clamped on write). */
    val maxSearchResults: Int = 5,
    /**
     * Daily digest (Phase 9): a WorkManager notification with the
     * morning briefing at [dailyDigestHour]:[dailyDigestMinute].
     * Off by default — proactive features never start uninvited.
     */
    val dailyDigestEnabled: Boolean = false,
    val dailyDigestHour: Int = 8,
    val dailyDigestMinute: Int = 0,
    /**
     * Quiet hours (Phase 9), minutes since midnight. Default 22:00–
     * 07:00. During quiet hours no proactive notification is posted
     * (except Phase 8 publish/schedule results and user-set task
     * reminders). Equal start/end disables quiet hours.
     */
    val quietHoursStartMinute: Int = 22 * 60,
    val quietHoursEndMinute: Int = 7 * 60,
    /**
     * Smart overdue reminders (Phase 9): one gentle nudge per task
     * per day when a task becomes overdue. On by default, but quiet
     * by design (dedupe + quiet hours) — and with a clear off switch.
     */
    val overdueRemindersEnabled: Boolean = true,
    /**
     * Break reminders (Phase 9): a nudge after
     * [breakReminderIntervalMinutes] of continuous screen time, at
     * most once per hour, never during quiet hours or a focus
     * session. Off by default; needs usage access (UsageStats).
     */
    val breakRemindersEnabled: Boolean = false,
    val breakReminderIntervalMinutes: Int = 60,
    /**
     * Sleep wind-down (Phase 9): a nudge at [windDownHour]:
     * [windDownMinute] suggesting DND + dimming the screen. Off by
     * default. The notification itself never changes a setting —
     * the action goes through the normal gated path in-app.
     */
    val windDownEnabled: Boolean = false,
    val windDownHour: Int = 23,
    val windDownMinute: Int = 0,
    /**
     * Usage insights (Phase 10): local, on-device analytics — tool
     * names, tiers, outcomes, publish results, focus-session duration
     * buckets. Nothing personal, nothing leaves the device. Default
     * ON because it is the user's own data on their own device;
     * turning it off stops recording entirely.
     */
    val analyticsEnabled: Boolean = true,
    /**
     * Automatic local backup (Phase 10): a weekly WorkManager job
     * writes the same export JSON as a manual backup to the app's
     * private files directory (never shared storage). Off by default;
     * at most 3 auto-backups are kept.
     */
    val autoBackupEnabled: Boolean = false,
    /** Placeholder counters until the agent reports real usage (Phase 3). */
    val totalTokensUsed: Long = 0L,
    val estimatedCostUsd: Double = 0.0,
) {
    /** Keeps model and provider consistent when the user switches provider. */
    fun withProvider(provider: LlmProvider): JarvisSettings {
        val model = if (llmModel.provider == provider) llmModel else LlmModel.defaultFor(provider)
        return copy(llmProvider = provider, llmModel = model)
    }

    /** Keeps provider and model consistent when the user picks a model. */
    fun withModel(model: LlmModel): JarvisSettings =
        copy(llmProvider = model.provider, llmModel = model)

    /** The custom provider currently selected, if any. */
    fun selectedCustomProvider(): CustomProviderConfig? =
        customProviders.firstOrNull { it.id == selectedCustomProviderId }

    /**
     * The model ID to send to the API for the current selection.
     * - CUSTOM → the selected custom provider's model ID.
     * - OPENROUTER with a free-text [customModelId] → that ID.
     * - Otherwise → the selected preset's API ID.
     * Returns "" when the selection is incomplete (e.g. CUSTOM with no
     * provider selected) — callers must refuse to call the API then.
     */
    fun resolvedModelApiId(): String = when (llmProvider) {
        LlmProvider.CUSTOM -> selectedCustomProvider()?.modelId ?: ""
        LlmProvider.OPENROUTER -> customModelId.ifBlank { llmModel.apiId }
        else -> llmModel.apiId
    }

    /** Cheap-tier model for the current provider, for simple intents. */
    fun cheapModelForCurrentProvider(): LlmModel? = LlmModel.cheapFor(llmProvider)
}
