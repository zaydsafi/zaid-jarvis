package com.zaid.jarvis.core.confirmation

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map

/** The recorded outcome of an approval request (Master Prompt §6). */
enum class AuditDecision(val displayName: String) {
    ALLOWED("Allowed"),
    AUTO_ALLOWED_SESSION("Auto-allowed (this session)"),
    AUTO_ALLOWED_TRUSTED("Auto-allowed (trusted action)"),
    DENIED("Denied"),
    EXPIRED("Expired"),
    CANCELLED("Cancelled"),
    EDITED("Edited — new request created"),
}

/**
 * One audit-log entry: time, tool, parameters, approval, result
 * (Master Prompt §6). Stored in the encrypted Room DB via [RoomAuditLog]
 * in :data; this is the pure-Kotlin model the engine and UI share.
 *
 * `paramsSummary` must never contain secrets — callers pass a short,
 * redacted summary (e.g. "to=+15550100, len=42"), never raw credentials.
 */
data class AuditEntry(
    val id: Long = 0,
    val timestampMillis: Long,
    val toolName: String,
    val tier: RiskTier,
    val action: String,
    val target: String,
    val paramsSummary: String,
    val decision: AuditDecision,
    val resultSummary: String? = null,
    /** Whether this action can in principle be undone (reversible tools). */
    val undoable: Boolean = false,
    /** Human-readable description of what undo would do. */
    val undoDescription: String? = null,
    /**
     * Machine-readable undo payload (Phase 5): a JSON string the tool
     * produced at execution time describing how to reverse this exact
     * action — e.g. the volume level or brightness value *before* the
     * change. Null when the action is not undoable. Never contains
     * secrets: it holds only previous device-state values.
     */
    val undoData: String? = null,
    /** Whether the undo has actually been performed. */
    val undone: Boolean = false,
)

/**
 * What a tool reports after a successful execution so the audit log can
 * offer a real undo (Phase 5). The tool knows the previous device state
 * only while it executes, so it hands this back with its result; the
 * Confirmation Engine stores it on the audit entry.
 */
data class UndoInfo(
    /** Human-readable description of what undo would do. */
    val description: String,
    /** JSON payload the tool's undo() needs to reverse the action. */
    val data: String,
)

/**
 * The audit log. The production implementation is Room-backed
 * (:data `RoomAuditLog`); [InMemoryAuditLog] is for tests and previews.
 */
interface AuditLog {
    suspend fun record(entry: AuditEntry): Long
    fun observeAll(): Flow<List<AuditEntry>>
    suspend fun search(query: String): List<AuditEntry>
    suspend fun get(id: Long): AuditEntry?
    suspend fun delete(id: Long)
    suspend fun clear()
    suspend fun markUndone(id: Long)
}

/** In-memory audit log for tests. Not used in production. */
class InMemoryAuditLog : AuditLog {
    private val entries = MutableStateFlow<List<AuditEntry>>(emptyList())
    private var nextId = 1L

    override suspend fun record(entry: AuditEntry): Long {
        val withId = entry.copy(id = nextId++)
        entries.value = entries.value + withId
        return withId.id
    }

    override fun observeAll(): Flow<List<AuditEntry>> =
        entries.map { it.sortedByDescending { entry -> entry.timestampMillis } }

    override suspend fun search(query: String): List<AuditEntry> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return entries.value.sortedByDescending { it.timestampMillis }
        return entries.value.filter {
            it.toolName.lowercase().contains(q) ||
                it.action.lowercase().contains(q) ||
                it.target.lowercase().contains(q) ||
                it.paramsSummary.lowercase().contains(q) ||
                it.decision.name.lowercase().contains(q)
        }.sortedByDescending { it.timestampMillis }
    }

    override suspend fun get(id: Long): AuditEntry? =
        entries.value.firstOrNull { it.id == id }

    override suspend fun delete(id: Long) {
        entries.value = entries.value.filterNot { it.id == id }
    }

    override suspend fun clear() {
        entries.value = emptyList()
    }

    override suspend fun markUndone(id: Long) {
        entries.value = entries.value.map {
            if (it.id == id) it.copy(undone = true) else it
        }
    }
}

/** Exports audit entries as CSV (for the Audit Log screen's share action). */
object AuditLogExporter {
    fun toCsv(entries: List<AuditEntry>): String {
        val header = "id,timestamp,tool,tier,action,target,params,decision,result,undoable,undone"
        val rows = entries.map { e ->
            listOf(
                e.id.toString(),
                e.timestampMillis.toString(),
                e.toolName,
                e.tier.name,
                e.action,
                e.target,
                e.paramsSummary,
                e.decision.name,
                e.resultSummary ?: "",
                e.undoable.toString(),
                e.undone.toString(),
            ).joinToString(",") { csvCell(it) }
        }
        return (listOf(header) + rows).joinToString("\n")
    }

    private fun csvCell(value: String): String {
        val escaped = value.replace("\"", "\"\"")
        return if (escaped.any { it == ',' || it == '"' || it == '\n' }) {
            "\"$escaped\""
        } else {
            escaped
        }
    }
}
