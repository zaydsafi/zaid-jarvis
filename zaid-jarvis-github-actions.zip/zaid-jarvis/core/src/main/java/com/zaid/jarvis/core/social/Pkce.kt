package com.zaid.jarvis.core.social

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

/**
 * OAuth 2.0 PKCE helpers (RFC 7636), pure Kotlin (Phase 8).
 *
 * Jarvis uses the Authorization Code flow with PKCE (S256) for every
 * platform: a random code verifier is generated, its SHA-256 challenge
 * goes to the authorization URL, and the verifier is presented when
 * exchanging the code — so a stolen authorization code alone is
 * useless. The verifier lives only in memory for the duration of one
 * connect flow and is never persisted.
 */
object Pkce {

    private val secureRandom = SecureRandom()

    /** Generates a random code verifier (43–128 chars, base64url). */
    fun generateCodeVerifier(lengthBytes: Int = 32): String {
        val bytes = ByteArray(lengthBytes)
        secureRandom.nextBytes(bytes)
        return base64UrlEncode(bytes)
    }

    /** Generates a random `state` value for CSRF protection on the redirect. */
    fun generateState(lengthBytes: Int = 16): String {
        val bytes = ByteArray(lengthBytes)
        secureRandom.nextBytes(bytes)
        return base64UrlEncode(bytes)
    }

    /**
     * S256 code challenge: `BASE64URL(SHA256(verifier))`, no padding.
     * Verified against the RFC 7636 Appendix B test vector in [PkceTest].
     */
    fun codeChallengeS256(verifier: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(verifier.toByteArray(Charsets.US_ASCII))
        return base64UrlEncode(hash)
    }

    /** Base64url encoding without padding (RFC 4648 §5). */
    fun base64UrlEncode(bytes: ByteArray): String =
        Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
}
