package com.zaid.jarvis.core.research

import kotlinx.serialization.Serializable

/**
 * Content drafts (Phase 7: the "draft" half of the publishing gate).
 *
 * Flow: `draft_post` (or the Drafts screen) creates a DRAFT → Zaid
 * edits it in the Draft editor → Zaid taps "Approve for publishing"
 * → APPROVED → Phase 8 publishes APPROVED drafts and marks them
 * PUBLISHED. Nothing in Phase 7 can set PUBLISHED — [DraftRepository]
 * refuses it — so a draft can never claim to be published when it
 * isn't.
 */

/** Draft lifecycle. PUBLISHED is only reachable from Phase 8. */
@Serializable
enum class DraftStatus {
    DRAFT,
    APPROVED,
    PUBLISHED,
}

/**
 * Platform presets with their character limits. The platform is stored
 * as free text on the draft (Zaid can type any platform); these
 * presets are what [DraftLimits] enforces, and [fromName] resolves a
 * name to a preset (case-insensitive, "X" and "Twitter" both match).
 */
enum class PlatformPreset(
    val displayName: String,
    /** Maximum characters for a single post on this platform. */
    val charLimit: Int,
) {
    X("X / Twitter", 280),
    THREADS("Threads", 500),
    INSTAGRAM("Instagram", 2200),
    LINKEDIN("LinkedIn", 3000),
    BLOG("Blog", 10000),
    OTHER("Other", 2000);

    companion object {
        fun fromName(name: String?): PlatformPreset {
            val normalized = name?.trim()?.lowercase() ?: ""
            return when (normalized) {
                "x", "twitter", "x / twitter" -> X
                "threads" -> THREADS
                "instagram", "ig" -> INSTAGRAM
                "linkedin" -> LINKEDIN
                "blog", "blog post", "article" -> BLOG
                else -> OTHER
            }
        }
    }
}

/** One draft post, stored in the encrypted Room DB. */
@Serializable
data class ContentDraft(
    val id: Long = 0,
    val title: String,
    val body: String,
    /** Platform hint: a preset name or free text ("X", "Instagram", …). */
    val platform: String,
    val status: DraftStatus = DraftStatus.DRAFT,
    /** Research this draft was based on, if any. */
    val researchId: Long? = null,
    /**
     * SHA-256 of the body at approve time (Phase 8 content binding).
     * The publish path refuses an APPROVED draft whose body no longer
     * matches this hash — an edited draft must be re-approved. Null
     * for drafts approved before Phase 8 (no binding was recorded).
     */
    val approvedBodyHash: String? = null,
    val createdAtMillis: Long = 0L,
    val updatedAtMillis: Long = 0L,
) {
    /** True when this draft was edited after it was approved (Phase 8). */
    fun editedSinceApproval(): Boolean =
        status == DraftStatus.APPROVED &&
            approvedBodyHash != null &&
            com.zaid.jarvis.core.confirmation.sha256Hex(body) != approvedBodyHash
}
