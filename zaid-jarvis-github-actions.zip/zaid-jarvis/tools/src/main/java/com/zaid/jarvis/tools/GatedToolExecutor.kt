package com.zaid.jarvis.tools

import com.zaid.jarvis.core.analytics.AnalyticsEvents
import com.zaid.jarvis.core.analytics.AnalyticsSink
import com.zaid.jarvis.core.analytics.NoOpAnalyticsSink
import com.zaid.jarvis.core.confirmation.AuditEntry
import com.zaid.jarvis.core.confirmation.ConfirmationEngine
import com.zaid.jarvis.core.confirmation.ExecutionOutcome
import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.core.confirmation.UndoInfo
import com.zaid.jarvis.core.util.JarvisResult
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject

/**
 * The single entry point for running tools (Master Prompt §2.1, §6).
 * Every tool call passes through the Confirmation Engine here — the
 * agent (Phase 3), macros (Phase 6), and plugins (Phase 10) must all
 * use this executor and never call [JarvisTool.execute] directly.
 *
 * Flow: resolve the tool → preview it with [JarvisTool.dryRun] (that
 * preview is the exact content shown on the approval card) → gate on
 * the tool's risk tier → execute only with the approved content.
 *
 * Content binding (Phase 5): if Zaid edits the preview on the approval
 * card, the engine hands the *edited* content to the block. Tools whose
 * payload is the content itself (an SMS body, an email) re-derive their
 * parameters from the edited text via
 * [JarvisTool.paramsFromEditedContent] — so the action runs with what
 * Zaid actually approved, never with the original parameters. A tool
 * that cannot parse edited content refuses to run rather than running
 * something Zaid did not approve.
 *
 * Undo (Phase 5): [executeUndo] reverses a completed action from its
 * audit entry. Undo is itself a gated action — a Tier 1 undo shows its
 * own approval card — and the audit entry is only marked undone by the
 * caller, after this returns success.
 *
 * Analytics (Phase 10): every [execute] call records one local,
 * on-device event (tool name + tier + outcome — no parameters, no
 * content) through [AnalyticsSink]. Recording is best-effort and never
 * throws into the caller; when insights are off, nothing is recorded.
 */
@Singleton
class GatedToolExecutor @Inject constructor(
    private val registry: ToolRegistry,
    private val engine: ConfirmationEngine,
    private val analyticsSink: AnalyticsSink = NoOpAnalyticsSink,
) {
    suspend fun execute(
        toolName: String,
        params: JsonObject,
        alwaysAskReadOnly: Boolean = false,
    ): JarvisResult<String> {
        val tool = registry.get(toolName)
            ?: return JarvisResult.Failure("Unknown tool: $toolName")

        // Schema check first: a malformed call never reaches Zaid's card.
        val schemaErrors = ToolSchema.validateParams(params, tool.inputSchema)
        if (schemaErrors.isNotEmpty()) {
            return JarvisResult.Failure(
                "Invalid parameters for $toolName: ${schemaErrors.joinToString("; ")}",
            )
        }

        val preview = runCatching { tool.dryRun(params) }
            .getOrElse { return JarvisResult.Failure("Could not preview $toolName: ${it.message}") }

        // The tier may depend on the parameters (Phase 6: run_macro).
        val tier = runCatching { tool.tierFor(params) }
            .getOrElse { return JarvisResult.Failure("Could not determine the risk tier of $toolName: ${it.message}") }

        val dataUsed = buildString {
            append("Parameters: ${params.keys.joinToString(", ").ifEmpty { "none" }}")
            if (tool.requiredPermissions.isNotEmpty()) {
                append("; Android permissions: ${tool.requiredPermissions.joinToString(", ")}")
            }
        }

        // Captured by the block so the engine can audit the undo data
        // and the parameters that actually ran (which may differ from
        // the originals when Zaid edited the preview).
        var capturedOutcome: ToolOutcome? = null
        var effectiveParams: JsonObject = params

        return when (
            val outcome = engine.execute(
                toolName = tool.name,
                tier = tier,
                action = tool.description,
                target = tool.name,
                dataUsed = dataUsed,
                exactContent = preview,
                paramsJson = params.toString(),
                alwaysAskReadOnly = alwaysAskReadOnly,
                undoInfoProvider = {
                    capturedOutcome?.let { outcome ->
                        outcome.undoData?.let { data ->
                            UndoInfo(
                                description = outcome.undoDescription ?: "Reverse this action.",
                                data = data,
                            )
                        }
                    }
                },
                paramsJsonProvider = { effectiveParams.toString() },
            ) { approvedContent ->
                // Content binding: run with what Zaid approved.
                when (val resolved = resolveRunParams(tool, preview, approvedContent, params)) {
                    is JarvisResult.Failure -> resolved
                    is JarvisResult.Success -> {
                        effectiveParams = resolved.value
                        when (val result = tool.execute(resolved.value)) {
                            is JarvisResult.Success -> {
                                capturedOutcome = result.value
                                JarvisResult.Success(result.value.message)
                            }
                            is JarvisResult.Failure -> result
                        }
                    }
                }
            }
        ) {
            is ExecutionOutcome.Executed -> outcome.result.also {
                recordExecution(tool.name, tier, it is JarvisResult.Success)
            }
            ExecutionOutcome.Denied -> JarvisResult.Failure("Denied by Zaid").also {
                recordOutcome(tool.name, tier, AnalyticsEvents.OUTCOME_DENIED)
            }
            ExecutionOutcome.Expired -> JarvisResult.Failure("Approval expired — please try again").also {
                recordOutcome(tool.name, tier, AnalyticsEvents.OUTCOME_EXPIRED)
            }
            ExecutionOutcome.Cancelled -> JarvisResult.Failure("Cancelled by kill switch").also {
                recordOutcome(tool.name, tier, AnalyticsEvents.OUTCOME_CANCELLED)
            }
            ExecutionOutcome.BiometricFailed ->
                JarvisResult.Failure("Biometric authentication failed — action not performed").also {
                    recordOutcome(tool.name, tier, AnalyticsEvents.OUTCOME_BIOMETRIC_FAILED)
                }
        }
    }

    /** One analytics event per execution (tool name + tier + outcome only). Never throws. */
    private suspend fun recordExecution(toolName: String, tier: RiskTier, success: Boolean) {
        recordOutcome(
            toolName,
            tier,
            if (success) AnalyticsEvents.OUTCOME_SUCCESS else AnalyticsEvents.OUTCOME_FAILURE,
        )
    }

    private suspend fun recordOutcome(toolName: String, tier: RiskTier, outcome: String) {
        runCatching { analyticsSink.recordToolExecution(toolName, tier, outcome) }
    }

    /**
     * Works out which parameters to run with: the originals when Zaid
     * approved the preview unchanged, or the parameters re-derived from
     * his edited text. A tool that cannot parse edited content fails
     * here — Jarvis never runs content Zaid did not approve.
     */
    private fun resolveRunParams(
        tool: JarvisTool,
        preview: String,
        approvedContent: String,
        originalParams: JsonObject,
    ): JarvisResult<JsonObject> {
        if (approvedContent == preview) return JarvisResult.Success(originalParams)
        val edited = tool.paramsFromEditedContent(approvedContent, originalParams)
            ?: return JarvisResult.Failure(
                "You edited the preview, but “${tool.name}” can't run edited " +
                    "content — please cancel and ask again in different words.",
            )
        return JarvisResult.Success(edited)
    }

    /**
     * Undoes a completed action recorded in [entry]. The undo runs
     * through the same Confirmation Engine as any other action, at the
     * tool's own tier — a Tier 1 undo shows its own approval card with
     * a preview of what undoing will do.
     *
     * The entry's `paramsSummary` holds the original parameters as JSON
     * (the engine stores the full params for tool calls; our tools'
     * parameters are far under its 500-character cap), and `undoData`
     * holds the previous device state the tool captured at execution.
     */
    suspend fun executeUndo(entry: AuditEntry): JarvisResult<String> {
        if (!entry.undoable) {
            return JarvisResult.Failure("This action cannot be undone.")
        }
        if (entry.undone) {
            return JarvisResult.Failure("This action was already undone.")
        }
        val tool = registry.get(entry.toolName)
            ?: return JarvisResult.Failure("The tool “${entry.toolName}” is no longer available.")
        if (!tool.supportsUndo) {
            return JarvisResult.Failure("“${entry.toolName}” does not support undo.")
        }
        val params = runCatching {
            Json.parseToJsonElement(entry.paramsSummary).jsonObject
        }.getOrElse { JsonObject(emptyMap()) }

        val preview = runCatching { tool.undoPreview(params, entry.undoData) }
            .getOrElse { return JarvisResult.Failure("Could not preview the undo: ${it.message}") }

        return when (
            val outcome = engine.execute(
                toolName = tool.name,
                tier = tool.riskTier,
                action = "Undo: ${tool.description}",
                target = tool.name,
                dataUsed = "Undo of audit entry #${entry.id} (${entry.toolName})",
                exactContent = preview,
                paramsJson = entry.paramsSummary,
            ) { _ /* approvedContent: undo previews are not editable */ ->
                when (val result = tool.undo(params, entry.undoData)) {
                    is JarvisResult.Success -> JarvisResult.Success(result.value.message)
                    is JarvisResult.Failure -> result
                }
            }
        ) {
            is ExecutionOutcome.Executed -> outcome.result
            ExecutionOutcome.Denied -> JarvisResult.Failure("Undo denied by Zaid")
            ExecutionOutcome.Expired -> JarvisResult.Failure("Undo approval expired — please try again")
            ExecutionOutcome.Cancelled -> JarvisResult.Failure("Undo cancelled by kill switch")
            ExecutionOutcome.BiometricFailed ->
                JarvisResult.Failure("Biometric authentication failed — undo not performed")
        }
    }
}
