package com.zaid.jarvis.tools.research

import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.core.research.PlatformPreset
import com.zaid.jarvis.core.research.ResearchEvent
import com.zaid.jarvis.core.research.UrlSafety
import com.zaid.jarvis.core.research.formatBrief
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.JarvisTool
import com.zaid.jarvis.tools.ToolOutcome
import com.zaid.jarvis.tools.ToolSchema
import com.zaid.jarvis.tools.intParamOr
import com.zaid.jarvis.tools.optStringParam
import com.zaid.jarvis.tools.stringParam
import kotlinx.serialization.json.JsonObject

// ─────────────────────────────────────────────────────────────────────────────
// Research & content tools (Phase 7).
//
// search_web / fetch_page / research_topic are Tier 0 (read-only): they
// read the public web and write only to Zaid's own encrypted database.
// draft_post is Tier 1: it creates a local draft (reversible — deletable),
// and NOTHING is published — the draft waits in the Drafts screen for
// Zaid to edit and approve it. Publishing is Phase 8.
//
// Flow note for draft_post: the approval card shows the topic, platform,
// and tone — NOT the generated text, because the text doesn't exist yet
// (the LLM writes it after approval). The generated draft is then shown
// in the Drafts screen, where Zaid reviews, edits, and approves it.
// ─────────────────────────────────────────────────────────────────────────────

/** Web search. Results are untrusted data — the planner's InjectionGuard scans them. */
class SearchWebTool(
    private val webSearch: WebSearch,
    private val defaultMaxResults: Int = 5,
) : JarvisTool {
    override val name: String = "search_web"
    override val description: String = "Search the web and show the top results (title, link, snippet)."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("query", "string", "What to search for."),
        ToolSchema.ParamSpec(
            name = "max_results",
            type = "integer",
            description = "How many results to return (1–10, default 5).",
            required = false,
        ),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val query = params.stringParam("query") ?: "?"
        val maxResults = params.intParamOr("max_results", defaultMaxResults).coerceIn(1, 10)
        return "Search the web for “$query” (up to $maxResults results)."
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val query = params.stringParam("query")
            ?: return JarvisResult.Failure("search_web needs a 'query' parameter.")
        if (query.isBlank()) {
            return JarvisResult.Failure("search_web needs a non-empty 'query'.")
        }
        val maxResults = params.intParamOr("max_results", defaultMaxResults).coerceIn(1, 10)
        return when (val result = webSearch.search(query.trim(), maxResults)) {
            is JarvisResult.Success -> {
                val results = result.value
                if (results.isEmpty()) {
                    JarvisResult.Success(ToolOutcome("No web results for “${query.trim()}”."))
                } else {
                    val lines = results.mapIndexed { index, item ->
                        "[${index + 1}] ${item.title} (${item.domain})\n    ${item.url}\n    ${item.snippet}"
                    }.joinToString("\n")
                    JarvisResult.Success(
                        ToolOutcome("Web results for “${query.trim()}”:\n$lines"),
                    )
                }
            }
            is JarvisResult.Failure -> result
        }
    }
}

/**
 * Fetches one page and returns its readable text (truncated).
 * The URL is validated here AND in the fetcher (defense in depth):
 * http(s) only, no localhost, no private IPs.
 */
class FetchPageTool(private val pageFetcher: PageFetcher) : JarvisTool {
    override val name: String = "fetch_page"
    override val description: String = "Fetch a web page and read its text (truncated to a summary)."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject =
        ToolSchema.singleStringParam("url", "The http(s) URL of the page to read.")

    override suspend fun dryRun(params: JsonObject): String {
        val url = params.stringParam("url") ?: "?"
        return "Fetch and read the page at $url."
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val url = params.stringParam("url")
            ?: return JarvisResult.Failure("fetch_page needs a 'url' parameter.")
        when (val valid = UrlSafety.validateUrl(url)) {
            is JarvisResult.Failure -> return valid
            is JarvisResult.Success -> { /* safe — fetch it */ }
        }
        return when (val result = pageFetcher.fetch(url.trim())) {
            is JarvisResult.Success -> {
                val page = result.value
                if (page.text.isBlank()) {
                    JarvisResult.Success(
                        ToolOutcome(
                            "Fetched ${page.url} but found no readable text " +
                                "(the page may render its content with JavaScript).",
                        ),
                    )
                } else {
                    val note = if (page.truncated) " (truncated — the page is longer)" else ""
                    val heading = if (page.title.isNotBlank()) "“${page.title}” — " else ""
                    JarvisResult.Success(
                        ToolOutcome("Page $heading${page.url}$note:\n${page.text}"),
                    )
                }
            }
            is JarvisResult.Failure -> result
        }
    }
}

/** Full research pipeline: search → fetch top pages → synthesize a sourced brief. */
class ResearchTopicTool(private val researchRunner: ResearchRunner) : JarvisTool {
    override val name: String = "research_topic"
    override val description: String =
        "Research a topic: search the web, read the top pages, and write a structured brief with sources."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject =
        ToolSchema.singleStringParam("topic", "The topic to research.")

    override suspend fun dryRun(params: JsonObject): String {
        val topic = params.stringParam("topic") ?: "?"
        return "Research “$topic”: search the web, read the top pages, and write a sourced brief."
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val topic = params.stringParam("topic")
            ?: return JarvisResult.Failure("research_topic needs a 'topic' parameter.")
        if (topic.isBlank()) {
            return JarvisResult.Failure("research_topic needs a non-empty 'topic'.")
        }
        var failure: String? = null
        var briefText: String? = null
        researchRunner.research(topic.trim()).collect { event ->
            when (event) {
                is ResearchEvent.Done -> briefText = formatBrief(event.brief)
                is ResearchEvent.Failed -> failure = event.message
                else -> { /* progress only — the chat UI shows it via the ViewModel path */ }
            }
        }
        return when {
            briefText != null -> JarvisResult.Success(ToolOutcome(briefText))
            failure != null -> JarvisResult.Failure(failure)
            else -> JarvisResult.Failure("Research for “${topic.trim()}” ended without a result.")
        }
    }
}

/**
 * Drafts a post with the LLM and saves it as a DRAFT. The approval card
 * shows topic + platform + tone — the generated text comes after
 * approval and is reviewed in the Drafts screen, where Zaid edits it
 * and approves it for publishing. Nothing is published here (Phase 8).
 */
class DraftPostTool(private val draftGenerator: DraftGenerator) : JarvisTool {
    override val name: String = "draft_post"
    override val description: String =
        "Write a draft post about a topic for a platform (X, Instagram, LinkedIn, blog). " +
            "The draft is saved for review — nothing is published."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("topic", "string", "What the post is about."),
        ToolSchema.ParamSpec(
            name = "platform",
            type = "string",
            description = "Where the post is for: X, Threads, Instagram, LinkedIn, Blog, or Other.",
            enumValues = PlatformPreset.entries.map { it.displayName },
        ),
        ToolSchema.ParamSpec(
            name = "tone",
            type = "string",
            description = "Speaking style (e.g. Friendly, Formal, Concise).",
            required = false,
        ),
        ToolSchema.ParamSpec(
            name = "context",
            type = "string",
            description = "Optional extra context (e.g. a research brief) to base the draft on.",
            required = false,
        ),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val topic = params.stringParam("topic") ?: "?"
        val platform = params.optStringParam("platform") ?: "Other"
        val tone = params.optStringParam("tone")
        val hasContext = params.optStringParam("context") != null
        return buildString {
            append("Draft a $platform post about “$topic”")
            if (tone != null) append(" (tone: $tone)")
            if (hasContext) append(" (using the research provided)")
            append(". The draft will be saved for review in Drafts — nothing is published.")
        }
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val topic = params.stringParam("topic")
            ?: return JarvisResult.Failure("draft_post needs a 'topic' parameter.")
        if (topic.isBlank()) {
            return JarvisResult.Failure("draft_post needs a non-empty 'topic'.")
        }
        val platform = params.optStringParam("platform") ?: "Other"
        val tone = params.optStringParam("tone") ?: "Friendly"
        val request = DraftRequest(
            topic = topic.trim(),
            platform = platform,
            tone = tone,
            context = params.optStringParam("context"),
        )
        return when (val result = draftGenerator.generate(request)) {
            is JarvisResult.Success -> {
                val generated = result.value
                val draft = generated.draft
                val message = buildString {
                    append("Draft saved for ${draft.platform}: “${draft.title}” ")
                    append("(${draft.body.length}/${generated.charLimit} characters).")
                    if (generated.truncated) {
                        append(" The text was longer than the ${generated.charLimit}-character " +
                            "limit and was truncated — please review it in Drafts.")
                    }
                    append(" Open Drafts to review, edit, and approve it for publishing.")
                }
                JarvisResult.Success(ToolOutcome(message))
            }
            is JarvisResult.Failure -> result
        }
    }
}
