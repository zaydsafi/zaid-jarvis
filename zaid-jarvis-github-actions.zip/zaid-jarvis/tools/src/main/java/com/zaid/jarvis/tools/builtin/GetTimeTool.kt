package com.zaid.jarvis.tools.builtin

import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.JarvisTool
import com.zaid.jarvis.tools.ToolOutcome
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.serialization.json.JsonObject

/**
 * Returns the current date and time (Tier 0, read-only, no permissions).
 * Time is injected so tests are deterministic.
 */
class GetTimeTool(
    private val clock: () -> Long = System::currentTimeMillis,
    private val zoneId: ZoneId = ZoneId.systemDefault(),
) : JarvisTool {
    override val name: String = "get_time"
    override val description: String = "Get the current date and time on this device."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> = emptyList()

    override suspend fun dryRun(params: JsonObject): String =
        "Read the current date and time."

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val formatted = DateTimeFormatter
            .ofPattern("EEEE, d MMMM yyyy, HH:mm:ss", Locale.ENGLISH)
            .withZone(zoneId)
            .format(Instant.ofEpochMilli(clock()))
        return JarvisResult.Success(ToolOutcome("Current date and time: $formatted"))
    }
}
