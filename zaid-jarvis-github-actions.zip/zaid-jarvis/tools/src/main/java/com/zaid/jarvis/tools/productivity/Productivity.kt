package com.zaid.jarvis.tools.productivity

import com.zaid.jarvis.core.productivity.CalendarEvent
import com.zaid.jarvis.core.productivity.FocusSession
import com.zaid.jarvis.core.productivity.ScreenTimeSummary
import com.zaid.jarvis.core.productivity.Task
import com.zaid.jarvis.core.util.JarvisResult

// ─────────────────────────────────────────────────────────────────────────────
// Productivity seams (Phase 9).
//
// :tools stays pure Kotlin, so everything that touches the database,
// the device calendar, UsageStats, or WorkManager lives behind these
// interfaces — the same pattern as PhoneDevice (Phase 5) and the
// social seams (Phase 8). Real implementations live in :data (task /
// focus-session storage), :agent (the briefing) and :app (calendar,
// screen time, WorkManager scheduling, focus sessions).
// The NoOp implementations fail with a plain-language message instead
// of silently doing nothing.
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Task storage. Implemented in :app (RoomTaskStore, adapting
 * :data's TaskRepository).
 */
interface TaskStore {
    suspend fun create(task: Task): JarvisResult<Long>
    suspend fun getById(id: Long): Task?
    suspend fun listAll(): List<Task>
    suspend fun update(task: Task): JarvisResult<Unit>
    suspend fun complete(id: Long): JarvisResult<Task>
    suspend fun delete(id: Long): JarvisResult<Unit>
    suspend fun setReminder(id: Long, reminderAtMillis: Long, workId: String?): JarvisResult<Task>
    suspend fun clearReminder(id: Long): JarvisResult<Unit>
    suspend fun markOverdueNotified(id: Long, epochDay: Long)
}

/** No-op task store: every call fails plainly. */
class NoOpTaskStore : TaskStore {
    private fun <T> unavailable(): JarvisResult<T> =
        JarvisResult.Failure("Tasks are not available in this build.")

    override suspend fun create(task: Task): JarvisResult<Long> = unavailable()
    override suspend fun getById(id: Long): Task? = null
    override suspend fun listAll(): List<Task> = emptyList()
    override suspend fun update(task: Task): JarvisResult<Unit> = unavailable()
    override suspend fun complete(id: Long): JarvisResult<Task> = unavailable()
    override suspend fun delete(id: Long): JarvisResult<Unit> = unavailable()
    override suspend fun setReminder(
        id: Long,
        reminderAtMillis: Long,
        workId: String?,
    ): JarvisResult<Task> = unavailable()

    override suspend fun clearReminder(id: Long): JarvisResult<Unit> = unavailable()
    override suspend fun markOverdueNotified(id: Long, epochDay: Long) = Unit
}

/**
 * Schedules task reminders via WorkManager. Implemented in :app
 * (WorkManagerReminderScheduler). The scheduler stores the reminder
 * time on the task and enqueues the one-time worker; the worker
 * itself only notifies — it never changes a task.
 */
interface ReminderScheduler {
    /** Schedules a reminder for [reminderAtMillis] (must be in the future). */
    suspend fun schedule(taskId: Long, reminderAtMillis: Long): JarvisResult<Task>

    /** Cancels a task's reminder (also cancels its WorkManager job). */
    suspend fun cancel(taskId: Long): JarvisResult<Unit>
}

/** No-op reminder scheduler: scheduling fails plainly. */
class NoOpReminderScheduler : ReminderScheduler {
    override suspend fun schedule(taskId: Long, reminderAtMillis: Long): JarvisResult<Task> =
        JarvisResult.Failure("Reminders are not available in this build.")

    override suspend fun cancel(taskId: Long): JarvisResult<Unit> =
        JarvisResult.Failure("Reminders are not available in this build.")
}

/**
 * Read-only device calendar access (CalendarContract). Implemented in
 * :app (CalendarContractReader). No event creation in Phase 9.
 */
interface CalendarReader {
    /** Whether the app currently holds READ_CALENDAR. */
    fun hasCalendarAccess(): Boolean

    /** Events overlapping [startMillis, endMillis), earliest first. */
    suspend fun eventsBetween(startMillis: Long, endMillis: Long): JarvisResult<List<CalendarEvent>>
}

/** No-op calendar reader: no access, every read fails plainly. */
class NoOpCalendarReader : CalendarReader {
    override fun hasCalendarAccess(): Boolean = false

    override suspend fun eventsBetween(
        startMillis: Long,
        endMillis: Long,
    ): JarvisResult<List<CalendarEvent>> =
        JarvisResult.Failure(
            "Jarvis can't see your calendar. Grant calendar access in " +
                "Settings → App permissions.",
        )
}

/**
 * On-device screen-time data (UsageStats). Implemented in :app
 * (UsageStatsScreenTimeReader). Data stays on-device; nothing is
 * uploaded anywhere.
 */
interface ScreenTimeReader {
    /** Whether the user granted usage access in system Settings. */
    fun hasUsageAccess(): Boolean

    /** Today's total screen time + top 5 apps. */
    suspend fun todaySummary(): JarvisResult<ScreenTimeSummary>

    /** Length of the current continuous screen session (break reminders). */
    suspend fun currentContinuousMillis(nowMillis: Long): JarvisResult<Long>
}

/** No-op screen-time reader: no access, every read fails plainly. */
class NoOpScreenTimeReader : ScreenTimeReader {
    override fun hasUsageAccess(): Boolean = false

    override suspend fun todaySummary(): JarvisResult<ScreenTimeSummary> =
        JarvisResult.Failure(
            "Screen time needs usage access. Grant it in " +
                "Settings → Productivity & wellness → Usage access.",
        )

    override suspend fun currentContinuousMillis(nowMillis: Long): JarvisResult<Long> =
        JarvisResult.Failure("Screen time needs usage access.")
}

/**
 * Focus sessions (Phase 9): timed Do Not Disturb sessions.
 * Implemented in :app (FocusSessionManagerImpl). Starting a session
 * sets DND to Alarms only and restores the previous mode when the
 * session ends (on time or stopped early). Ending is idempotent —
 * the foreground service and the WorkManager end worker can both try
 * to end the same session, and only the first one restores DND.
 */
interface FocusSessionManager {
    /** The currently running session, if any. */
    suspend fun currentSession(): FocusSession?

    /** Starts a session of [durationMinutes] (5–240). Fails when one is already running. */
    suspend fun start(durationMinutes: Int): JarvisResult<FocusSession>

    /** Stops the running session early (DND restored). Null when none is running. */
    suspend fun stop(): JarvisResult<FocusSession?>

    /**
     * Ends a session on time (timer ran out). Idempotent: returns
     * success whether or not this call was the one that ended it.
     */
    suspend fun endSession(sessionId: Long): JarvisResult<Unit>

    /** Recent sessions, newest first. */
    suspend fun history(limit: Int = 20): List<FocusSession>
}

/** No-op focus manager: focus sessions fail plainly. */
class NoOpFocusSessionManager : FocusSessionManager {
    override suspend fun currentSession(): FocusSession? = null

    override suspend fun start(durationMinutes: Int): JarvisResult<FocusSession> =
        JarvisResult.Failure("Focus sessions are not available in this build.")

    override suspend fun stop(): JarvisResult<FocusSession?> =
        JarvisResult.Failure("Focus sessions are not available in this build.")

    override suspend fun endSession(sessionId: Long): JarvisResult<Unit> =
        JarvisResult.Failure("Focus sessions are not available in this build.")

    override suspend fun history(limit: Int): List<FocusSession> = emptyList()
}

/**
 * The morning briefing: today's calendar events + tasks due today +
 * overdue tasks, as text. Implemented in :agent (BriefingService):
 * LLM-polished when an LLM is configured and reachable, plain
 * templated summary otherwise — the briefing never fails just
 * because the LLM is unavailable.
 */
interface BriefingProvider {
    suspend fun briefing(): JarvisResult<String>
}

/** No-op briefing provider: fails plainly. */
class NoOpBriefingProvider : BriefingProvider {
    override suspend fun briefing(): JarvisResult<String> =
        JarvisResult.Failure("The morning briefing is not available in this build.")
}
