package com.zaid.jarvis.tools

import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive

/**
 * Small helpers for reading typed tool parameters (Phase 5).
 *
 * The schema validator ([ToolSchema.validateParams]) already checked
 * required fields and primitive types before a tool runs, so these
 * helpers only need to handle the "parameter missing / wrong shape"
 * cases defensively — a tool must never crash on bad input.
 */

/** Required string parameter, or null when missing or not a string. */
fun JsonObject.stringParam(name: String): String? =
    this[name]?.let { runCatching { it.jsonPrimitive.contentOrNull }.getOrNull() }

/** Optional string parameter: null when missing, blank, or not a string. */
fun JsonObject.optStringParam(name: String): String? =
    stringParam(name)?.takeIf { it.isNotBlank() }

/** Required integer parameter, or null when missing or not an integer. */
fun JsonObject.intParam(name: String): Int? =
    this[name]?.let {
        runCatching {
            val primitive = it.jsonPrimitive
            if (primitive.isString) null else primitive.content.toInt()
        }.getOrNull()
    }

/** Required boolean parameter, or null when missing or not a boolean. */
fun JsonObject.boolParam(name: String): Boolean? =
    this[name]?.let {
        runCatching {
            val primitive = it as? JsonPrimitive ?: return@runCatching null
            if (primitive.isString) null else primitive.content.toBooleanStrict()
        }.getOrNull()
    }

/** Integer parameter with a default when missing. */
fun JsonObject.intParamOr(name: String, default: Int): Int = intParam(name) ?: default
