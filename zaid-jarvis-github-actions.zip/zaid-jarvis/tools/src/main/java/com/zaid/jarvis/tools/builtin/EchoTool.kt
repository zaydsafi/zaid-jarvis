package com.zaid.jarvis.tools.builtin

import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.JarvisTool
import com.zaid.jarvis.tools.ToolOutcome
import com.zaid.jarvis.tools.ToolSchema
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * Echoes its input back unchanged (Tier 0, read-only, no permissions,
 * works offline). A demo tool for proving the plan → confirm → execute
 * loop end to end, and for tests that need a tool with a parameter.
 * It does nothing else by design.
 */
class EchoTool : JarvisTool {
    override val name: String = "echo"
    override val description: String = "Repeat a short message back (demo tool — does nothing else)."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject =
        ToolSchema.singleStringParam("message", "The message to repeat back.")

    override suspend fun dryRun(params: JsonObject): String {
        val message = params["message"]?.jsonPrimitive?.content ?: "?"
        return "Repeat back: \"$message\""
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val message = params["message"]?.jsonPrimitive?.content
            ?: return JarvisResult.Failure("echo needs a 'message' parameter")
        return JarvisResult.Success(ToolOutcome(message))
    }
}
