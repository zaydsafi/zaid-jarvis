package com.zaid.jarvis.tools.phone

import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.JarvisTool
import com.zaid.jarvis.tools.ToolOutcome
import com.zaid.jarvis.tools.ToolSchema
import com.zaid.jarvis.tools.optStringParam
import com.zaid.jarvis.tools.stringParam
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

// ─────────────────────────────────────────────────────────────────────────────
// Tier 2 phone tools (Phase 5): external / visible. Approval card with the
// full preview, plus a second confirmation.
//
// SAFETY (Master Prompt §6): these tools NEVER perform the external action
// themselves. They only build a SystemAction that opens the system app
// (dialer, messaging, email, share sheet) with everything pre-filled —
// Zaid takes the final step there (taps Call / Send). That is why the app
// deliberately does NOT declare CALL_PHONE or SEND_SMS.
// ─────────────────────────────────────────────────────────────────────────────

/** A resolved recipient: the number to use + a display name for previews. */
private data class Recipient(val number: String, val displayName: String)

/**
 * Resolves the recipient of a call/SMS from the tool parameters.
 * Either a direct [number] or a [contact] name. A name is looked up in
 * the contacts; ambiguous names return the candidate list so the
 * planner can ask Zaid — Jarvis never guesses which "John" to call.
 */
private suspend fun resolveRecipient(
    device: PhoneDevice,
    params: JsonObject,
): JarvisResult<Recipient> {
    val directNumber = params.optStringParam("number")
    if (directNumber != null) {
        return JarvisResult.Success(Recipient(directNumber, directNumber))
    }
    val contactName = params.optStringParam("contact")
        ?: return JarvisResult.Failure("Provide a 'contact' name or a 'number'.")
    if (ContactResolver.isPhoneNumber(contactName)) {
        return JarvisResult.Success(Recipient(contactName, contactName))
    }
    if (!device.hasPermission("android.permission.READ_CONTACTS")) {
        return JarvisResult.Failure(
            "Jarvis needs permission to read contacts to find “$contactName”. " +
                "Grant it in Settings → App permissions → Contacts, then try again.",
        )
    }
    return when (val result = device.searchContacts(contactName)) {
        is JarvisResult.Success -> when (val resolution = ContactResolver.resolve(contactName, result.value)) {
            is ContactResolver.Resolution.Single ->
                JarvisResult.Success(Recipient(resolution.contact.phoneNumber, resolution.contact.name))
            is ContactResolver.Resolution.Ambiguous -> JarvisResult.Failure(
                "AMBIGUOUS:" + ContactResolver.formatCandidates(resolution.candidates),
            )
            ContactResolver.Resolution.None ->
                JarvisResult.Failure("No contact named “$contactName”.")
        }
        is JarvisResult.Failure -> result
    }
}

/** True when a failure message is the "ambiguous contacts" signal. */
private fun JarvisResult.Failure.isAmbiguous(): Boolean = message.startsWith("AMBIGUOUS:")

/** The candidate list carried by an "ambiguous contacts" failure. */
private fun JarvisResult.Failure.candidates(): String = message.removePrefix("AMBIGUOUS:")

/** Open the dialer with the number pre-filled. Never dials by itself. */
class MakeCallTool(private val device: PhoneDevice) : JarvisTool {
    override val name: String = "make_call"
    override val description: String = "Open the dialer for a contact or number (you tap Call to place the call)."
    override val riskTier: RiskTier = RiskTier.EXTERNAL
    override val requiredPermissions: List<String> =
        listOf("android.permission.READ_CONTACTS")

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("contact", "string", "Contact name to call.", required = false),
        ToolSchema.ParamSpec("number", "string", "Phone number to call directly.", required = false),
    )

    override suspend fun dryRun(params: JsonObject): String {
        return when (val recipient = resolveRecipient(device, params)) {
            is JarvisResult.Success -> {
                val r = recipient.value
                val namePart = if (r.displayName == r.number) "" else " (${r.displayName})"
                "Open the dialer for ${r.number}$namePart.\n" +
                    "You tap Call to place the call — Jarvis never dials by itself."
            }
            is JarvisResult.Failure -> if (recipient.isAmbiguous()) {
                "Several contacts match — Jarvis will ask which one (nothing will be dialled yet)."
            } else {
                "Open the dialer: ${recipient.message}"
            }
        }
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        return when (val recipient = resolveRecipient(device, params)) {
            is JarvisResult.Success -> {
                when (val launch = device.launch(SystemAction.Dial(recipient.value.number))) {
                    is JarvisResult.Success -> JarvisResult.Success(
                        ToolOutcome(
                            "Opened the dialer for ${recipient.value.displayName} " +
                                "(${recipient.value.number}) — tap Call to place the call.",
                        ),
                    )
                    is JarvisResult.Failure -> launch
                }
            }
            is JarvisResult.Failure -> if (recipient.isAmbiguous()) {
                JarvisResult.Success(
                    ToolOutcome("Several contacts match — which one?\n${recipient.candidates()}"),
                )
            } else {
                recipient
            }
        }
    }

    override fun paramsFromEditedContent(
        editedContent: String,
        originalParams: JsonObject,
    ): JsonObject? {
        // First line: "Open the dialer for <number> (<name>)." — take the number.
        val firstLine = editedContent.lineSequence().firstOrNull() ?: return null
        val number = Regex("""[+0-9][0-9 ()-]{6,}""").find(firstLine)?.value?.trim()
            ?: return null
        return buildJsonObject { put("number", number) }
    }
}

/** Open the messaging app with recipient + body pre-filled. Never sends. */
class SendSmsTool(private val device: PhoneDevice) : JarvisTool {
    override val name: String = "send_sms"
    override val description: String = "Open the messaging app with a text message ready to send (you tap Send)."
    override val riskTier: RiskTier = RiskTier.EXTERNAL
    override val requiredPermissions: List<String> =
        listOf("android.permission.READ_CONTACTS")

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("contact", "string", "Contact name to text.", required = false),
        ToolSchema.ParamSpec("number", "string", "Phone number to text directly.", required = false),
        ToolSchema.ParamSpec("body", "string", "The exact message text."),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val body = params.stringParam("body") ?: "?"
        return when (val recipient = resolveRecipient(device, params)) {
            is JarvisResult.Success -> {
                val r = recipient.value
                val namePart = if (r.displayName == r.number) "" else " (${r.displayName})"
                "Send SMS to ${r.number}$namePart:\n$body"
            }
            is JarvisResult.Failure -> if (recipient.isAmbiguous()) {
                "Several contacts match — Jarvis will ask which one (nothing will be sent yet)."
            } else {
                "Send SMS: ${recipient.message}"
            }
        }
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val body = params.stringParam("body")
            ?: return JarvisResult.Failure("send_sms needs a 'body' parameter")
        return when (val recipient = resolveRecipient(device, params)) {
            is JarvisResult.Success -> {
                when (val launch = device.launch(SystemAction.SendSms(recipient.value.number, body))) {
                    is JarvisResult.Success -> JarvisResult.Success(
                        ToolOutcome(
                            "Opened the messaging app for ${recipient.value.displayName} " +
                                "with the message ready — tap Send to send it.",
                        ),
                    )
                    is JarvisResult.Failure -> launch
                }
            }
            is JarvisResult.Failure -> if (recipient.isAmbiguous()) {
                JarvisResult.Success(
                    ToolOutcome("Several contacts match — which one?\n${recipient.candidates()}"),
                )
            } else {
                recipient
            }
        }
    }

    override fun paramsFromEditedContent(
        editedContent: String,
        originalParams: JsonObject,
    ): JsonObject? {
        // Preview shape:
        //   Send SMS to <number> (<name>):
        //   <body, possibly several lines>
        val lines = editedContent.lines()
        if (lines.size < 2) return null
        val firstLine = lines.first()
        if (!firstLine.startsWith("Send SMS to ") || !firstLine.endsWith(":")) return null
        val recipientPart = firstLine.removePrefix("Send SMS to ").removeSuffix(":").trim()
        val number = recipientPart.substringBefore(" (").trim()
        if (number.isBlank()) return null
        val body = lines.drop(1).joinToString("\n")
        return buildJsonObject {
            put("number", number)
            put("body", body)
        }
    }
}

/** Open the email app with to/subject/body pre-filled. Never sends. */
class SendEmailTool(private val device: PhoneDevice) : JarvisTool {
    override val name: String = "send_email"
    override val description: String = "Open the email app with an email ready to send (you tap Send)."
    override val riskTier: RiskTier = RiskTier.EXTERNAL
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("to", "string", "Recipient email address(es), comma-separated."),
        ToolSchema.ParamSpec("subject", "string", "Email subject.", required = false),
        ToolSchema.ParamSpec("body", "string", "Email body.", required = false),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val to = params.stringParam("to") ?: "?"
        val subject = params.optStringParam("subject") ?: ""
        val body = params.optStringParam("body") ?: ""
        return "Send email to $to:\nSubject: $subject\n$body"
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val toRaw = params.stringParam("to")
            ?: return JarvisResult.Failure("send_email needs a 'to' parameter")
        val to = toRaw.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (to.isEmpty()) {
            return JarvisResult.Failure("send_email needs at least one recipient address")
        }
        val invalid = to.firstOrNull { !it.contains("@") }
        if (invalid != null) {
            return JarvisResult.Failure("“$invalid” doesn't look like an email address.")
        }
        val subject = params.optStringParam("subject") ?: ""
        val body = params.optStringParam("body") ?: ""
        return when (val launch = device.launch(SystemAction.SendEmail(to, subject, body))) {
            is JarvisResult.Success -> JarvisResult.Success(
                ToolOutcome(
                    "Opened the email app for ${to.joinToString(", ")} with the email ready — " +
                        "tap Send to send it.",
                ),
            )
            is JarvisResult.Failure -> launch
        }
    }

    override fun paramsFromEditedContent(
        editedContent: String,
        originalParams: JsonObject,
    ): JsonObject? {
        // Preview shape:
        //   Send email to <to>:
        //   Subject: <subject>
        //   <body, possibly several lines>
        val lines = editedContent.lines()
        if (lines.size < 2) return null
        val firstLine = lines.first()
        if (!firstLine.startsWith("Send email to ") || !firstLine.endsWith(":")) return null
        val to = firstLine.removePrefix("Send email to ").removeSuffix(":").trim()
        if (to.isBlank()) return null
        val subjectLine = lines.getOrNull(1) ?: return null
        if (!subjectLine.startsWith("Subject: ")) return null
        val subject = subjectLine.removePrefix("Subject: ")
        val body = lines.drop(2).joinToString("\n")
        return buildJsonObject {
            put("to", to)
            put("subject", subject)
            put("body", body)
        }
    }
}

/** Open the system share sheet with text. */
class ShareTextTool(private val device: PhoneDevice) : JarvisTool {
    override val name: String = "share_text"
    override val description: String = "Open the share sheet with some text (you pick where it goes)."
    override val riskTier: RiskTier = RiskTier.EXTERNAL
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("text", "string", "The text to share."),
        ToolSchema.ParamSpec("title", "string", "Optional title for the share sheet.", required = false),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val text = params.stringParam("text") ?: "?"
        return "Open the share sheet with:\n$text"
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val text = params.stringParam("text")
            ?: return JarvisResult.Failure("share_text needs a 'text' parameter")
        val title = params.optStringParam("title") ?: "Share via Jarvis"
        return when (val launch = device.launch(SystemAction.ShareText(text, title))) {
            is JarvisResult.Success ->
                JarvisResult.Success(ToolOutcome("Opened the share sheet — pick where the text goes."))
            is JarvisResult.Failure -> launch
        }
    }

    override fun paramsFromEditedContent(
        editedContent: String,
        originalParams: JsonObject,
    ): JsonObject? {
        // Preview shape:
        //   Open the share sheet with:
        //   <text, possibly several lines>
        val lines = editedContent.lines()
        if (lines.size < 2) return null
        if (lines.first() != "Open the share sheet with:") return null
        val text = lines.drop(1).joinToString("\n")
        return buildJsonObject { put("text", text) }
    }
}
