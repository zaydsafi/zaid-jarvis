package com.zaid.jarvis.tools.social

import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.core.research.DraftStatus
import com.zaid.jarvis.core.social.ScheduleValidation
import com.zaid.jarvis.core.social.ScheduledPostStatus
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.JarvisTool
import com.zaid.jarvis.tools.ToolOutcome
import com.zaid.jarvis.tools.ToolSchema
import com.zaid.jarvis.tools.intParam
import com.zaid.jarvis.tools.intParamOr
import com.zaid.jarvis.tools.optStringParam
import kotlinx.serialization.json.JsonObject
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

// ─────────────────────────────────────────────────────────────────────────────
// Social publishing tools (Phase 8).
//
// publish_draft and schedule_post are Tier 2: the approval card (plus a
// second confirmation) shows the EXACT text, platform, account, and —
// for scheduling — time, before anything leaves the device. The planner
// can never publish without that card: these tools only run through
// GatedToolExecutor, and the publish gate itself (APPROVED-only,
// content binding, char-limit re-check) is enforced one layer down in
// PublishService, so even a direct call can't publish a draft Zaid
// hasn't approved.
//
// Publishing is NOT undoable (a post that left the device can't be
// un-posted by Jarvis — Zaid deletes it in the platform's own app), so
// supportsUndo stays false for all four tools.
// ─────────────────────────────────────────────────────────────────────────────

/** Formats an epoch-millis time for approval cards and lists. */
internal fun formatScheduledTime(epochMillis: Long): String {
    val dateTime = Instant.ofEpochMilli(epochMillis).atZone(ZoneId.systemDefault())
    return dateTime.format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.SHORT))
}

/** Publishes an APPROVED draft right now (Tier 2). */
class PublishDraftTool(
    private val publishService: PublishService,
    private val publisher: SocialPublisher,
) : JarvisTool {
    override val name: String = "publish_draft"
    override val description: String =
        "Publish an APPROVED draft to its social platform right now. Only drafts Zaid has " +
            "approved can be published; the approval card shows the exact text first."
    override val riskTier: RiskTier = RiskTier.EXTERNAL
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec(
            "draft_id",
            "integer",
            "The id of the APPROVED draft to publish (from the Drafts screen).",
        ),
        ToolSchema.ParamSpec(
            name = "image_url",
            type = "string",
            description = "Public image URL. Required for Instagram posts (Instagram cannot " +
                "publish text-only posts); ignored for other platforms in Phase 8.",
            required = false,
        ),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val draftId = params.intParam("draft_id")?.toLong()
            ?: return "Publish a draft — missing draft_id."
        val draft = publishService.getDraft(draftId)
            ?: return "Publish draft #$draftId — no draft with that id exists."
        if (draft.status != DraftStatus.APPROVED) {
            return "Cannot publish “${draft.title}”: it is ${draft.status.name.lowercase()}, " +
                "not approved. Approve it in Drafts first — only APPROVED drafts can be published."
        }
        if (draft.editedSinceApproval()) {
            return "Cannot publish “${draft.title}”: it was edited after you approved it. " +
                "Approve the edited text again in Drafts before publishing."
        }
        val platform = SocialPlatform.fromName(draft.platform)
            ?: return "Cannot publish “${draft.title}”: “${draft.platform}” is not a social " +
                "platform Jarvis can publish to."
        val account = publisher.connectedAccount(platform)
            ?: return "Cannot publish “${draft.title}” to ${platform.displayName}: no account " +
                "connected. Connect one in Settings → Connected accounts first."
        val imageUrl = params.optStringParam("image_url")
        val imageLine = if (platform == SocialPlatform.INSTAGRAM) {
            if (imageUrl.isNullOrBlank()) {
                "\n⚠ Instagram needs a photo — no image URL was given, so this publish will fail. " +
                    "Add a public image URL."
            } else {
                "\nImage: $imageUrl"
            }
        } else {
            ""
        }
        return "Publish to ${platform.displayName} as @${account.handle}:\n" +
            "“${draft.body}”$imageLine"
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val draftId = params.intParam("draft_id")?.toLong()
            ?: return JarvisResult.Failure("publish_draft needs a 'draft_id' parameter.")
        val imageUrl = params.optStringParam("image_url")
        return when (val result = publishService.publishDraftNow(draftId, imageUrl)) {
            is JarvisResult.Success -> {
                val published = result.value
                val link = published.postUrl?.let { "\n$it" } ?: ""
                JarvisResult.Success(
                    ToolOutcome("Published to ${published.platform.displayName} — link:$link"),
                )
            }
            is JarvisResult.Failure -> result
        }
    }

    /**
     * Edited publish previews are refused: the approval card shows the
     * exact text that will be published, and changing it on the card
     * would publish text that was never approved. Zaid edits the draft
     * itself instead (which re-requires approval).
     */
    override fun paramsFromEditedContent(
        editedContent: String,
        originalParams: JsonObject,
    ): JsonObject? = null
}

/** Schedules an APPROVED draft for later publication (Tier 2). */
class SchedulePostTool(
    private val publishService: PublishService,
    private val publisher: SocialPublisher,
    private val scheduler: SocialScheduler,
    private val nowMillis: () -> Long = { System.currentTimeMillis() },
) : JarvisTool {
    override val name: String = "schedule_post"
    override val description: String =
        "Schedule an APPROVED draft to publish later (at least 5 minutes ahead). The approval " +
            "card shows the exact text, platform, and time. If the draft is edited after " +
            "scheduling, the post is cancelled instead of publishing stale content."
    override val riskTier: RiskTier = RiskTier.EXTERNAL
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec(
            "draft_id",
            "integer",
            "The id of the APPROVED draft to schedule (from the Drafts screen).",
        ),
        ToolSchema.ParamSpec(
            "delay_minutes",
            "integer",
            "How many minutes from now to publish (at least 5).",
        ),
        ToolSchema.ParamSpec(
            name = "image_url",
            type = "string",
            description = "Public image URL. Required when scheduling an Instagram post " +
                "(Instagram cannot publish text-only posts); ignored for other platforms.",
            required = false,
        ),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val draftId = params.intParam("draft_id")?.toLong()
            ?: return "Schedule a draft — missing draft_id."
        val delayMinutes = params.intParamOr("delay_minutes", 0)
        if (delayMinutes < 5) {
            return "Cannot schedule: scheduled posts need at least 5 minutes' notice " +
                "(asked for $delayMinutes minutes)."
        }
        val draft = publishService.getDraft(draftId)
            ?: return "Schedule draft #$draftId — no draft with that id exists."
        if (draft.status != DraftStatus.APPROVED) {
            return "Cannot schedule “${draft.title}”: it is ${draft.status.name.lowercase()}, " +
                "not approved. Approve it in Drafts first."
        }
        // Phase 11 fix: an edited-after-approval draft must not be
        // scheduled — the worker's schedule-time hash check cannot
        // catch an edit that happened before scheduling (the hash is
        // recorded from the edited text), so refusing here is what
        // keeps unapproved text out of the queue.
        if (draft.editedSinceApproval()) {
            return "Cannot schedule “${draft.title}”: it was edited after you approved it. " +
                "Approve the edited text again in Drafts before scheduling."
        }
        val platform = SocialPlatform.fromName(draft.platform)
            ?: return "Cannot schedule “${draft.title}”: “${draft.platform}” is not a social " +
                "platform Jarvis can publish to."
        val account = publisher.connectedAccount(platform)
            ?: return "Cannot schedule “${draft.title}” for ${platform.displayName}: no account " +
                "connected. Connect one in Settings → Connected accounts first."
        val scheduledAt = nowMillis() + delayMinutes * 60 * 1000L
        val imageUrl = params.optStringParam("image_url")
        val imageLine = if (platform == SocialPlatform.INSTAGRAM) {
            if (imageUrl.isNullOrBlank()) {
                "\n⚠ Instagram needs a photo — no image URL was given, so this scheduled " +
                    "post will fail. Add a public image URL."
            } else {
                "\nImage: $imageUrl"
            }
        } else {
            ""
        }
        return "Schedule for ${platform.displayName} as @${account.handle} at " +
            "${formatScheduledTime(scheduledAt)}:\n“${draft.body}”$imageLine"
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val draftId = params.intParam("draft_id")?.toLong()
            ?: return JarvisResult.Failure("schedule_post needs a 'draft_id' parameter.")
        val delayMinutes = params.intParam("delay_minutes")?.toLong()
            ?: return JarvisResult.Failure("schedule_post needs a 'delay_minutes' parameter.")
        val now = nowMillis()
        val scheduledAt = when (val validated = ScheduleValidation.validateDelayMinutes(delayMinutes, now)) {
            is JarvisResult.Success -> validated.value
            is JarvisResult.Failure -> return validated
        }
        val draft = publishService.getDraft(draftId)
            ?: return JarvisResult.Failure("No draft with id $draftId exists.")
        if (draft.status != DraftStatus.APPROVED) {
            return JarvisResult.Failure(
                "“${draft.title}” is ${draft.status.name.lowercase()}, not approved — " +
                    "only APPROVED drafts can be scheduled.",
            )
        }
        if (draft.editedSinceApproval()) {
            return JarvisResult.Failure(
                "“${draft.title}” was edited after you approved it — approve the " +
                    "edited text again in Drafts before scheduling.",
            )
        }
        val platform = SocialPlatform.fromName(draft.platform)
            ?: return JarvisResult.Failure(
                "“${draft.platform}” is not a social platform Jarvis can publish to.",
            )
        val account = publisher.connectedAccount(platform)
            ?: return JarvisResult.Failure(
                "No ${platform.displayName} account connected — connect one in " +
                    "Settings → Connected accounts first.",
            )
        return when (
            val scheduled = scheduler.schedule(
                draftId = draftId,
                platform = platform,
                accountHandle = account.handle,
                scheduledAtMillis = scheduledAt,
                contentHash = ScheduleValidation.draftContentHash(draft.body),
                imageUrl = params.optStringParam("image_url"),
            )
        ) {
            is JarvisResult.Success -> JarvisResult.Success(
                ToolOutcome(
                    "Scheduled “${draft.title}” for ${platform.displayName} at " +
                        "${formatScheduledTime(scheduledAt)}. If you edit the draft before " +
                        "then, the post will be cancelled instead of publishing the old text.",
                ),
            )
            is JarvisResult.Failure -> scheduled
        }
    }

    override fun paramsFromEditedContent(
        editedContent: String,
        originalParams: JsonObject,
    ): JsonObject? = null
}

/** Lists scheduled posts (Tier 0, read-only). */
class ListScheduledPostsTool(
    private val scheduler: SocialScheduler,
) : JarvisTool {
    override val name: String = "list_scheduled_posts"
    override val description: String = "List scheduled posts: upcoming, published, failed, and cancelled."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> = emptyList()

    override suspend fun dryRun(params: JsonObject): String = "List scheduled posts."

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val posts = scheduler.listAll()
        if (posts.isEmpty()) {
            return JarvisResult.Success(ToolOutcome("No scheduled posts yet."))
        }
        val shown = posts.take(MAX_LISTED_POSTS)
        val lines = shown.map { post ->
            val status = when (post.status) {
                ScheduledPostStatus.SCHEDULED -> "scheduled for ${formatScheduledTime(post.scheduledAtMillis)}"
                ScheduledPostStatus.PUBLISHED -> "published${post.postUrl?.let { " — $it" } ?: ""}"
                ScheduledPostStatus.FAILED -> "failed: ${post.failureReason ?: "unknown reason"}"
                ScheduledPostStatus.CANCELLED -> "cancelled${post.failureReason?.let { ": $it" } ?: ""}"
            }
            "#${post.id} · ${post.platform.displayName} · $status"
        }
        val more = posts.size - shown.size
        val body = buildString {
            append("Scheduled posts:\n")
            append(lines.joinToString("\n"))
            if (more > 0) {
                append("\n…and $more more (see the Scheduled posts screen for the full list).")
            }
        }
        return JarvisResult.Success(ToolOutcome(body))
    }

    companion object {
        /**
         * Max posts formatted into one tool result (Phase 11 hardening).
         * The scheduler store is bulk-capped (5,000), but the LLM only
         * ever sees the first 50 — a huge history must not flood context.
         */
        const val MAX_LISTED_POSTS: Int = 50
    }
}

/** Cancels a scheduled post (Tier 1 — reversible, the draft is untouched). */
class CancelScheduledPostTool(
    private val scheduler: SocialScheduler,
) : JarvisTool {
    override val name: String = "cancel_scheduled_post"
    override val description: String =
        "Cancel a scheduled post. The draft itself is not changed — it stays APPROVED and can be published or rescheduled later."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec(
            "scheduled_post_id",
            "integer",
            "The id of the scheduled post to cancel (from list_scheduled_posts).",
        ),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val postId = params.intParam("scheduled_post_id")?.toLong()
            ?: return "Cancel a scheduled post — missing scheduled_post_id."
        val post = scheduler.getById(postId)
            ?: return "Cancel scheduled post #$postId — no scheduled post with that id exists."
        if (post.status != ScheduledPostStatus.SCHEDULED) {
            return "Scheduled post #${post.id} is already ${post.status.name.lowercase()} — " +
                "there is nothing to cancel."
        }
        return "Cancel the scheduled post to ${post.platform.displayName} " +
            "at ${formatScheduledTime(post.scheduledAtMillis)}. " +
            "The draft stays approved and can be published later."
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val postId = params.intParam("scheduled_post_id")?.toLong()
            ?: return JarvisResult.Failure("cancel_scheduled_post needs a 'scheduled_post_id' parameter.")
        return when (val result = scheduler.cancel(postId)) {
            is JarvisResult.Success -> JarvisResult.Success(
                ToolOutcome("Cancelled scheduled post #$postId. The draft is unchanged."),
            )
            is JarvisResult.Failure -> result
        }
    }
}
