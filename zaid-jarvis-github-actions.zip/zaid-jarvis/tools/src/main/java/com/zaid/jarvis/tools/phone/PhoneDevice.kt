package com.zaid.jarvis.tools.phone

import com.zaid.jarvis.core.util.JarvisResult

/**
 * Pure-Kotlin data types for the phone tools (Phase 5). No Android APIs
 * here — `:tools` compiles and tests on the JVM. The Android
 * implementation lives in `:app` ([com.zaid.jarvis.phone.AndroidPhoneDevice]).
 */

/** Battery state. [percent] is null when the device cannot report it. */
data class BatteryInfo(
    val percent: Int?,
    val isCharging: Boolean,
)

/** Network state. [type] is "Wi-Fi", "Mobile", "Ethernet", "VPN", or "None". */
data class NetworkInfo(
    val isOnline: Boolean,
    val type: String,
)

/** One contact: display name + a phone number. */
data class Contact(
    val id: Long,
    val name: String,
    val phoneNumber: String,
)

/** One installed, launchable app. */
data class AppInfo(
    val name: String,
    val packageName: String,
)

/** Audio streams Jarvis can set the volume of. */
enum class VolumeStream(val displayName: String) {
    MUSIC("Media"),
    ALARM("Alarm"),
    RING("Ring"),
    NOTIFICATION("Notification"),
    CALL("Call"),
    SYSTEM("System"),
    ;

    companion object {
        /** Parses an LLM-supplied stream name (case-insensitive, with aliases). */
        fun fromName(name: String): VolumeStream? = when (name.trim().lowercase()) {
            "music", "media" -> MUSIC
            "alarm" -> ALARM
            "ring", "ringer", "ringtone" -> RING
            "notification", "notifications" -> NOTIFICATION
            "call", "voice_call", "voice" -> CALL
            "system" -> SYSTEM
            else -> null
        }
    }
}

/** A stream's current level and its maximum. */
data class VolumeInfo(
    val stream: VolumeStream,
    val level: Int,
    val maxLevel: Int,
)

/** What a brightness change returned: the previous value + auto-brightness state. */
data class BrightnessChange(
    val previousPercent: Int,
    val autoBrightnessOn: Boolean,
)

/** Do Not Disturb modes, matching Android's interruption filters. */
enum class DndMode(val displayName: String) {
    OFF("Off"),
    ALARMS_ONLY("Alarms only"),
    PRIORITY_ONLY("Priority only"),
    TOTAL_SILENCE("Total silence"),
    ;

    companion object {
        /** Parses an LLM-supplied mode name (case-insensitive, with aliases). */
        fun fromName(name: String): DndMode? = when (name.trim().lowercase()) {
            "off", "none", "disabled" -> OFF
            "alarms_only", "alarms only", "alarms" -> ALARMS_ONLY
            "priority_only", "priority only", "priority" -> PRIORITY_ONLY
            "total_silence", "total silence", "silence", "do_not_disturb", "dnd" -> TOTAL_SILENCE
            else -> null
        }
    }
}

/**
 * What happened when Jarvis tried to toggle Wi-Fi. Android 10+ does not
 * let apps switch Wi-Fi directly, so on those devices Jarvis opens the
 * Wi-Fi settings panel instead and Zaid toggles it there — nothing
 * changed, so there is nothing to undo.
 */
sealed interface WifiToggleResult {
    /** Wi-Fi was switched directly; [previousEnabled] is the old state. */
    data class Changed(val previousEnabled: Boolean) : WifiToggleResult

    /** The Wi-Fi settings panel was opened; Zaid toggles it there. */
    data object PanelOpened : WifiToggleResult
}

/**
 * What happened when Jarvis tried to toggle Bluetooth. On Android 13+
 * enabling Bluetooth shows the system's own confirmation dialog — Jarvis
 * cannot switch it on silently.
 */
sealed interface BluetoothToggleResult {
    /** Bluetooth was switched directly; [previousEnabled] is the old state. */
    data class Changed(val previousEnabled: Boolean) : BluetoothToggleResult

    /** The system's "turn on Bluetooth?" dialog was shown. */
    data object EnableDialogOpened : BluetoothToggleResult
}

/**
 * The phone's capabilities, as the tools see them (Phase 5).
 *
 * Every method returns a [JarvisResult]: tools must check permission
 * availability before acting and return clear failures (naming the
 * permission and how to grant it) instead of crashing. Implementations
 * never throw for expected failures — missing permissions, missing
 * hardware, or an Android version restriction all come back as
 * [JarvisResult.Failure] with a plain-language message.
 *
 * State-changing methods return the *previous* state (or a result type
 * carrying it) so the tool can record real undo data.
 */
interface PhoneDevice {

    // ── Tier 0 reads ──────────────────────────────────────────────────

    suspend fun battery(): JarvisResult<BatteryInfo>

    suspend fun network(): JarvisResult<NetworkInfo>

    /** Contacts whose name contains [query] (case-insensitive), up to 20. */
    suspend fun searchContacts(query: String): JarvisResult<List<Contact>>

    /** Launchable apps, optionally filtered by name/package [query]. */
    suspend fun listApps(query: String?): JarvisResult<List<AppInfo>>

    // ── Tier 1 state ──────────────────────────────────────────────────

    suspend fun isFlashlightOn(): JarvisResult<Boolean>

    /** Sets the torch; returns the previous state. */
    suspend fun setFlashlight(on: Boolean): JarvisResult<Boolean>

    suspend fun volumeInfo(stream: VolumeStream): JarvisResult<VolumeInfo>

    /** Sets the volume; returns the previous level info. */
    suspend fun setVolume(stream: VolumeStream, level: Int): JarvisResult<VolumeInfo>

    /** Current screen brightness as a percentage (0–100). */
    suspend fun brightnessPercent(): JarvisResult<Int>

    /**
     * Sets the brightness; returns the previous percentage plus whether
     * auto-brightness is on (when it is, the new value may not be
     * visible until Zaid turns auto-brightness off).
     */
    suspend fun setBrightnessPercent(percent: Int): JarvisResult<BrightnessChange>

    suspend fun isWifiEnabled(): JarvisResult<Boolean>

    suspend fun setWifi(enabled: Boolean): JarvisResult<WifiToggleResult>

    suspend fun isBluetoothEnabled(): JarvisResult<Boolean>

    suspend fun setBluetooth(enabled: Boolean): JarvisResult<BluetoothToggleResult>

    suspend fun dndMode(): JarvisResult<DndMode>

    /** Sets Do Not Disturb; returns the previous mode. */
    suspend fun setDndMode(mode: DndMode): JarvisResult<DndMode>

    // ── Permissions ───────────────────────────────────────────────────

    /** Whether the app currently holds the Android [permission]. */
    fun hasPermission(permission: String): Boolean

    // ── System actions (intents) ──────────────────────────────────────

    /**
     * Hands a [SystemAction] to the system app that owns it (dialer,
     * messaging app, email app, Clock app, share sheet, …). The system
     * app opens with everything pre-filled; **the user always takes
     * the final step there** — Jarvis never places a call, sends a
     * message, or sends an email by itself.
     */
    suspend fun launch(action: SystemAction): JarvisResult<String>
}
