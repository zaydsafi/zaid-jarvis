package com.zaid.jarvis.tools.research

import com.zaid.jarvis.core.research.ContentDraft
import com.zaid.jarvis.core.research.PageContent
import com.zaid.jarvis.core.research.ResearchEvent
import com.zaid.jarvis.core.research.SearchResult
import com.zaid.jarvis.core.util.JarvisResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

/**
 * Research interfaces (Phase 7). The tools in :tools program against
 * these; the real implementations live in :agent (network + LLM) so
 * :tools stays pure Kotlin and unit-testable on the JVM — the same
 * seam pattern as PhoneDevice (Phase 5) and AutomationDevice (Phase 6).
 *
 * Everything these return from the web is UNTRUSTED DATA: the planner
 * scans every tool result with the Phase 3 InjectionGuard before
 * acting on it, and the ResearchEngine scans fetched pages before
 * they reach the synthesis prompt.
 */

/** Web search: one query → up to [maxResults] results. */
interface WebSearch {
    suspend fun search(query: String, maxResults: Int): JarvisResult<List<SearchResult>>
}

/** Fetches one page and reduces it to readable text (SSRF-guarded). */
interface PageFetcher {
    suspend fun fetch(url: String): JarvisResult<PageContent>
}

/** Runs the full research pipeline (search → fetch → synthesize). */
interface ResearchRunner {
    fun research(topic: String): Flow<ResearchEvent>
}

/** What `draft_post` asks the draft composer to write. */
data class DraftRequest(
    val topic: String,
    /** Platform preset name or free text ("X", "Instagram", …). */
    val platform: String,
    /** Speaking style, e.g. the Personality setting's display name. */
    val tone: String,
    /** Optional extra context (e.g. a research brief) to base the draft on. */
    val context: String? = null,
    /** Research record this draft is based on, if any. */
    val researchId: Long? = null,
)

/** What the draft composer returns after saving the draft. */
data class DraftGenerationResult(
    /** The saved draft (status DRAFT — approval happens in the UI). */
    val draft: ContentDraft,
    /** The platform's character limit. */
    val charLimit: Int,
    /** True when the text had to be hard-truncated to fit the limit. */
    val truncated: Boolean,
    /** True when the first attempt was over the limit and a rewrite was tried. */
    val wasRewritten: Boolean,
)

/** Generates a draft post with the LLM and saves it (status DRAFT). */
interface DraftGenerator {
    suspend fun generate(request: DraftRequest): JarvisResult<DraftGenerationResult>
}

// ── No-op implementations (tests + builds without network) ───────────────

object NoOpWebSearch : WebSearch {
    override suspend fun search(query: String, maxResults: Int): JarvisResult<List<SearchResult>> =
        JarvisResult.Failure("Web search is not available in this build.")
}

object NoOpPageFetcher : PageFetcher {
    override suspend fun fetch(url: String): JarvisResult<PageContent> =
        JarvisResult.Failure("Page fetching is not available in this build.")
}

object NoOpResearchRunner : ResearchRunner {
    override fun research(topic: String): Flow<ResearchEvent> =
        flowOf(ResearchEvent.Failed("Research is not available in this build."))
}

object NoOpDraftGenerator : DraftGenerator {
    override suspend fun generate(request: DraftRequest): JarvisResult<DraftGenerationResult> =
        JarvisResult.Failure("Draft generation is not available in this build.")
}
