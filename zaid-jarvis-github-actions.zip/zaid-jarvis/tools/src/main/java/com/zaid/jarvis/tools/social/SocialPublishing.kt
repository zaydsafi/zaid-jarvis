package com.zaid.jarvis.tools.social

import com.zaid.jarvis.core.research.ContentDraft
import com.zaid.jarvis.core.social.OAuthClientCredentials
import com.zaid.jarvis.core.social.OAuthTokens
import com.zaid.jarvis.core.social.PublishRequest
import com.zaid.jarvis.core.social.PublishResult
import com.zaid.jarvis.core.social.ScheduledPost
import com.zaid.jarvis.core.social.SocialAccount
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.core.util.JarvisResult

// ─────────────────────────────────────────────────────────────────────────────
// Social publishing seams (Phase 8).
//
// :tools stays pure Kotlin, so everything that touches the network, the
// database, or WorkManager lives behind these interfaces — the same
// pattern as PhoneDevice (Phase 5) and AutomationDevice (Phase 6).
// Real implementations live in :agent (publishing + OAuth), :data
// (accounts + scheduled posts) and :app (WorkManager scheduling).
// The NoOp implementations are what the registry uses when a real
// implementation is not wired in (tests, and any build without the
// social modules); they fail with a plain-language message instead of
// silently doing nothing.
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Storage for connected social accounts: public metadata in DataStore,
 * tokens and OAuth client credentials in Keystore-encrypted
 * EncryptedSharedPreferences. Tokens are never in Room and never
 * logged. Implemented by :data's SocialAccountRepository.
 */
interface SocialAccountStore {
    suspend fun getAccount(platform: SocialPlatform): SocialAccount?
    suspend fun allAccounts(): List<SocialAccount>
    suspend fun saveAccount(account: SocialAccount)
    suspend fun deleteAccount(platform: SocialPlatform)

    suspend fun getTokens(platform: SocialPlatform): OAuthTokens?
    suspend fun saveTokens(platform: SocialPlatform, tokens: OAuthTokens)
    suspend fun clearTokens(platform: SocialPlatform)

    suspend fun getClientCredentials(platform: SocialPlatform): OAuthClientCredentials?
    suspend fun saveClientCredentials(platform: SocialPlatform, credentials: OAuthClientCredentials)
    suspend fun clearClientCredentials(platform: SocialPlatform)

    /** Removes every social secret (tokens + client credentials) — used by "Delete all secrets". */
    suspend fun clearAllSocialSecrets()
}

/** In-memory fake/no-op account store (tests and unwired builds). */
class NoOpSocialAccountStore : SocialAccountStore {
    private val accounts = mutableMapOf<SocialPlatform, SocialAccount>()
    private val tokens = mutableMapOf<SocialPlatform, OAuthTokens>()
    private val credentials = mutableMapOf<SocialPlatform, OAuthClientCredentials>()

    override suspend fun getAccount(platform: SocialPlatform): SocialAccount? = accounts[platform]
    override suspend fun allAccounts(): List<SocialAccount> = accounts.values.toList()
    override suspend fun saveAccount(account: SocialAccount) { accounts[account.platform] = account }
    override suspend fun deleteAccount(platform: SocialPlatform) {
        accounts.remove(platform)
        tokens.remove(platform)
    }

    override suspend fun getTokens(platform: SocialPlatform): OAuthTokens? = tokens[platform]
    override suspend fun saveTokens(platform: SocialPlatform, tokens: OAuthTokens) {
        this.tokens[platform] = tokens
    }

    override suspend fun clearTokens(platform: SocialPlatform) { tokens.remove(platform) }
    override suspend fun getClientCredentials(platform: SocialPlatform): OAuthClientCredentials? =
        credentials[platform]

    override suspend fun saveClientCredentials(
        platform: SocialPlatform,
        credentials: OAuthClientCredentials,
    ) {
        this.credentials[platform] = credentials
    }

    override suspend fun clearClientCredentials(platform: SocialPlatform) {
        credentials.remove(platform)
    }

    override suspend fun clearAllSocialSecrets() {
        tokens.clear()
        credentials.clear()
    }
}

/**
 * Publishes text to the social platforms via their official APIs.
 * Implemented in :agent (SocialPublisherImpl); handles token refresh
 * internally (401 → refresh once → retry; refresh failure →
 * disconnected).
 */
interface SocialPublisher {
    /** The connected account for [platform], or null when not connected. */
    suspend fun connectedAccount(platform: SocialPlatform): SocialAccount?

    /** Publishes [request] now. Fails plainly when not connected or the API rejects it. */
    suspend fun publish(request: PublishRequest): JarvisResult<PublishResult>

    /**
     * Fetches the /me profile for [platform] with a fresh access token
     * (used by the connect flow to learn the account handle). The
     * caller must have just stored the tokens.
     */
    suspend fun fetchProfile(platform: SocialPlatform): JarvisResult<SocialAccount>
}

/** No-op publisher: every publish fails with a plain-language message. */
class NoOpSocialPublisher : SocialPublisher {
    override suspend fun connectedAccount(platform: SocialPlatform): SocialAccount? = null

    override suspend fun publish(request: PublishRequest): JarvisResult<PublishResult> =
        JarvisResult.Failure(
            "Social publishing is not available in this build — " +
                "connect an account in Settings → Connected accounts first.",
        )

    override suspend fun fetchProfile(platform: SocialPlatform): JarvisResult<SocialAccount> =
        JarvisResult.Failure("Social publishing is not available in this build.")
}

/**
 * The publishing gate, enforced in code (Master Prompt §9.8:
 * research → draft → preview → Allow → publish → report).
 *
 * This is the single place where a draft may move to PUBLISHED, and it
 * is shared by the `publish_draft` tool (immediate publish) and the
 * WorkManager worker (scheduled publish), so both paths enforce exactly
 * the same rules. Implemented in :agent (PublishServiceImpl).
 *
 * Rules enforced here (the approval card itself is the Confirmation
 * Engine's job, one layer up, via GatedToolExecutor):
 * - Only APPROVED drafts can be published — DRAFT is refused.
 * - The platform character limit is re-checked at publish time; the
 *   approved text is never silently truncated.
 * - Scheduled posts re-check the content hash: if the draft changed
 *   since scheduling, the post is CANCELLED, never published stale.
 */
interface PublishService {
    /** Loads a draft by id (for tool previews and gate checks). */
    suspend fun getDraft(draftId: Long): ContentDraft?

    /**
     * Publishes an APPROVED draft right now and marks it PUBLISHED.
     * Refuses DRAFT status, unknown/unsupported platforms, over-limit
     * text, and missing connections with a plain-language error.
     */
    suspend fun publishDraftNow(draftId: Long, imageUrl: String? = null): JarvisResult<PublishResult>

    /**
     * Publishes a scheduled post (worker path). Re-checks that the
     * draft is still APPROVED and byte-identical to schedule time; on
     * any mismatch the scheduled post is CANCELLED (not published) and
     * a failure is returned. On success the scheduled post is marked
     * PUBLISHED with the post URL and the draft is marked PUBLISHED.
     * On a publish failure the scheduled post is marked FAILED with
     * the reason, so Zaid can retry it from the Scheduled screen.
     */
    suspend fun publishScheduled(scheduledPostId: Long): JarvisResult<PublishResult>
}

/** No-op publish service: every publish fails plainly. */
class NoOpPublishService : PublishService {
    override suspend fun getDraft(draftId: Long): ContentDraft? = null

    override suspend fun publishDraftNow(
        draftId: Long,
        imageUrl: String?,
    ): JarvisResult<PublishResult> =
        JarvisResult.Failure("Social publishing is not available in this build.")

    override suspend fun publishScheduled(scheduledPostId: Long): JarvisResult<PublishResult> =
        JarvisResult.Failure("Social publishing is not available in this build.")
}

/**
 * Schedules posts for later publication via WorkManager. Implemented
 * in :app (WorkManagerSocialScheduler). The scheduler only stores the
 * schedule and enqueues the work — the actual publish (and all gate
 * re-checks) happen in [PublishService.publishScheduled] at run time.
 */
interface SocialScheduler {
    /**
     * Schedules an APPROVED draft for [scheduledAtMillis] (must be at
     * least 5 minutes in the future). [contentHash] is the SHA-256 of
     * the draft body at schedule time. Returns the saved scheduled post.
     */
    suspend fun schedule(
        draftId: Long,
        platform: SocialPlatform,
        accountHandle: String,
        scheduledAtMillis: Long,
        contentHash: String,
        imageUrl: String? = null,
    ): JarvisResult<ScheduledPost>

    /** Cancels a SCHEDULED post (also cancels its WorkManager job). */
    suspend fun cancel(scheduledPostId: Long): JarvisResult<Unit>

    /** All scheduled posts, newest first. */
    suspend fun listAll(): List<ScheduledPost>

    /** One scheduled post by id, or null. */
    suspend fun getById(scheduledPostId: Long): ScheduledPost?

    /** Deletes a scheduled-post row (used after a successful retry of a failed post). */
    suspend fun delete(scheduledPostId: Long)
}

/** No-op scheduler: scheduling fails plainly; lists are empty. */
class NoOpSocialScheduler : SocialScheduler {
    override suspend fun schedule(
        draftId: Long,
        platform: SocialPlatform,
        accountHandle: String,
        scheduledAtMillis: Long,
        contentHash: String,
        imageUrl: String?,
    ): JarvisResult<ScheduledPost> =
        JarvisResult.Failure("Scheduling is not available in this build.")

    override suspend fun cancel(scheduledPostId: Long): JarvisResult<Unit> =
        JarvisResult.Failure("Scheduling is not available in this build.")

    override suspend fun listAll(): List<ScheduledPost> = emptyList()

    override suspend fun getById(scheduledPostId: Long): ScheduledPost? = null

    override suspend fun delete(scheduledPostId: Long) = Unit
}
