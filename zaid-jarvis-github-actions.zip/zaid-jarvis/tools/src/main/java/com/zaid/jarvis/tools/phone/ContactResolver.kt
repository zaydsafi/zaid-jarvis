package com.zaid.jarvis.tools.phone

/**
 * Resolves a contact name to a phone number (Phase 5).
 *
 * Pure Kotlin, no Android APIs — the caller supplies the candidate
 * contacts (from [PhoneDevice.searchContacts]) and this decides:
 * a single clear match, several candidates Zaid must choose between,
 * or no match at all. **Jarvis never guesses**: when several contacts
 * score equally well, the result is [Resolution.Ambiguous] and the
 * planner asks Zaid to pick one.
 */
object ContactResolver {

    sealed interface Resolution {
        /** Exactly one clear match. */
        data class Single(val contact: Contact) : Resolution

        /** Several equally good matches — Zaid must choose (max 5 shown). */
        data class Ambiguous(val candidates: List<Contact>) : Resolution

        /** No contact matched. */
        data object None : Resolution
    }

    /**
     * Resolves [query] against [contacts]. Ranking, best first:
     * exact name match → name starts with the query → a name word
     * starts with the query → name contains the query. Within a rank,
     * a shorter name wins (a closer match). Ties at the best rank are
     * ambiguous.
     */
    fun resolve(query: String, contacts: List<Contact>): Resolution {
        val q = query.trim().lowercase()
        if (q.isEmpty() || contacts.isEmpty()) return Resolution.None

        val scored = contacts.mapNotNull { contact ->
            score(q, contact.name.lowercase())?.let { contact to it }
        }
        if (scored.isEmpty()) return Resolution.None

        val best = scored.minByOrNull { it.second }!!.second
        val winners = scored.filter { it.second == best }
            .sortedBy { it.first.name.length }
            .map { it.first }
        return when {
            winners.size == 1 -> Resolution.Single(winners.single())
            else -> Resolution.Ambiguous(winners.take(5))
        }
    }

    /** Lower is better; null means "no match at all". */
    private fun score(query: String, name: String): Int? = when {
        name == query -> 0
        name.startsWith(query) -> 1
        name.split(" ").any { it.startsWith(query) } -> 2
        name.contains(query) -> 3
        else -> null
    }

    /** True when [text] already looks like a phone number (not a name). */
    fun isPhoneNumber(text: String): Boolean {
        val digits = text.filter { it.isDigit() }
        if (digits.length < 7) return false
        return text.trim().all { it.isDigit() || it in " +()-" }
    }

    /** Formats candidates for a "which one?" message to Zaid. */
    fun formatCandidates(candidates: List<Contact>): String =
        candidates.joinToString("\n") { "• ${it.name} — ${it.phoneNumber}" }
}
