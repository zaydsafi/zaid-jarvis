package com.zaid.jarvis.tools.phone

import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.JarvisTool
import com.zaid.jarvis.tools.ToolOutcome
import com.zaid.jarvis.tools.ToolSchema
import com.zaid.jarvis.tools.boolParam
import com.zaid.jarvis.tools.intParam
import com.zaid.jarvis.tools.optStringParam
import com.zaid.jarvis.tools.stringParam
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

// ─────────────────────────────────────────────────────────────────────────────
// Tier 1 phone tools (Phase 5): reversible. Approval card each time.
// Every tool records the previous device state in its undo data, so the
// Audit Log screen can offer a real Undo. A no-op (setting a value that
// is already set) records no undo data — nothing changed, so there is
// nothing to reverse.
// ─────────────────────────────────────────────────────────────────────────────

/** Parses undo JSON produced by these tools; null when absent or malformed. */
private fun parseUndoData(undoData: String?): JsonObject? =
    undoData?.let { runCatching { Json.parseToJsonElement(it).jsonObject }.getOrNull() }

private fun JsonObject.boolValue(name: String): Boolean? =
    this[name]?.let { runCatching { it.jsonPrimitive.content.toBooleanStrict() }.getOrNull() }

private fun JsonObject.intValue(name: String): Int? =
    this[name]?.let { runCatching { it.jsonPrimitive.content.toInt() }.getOrNull() }

private fun JsonObject.stringValue(name: String): String? =
    this[name]?.let { runCatching { it.jsonPrimitive.content }.getOrNull() }

/** Flashlight on/off via the camera torch. Needs the CAMERA permission. */
class SetFlashlightTool(private val device: PhoneDevice) : JarvisTool {
    override val name: String = "set_flashlight"
    override val description: String = "Turn the flashlight (torch) on or off."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = listOf("android.permission.CAMERA")

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("enabled", "boolean", "true to turn the flashlight on, false to turn it off."),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val on = params.boolParam("enabled")
        val current = (device.isFlashlightOn() as? JarvisResult.Success)?.value
        val currentText = when (current) {
            true -> "currently on"
            false -> "currently off"
            null -> "current state unknown"
        }
        return when (on) {
            true -> "Turn flashlight ON ($currentText)."
            false -> "Turn flashlight OFF ($currentText)."
            null -> "Change the flashlight (missing 'enabled' parameter)."
        }
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val on = params.boolParam("enabled")
            ?: return JarvisResult.Failure("set_flashlight needs an 'enabled' parameter (true/false)")
        if (!device.hasPermission("android.permission.CAMERA")) {
            return JarvisResult.Failure(
                "Jarvis needs camera permission to use the flashlight. " +
                    "Grant it in Settings → App permissions → Camera, then try again.",
            )
        }
        return when (val result = device.setFlashlight(on)) {
            is JarvisResult.Success -> {
                val previous = result.value
                if (previous == on) {
                    JarvisResult.Success(
                        ToolOutcome("Flashlight is already ${if (on) "on" else "off"}."),
                    )
                } else {
                    JarvisResult.Success(
                        ToolOutcome(
                            message = "Flashlight turned ${if (on) "on" else "off"}.",
                            undoData = buildJsonObject { put("previousEnabled", previous) }.toString(),
                            undoDescription = "Turn flashlight ${if (previous) "on" else "off"} again.",
                        ),
                    )
                }
            }
            is JarvisResult.Failure -> result
        }
    }

    override val supportsUndo: Boolean = true

    override suspend fun undoPreview(params: JsonObject, undoData: String?): String {
        val previous = parseUndoData(undoData)?.boolValue("previousEnabled")
        return "Turn flashlight ${if (previous == true) "ON" else "OFF"} again (undo)."
    }

    override suspend fun undo(params: JsonObject, undoData: String?): JarvisResult<ToolOutcome> {
        val previous = parseUndoData(undoData)?.boolValue("previousEnabled")
            ?: return JarvisResult.Failure("Cannot undo: the previous flashlight state is unknown.")
        return when (val result = device.setFlashlight(previous)) {
            is JarvisResult.Success ->
                JarvisResult.Success(ToolOutcome("Flashlight turned ${if (previous) "on" else "off"} again."))
            is JarvisResult.Failure -> result
        }
    }
}

/** Volume for one audio stream. Validates the level against the stream's max. */
class SetVolumeTool(private val device: PhoneDevice) : JarvisTool {
    override val name: String = "set_volume"
    override val description: String = "Set the volume of an audio stream (media, alarm, ring, notification, call, system)."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec(
            "stream", "string",
            "Which volume: media, alarm, ring, notification, call, or system.",
            enumValues = listOf("media", "alarm", "ring", "notification", "call", "system"),
        ),
        ToolSchema.ParamSpec("level", "integer", "The new volume level (0 up to the stream's maximum)."),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val stream = params.stringParam("stream")?.let { VolumeStream.fromName(it) }
            ?: return "Set volume: unknown stream “${params.stringParam("stream") ?: "?"}” " +
                "(valid: media, alarm, ring, notification, call, system)."
        val level = params.intParam("level")
            ?: return "Set ${stream.displayName.lowercase()} volume (missing 'level' parameter)."
        val info = (device.volumeInfo(stream) as? JarvisResult.Success)?.value
        return if (info == null) {
            "Set ${stream.displayName.lowercase()} volume to $level."
        } else {
            "Set ${stream.displayName.lowercase()} volume to $level/${info.maxLevel} (was ${info.level}/${info.maxLevel})."
        }
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val stream = params.stringParam("stream")?.let { VolumeStream.fromName(it) }
            ?: return JarvisResult.Failure(
                "Unknown volume stream “${params.stringParam("stream") ?: "?"}”. " +
                    "Valid streams: media, alarm, ring, notification, call, system.",
            )
        val level = params.intParam("level")
            ?: return JarvisResult.Failure("set_volume needs a 'level' parameter")
        val info = when (val result = device.volumeInfo(stream)) {
            is JarvisResult.Success -> result.value
            is JarvisResult.Failure -> return result
        }
        if (level < 0 || level > info.maxLevel) {
            return JarvisResult.Failure(
                "${stream.displayName} volume only goes from 0 to ${info.maxLevel} — $level is out of range.",
            )
        }
        return when (val result = device.setVolume(stream, level)) {
            is JarvisResult.Success -> {
                val previous = result.value.level
                if (previous == level) {
                    JarvisResult.Success(
                        ToolOutcome("${stream.displayName} volume is already $level/${info.maxLevel}."),
                    )
                } else {
                    JarvisResult.Success(
                        ToolOutcome(
                            message = "${stream.displayName} volume set to $level/${info.maxLevel} (was $previous/${info.maxLevel}).",
                            undoData = buildJsonObject {
                                put("stream", stream.name)
                                put("previousLevel", previous)
                            }.toString(),
                            undoDescription = "Restore ${stream.displayName.lowercase()} volume to $previous/${info.maxLevel}.",
                        ),
                    )
                }
            }
            is JarvisResult.Failure -> result
        }
    }

    override val supportsUndo: Boolean = true

    override suspend fun undoPreview(params: JsonObject, undoData: String?): String {
        val data = parseUndoData(undoData)
        val stream = data?.stringValue("stream")?.let { runCatching { VolumeStream.valueOf(it) }.getOrNull() }
        val previous = data?.intValue("previousLevel")
        return if (stream != null && previous != null) {
            "Restore ${stream.displayName.lowercase()} volume to $previous (undo)."
        } else {
            "Restore the previous volume (undo)."
        }
    }

    override suspend fun undo(params: JsonObject, undoData: String?): JarvisResult<ToolOutcome> {
        val data = parseUndoData(undoData)
        val stream = data?.stringValue("stream")?.let { runCatching { VolumeStream.valueOf(it) }.getOrNull() }
        val previous = data?.intValue("previousLevel")
        if (stream == null || previous == null) {
            return JarvisResult.Failure("Cannot undo: the previous volume is unknown.")
        }
        return when (val result = device.setVolume(stream, previous)) {
            is JarvisResult.Success ->
                JarvisResult.Success(ToolOutcome("${stream.displayName} volume restored to $previous."))
            is JarvisResult.Failure -> result
        }
    }
}

/**
 * Screen brightness (0–100%). Needs "Modify system settings" — a special
 * access granted in system Settings, not a runtime permission. When it
 * is missing, the device layer returns a clear error naming it.
 */
class SetBrightnessTool(private val device: PhoneDevice) : JarvisTool {
    override val name: String = "set_brightness"
    override val description: String = "Set the screen brightness (0–100%)."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("percent", "integer", "The new brightness as a percentage, 0–100."),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val percent = params.intParam("percent")
            ?: return "Set screen brightness (missing 'percent' parameter)."
        val current = (device.brightnessPercent() as? JarvisResult.Success)?.value
        return if (current == null) {
            "Set screen brightness to $percent%."
        } else {
            "Set screen brightness to $percent% (was $current%)."
        }
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val percent = params.intParam("percent")
            ?: return JarvisResult.Failure("set_brightness needs a 'percent' parameter (0–100)")
        if (percent < 0 || percent > 100) {
            return JarvisResult.Failure("Brightness must be between 0 and 100% — $percent is out of range.")
        }
        return when (val result = device.setBrightnessPercent(percent)) {
            is JarvisResult.Success -> {
                val previous = result.value.previousPercent
                if (previous == percent) {
                    JarvisResult.Success(ToolOutcome("Screen brightness is already $percent%."))
                } else {
                    val autoNote = if (result.value.autoBrightnessOn) {
                        " Note: auto-brightness is on, so the change may not be visible " +
                            "until you turn auto-brightness off."
                    } else {
                        ""
                    }
                    JarvisResult.Success(
                        ToolOutcome(
                            message = "Screen brightness set to $percent% (was $previous%).$autoNote",
                            undoData = buildJsonObject { put("previousPercent", previous) }.toString(),
                            undoDescription = "Restore screen brightness to $previous%.",
                        ),
                    )
                }
            }
            is JarvisResult.Failure -> result
        }
    }

    override val supportsUndo: Boolean = true

    override suspend fun undoPreview(params: JsonObject, undoData: String?): String {
        val previous = parseUndoData(undoData)?.intValue("previousPercent")
        return if (previous != null) "Restore screen brightness to $previous% (undo)."
        else "Restore the previous brightness (undo)."
    }

    override suspend fun undo(params: JsonObject, undoData: String?): JarvisResult<ToolOutcome> {
        val previous = parseUndoData(undoData)?.intValue("previousPercent")
            ?: return JarvisResult.Failure("Cannot undo: the previous brightness is unknown.")
        return when (val result = device.setBrightnessPercent(previous)) {
            is JarvisResult.Success ->
                JarvisResult.Success(ToolOutcome("Screen brightness restored to $previous%."))
            is JarvisResult.Failure -> result
        }
    }
}

/**
 * Wi-Fi on/off. On Android 10+ apps cannot toggle Wi-Fi directly, so
 * Jarvis opens the Wi-Fi settings panel instead and Zaid toggles it
 * there — that path changes nothing, so it records no undo data.
 */
class SetWifiTool(private val device: PhoneDevice) : JarvisTool {
    override val name: String = "set_wifi"
    override val description: String = "Turn Wi-Fi on or off."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("enabled", "boolean", "true to turn Wi-Fi on, false to turn it off."),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val on = params.boolParam("enabled")
        val current = (device.isWifiEnabled() as? JarvisResult.Success)?.value
        val currentText = when (current) {
            true -> "currently on"
            false -> "currently off"
            null -> "current state unknown"
        }
        return when (on) {
            true -> "Turn Wi-Fi ON ($currentText)."
            false -> "Turn Wi-Fi OFF ($currentText)."
            null -> "Change Wi-Fi (missing 'enabled' parameter)."
        }
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val on = params.boolParam("enabled")
            ?: return JarvisResult.Failure("set_wifi needs an 'enabled' parameter (true/false)")
        return when (val result = device.setWifi(on)) {
            is JarvisResult.Success -> when (val toggle = result.value) {
                is WifiToggleResult.Changed -> {
                    if (toggle.previousEnabled == on) {
                        JarvisResult.Success(ToolOutcome("Wi-Fi is already ${if (on) "on" else "off"}."))
                    } else {
                        JarvisResult.Success(
                            ToolOutcome(
                                message = "Wi-Fi turned ${if (on) "on" else "off"}.",
                                undoData = buildJsonObject { put("previousEnabled", toggle.previousEnabled) }.toString(),
                                undoDescription = "Turn Wi-Fi ${if (toggle.previousEnabled) "on" else "off"} again.",
                            ),
                        )
                    }
                }
                WifiToggleResult.PanelOpened -> JarvisResult.Success(
                    ToolOutcome(
                        "Android 10 and later don't let apps switch Wi-Fi directly, " +
                            "so I opened the Wi-Fi settings panel — please toggle it there.",
                    ),
                )
            }
            is JarvisResult.Failure -> result
        }
    }

    override val supportsUndo: Boolean = true

    override suspend fun undoPreview(params: JsonObject, undoData: String?): String {
        val previous = parseUndoData(undoData)?.boolValue("previousEnabled")
        return "Turn Wi-Fi ${if (previous == true) "ON" else "OFF"} again (undo)."
    }

    override suspend fun undo(params: JsonObject, undoData: String?): JarvisResult<ToolOutcome> {
        val previous = parseUndoData(undoData)?.boolValue("previousEnabled")
            ?: return JarvisResult.Failure("Cannot undo: the previous Wi-Fi state is unknown.")
        return when (val result = device.setWifi(previous)) {
            is JarvisResult.Success -> when (result.value) {
                is WifiToggleResult.Changed ->
                    JarvisResult.Success(ToolOutcome("Wi-Fi turned ${if (previous) "on" else "off"} again."))
                WifiToggleResult.PanelOpened -> JarvisResult.Success(
                    ToolOutcome(
                        "I opened the Wi-Fi settings panel — please toggle Wi-Fi " +
                            "${if (previous) "on" else "off"} there (Android won't let apps do it directly).",
                    ),
                )
            }
            is JarvisResult.Failure -> result
        }
    }
}

/**
 * Bluetooth on/off. Needs BLUETOOTH_CONNECT (Android 12+). On Android
 * 13+, turning Bluetooth on shows the system's own confirmation dialog.
 */
class SetBluetoothTool(private val device: PhoneDevice) : JarvisTool {
    override val name: String = "set_bluetooth"
    override val description: String = "Turn Bluetooth on or off."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> =
        listOf("android.permission.BLUETOOTH_CONNECT")

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("enabled", "boolean", "true to turn Bluetooth on, false to turn it off."),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val on = params.boolParam("enabled")
        val current = (device.isBluetoothEnabled() as? JarvisResult.Success)?.value
        val currentText = when (current) {
            true -> "currently on"
            false -> "currently off"
            null -> "current state unknown"
        }
        return when (on) {
            true -> "Turn Bluetooth ON ($currentText)."
            false -> "Turn Bluetooth OFF ($currentText)."
            null -> "Change Bluetooth (missing 'enabled' parameter)."
        }
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val on = params.boolParam("enabled")
            ?: return JarvisResult.Failure("set_bluetooth needs an 'enabled' parameter (true/false)")
        if (!device.hasPermission("android.permission.BLUETOOTH_CONNECT")) {
            return JarvisResult.Failure(
                "Jarvis needs Bluetooth permission to switch Bluetooth. " +
                    "Grant it in Settings → App permissions → Bluetooth, then try again.",
            )
        }
        return when (val result = device.setBluetooth(on)) {
            is JarvisResult.Success -> when (val toggle = result.value) {
                is BluetoothToggleResult.Changed -> {
                    if (toggle.previousEnabled == on) {
                        JarvisResult.Success(ToolOutcome("Bluetooth is already ${if (on) "on" else "off"}."))
                    } else {
                        JarvisResult.Success(
                            ToolOutcome(
                                message = "Bluetooth turned ${if (on) "on" else "off"}.",
                                undoData = buildJsonObject { put("previousEnabled", toggle.previousEnabled) }.toString(),
                                undoDescription = "Turn Bluetooth ${if (toggle.previousEnabled) "on" else "off"} again.",
                            ),
                        )
                    }
                }
                BluetoothToggleResult.EnableDialogOpened -> JarvisResult.Success(
                    ToolOutcome(
                        "I asked Android to show the “turn on Bluetooth?” dialog — " +
                            "please confirm it there.",
                    ),
                )
            }
            is JarvisResult.Failure -> result
        }
    }

    override val supportsUndo: Boolean = true

    override suspend fun undoPreview(params: JsonObject, undoData: String?): String {
        val previous = parseUndoData(undoData)?.boolValue("previousEnabled")
        return "Turn Bluetooth ${if (previous == true) "ON" else "OFF"} again (undo)."
    }

    override suspend fun undo(params: JsonObject, undoData: String?): JarvisResult<ToolOutcome> {
        val previous = parseUndoData(undoData)?.boolValue("previousEnabled")
            ?: return JarvisResult.Failure("Cannot undo: the previous Bluetooth state is unknown.")
        return when (val result = device.setBluetooth(previous)) {
            is JarvisResult.Success -> when (result.value) {
                is BluetoothToggleResult.Changed ->
                    JarvisResult.Success(ToolOutcome("Bluetooth turned ${if (previous) "on" else "off"} again."))
                BluetoothToggleResult.EnableDialogOpened -> JarvisResult.Success(
                    ToolOutcome("I asked Android to show the “turn on Bluetooth?” dialog — please confirm it there."),
                )
            }
            is JarvisResult.Failure -> result
        }
    }
}

/**
 * Set an alarm in the system Clock app. The alarm is created by the
 * Clock app itself (AlarmClock intent) — Jarvis only pre-fills it.
 *
 * Undo honesty: Android has no API for an app to cancel an alarm it
 * created through the Clock app, so undo opens the Clock app and Zaid
 * deletes the alarm there. The undo message says exactly that.
 */
class SetAlarmTool(private val device: PhoneDevice) : JarvisTool {
    override val name: String = "set_alarm"
    override val description: String = "Set an alarm in the Clock app."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("hour", "integer", "Hour of the alarm, 0–23."),
        ToolSchema.ParamSpec("minute", "integer", "Minute of the alarm, 0–59."),
        ToolSchema.ParamSpec("label", "string", "Optional label for the alarm.", required = false),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val hour = params.intParam("hour")
        val minute = params.intParam("minute")
        if (hour == null || minute == null) {
            return "Set an alarm (missing 'hour' and/or 'minute' parameter)."
        }
        val label = params.optStringParam("label")
        val labelText = if (label == null) "" else " (“$label”)"
        return "Set an alarm for ${formatTime(hour, minute)}$labelText in the Clock app."
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val hour = params.intParam("hour")
        val minute = params.intParam("minute")
        if (hour == null || minute == null) {
            return JarvisResult.Failure("set_alarm needs 'hour' (0–23) and 'minute' (0–59) parameters")
        }
        if (hour !in 0..23 || minute !in 0..59) {
            return JarvisResult.Failure("Alarm time $hour:$minute is invalid — hour must be 0–23, minute 0–59.")
        }
        val label = params.optStringParam("label") ?: ""
        return when (val result = device.launch(SystemAction.SetAlarm(hour, minute, label))) {
            is JarvisResult.Success -> JarvisResult.Success(
                ToolOutcome(
                    message = "Alarm set for ${formatTime(hour, minute)}" +
                        (if (label.isBlank()) "." else " (“$label”)."),
                    // Marker payload: undo opens the Clock app (see below).
                    undoData = buildJsonObject {
                        put("hour", hour)
                        put("minute", minute)
                    }.toString(),
                    undoDescription = "Open the Clock app to delete the ${formatTime(hour, minute)} alarm " +
                        "(Android can't cancel alarms directly).",
                ),
            )
            is JarvisResult.Failure -> result
        }
    }

    override val supportsUndo: Boolean = true

    override suspend fun undoPreview(params: JsonObject, undoData: String?): String {
        val data = parseUndoData(undoData)
        val hour = data?.intValue("hour") ?: params.intParam("hour")
        val minute = data?.intValue("minute") ?: params.intParam("minute")
        val whenText = if (hour != null && minute != null) " the ${formatTime(hour, minute)} alarm" else " the alarm"
        return "Open the Clock app so you can delete$whenText (Android can't cancel alarms directly)."
    }

    override suspend fun undo(params: JsonObject, undoData: String?): JarvisResult<ToolOutcome> {
        return when (val result = device.launch(SystemAction.OpenClockApp)) {
            is JarvisResult.Success -> JarvisResult.Success(
                ToolOutcome(
                    "Opened the Clock app — please delete the alarm there. " +
                        "Android doesn't let apps cancel alarms directly, so this is as far as undo can go.",
                ),
            )
            is JarvisResult.Failure -> result
        }
    }

    private fun formatTime(hour: Int, minute: Int): String =
        "%02d:%02d".format(hour, minute)
}

/**
 * Set a timer in the system Clock app. Same undo limitation as alarms:
 * undo opens the Clock app for manual removal.
 */
class SetTimerTool(private val device: PhoneDevice) : JarvisTool {
    override val name: String = "set_timer"
    override val description: String = "Set a timer in the Clock app."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("seconds", "integer", "Timer length in seconds (1–86400)."),
        ToolSchema.ParamSpec("label", "string", "Optional label for the timer.", required = false),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val seconds = params.intParam("seconds")
            ?: return "Set a timer (missing 'seconds' parameter)."
        val label = params.optStringParam("label")
        val labelText = if (label == null) "" else " (“$label”)"
        return "Set a ${formatDuration(seconds)} timer$labelText in the Clock app."
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val seconds = params.intParam("seconds")
            ?: return JarvisResult.Failure("set_timer needs a 'seconds' parameter")
        if (seconds !in 1..86_400) {
            return JarvisResult.Failure("Timer length must be between 1 second and 24 hours (86400 seconds).")
        }
        val label = params.optStringParam("label") ?: ""
        return when (val result = device.launch(SystemAction.SetTimer(seconds, label))) {
            is JarvisResult.Success -> JarvisResult.Success(
                ToolOutcome(
                    message = "Timer set for ${formatDuration(seconds)}" +
                        (if (label.isBlank()) "." else " (“$label”)."),
                    undoData = buildJsonObject { put("seconds", seconds) }.toString(),
                    undoDescription = "Open the Clock app to cancel the ${formatDuration(seconds)} timer " +
                        "(Android can't cancel timers directly).",
                ),
            )
            is JarvisResult.Failure -> result
        }
    }

    override val supportsUndo: Boolean = true

    override suspend fun undoPreview(params: JsonObject, undoData: String?): String =
        "Open the Clock app so you can cancel the timer (Android can't cancel timers directly)."

    override suspend fun undo(params: JsonObject, undoData: String?): JarvisResult<ToolOutcome> {
        return when (val result = device.launch(SystemAction.OpenClockApp)) {
            is JarvisResult.Success -> JarvisResult.Success(
                ToolOutcome(
                    "Opened the Clock app — please cancel the timer there. " +
                        "Android doesn't let apps cancel timers directly, so this is as far as undo can go.",
                ),
            )
            is JarvisResult.Failure -> result
        }
    }

    private fun formatDuration(seconds: Int): String = when {
        seconds % 3600 == 0 -> {
            val hours = seconds / 3600
            "$hours hour${if (hours == 1) "" else "s"}"
        }
        seconds % 60 == 0 -> {
            val minutes = seconds / 60
            "$minutes minute${if (minutes == 1) "" else "s"}"
        }
        else -> "$seconds seconds"
    }
}

/**
 * Launch an app by name or package. Ambiguous names return the candidate
 * list so the planner can ask Zaid — Jarvis never guesses which app.
 * Not undoable: an opened app cannot be "un-opened".
 */
class OpenAppTool(private val device: PhoneDevice) : JarvisTool {
    override val name: String = "open_app"
    override val description: String = "Open an installed app by name or package."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject =
        ToolSchema.singleStringParam("query", "The app name (e.g. \"Maps\") or package (e.g. \"com.google.android.apps.maps\").")

    override suspend fun dryRun(params: JsonObject): String {
        val query = params.stringParam("query") ?: "?"
        return "Open the app matching “$query”."
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val query = params.stringParam("query")
            ?: return JarvisResult.Failure("open_app needs a 'query' parameter")
        return when (val result = device.listApps(query)) {
            is JarvisResult.Success -> {
                val apps = result.value
                val exactPackage = apps.firstOrNull { it.packageName.equals(query, ignoreCase = true) }
                val exactName = apps.firstOrNull { it.name.equals(query, ignoreCase = true) }
                val chosen = exactPackage ?: exactName ?: apps.singleOrNull()
                if (chosen != null) {
                    when (val launch = device.launch(SystemAction.OpenApp(chosen.packageName))) {
                        is JarvisResult.Success ->
                            JarvisResult.Success(ToolOutcome("Opened ${chosen.name}."))
                        is JarvisResult.Failure -> launch
                    }
                } else if (apps.isEmpty()) {
                    JarvisResult.Failure("No installed app matches “$query”.")
                } else {
                    // Ambiguous: list the candidates so the planner asks Zaid.
                    val lines = apps.take(5).joinToString("\n") { "• ${it.name}" }
                    JarvisResult.Success(
                        ToolOutcome("Several apps match “$query” — which one?\n$lines"),
                    )
                }
            }
            is JarvisResult.Failure -> result
        }
    }
}

/**
 * Do Not Disturb mode. Needs Notification Policy access — a special
 * access granted in system Settings. When missing, the device layer
 * returns a clear error naming it.
 */
class SetDoNotDisturbTool(private val device: PhoneDevice) : JarvisTool {
    override val name: String = "set_do_not_disturb"
    override val description: String = "Set Do Not Disturb mode (off, alarms only, priority only, total silence)."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec(
            "mode", "string",
            "The mode: off, alarms_only, priority_only, or total_silence.",
            enumValues = listOf("off", "alarms_only", "priority_only", "total_silence"),
        ),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val mode = params.stringParam("mode")?.let { DndMode.fromName(it) }
            ?: return "Set Do Not Disturb: unknown mode “${params.stringParam("mode") ?: "?"}” " +
                "(valid: off, alarms_only, priority_only, total_silence)."
        val current = (device.dndMode() as? JarvisResult.Success)?.value
        val currentText = if (current == null) "" else " (currently ${current.displayName})"
        return "Set Do Not Disturb to ${mode.displayName}$currentText."
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val mode = params.stringParam("mode")?.let { DndMode.fromName(it) }
            ?: return JarvisResult.Failure(
                "Unknown Do Not Disturb mode “${params.stringParam("mode") ?: "?"}”. " +
                    "Valid modes: off, alarms_only, priority_only, total_silence.",
            )
        return when (val result = device.setDndMode(mode)) {
            is JarvisResult.Success -> {
                val previous = result.value
                if (previous == mode) {
                    JarvisResult.Success(
                        ToolOutcome("Do Not Disturb is already ${mode.displayName}."),
                    )
                } else {
                    JarvisResult.Success(
                        ToolOutcome(
                            message = "Do Not Disturb set to ${mode.displayName} (was ${previous.displayName}).",
                            undoData = buildJsonObject { put("previousMode", previous.name) }.toString(),
                            undoDescription = "Restore Do Not Disturb to ${previous.displayName}.",
                        ),
                    )
                }
            }
            is JarvisResult.Failure -> result
        }
    }

    override val supportsUndo: Boolean = true

    override suspend fun undoPreview(params: JsonObject, undoData: String?): String {
        val previous = parseUndoData(undoData)?.stringValue("previousMode")
            ?.let { runCatching { DndMode.valueOf(it) }.getOrNull() }
        return if (previous != null) "Restore Do Not Disturb to ${previous.displayName} (undo)."
        else "Restore the previous Do Not Disturb mode (undo)."
    }

    override suspend fun undo(params: JsonObject, undoData: String?): JarvisResult<ToolOutcome> {
        val previous = parseUndoData(undoData)?.stringValue("previousMode")
            ?.let { runCatching { DndMode.valueOf(it) }.getOrNull() }
            ?: return JarvisResult.Failure("Cannot undo: the previous Do Not Disturb mode is unknown.")
        return when (val result = device.setDndMode(previous)) {
            is JarvisResult.Success ->
                JarvisResult.Success(ToolOutcome("Do Not Disturb restored to ${previous.displayName}."))
            is JarvisResult.Failure -> result
        }
    }
}
