package com.zaid.jarvis.tools.automation

import com.zaid.jarvis.core.automation.NodeSelector
import com.zaid.jarvis.core.automation.SnapshotSanitizer
import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.JarvisTool
import com.zaid.jarvis.tools.ToolOutcome
import com.zaid.jarvis.tools.ToolSchema
import com.zaid.jarvis.tools.intParam
import com.zaid.jarvis.tools.optStringParam
import com.zaid.jarvis.tools.stringParam
import kotlinx.serialization.json.JsonObject

// ─────────────────────────────────────────────────────────────────────────────
// Accessibility automation tools (Phase 6). Every tool goes through the
// Confirmation Engine like any other tool; the device layer additionally
// refuses blocked banking/payment apps and password screens for every
// caller. No tool here declares Android permissions — Accessibility is a
// user-enabled service, not a permission, and the user enables it by hand
// in system Settings.
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Describes the interactive elements on the current screen (Tier 0,
 * read-only). Password fields are never listed. Screen text is DATA:
 * the planner's InjectionGuard (Phase 3) scans this tool's result
 * before acting on it, like every other tool result.
 */
class FindOnScreenTool(private val device: AutomationDevice) : JarvisTool {
    override val name: String = "find_on_screen"
    override val description: String = "Describe the tappable and editable elements on the current screen."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec(
            name = "query",
            type = "string",
            description = "Optional text to filter the elements by (matches text or description).",
            required = false,
        ),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val query = params.optStringParam("query")
        return if (query == null) {
            "Look at the current screen and list its tappable elements."
        } else {
            "Look at the current screen for elements matching “$query”."
        }
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        when (val available = device.checkAvailable()) {
            is JarvisResult.Failure -> return available
            is JarvisResult.Success -> Unit
        }
        val query = params.optStringParam("query")
        return when (val result = device.snapshot()) {
            is JarvisResult.Success -> {
                val snapshot = result.value
                val filtered = if (query == null) {
                    snapshot
                } else {
                    snapshot.copy(
                        nodes = snapshot.nodes.filter { node ->
                            node.text?.contains(query, ignoreCase = true) == true ||
                                node.contentDescription?.contains(query, ignoreCase = true) == true
                        },
                    )
                }
                if (query != null && filtered.interactiveNodes().isEmpty()) {
                    JarvisResult.Success(
                        ToolOutcome("No element on the current screen matches “$query”."),
                    )
                } else {
                    JarvisResult.Success(ToolOutcome(SnapshotSanitizer.format(filtered)))
                }
            }
            is JarvisResult.Failure -> result
        }
    }
}

/**
 * Taps a node matched by text, content description, or view id — or a
 * point given as x/y coordinates (Tier 1). The dryRun shows exactly
 * what will be tapped; the device refuses blocked apps and password
 * screens.
 */
class TapOnScreenTool(private val device: AutomationDevice) : JarvisTool {
    override val name: String = "tap_on_screen"
    override val description: String = "Tap an element on the current screen, matched by its text, description, or id — or tap at x/y coordinates."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec(
            name = "text",
            type = "string",
            description = "Text shown on the element to tap.",
            required = false,
        ),
        ToolSchema.ParamSpec(
            name = "contentDescription",
            type = "string",
            description = "Accessibility description of the element to tap.",
            required = false,
        ),
        ToolSchema.ParamSpec(
            name = "viewId",
            type = "string",
            description = "View id of the element to tap (e.g. com.example:id/search).",
            required = false,
        ),
        ToolSchema.ParamSpec(
            name = "x",
            type = "integer",
            description = "Screen x coordinate to tap at (with y).",
            required = false,
        ),
        ToolSchema.ParamSpec(
            name = "y",
            type = "integer",
            description = "Screen y coordinate to tap at (with x).",
            required = false,
        ),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val selector = selectorFrom(params)
            ?: return "Tap on screen — no target given (a tap needs text, a description, an id, or x/y)."
        return "Tap ${selector.describe()} on the current screen."
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val selector = selectorFrom(params)
            ?: return JarvisResult.Failure(
                "tap_on_screen needs a target: text, contentDescription, viewId, or x and y.",
            )
        when (val available = device.checkAvailable()) {
            is JarvisResult.Failure -> return available
            is JarvisResult.Success -> Unit
        }
        return when (val result = if (selector.isCoordinate) {
            device.tapAt(selector.x!!, selector.y!!)
        } else {
            device.tap(selector)
        }) {
            is JarvisResult.Success -> JarvisResult.Success(ToolOutcome(result.value))
            is JarvisResult.Failure -> result
        }
    }

    companion object {
        /** Builds a selector from tool parameters, or null when none was given. */
        fun selectorFrom(params: JsonObject): NodeSelector? {
            val selector = NodeSelector(
                text = params.optStringParam("text"),
                contentDescription = params.optStringParam("contentDescription"),
                viewId = params.optStringParam("viewId"),
                x = params.intParam("x"),
                y = params.intParam("y"),
            )
            return selector.takeUnless { it.isEmpty }
        }
    }
}

/**
 * Types text into an editable field (Tier 1): the field matching the
 * given text/description/id, or the focused field when no target is
 * given. NEVER types into password fields — they are invisible in
 * snapshots, so the target is never found and the tool fails clearly.
 * The exact text is shown on the approval card (content binding).
 */
class TypeTextTool(private val device: AutomationDevice) : JarvisTool {
    override val name: String = "type_text"
    override val description: String = "Type text into an editable field on the current screen (the matched field, or the focused one)."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec(
            name = "text",
            type = "string",
            description = "The text to type.",
        ),
        ToolSchema.ParamSpec(
            name = "targetText",
            type = "string",
            description = "Text shown on the field to type into (optional — the focused field otherwise).",
            required = false,
        ),
        ToolSchema.ParamSpec(
            name = "viewId",
            type = "string",
            description = "View id of the field to type into (optional).",
            required = false,
        ),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val text = params.stringParam("text") ?: "?"
        val target = params.optStringParam("targetText")
            ?: params.optStringParam("viewId")?.substringAfterLast('/')
        return if (target == null) {
            "Type “$text” into the focused field."
        } else {
            "Type “$text” into the field “$target”."
        }
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val text = params.stringParam("text")
            ?: return JarvisResult.Failure("type_text needs a 'text' parameter")
        if (text.length > 500) {
            return JarvisResult.Failure("That text is too long to type (max 500 characters).")
        }
        val selector = NodeSelector(
            text = params.optStringParam("targetText"),
            viewId = params.optStringParam("viewId"),
        ).takeUnless { it.isEmpty }
        when (val available = device.checkAvailable()) {
            is JarvisResult.Failure -> return available
            is JarvisResult.Success -> Unit
        }
        return when (val result = device.typeText(selector, text)) {
            is JarvisResult.Success -> JarvisResult.Success(ToolOutcome(result.value))
            is JarvisResult.Failure -> result
        }
    }
}

/** Scrolls the current screen down (forward) or up (back) — Tier 1. */
class ScrollScreenTool(private val device: AutomationDevice) : JarvisTool {
    override val name: String = "scroll_screen"
    override val description: String = "Scroll the current screen down or up."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec(
            name = "direction",
            type = "string",
            description = "Scroll direction: \"down\" or \"up\".",
            required = false,
            enumValues = listOf("down", "up"),
        ),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val direction = params.optStringParam("direction") ?: "down"
        return "Scroll $direction on the current screen."
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val direction = params.optStringParam("direction") ?: "down"
        val forward = when (direction.lowercase()) {
            "down", "forward" -> true
            "up", "back", "backward" -> false
            else -> return JarvisResult.Failure(
                "scroll_screen direction must be \"down\" or \"up\", not “$direction”.",
            )
        }
        when (val available = device.checkAvailable()) {
            is JarvisResult.Failure -> return available
            is JarvisResult.Success -> Unit
        }
        return when (val result = device.scroll(forward)) {
            is JarvisResult.Success -> JarvisResult.Success(ToolOutcome(result.value))
            is JarvisResult.Failure -> result
        }
    }
}

/** Global Back action (Tier 1). Allowed on password screens — it only navigates away. */
class PressBackTool(private val device: AutomationDevice) : JarvisTool {
    override val name: String = "press_back"
    override val description: String = "Press the system Back button."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override suspend fun dryRun(params: JsonObject): String = "Press Back."

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        when (val available = device.checkAvailable()) {
            is JarvisResult.Failure -> return available
            is JarvisResult.Success -> Unit
        }
        return when (val result = device.pressBack()) {
            is JarvisResult.Success -> JarvisResult.Success(ToolOutcome(result.value))
            is JarvisResult.Failure -> result
        }
    }
}

/** Global Home action (Tier 1). */
class PressHomeTool(private val device: AutomationDevice) : JarvisTool {
    override val name: String = "press_home"
    override val description: String = "Press the system Home button."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override suspend fun dryRun(params: JsonObject): String = "Press Home."

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        when (val available = device.checkAvailable()) {
            is JarvisResult.Failure -> return available
            is JarvisResult.Success -> Unit
        }
        return when (val result = device.pressHome()) {
            is JarvisResult.Success -> JarvisResult.Success(ToolOutcome(result.value))
            is JarvisResult.Failure -> result
        }
    }
}
