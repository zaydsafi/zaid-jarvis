package com.zaid.jarvis.tools

import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.core.util.JarvisResult
import kotlinx.serialization.json.JsonObject

// ─────────────────────────────────────────────────────────────────────────────
// Phase 1 stubs + Phase 2 gate wiring. Real phone tools land in Phase 5
// (see phone/), automation in Phase 6. The Confirmation Engine (Phase 2)
// gates every tool call by risk tier — tools are never executed directly,
// only through GatedToolExecutor.
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Risk tiers from Master Prompt §6. The canonical definition moved to
 * :core in Phase 2 (see [RiskTier]); this alias keeps the Phase 1 name.
 */
typealias ToolRiskTier = RiskTier

/**
 * What a tool execution produces (Phase 5).
 *
 * [message] is what the planner and Zaid see. [undoData] is a JSON
 * string the tool captured during execution describing how to reverse
 * this exact action (e.g. the previous volume level) — null when the
 * action cannot be undone. [undoDescription] says in plain language
 * what undo would do. Both are stored on the audit entry by the
 * Confirmation Engine so the Audit Log screen can offer a real Undo.
 */
data class ToolOutcome(
    val message: String,
    val undoData: String? = null,
    val undoDescription: String? = null,
)

/**
 * Contract every Jarvis tool implements. Tools are typed, declare their
 * risk tier and required Android permissions, and can preview themselves
 * via [dryRun] so the Confirmation Engine can show Zaid exactly what
 * will happen before it happens.
 */
interface JarvisTool {
    val name: String
    val description: String
    val riskTier: ToolRiskTier
    val requiredPermissions: List<String>

    /**
     * JSON Schema for this tool's parameters (Master Prompt §4: "every
     * capability is a typed tool with name, JSON schema, risk tier,
     * required Android permissions and a dryRun() preview").
     * The planner sends this schema to the LLM so it knows what
     * arguments are valid; [validateParams] checks the LLM's arguments
     * against it before anything runs. Defaults to "no parameters".
     */
    val inputSchema: JsonObject
        get() = ToolSchema.noParams()

    /**
     * The risk tier for this specific call (Phase 6). Defaults to
     * [riskTier]; tools whose risk depends on the parameters override
     * it — `run_macro` is Tier 2 when the macro taps or types in
     * another app, Tier 1 when it only scrolls, navigates, or waits.
     * The executor consults this (not [riskTier] directly) so the
     * approval card always matches what will actually run.
     */
    suspend fun tierFor(params: JsonObject): RiskTier = riskTier

    /** Human-readable preview of what this call would do, without doing it. */
    suspend fun dryRun(params: JsonObject): String

    /** Executes the tool. Only ever called after approval (Phase 2+). */
    suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome>

    /**
     * Whether this tool can reverse its own actions (Phase 5).
     * Read-only tools and tools whose effect leaves the device (calls,
     * messages, sharing) return false.
     */
    val supportsUndo: Boolean
        get() = false

    /**
     * Human-readable preview of what undoing this call would do, using
     * the [undoData] captured when the action ran. Shown on the
     * approval card for the undo itself — undo is a gated action too.
     */
    suspend fun undoPreview(params: JsonObject, undoData: String?): String =
        "Undo: $description"

    /**
     * Reverses the action described by [params] and [undoData].
     * Only called after approval, via [GatedToolExecutor.executeUndo].
     * Default: this tool does not support undo.
     */
    suspend fun undo(params: JsonObject, undoData: String?): JarvisResult<ToolOutcome> =
        JarvisResult.Failure("“$name” does not support undo.")

    /**
     * Rebuilds the parameters from content Zaid edited on the approval
     * card (Phase 5 content binding). The Confirmation Engine hands the
     * *approved* content to the executor; for tools whose payload is the
     * content itself (an SMS body, an email), executing with the
     * original parameters after Zaid edited the text would send the
     * wrong thing. Tools that support edits parse the edited preview
     * back into parameters here; tools that return null refuse edited
     * content — the executor fails with a clear message telling Zaid
     * to cancel and rephrase instead of running something he did not
     * approve.
     */
    fun paramsFromEditedContent(
        editedContent: String,
        originalParams: JsonObject,
    ): JsonObject? = null
}

/** Registry of all available tools. Provided by Hilt via [ToolsModule], pre-loaded with the built-in tools. */
class ToolRegistry {
    private val tools = mutableMapOf<String, JarvisTool>()

    fun register(tool: JarvisTool) {
        tools[tool.name] = tool
    }

    /** Removes a tool by name (Phase 10: disabling a plugin unregisters its tools immediately). */
    fun unregister(toolName: String) {
        tools.remove(toolName)
    }

    fun get(name: String): JarvisTool? = tools[name]

    fun all(): List<JarvisTool> = tools.values.toList()
}
