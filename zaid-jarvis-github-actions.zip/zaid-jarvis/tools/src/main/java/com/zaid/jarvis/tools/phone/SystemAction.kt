package com.zaid.jarvis.tools.phone

/**
 * A system action Jarvis asks Android to perform (Phase 5).
 *
 * These are pure data — the tool builds one, and the device layer
 * ([PhoneDevice.launch]) converts it into an Android Intent and starts
 * the system app that owns it. The tool itself never touches an Intent,
 * which keeps `:tools` pure Kotlin and lets tests assert exactly which
 * action a tool produced.
 *
 * **Safety rule (Master Prompt §6):** Tier 2 actions only ever *open*
 * the system app with the content pre-filled. The dialer opens with the
 * number in it — Zaid taps Call. The messaging app opens with the text
 * in it — Zaid taps Send. Nothing here places a call, sends a message,
 * or sends an email on its own. That is why the app deliberately does
 * NOT declare CALL_PHONE or SEND_SMS.
 */
sealed interface SystemAction {

    /** Open the dialer with [phoneNumber] pre-filled (never dials). */
    data class Dial(val phoneNumber: String) : SystemAction

    /** Open the messaging app with [phoneNumber] and [body] pre-filled. */
    data class SendSms(val phoneNumber: String, val body: String) : SystemAction

    /** Open the email app with [to], [subject], and [body] pre-filled. */
    data class SendEmail(
        val to: List<String>,
        val subject: String,
        val body: String,
    ) : SystemAction

    /** Open the system share sheet with [text]. */
    data class ShareText(val text: String, val title: String = "Share via Jarvis") : SystemAction

    /** Launch the app with this package name. */
    data class OpenApp(val packageName: String) : SystemAction

    /** Open the Clock app's "set alarm" screen, pre-filled. */
    data class SetAlarm(val hour: Int, val minute: Int, val label: String) : SystemAction

    /** Open the Clock app's "set timer" screen, pre-filled. */
    data class SetTimer(val seconds: Int, val label: String) : SystemAction

    /** Open the system Wi-Fi settings panel (Android 10+ toggle fallback). */
    data object OpenWifiPanel : SystemAction

    /** Show the system's "turn on Bluetooth?" dialog (Android 13+). */
    data object RequestBluetoothEnable : SystemAction

    /** Open the Clock app (used by alarm/timer undo — see PHASE5.md). */
    data object OpenClockApp : SystemAction
}
