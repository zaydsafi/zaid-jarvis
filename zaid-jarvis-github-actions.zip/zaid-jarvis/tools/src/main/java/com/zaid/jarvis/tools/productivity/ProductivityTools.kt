package com.zaid.jarvis.tools.productivity

import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.core.productivity.DueDateParser
import com.zaid.jarvis.core.productivity.FocusSession
import com.zaid.jarvis.core.productivity.Task
import com.zaid.jarvis.core.productivity.TaskPriority
import com.zaid.jarvis.core.productivity.TaskStatus
import com.zaid.jarvis.core.productivity.formatDuration
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.JarvisTool
import com.zaid.jarvis.tools.ToolOutcome
import com.zaid.jarvis.tools.ToolSchema
import com.zaid.jarvis.tools.intParam
import com.zaid.jarvis.tools.intParamOr
import com.zaid.jarvis.tools.optStringParam
import com.zaid.jarvis.tools.stringParam
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import kotlinx.serialization.json.JsonObject

// ─────────────────────────────────────────────────────────────────────────────
// Productivity & wellness tools (Phase 9).
//
// Tasks and reminders are Tier 1 (reversible, local state); reads are
// Tier 0. Everything runs through GatedToolExecutor like every other
// tool — the approval card shows the exact task / time before anything
// changes. Due dates and reminder times come from Zaid's words via
// DueDateParser; anything the parser cannot understand is asked about,
// never guessed — the dry-run says so and execute refuses.
// ─────────────────────────────────────────────────────────────────────────────

/** Formats an epoch-millis time for approval cards and lists. */
internal fun formatTaskTime(epochMillis: Long): String {
    val dateTime = Instant.ofEpochMilli(epochMillis).atZone(ZoneId.systemDefault())
    return dateTime.format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.SHORT))
}

/** One task as a list line: "#3 · Buy milk · High · due Fri 20 Nov, 23:59 · OVERDUE". */
internal fun formatTaskLine(task: Task, nowMillis: Long): String {
    val due = task.dueAtMillis?.let { " · due ${formatTaskTime(it)}" } ?: ""
    val priority = if (task.priority != TaskPriority.MEDIUM) " · ${task.priority.displayName}" else ""
    val overdue = if (task.isOverdue(nowMillis)) " · OVERDUE" else ""
    val done = if (task.status == TaskStatus.DONE) " · done" else ""
    return "#${task.id} · ${task.title}$priority$due$overdue$done"
}

/** Creates a task (Tier 1). */
class CreateTaskTool(
    private val taskStore: TaskStore,
    private val nowMillis: () -> Long = { System.currentTimeMillis() },
) : JarvisTool {
    override val name: String = "create_task"
    override val description: String =
        "Create a task with a title, optional notes, an optional due date in plain words " +
            "(\"tomorrow\", \"next Monday\", \"Friday at 5pm\"), and an optional priority " +
            "(low, medium, high)."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("title", "string", "The task title."),
        ToolSchema.ParamSpec(
            name = "notes",
            type = "string",
            description = "Optional notes for the task.",
            required = false,
        ),
        ToolSchema.ParamSpec(
            name = "due",
            type = "string",
            description = "Optional due date in plain words: \"tomorrow\", \"next Monday\", " +
                "\"Friday at 5pm\", \"in 3 days\". A bare day means end of day (23:59).",
            required = false,
        ),
        ToolSchema.ParamSpec(
            name = "priority",
            type = "string",
            description = "Optional priority: low, medium (default), or high.",
            required = false,
            enumValues = listOf("low", "medium", "high"),
        ),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val title = params.stringParam("title")
            ?: return "Create a task — missing title."
        val duePhrase = params.optStringParam("due")
        val dueLine = if (duePhrase == null) {
            ""
        } else {
            val due = parseDue(duePhrase)
                ?: return "Create task “$title” — I couldn't understand the due date “$duePhrase”. " +
                    "Try \"tomorrow\", \"next Monday\", or \"Friday at 5pm\"."
            " · due ${formatTaskTime(due)}"
        }
        val priority = params.optStringParam("priority")?.let { TaskPriority.fromName(it) }
            ?: TaskPriority.MEDIUM
        val priorityLine = if (priority != TaskPriority.MEDIUM) " · ${priority.displayName} priority" else ""
        return "Create task: “$title”$priorityLine$dueLine"
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val title = params.stringParam("title")?.takeIf { it.isNotBlank() }
            ?: return JarvisResult.Failure("create_task needs a 'title' parameter.")
        val duePhrase = params.optStringParam("due")
        val due = if (duePhrase == null) {
            null
        } else {
            parseDue(duePhrase)
                ?: return JarvisResult.Failure(
                    "I couldn't understand the due date “$duePhrase”. " +
                        "Try \"tomorrow\", \"next Monday\", or \"Friday at 5pm\".",
                )
        }
        if (due != null && due < nowMillis()) {
            return JarvisResult.Failure(
                "That due date is in the past (${formatTaskTime(due)}). " +
                    "Pick a future date.",
            )
        }
        val priorityText = params.optStringParam("priority")
        val priority = if (priorityText == null) {
            TaskPriority.MEDIUM
        } else {
            TaskPriority.fromName(priorityText)
                ?: return JarvisResult.Failure(
                    "Unknown priority “$priorityText” (valid: low, medium, high).",
                )
        }
        val task = Task(
            title = title,
            notes = params.optStringParam("notes") ?: "",
            dueAtMillis = due,
            priority = priority,
        )
        return when (val saved = taskStore.create(task)) {
            is JarvisResult.Success -> {
                val dueLine = due?.let { " · due ${formatTaskTime(it)}" } ?: ""
                JarvisResult.Success(
                    ToolOutcome("Task #${saved.value} created: “$title”$dueLine"),
                )
            }
            is JarvisResult.Failure -> saved
        }
    }

    private fun parseDue(phrase: String): Long? {
        val now = ZonedDateTime.ofInstant(
            Instant.ofEpochMilli(nowMillis()),
            ZoneId.systemDefault(),
        )
        return DueDateParser.parse(phrase, now)
    }
}

/** Lists tasks (Tier 0, read-only). */
class ListTasksTool(
    private val taskStore: TaskStore,
    private val nowMillis: () -> Long = { System.currentTimeMillis() },
) : JarvisTool {
    override val name: String = "list_tasks"
    override val description: String =
        "List tasks. Filter by open (default), done, overdue, or all; optionally by priority."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec(
            name = "filter",
            type = "string",
            description = "Which tasks: open (default), done, overdue, or all.",
            required = false,
            enumValues = listOf("open", "done", "overdue", "all"),
        ),
        ToolSchema.ParamSpec(
            name = "priority",
            type = "string",
            description = "Optional priority filter: low, medium, or high.",
            required = false,
            enumValues = listOf("low", "medium", "high"),
        ),
    )

    override suspend fun dryRun(params: JsonObject): String = "List tasks."

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val now = nowMillis()
        val filter = params.optStringParam("filter")?.lowercase() ?: "open"
        if (filter !in setOf("open", "done", "overdue", "all")) {
            return JarvisResult.Failure(
                "Unknown filter “$filter” (valid: open, done, overdue, all).",
            )
        }
        val priorityText = params.optStringParam("priority")
        val priority = if (priorityText == null) {
            null
        } else {
            TaskPriority.fromName(priorityText)
                ?: return JarvisResult.Failure(
                    "Unknown priority “$priorityText” (valid: low, medium, high).",
                )
        }
        val tasks = taskStore.listAll()
            .filter { task ->
                when (filter) {
                    "open" -> task.status == TaskStatus.OPEN
                    "done" -> task.status == TaskStatus.DONE
                    "overdue" -> task.isOverdue(now)
                    else -> true
                }
            }
            .filter { task -> priority == null || task.priority == priority }
            .sortedWith(
                compareBy<Task> { it.dueAtMillis ?: Long.MAX_VALUE }.thenBy { it.updatedAtMillis },
            )
        if (tasks.isEmpty()) {
            val label = when (filter) {
                "overdue" -> "No overdue tasks — nothing is late."
                "done" -> "No completed tasks yet."
                else -> "No tasks here yet."
            }
            return JarvisResult.Success(ToolOutcome(label))
        }
        val shown = tasks.take(MAX_LISTED_TASKS)
        val lines = shown.map { formatTaskLine(it, now) }
        val more = tasks.size - shown.size
        val body = buildString {
            append("Tasks ($filter):\n")
            append(lines.joinToString("\n"))
            if (more > 0) {
                append("\n…and $more more (narrow the filter or priority to see fewer).")
            }
        }
        return JarvisResult.Success(ToolOutcome(body))
    }

    companion object {
        /**
         * Max tasks formatted into one tool result (Phase 11 hardening).
         * The store itself is bulk-capped (5,000), but the LLM only ever
         * sees the first 50 — a huge task list must not flood its context.
         */
        const val MAX_LISTED_TASKS: Int = 50
    }
}

/** Marks a task done (Tier 1). */
class CompleteTaskTool(
    private val taskStore: TaskStore,
) : JarvisTool {
    override val name: String = "complete_task"
    override val description: String = "Mark a task done (by its id, from list_tasks)."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("task_id", "integer", "The id of the task to complete."),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val taskId = params.intParam("task_id")?.toLong()
            ?: return "Complete a task — missing task_id."
        val task = taskStore.getById(taskId)
            ?: return "Complete task #$taskId — no task with that id exists."
        if (task.status == TaskStatus.DONE) {
            return "“${task.title}” is already done."
        }
        return "Mark done: “${task.title}”."
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val taskId = params.intParam("task_id")?.toLong()
            ?: return JarvisResult.Failure("complete_task needs a 'task_id' parameter.")
        return when (val result = taskStore.complete(taskId)) {
            is JarvisResult.Success ->
                JarvisResult.Success(ToolOutcome("Done: “${result.value.title}”."))
            is JarvisResult.Failure -> result
        }
    }
}

/** Deletes a task (Tier 1). */
class DeleteTaskTool(
    private val taskStore: TaskStore,
    private val reminderScheduler: ReminderScheduler,
) : JarvisTool {
    override val name: String = "delete_task"
    override val description: String =
        "Delete a task (by its id, from list_tasks). Any reminder on it is cancelled too."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("task_id", "integer", "The id of the task to delete."),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val taskId = params.intParam("task_id")?.toLong()
            ?: return "Delete a task — missing task_id."
        val task = taskStore.getById(taskId)
            ?: return "Delete task #$taskId — no task with that id exists."
        val reminderLine = if (task.reminderAtMillis != null) " (its reminder will be cancelled too)" else ""
        return "Delete task: “${task.title}”.$reminderLine"
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val taskId = params.intParam("task_id")?.toLong()
            ?: return JarvisResult.Failure("delete_task needs a 'task_id' parameter.")
        val task = taskStore.getById(taskId)
            ?: return JarvisResult.Failure("No task with id $taskId.")
        if (task.reminderAtMillis != null) {
            // Best effort: the row is deleted either way, and the
            // reminder worker checks the task still exists before notifying.
            reminderScheduler.cancel(taskId)
        }
        return when (val result = taskStore.delete(taskId)) {
            is JarvisResult.Success ->
                JarvisResult.Success(ToolOutcome("Deleted task: “${task.title}”."))
            is JarvisResult.Failure -> result
        }
    }
}

/** Attaches a reminder time to a task (Tier 1). */
class SetReminderTool(
    private val taskStore: TaskStore,
    private val reminderScheduler: ReminderScheduler,
    private val nowMillis: () -> Long = { System.currentTimeMillis() },
) : JarvisTool {
    override val name: String = "set_reminder"
    override val description: String =
        "Set a reminder on a task: Jarvis notifies at the given time (plain words: " +
            "\"tomorrow at 9am\", \"in 2 hours\"). User-set reminders are exempt from quiet hours."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec("task_id", "integer", "The id of the task to remind about."),
        ToolSchema.ParamSpec(
            "when",
            "string",
            "When to remind, in plain words: \"tomorrow at 9am\", \"in 2 hours\", \"Friday at 5pm\".",
        ),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val taskId = params.intParam("task_id")?.toLong()
            ?: return "Set a reminder — missing task_id."
        val task = taskStore.getById(taskId)
            ?: return "Set a reminder on task #$taskId — no task with that id exists."
        val whenPhrase = params.stringParam("when")
            ?: return "Set a reminder on “${task.title}” — missing 'when'."
        val at = parseWhen(whenPhrase)
            ?: return "Set a reminder on “${task.title}” — I couldn't understand “$whenPhrase”. " +
                "Try \"tomorrow at 9am\" or \"in 2 hours\"."
        if (at <= nowMillis()) {
            return "Set a reminder on “${task.title}” — ${formatTaskTime(at)} is in the past. " +
                "Pick a future time."
        }
        return "Remind about “${task.title}” at ${formatTaskTime(at)}."
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val taskId = params.intParam("task_id")?.toLong()
            ?: return JarvisResult.Failure("set_reminder needs a 'task_id' parameter.")
        val whenPhrase = params.stringParam("when")
            ?: return JarvisResult.Failure("set_reminder needs a 'when' parameter.")
        val at = parseWhen(whenPhrase)
            ?: return JarvisResult.Failure(
                "I couldn't understand “$whenPhrase”. Try \"tomorrow at 9am\" or \"in 2 hours\".",
            )
        if (at <= nowMillis()) {
            return JarvisResult.Failure(
                "${formatTaskTime(at)} is in the past — pick a future time.",
            )
        }
        val task = taskStore.getById(taskId)
            ?: return JarvisResult.Failure("No task with id $taskId.")
        return when (val scheduled = reminderScheduler.schedule(taskId, at)) {
            is JarvisResult.Success -> JarvisResult.Success(
                ToolOutcome(
                    "Reminder set: I'll remind you about “${task.title}” at ${formatTaskTime(at)}.",
                ),
            )
            is JarvisResult.Failure -> scheduled
        }
    }

    private fun parseWhen(phrase: String): Long? {
        val now = ZonedDateTime.ofInstant(
            Instant.ofEpochMilli(nowMillis()),
            ZoneId.systemDefault(),
        )
        return DueDateParser.parse(phrase, now)
    }
}

/** Lists device-calendar events for today or tomorrow (Tier 0, read-only). */
class ListEventsTool(
    private val calendarReader: CalendarReader,
    private val nowMillis: () -> Long = { System.currentTimeMillis() },
) : JarvisTool {
    override val name: String = "list_events"
    override val description: String =
        "List calendar events for today or tomorrow (read-only). Needs calendar access " +
            "(granted in Settings → App permissions)."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec(
            name = "day",
            type = "string",
            description = "Which day: today (default) or tomorrow.",
            required = false,
            enumValues = listOf("today", "tomorrow"),
        ),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val day = params.optStringParam("day") ?: "today"
        return "List calendar events for $day."
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val day = (params.optStringParam("day") ?: "today").lowercase()
        if (day != "today" && day != "tomorrow") {
            return JarvisResult.Failure("Unknown day “$day” (valid: today, tomorrow).")
        }
        if (!calendarReader.hasCalendarAccess()) {
            return JarvisResult.Failure(
                "Jarvis can't see your calendar. Grant calendar access in " +
                    "Settings → App permissions.",
            )
        }
        val zone = ZoneId.systemDefault()
        val date = LocalDate.ofInstant(Instant.ofEpochMilli(nowMillis()), zone)
            .let { if (day == "tomorrow") it.plusDays(1) else it }
        val start = date.atStartOfDay(zone).toInstant().toEpochMilli()
        val end = date.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        return when (val result = calendarReader.eventsBetween(start, end)) {
            is JarvisResult.Success -> {
                if (result.value.isEmpty()) {
                    JarvisResult.Success(ToolOutcome("No events $day."))
                } else {
                    val timeFormat = DateTimeFormatter.ofPattern("HH:mm")
                    val lines = result.value.map { event ->
                        val time = if (event.allDay) {
                            "All day"
                        } else {
                            val startTime = Instant.ofEpochMilli(event.startMillis).atZone(zone)
                                .format(timeFormat)
                            val endTime = Instant.ofEpochMilli(event.endMillis).atZone(zone)
                                .format(timeFormat)
                            "$startTime–$endTime"
                        }
                        val location = event.location.takeIf { it.isNotBlank() }
                            ?.let { " ($it)" } ?: ""
                        "• $time — ${event.title}$location"
                    }
                    val label = date.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM))
                    JarvisResult.Success(
                        ToolOutcome("Events for $label:\n" + lines.joinToString("\n")),
                    )
                }
            }
            is JarvisResult.Failure -> result
        }
    }
}

/** The morning briefing (Tier 0): today's events + tasks due + overdue. */
class MorningBriefingTool(
    private val briefingProvider: BriefingProvider,
) : JarvisTool {
    override val name: String = "morning_briefing"
    override val description: String =
        "Give the morning briefing: today's calendar events, tasks due today, and overdue tasks."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> = emptyList()

    override suspend fun dryRun(params: JsonObject): String = "Give the morning briefing."

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> =
        when (val result = briefingProvider.briefing()) {
            is JarvisResult.Success -> JarvisResult.Success(ToolOutcome(result.value))
            is JarvisResult.Failure -> result
        }
}

/** Starts a focus session (Tier 1): DND on, timer running, DND restored at the end. */
class StartFocusTool(
    private val focusSessionManager: FocusSessionManager,
) : JarvisTool {
    override val name: String = "start_focus"
    override val description: String =
        "Start a focus session (25, 50, or 90 minutes, or a custom length): Jarvis sets " +
            "Do Not Disturb to Alarms only, shows a timer notification, and restores DND " +
            "when the session ends."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec(
            name = "duration_minutes",
            type = "integer",
            description = "Session length in minutes (5–240). Default 25.",
            required = false,
        ),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val minutes = params.intParamOr("duration_minutes", 25)
        if (minutes !in 5..240) {
            return "Start a focus session — $minutes minutes is out of range (5–240)."
        }
        val current = focusSessionManager.currentSession()
        if (current != null) {
            return "A focus session is already running (${formatDuration(current.remainingMillis())} left) — " +
                "stop it first with stop_focus."
        }
        return "Start a $minutes-minute focus session: Do Not Disturb will be set to " +
            "Alarms only and restored when the session ends."
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val minutes = params.intParamOr("duration_minutes", 25)
        if (minutes !in 5..240) {
            return JarvisResult.Failure("Focus sessions are 5–240 minutes — $minutes is out of range.")
        }
        return when (val result = focusSessionManager.start(minutes)) {
            is JarvisResult.Success -> {
                val session: FocusSession = result.value
                JarvisResult.Success(
                    ToolOutcome(
                        "Focus session started: $minutes minutes, ending at " +
                            "${formatTaskTime(session.endsAtMillis())}. " +
                            "Do Not Disturb is on (alarms only) and will be restored at the end.",
                    ),
                )
            }
            is JarvisResult.Failure -> result
        }
    }
}

/** Stops the running focus session early (Tier 1). */
class StopFocusTool(
    private val focusSessionManager: FocusSessionManager,
) : JarvisTool {
    override val name: String = "stop_focus"
    override val description: String =
        "Stop the running focus session early. Do Not Disturb is restored to what it was before."
    override val riskTier: RiskTier = RiskTier.REVERSIBLE
    override val requiredPermissions: List<String> = emptyList()

    override suspend fun dryRun(params: JsonObject): String {
        val current = focusSessionManager.currentSession()
            ?: return "Stop the focus session — no focus session is running."
        return "Stop the focus session early (${formatDuration(current.remainingMillis())} left). " +
            "Do Not Disturb will be restored."
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        return when (val result = focusSessionManager.stop()) {
            is JarvisResult.Success -> {
                val stopped = result.value
                if (stopped == null) {
                    JarvisResult.Success(ToolOutcome("No focus session is running."))
                } else {
                    JarvisResult.Success(
                        ToolOutcome("Focus session stopped early. Do Not Disturb restored."),
                    )
                }
            }
            is JarvisResult.Failure -> result
        }
    }
}

/** Today's screen time + top apps (Tier 0, read-only, on-device only). */
class GetScreenTimeTool(
    private val screenTimeReader: ScreenTimeReader,
) : JarvisTool {
    override val name: String = "get_screen_time"
    override val description: String =
        "Show today's screen time and the top 5 apps. Needs usage access " +
            "(granted in Settings → Productivity & wellness). Data stays on-device."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> = emptyList()

    override suspend fun dryRun(params: JsonObject): String = "Show today's screen time."

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        if (!screenTimeReader.hasUsageAccess()) {
            return JarvisResult.Failure(
                "Screen time needs usage access. Grant it in " +
                    "Settings → Productivity & wellness → Usage access.",
            )
        }
        return when (val result = screenTimeReader.todaySummary()) {
            is JarvisResult.Success -> {
                val summary = result.value
                if (summary.totalMillis == 0L) {
                    JarvisResult.Success(ToolOutcome("No screen time recorded today yet."))
                } else {
                    val lines = summary.topApps.map { app ->
                        "• ${app.packageName}: ${formatDuration(app.totalTimeInForegroundMillis)}"
                    }
                    JarvisResult.Success(
                        ToolOutcome(
                            "Screen time today: ${summary.totalLabel()}.\n" +
                                "Top apps:\n" + lines.joinToString("\n"),
                        ),
                    )
                }
            }
            is JarvisResult.Failure -> result
        }
    }
}
