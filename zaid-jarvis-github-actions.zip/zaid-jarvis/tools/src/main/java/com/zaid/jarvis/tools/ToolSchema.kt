package com.zaid.jarvis.tools

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/**
 * Helpers for tool parameter JSON Schemas (Master Prompt §4).
 *
 * Schemas are a small, strict subset of JSON Schema: `type: "object"`,
 * `properties` (string / number / boolean / integer), and `required`.
 * The planner sends the schema to the LLM, and [validateParams] checks
 * the LLM's arguments against it before the Confirmation Engine is even
 * consulted — a malformed call never reaches Zaid's approval card.
 */
object ToolSchema {

    /** Schema for a tool that takes no parameters. */
    fun noParams(): JsonObject = buildJsonObject {
        put("type", "object")
        put("properties", JsonObject(emptyMap()))
    }

    /** Schema for one required string parameter. */
    fun singleStringParam(name: String, description: String): JsonObject =
        buildJsonObject {
            put("type", "object")
            put(
                "properties",
                buildJsonObject {
                    put(
                        name,
                        buildJsonObject {
                            put("type", "string")
                            put("description", description)
                        },
                    )
                },
            )
            put("required", JsonArray(listOf(JsonPrimitive(name))))
        }

    /**
     * One parameter of a multi-parameter schema (Phase 5).
     *
     * [type] is one of "string" / "integer" / "number" / "boolean".
     * [enumValues] lists the accepted values for a string parameter
     * (e.g. volume streams); the LLM sees them in the schema, and the
     * tool itself validates the value — [validateParams] checks types
     * only, never enum membership.
     */
    data class ParamSpec(
        val name: String,
        val type: String,
        val description: String,
        val required: Boolean = true,
        val enumValues: List<String> = emptyList(),
    )

    /** Schema for several parameters at once. */
    fun objectSchema(vararg params: ParamSpec): JsonObject =
        buildJsonObject {
            put("type", "object")
            put(
                "properties",
                buildJsonObject {
                    for (param in params) {
                        put(
                            param.name,
                            buildJsonObject {
                                put("type", param.type)
                                put("description", param.description)
                                if (param.enumValues.isNotEmpty()) {
                                    put(
                                        "enum",
                                        JsonArray(param.enumValues.map { JsonPrimitive(it) }),
                                    )
                                }
                            },
                        )
                    }
                },
            )
            val required = params.filter { it.required }.map { JsonPrimitive(it.name) }
            if (required.isNotEmpty()) {
                put("required", JsonArray(required))
            }
        }

    /**
     * Validates [params] against [schema]. Returns a list of problems;
     * empty means the parameters are valid. Checks required fields and
     * primitive types only — deeper validation is the tool's own job.
     */
    fun validateParams(params: JsonObject, schema: JsonObject): List<String> {
        val errors = mutableListOf<String>()
        val properties = schema["properties"]?.jsonObject ?: JsonObject(emptyMap())
        val required = schema["required"]?.jsonArray
            ?.mapNotNull { runCatching { it.jsonPrimitive.content }.getOrNull() }
            ?: emptyList()

        for (name in required) {
            if (name !in params) errors += "Missing required parameter: $name"
        }
        for ((name, value) in params) {
            val expected = properties[name]?.jsonObject?.get("type")
                ?.let { runCatching { it.jsonPrimitive.content }.getOrNull() }
                ?: continue // Unknown extra parameter: tolerated, tools ignore it.
            if (!matchesType(value, expected)) {
                errors += "Parameter '$name' must be $expected"
            }
        }
        return errors
    }

    private fun matchesType(value: JsonElement, type: String): Boolean {
        val primitive = value as? JsonPrimitive ?: return false
        return when (type) {
            "string" -> primitive.isString
            "boolean" -> runCatching { primitive.content.toBooleanStrict() }.isSuccess &&
                (primitive.content == "true" || primitive.content == "false")
            "number" -> !primitive.isString &&
                runCatching { primitive.content.toDouble() }.isSuccess
            "integer" -> !primitive.isString &&
                runCatching { primitive.content.toLong() }.isSuccess
            else -> true
        }
    }
}
