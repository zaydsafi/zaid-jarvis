package com.zaid.jarvis.tools.automation

import com.zaid.jarvis.core.automation.Macro
import com.zaid.jarvis.core.automation.MacroAction
import com.zaid.jarvis.core.automation.MacroLimits
import com.zaid.jarvis.core.automation.MacroStep
import com.zaid.jarvis.core.automation.MacroValidation
import com.zaid.jarvis.core.automation.SnapshotSanitizer
import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.core.util.JarvisResult
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeout

/**
 * Macro playback (Phase 6): runs a macro's steps one at a time through
 * the [AutomationDevice].
 *
 * Rules enforced here (Master Prompt §3):
 * - **One approval for the whole macro** — the `run_macro` tool's
 *   approval card lists every step; playback itself does not re-ask
 *   per step. (The gate lives in GatedToolExecutor, not here.)
 * - **Verify each step** — before a TAP/TYPE_TEXT step runs, the
 *   target must exist on screen; after the step, the action must
 *   report success. On the first failure playback **stops** and
 *   reports exactly which step failed and what the screen showed —
 *   it never continues blindly.
 * - **Kill switch** — the generation is checked before every step; a
 *   stop cancels playback immediately (the next step never runs).
 * - **Per-step timeout** ([stepTimeoutMillis], default 10s) — a step
 *   that hangs fails the run instead of hanging Jarvis.
 * - **Bounded macros** — validation rejects empty, oversized, or
 *   malformed macros before anything runs.
 *
 * [sleeper] is injectable so tests never wait for real WAIT steps.
 */
class MacroPlayer(
    private val device: AutomationDevice,
    private val killSwitch: KillSwitch,
    private val stepTimeoutMillis: Long = MacroLimits.STEP_TIMEOUT_MILLIS,
    private val sleeper: suspend (Long) -> Unit = { delay(it) },
) {
    /** Progress events for the UI (chat lines / macro run status). */
    sealed interface PlaybackEvent {
        data class StepStarted(val index: Int, val step: MacroStep) : PlaybackEvent
        data class StepFinished(val index: Int, val step: MacroStep) : PlaybackEvent
    }

    /**
     * Plays [macro] to completion. Success reports the step count;
     * failure names the failed step and what was on screen instead.
     * Cancellation (kill switch cancelling the running job) propagates
     * as a [kotlinx.coroutines.CancellationException] — it is not
     * converted into a failure result.
     */
    suspend fun play(
        macro: Macro,
        onEvent: (PlaybackEvent) -> Unit = {},
    ): JarvisResult<String> {
        val validationErrors = MacroValidation.validate(macro)
        if (validationErrors.isNotEmpty()) {
            return JarvisResult.Failure(
                "Macro “${macro.name}” is not valid: ${validationErrors.joinToString(" ")}",
            )
        }
        when (val available = device.checkAvailable()) {
            is JarvisResult.Failure -> return available
            is JarvisResult.Success -> Unit
        }

        val generation = killSwitch.currentGeneration()
        val stepResults = mutableListOf<String>()

        for ((index, step) in macro.steps.withIndex()) {
            val stepNumber = index + 1
            if (killSwitch.currentGeneration() != generation) {
                return JarvisResult.Failure(
                    "Macro “${macro.name}” stopped by the kill switch " +
                        "after ${index} of ${macro.steps.size} steps.",
                )
            }
            onEvent(PlaybackEvent.StepStarted(index, step))
            val result = try {
                withTimeout(stepTimeoutMillis) { runStep(step) }
            } catch (e: TimeoutCancellationException) {
                JarvisResult.Failure(
                    "Step $stepNumber (${step.describe()}) timed out after " +
                        "${stepTimeoutMillis}ms.",
                )
            }
            when (result) {
                is JarvisResult.Success -> {
                    stepResults += result.value
                    onEvent(PlaybackEvent.StepFinished(index, step))
                }
                is JarvisResult.Failure -> {
                    val screenSummary = currentScreenSummary()
                    return JarvisResult.Failure(
                        "Macro “${macro.name}” stopped at step $stepNumber of " +
                            "${macro.steps.size} (${step.describe()}): ${result.message}" +
                            if (screenSummary != null) "\nWhat I see now:\n$screenSummary" else "",
                    )
                }
            }
        }
        return JarvisResult.Success(
            "Ran macro “${macro.name}”: ${macro.steps.size} step(s) completed." +
                if (stepResults.isNotEmpty()) "\n" + stepResults.joinToString("\n") else "",
        )
    }

    /** Runs one step: verify the target exists (tap/type), then act. */
    private suspend fun runStep(step: MacroStep): JarvisResult<String> {
        return when (step.action) {
            MacroAction.TAP -> {
                val selector = step.selector
                    ?: return JarvisResult.Failure("Tap step has no target.")
                verifyTargetExists(selector, "tap")?.let { return it }
                device.tap(selector)
            }
            MacroAction.TAP_AT -> {
                val selector = step.selector
                if (selector?.isCoordinate != true) {
                    return JarvisResult.Failure("Tap-at-point step has no coordinates.")
                }
                device.tapAt(selector.x!!, selector.y!!)
            }
            MacroAction.TYPE_TEXT -> {
                val text = step.text
                    ?: return JarvisResult.Failure("Type step has no text.")
                step.selector?.let { selector ->
                    verifyTargetExists(selector, "type into")?.let { return it }
                }
                device.typeText(step.selector, text)
            }
            MacroAction.SCROLL_FORWARD -> device.scroll(forward = true)
            MacroAction.SCROLL_BACK -> device.scroll(forward = false)
            MacroAction.BACK -> device.pressBack()
            MacroAction.HOME -> device.pressHome()
            MacroAction.WAIT -> {
                sleeper(step.waitMillis)
                JarvisResult.Success("Waited ${step.waitMillis}ms.")
            }
        }
    }

    /**
     * Checks the target of a TAP/TYPE_TEXT step exists on screen right
     * now. Returns null when it does (proceed), or a Failure describing
     * what is on screen instead (stop). A missing target on a screen
     * with a password field gets a specific hint — the field Jarvis is
     * looking for may be the password field it refuses to see.
     */
    private suspend fun verifyTargetExists(
        selector: com.zaid.jarvis.core.automation.NodeSelector,
        verb: String,
    ): JarvisResult.Failure? {
        return when (val snapshot = device.snapshot()) {
            is JarvisResult.Failure -> snapshot
            is JarvisResult.Success -> {
                val found = snapshot.value.find(selector)
                if (found != null) {
                    null
                } else {
                    val hint = if (snapshot.value.hasPasswordField) {
                        " The screen has a password field, which I never read — " +
                            "the target may be that field."
                    } else {
                        ""
                    }
                    JarvisResult.Failure(
                        "I couldn't find ${selector.describe()} to $verb.$hint",
                    )
                }
            }
        }
    }

    /** Short "what I see now" summary for failure messages (null when unavailable). */
    private suspend fun currentScreenSummary(): String? =
        when (val snapshot = runCatching { device.snapshot() }.getOrNull()) {
            is JarvisResult.Success -> SnapshotSanitizer.format(snapshot.value, maxNodes = 10)
            else -> null
        }
}
