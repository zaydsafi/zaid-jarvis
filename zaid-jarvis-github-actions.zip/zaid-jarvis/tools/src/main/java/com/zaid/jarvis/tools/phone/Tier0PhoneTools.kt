package com.zaid.jarvis.tools.phone

import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.JarvisTool
import com.zaid.jarvis.tools.ToolOutcome
import com.zaid.jarvis.tools.ToolSchema
import com.zaid.jarvis.tools.optStringParam
import com.zaid.jarvis.tools.stringParam
import kotlinx.serialization.json.JsonObject

// ─────────────────────────────────────────────────────────────────────────────
// Tier 0 phone tools (Phase 5): read-only. Ask once per session, then
// auto-allow (unless "always ask for read-only" is on in Settings).
// ─────────────────────────────────────────────────────────────────────────────

/** Battery level + charging state. No permission needed. */
class GetBatteryTool(private val device: PhoneDevice) : JarvisTool {
    override val name: String = "get_battery"
    override val description: String = "Read the battery level and whether the phone is charging."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> = emptyList()

    override suspend fun dryRun(params: JsonObject): String =
        "Read the battery level."

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> =
        when (val result = device.battery()) {
            is JarvisResult.Success -> {
                val info = result.value
                val level = info.percent?.let { "$it%" } ?: "unknown"
                val charging = if (info.isCharging) "charging" else "not charging"
                JarvisResult.Success(ToolOutcome("Battery: $level ($charging)."))
            }
            is JarvisResult.Failure -> result
        }
}

/** Network connection type + online state. No permission needed. */
class GetNetworkTool(private val device: PhoneDevice) : JarvisTool {
    override val name: String = "get_network"
    override val description: String = "Read the network connection type and whether the phone is online."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> = emptyList()

    override suspend fun dryRun(params: JsonObject): String =
        "Read the network connection state."

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> =
        when (val result = device.network()) {
            is JarvisResult.Success -> {
                val info = result.value
                val text = if (info.isOnline) {
                    "Network: ${info.type} (online)."
                } else {
                    "No network connection (offline)."
                }
                JarvisResult.Success(ToolOutcome(text))
            }
            is JarvisResult.Failure -> result
        }
}

/**
 * Search contacts by name. Needs READ_CONTACTS — checked before the
 * query runs, with a clear message telling Zaid where to grant it.
 * Returns names + phone numbers only (never emails, addresses, or notes).
 */
class GetContactsTool(private val device: PhoneDevice) : JarvisTool {
    override val name: String = "get_contacts"
    override val description: String = "Search contacts by name and show their phone numbers."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> =
        listOf("android.permission.READ_CONTACTS")

    override val inputSchema: JsonObject =
        ToolSchema.singleStringParam("query", "The name (or part of a name) to search for.")

    override suspend fun dryRun(params: JsonObject): String {
        val query = params.stringParam("query") ?: "?"
        return "Search contacts for “$query”."
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val query = params.stringParam("query")
            ?: return JarvisResult.Failure("get_contacts needs a 'query' parameter")
        if (!device.hasPermission("android.permission.READ_CONTACTS")) {
            return JarvisResult.Failure(
                "Jarvis doesn't have permission to read contacts. " +
                    "Grant it in Settings → App permissions → Contacts, then try again.",
            )
        }
        return when (val result = device.searchContacts(query)) {
            is JarvisResult.Success -> {
                val contacts = result.value
                if (contacts.isEmpty()) {
                    JarvisResult.Success(ToolOutcome("No contacts matching “$query”."))
                } else {
                    val lines = contacts.joinToString("\n") { "• ${it.name} — ${it.phoneNumber}" }
                    JarvisResult.Success(
                        ToolOutcome("Found ${contacts.size} contact(s) matching “$query”:\n$lines"),
                    )
                }
            }
            is JarvisResult.Failure -> result
        }
    }
}

/**
 * List installed, launchable apps, optionally filtered by name or
 * package. No permission needed — only apps with a launcher icon are
 * listed, which are exactly the apps open_app can open.
 */
class ListAppsTool(private val device: PhoneDevice) : JarvisTool {
    override val name: String = "list_installed_apps"
    override val description: String = "List installed apps, optionally filtered by name."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject = ToolSchema.objectSchema(
        ToolSchema.ParamSpec(
            name = "query",
            type = "string",
            description = "Optional text to filter app names by.",
            required = false,
        ),
    )

    override suspend fun dryRun(params: JsonObject): String {
        val query = params.optStringParam("query")
        return if (query == null) "List installed apps." else "List installed apps matching “$query”."
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val query = params.optStringParam("query")
        return when (val result = device.listApps(query)) {
            is JarvisResult.Success -> {
                val apps = result.value
                if (apps.isEmpty()) {
                    JarvisResult.Success(
                        ToolOutcome(
                            if (query == null) "No launchable apps found."
                            else "No installed app matches “$query”.",
                        ),
                    )
                } else {
                    val shown = apps.take(20)
                    val lines = shown.joinToString("\n") { "• ${it.name} (${it.packageName})" }
                    val extra = if (apps.size > shown.size) {
                        "\n… and ${apps.size - shown.size} more."
                    } else {
                        ""
                    }
                    JarvisResult.Success(ToolOutcome("Installed apps:\n$lines$extra"))
                }
            }
            is JarvisResult.Failure -> result
        }
    }
}
