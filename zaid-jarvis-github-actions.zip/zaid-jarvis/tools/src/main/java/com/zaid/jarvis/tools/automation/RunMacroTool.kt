package com.zaid.jarvis.tools.automation

import com.zaid.jarvis.core.automation.Macro
import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.JarvisTool
import com.zaid.jarvis.tools.ToolOutcome
import com.zaid.jarvis.tools.ToolSchema
import com.zaid.jarvis.tools.stringParam
import kotlinx.serialization.json.JsonObject

/**
 * Runs a saved macro by name (Phase 6).
 *
 * **Tier rule** (see [tierFor]): the whole macro is approved once, on a
 * single card listing every step. The tier depends on what the macro
 * does — a macro that taps or types in another app can cause visible,
 * external effects (a tap can press Send), so it is Tier 2 (card +
 * second confirm); a macro that only scrolls, navigates, or waits is
 * Tier 1. A macro that cannot be found is treated as Tier 2 (fail-safe)
 * and then fails clearly at execution time.
 *
 * Playback itself ([MacroPlayer]) verifies each step, stops at the
 * first failure, and honours the kill switch. A successful run updates
 * the macro's last-run time in storage.
 */
class RunMacroTool(
    private val macroStore: MacroStore,
    private val player: MacroPlayer,
) : JarvisTool {
    override val name: String = "run_macro"
    override val description: String = "Run a saved macro (a recorded sequence of taps, typing, and scrolling) by name."
    override val riskTier: RiskTier = RiskTier.EXTERNAL
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject =
        ToolSchema.singleStringParam("name", "The name of the macro to run.")

    override suspend fun tierFor(params: JsonObject): RiskTier {
        val macro = macroByName(params) ?: return RiskTier.EXTERNAL
        return if (macro.isExternal) RiskTier.EXTERNAL else RiskTier.REVERSIBLE
    }

    override suspend fun dryRun(params: JsonObject): String {
        val name = params.stringParam("name") ?: "?"
        val macro = macroByName(params)
            ?: return "Run macro “$name” — no macro with that name exists."
        return buildString {
            appendLine("Run macro “${macro.name}” (${macro.steps.size} step(s)):")
            append(macro.describeSteps())
        }.trimEnd()
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val name = params.stringParam("name")
            ?: return JarvisResult.Failure("run_macro needs a 'name' parameter")
        val macro = macroStore.getByName(name)
            ?: return JarvisResult.Failure(
                "No macro named “$name”. Record one in Macros first, or check the name.",
            )
        return when (val result = player.play(macro)) {
            is JarvisResult.Success -> {
                macroStore.markRun(macro.id)
                JarvisResult.Success(ToolOutcome(result.value))
            }
            is JarvisResult.Failure -> result
        }
    }

    private suspend fun macroByName(params: JsonObject): Macro? {
        val name = params.stringParam("name") ?: return null
        return macroStore.getByName(name)
    }
}
