package com.zaid.jarvis.tools.phone

import com.zaid.jarvis.core.util.JarvisResult

/**
 * A [PhoneDevice] that does nothing (Phase 5).
 *
 * Used by tests that need a tool registry without a device, and as a
 * safe fallback wherever no real device implementation is available.
 * Every operation fails with a clear message — it never pretends an
 * action happened.
 */
object NoOpPhoneDevice : PhoneDevice {

    private fun unavailable(): JarvisResult.Failure =
        JarvisResult.Failure("Phone access is not available in this build.")

    override suspend fun battery(): JarvisResult<BatteryInfo> = unavailable()

    override suspend fun network(): JarvisResult<NetworkInfo> = unavailable()

    override suspend fun searchContacts(query: String): JarvisResult<List<Contact>> = unavailable()

    override suspend fun listApps(query: String?): JarvisResult<List<AppInfo>> = unavailable()

    override suspend fun isFlashlightOn(): JarvisResult<Boolean> = unavailable()

    override suspend fun setFlashlight(on: Boolean): JarvisResult<Boolean> = unavailable()

    override suspend fun volumeInfo(stream: VolumeStream): JarvisResult<VolumeInfo> = unavailable()

    override suspend fun setVolume(stream: VolumeStream, level: Int): JarvisResult<VolumeInfo> =
        unavailable()

    override suspend fun brightnessPercent(): JarvisResult<Int> = unavailable()

    override suspend fun setBrightnessPercent(percent: Int): JarvisResult<BrightnessChange> =
        unavailable()

    override suspend fun isWifiEnabled(): JarvisResult<Boolean> = unavailable()

    override suspend fun setWifi(enabled: Boolean): JarvisResult<WifiToggleResult> = unavailable()

    override suspend fun isBluetoothEnabled(): JarvisResult<Boolean> = unavailable()

    override suspend fun setBluetooth(enabled: Boolean): JarvisResult<BluetoothToggleResult> =
        unavailable()

    override suspend fun dndMode(): JarvisResult<DndMode> = unavailable()

    override suspend fun setDndMode(mode: DndMode): JarvisResult<DndMode> = unavailable()

    override fun hasPermission(permission: String): Boolean = false

    override suspend fun launch(action: SystemAction): JarvisResult<String> = unavailable()
}
