package com.zaid.jarvis.tools.automation

import com.zaid.jarvis.core.automation.Macro
import com.zaid.jarvis.core.automation.NodeSelector
import com.zaid.jarvis.core.automation.ScreenSnapshot
import com.zaid.jarvis.core.util.JarvisResult

/**
 * The screen-automation capabilities, as the tools see them (Phase 6).
 * Pure Kotlin — `:tools` compiles and tests on the JVM. The Android
 * implementation lives in `:app`
 * ([com.zaid.jarvis.accessibility.AccessibilityAutomationDevice]), backed
 * by the AccessibilityService.
 *
 * Every method returns a [JarvisResult]: a missing service, a disabled
 * automation toggle, a blocked banking app, or a password screen all
 * come back as [JarvisResult.Failure] with a plain-language message —
 * never a crash, never a silent no-op.
 *
 * Safety is enforced by the implementation, not by the tools: the
 * service refuses blocked apps and password screens for *every* caller,
 * so a tool cannot bypass the guards by calling the device directly.
 * Tools still go through the Confirmation Engine as well — the gate is
 * the user-facing approval, the device guards are the backstop.
 */
interface AutomationDevice {

    /**
     * Fails with a plain-language message when automation cannot run
     * right now: the automation toggle is off, or the Accessibility
     * service is not connected. Tools call this first.
     */
    suspend fun checkAvailable(): JarvisResult<Unit>

    /** Sanitized snapshot of the current screen (password fields excluded). */
    suspend fun snapshot(): JarvisResult<ScreenSnapshot>

    /**
     * Taps the first node matching [selector]. Returns a description of
     * what was tapped (e.g. "Tapped Button “Search”"). Fails when no
     * matching node exists, the screen is blocked, or the screen has a
     * password field.
     */
    suspend fun tap(selector: NodeSelector): JarvisResult<String>

    /** Taps at screen coordinates via a dispatched gesture. */
    suspend fun tapAt(x: Int, y: Int): JarvisResult<String>

    /**
     * Types [text] into the field matching [selector] — or the focused
     * field when [selector] is null. Refuses password fields (they are
     * invisible in snapshots, so the target is never found) and fails
     * when the target is not editable.
     */
    suspend fun typeText(selector: NodeSelector?, text: String): JarvisResult<String>

    /** Scrolls the current screen forward (down) or back (up). */
    suspend fun scroll(forward: Boolean): JarvisResult<String>

    /** Global Back action. Allowed on password screens (it only navigates away). */
    suspend fun pressBack(): JarvisResult<String>

    /** Global Home action. */
    suspend fun pressHome(): JarvisResult<String>
}

/**
 * The macro storage the `run_macro` tool needs (Phase 6). `:tools`
 * cannot depend on `:data`, so this interface is implemented in `:app`
 * ([com.zaid.jarvis.accessibility.RoomMacroStore]) on top of
 * MacroRepository. Kept minimal on purpose — listing, renaming, and
 * deleting macros are UI concerns, not tool concerns.
 */
interface MacroStore {
    /** The macro named [name] (case-insensitive), or null. */
    suspend fun getByName(name: String): Macro?

    /** Records that the macro with [id] ran just now. */
    suspend fun markRun(id: Long)
}

/** An automation device that does nothing — for tests and for builds without accessibility. */
object NoOpAutomationDevice : AutomationDevice {
    private fun unavailable(): JarvisResult.Failure =
        JarvisResult.Failure(
            "Accessibility automation is not available. Enable the Jarvis " +
                "Accessibility service in Settings → Accessibility, then turn " +
                "Automation on in Settings → Automation.",
        )

    override suspend fun checkAvailable(): JarvisResult<Unit> = unavailable()
    override suspend fun snapshot(): JarvisResult<ScreenSnapshot> = unavailable()
    override suspend fun tap(selector: NodeSelector): JarvisResult<String> = unavailable()
    override suspend fun tapAt(x: Int, y: Int): JarvisResult<String> = unavailable()
    override suspend fun typeText(selector: NodeSelector?, text: String): JarvisResult<String> =
        unavailable()
    override suspend fun scroll(forward: Boolean): JarvisResult<String> = unavailable()
    override suspend fun pressBack(): JarvisResult<String> = unavailable()
    override suspend fun pressHome(): JarvisResult<String> = unavailable()
}

/** A macro store with no macros — for tests and for builds without accessibility. */
object NoMacroStore : MacroStore {
    override suspend fun getByName(name: String): Macro? = null
    override suspend fun markRun(id: Long) = Unit
}
