package com.zaid.jarvis.tools

import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.tools.automation.AutomationDevice
import com.zaid.jarvis.tools.automation.FindOnScreenTool
import com.zaid.jarvis.tools.automation.MacroPlayer
import com.zaid.jarvis.tools.automation.MacroStore
import com.zaid.jarvis.tools.automation.NoMacroStore
import com.zaid.jarvis.tools.automation.NoOpAutomationDevice
import com.zaid.jarvis.tools.automation.PressBackTool
import com.zaid.jarvis.tools.automation.PressHomeTool
import com.zaid.jarvis.tools.automation.RunMacroTool
import com.zaid.jarvis.tools.automation.ScrollScreenTool
import com.zaid.jarvis.tools.automation.TapOnScreenTool
import com.zaid.jarvis.tools.automation.TypeTextTool
import com.zaid.jarvis.tools.builtin.CalculatorTool
import com.zaid.jarvis.tools.builtin.EchoTool
import com.zaid.jarvis.tools.builtin.GetTimeTool
import com.zaid.jarvis.tools.phone.GetBatteryTool
import com.zaid.jarvis.tools.phone.GetContactsTool
import com.zaid.jarvis.tools.phone.GetNetworkTool
import com.zaid.jarvis.tools.phone.ListAppsTool
import com.zaid.jarvis.tools.phone.MakeCallTool
import com.zaid.jarvis.tools.phone.OpenAppTool
import com.zaid.jarvis.tools.phone.PhoneDevice
import com.zaid.jarvis.tools.phone.SendEmailTool
import com.zaid.jarvis.tools.phone.SendSmsTool
import com.zaid.jarvis.tools.phone.SetAlarmTool
import com.zaid.jarvis.tools.phone.SetBluetoothTool
import com.zaid.jarvis.tools.phone.SetBrightnessTool
import com.zaid.jarvis.tools.phone.SetDoNotDisturbTool
import com.zaid.jarvis.tools.phone.SetFlashlightTool
import com.zaid.jarvis.tools.phone.SetTimerTool
import com.zaid.jarvis.tools.phone.SetVolumeTool
import com.zaid.jarvis.tools.phone.SetWifiTool
import com.zaid.jarvis.tools.phone.ShareTextTool
import com.zaid.jarvis.tools.productivity.BriefingProvider
import com.zaid.jarvis.tools.productivity.CalendarReader
import com.zaid.jarvis.tools.productivity.CompleteTaskTool
import com.zaid.jarvis.tools.productivity.CreateTaskTool
import com.zaid.jarvis.tools.productivity.DeleteTaskTool
import com.zaid.jarvis.tools.productivity.FocusSessionManager
import com.zaid.jarvis.tools.productivity.GetScreenTimeTool
import com.zaid.jarvis.tools.productivity.ListEventsTool
import com.zaid.jarvis.tools.productivity.ListTasksTool
import com.zaid.jarvis.tools.productivity.MorningBriefingTool
import com.zaid.jarvis.tools.productivity.NoOpBriefingProvider
import com.zaid.jarvis.tools.productivity.NoOpCalendarReader
import com.zaid.jarvis.tools.productivity.NoOpFocusSessionManager
import com.zaid.jarvis.tools.productivity.NoOpReminderScheduler
import com.zaid.jarvis.tools.productivity.NoOpScreenTimeReader
import com.zaid.jarvis.tools.productivity.NoOpTaskStore
import com.zaid.jarvis.tools.productivity.ReminderScheduler
import com.zaid.jarvis.tools.productivity.ScreenTimeReader
import com.zaid.jarvis.tools.productivity.SetReminderTool
import com.zaid.jarvis.tools.productivity.StartFocusTool
import com.zaid.jarvis.tools.productivity.StopFocusTool
import com.zaid.jarvis.tools.productivity.TaskStore
import com.zaid.jarvis.tools.research.DraftGenerator
import com.zaid.jarvis.tools.research.DraftPostTool
import com.zaid.jarvis.tools.research.FetchPageTool
import com.zaid.jarvis.tools.research.NoOpDraftGenerator
import com.zaid.jarvis.tools.research.NoOpPageFetcher
import com.zaid.jarvis.tools.research.NoOpResearchRunner
import com.zaid.jarvis.tools.research.NoOpWebSearch
import com.zaid.jarvis.tools.research.PageFetcher
import com.zaid.jarvis.tools.research.ResearchRunner
import com.zaid.jarvis.tools.research.ResearchTopicTool
import com.zaid.jarvis.tools.research.SearchWebTool
import com.zaid.jarvis.tools.research.WebSearch
import com.zaid.jarvis.tools.social.CancelScheduledPostTool
import com.zaid.jarvis.tools.social.ListScheduledPostsTool
import com.zaid.jarvis.tools.social.NoOpPublishService
import com.zaid.jarvis.tools.social.NoOpSocialPublisher
import com.zaid.jarvis.tools.social.NoOpSocialScheduler
import com.zaid.jarvis.tools.social.PublishDraftTool
import com.zaid.jarvis.tools.social.PublishService
import com.zaid.jarvis.tools.social.SchedulePostTool
import com.zaid.jarvis.tools.social.SocialPublisher
import com.zaid.jarvis.tools.social.SocialScheduler
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * The tools Jarvis ships with (Master Prompt §4–§5).
 *
 * Phase 3 registers only pure, permission-free tools: time, calculator,
 * echo. Phase 5 adds the phone tools (tiers 0–2) — they take a
 * [PhoneDevice], whose Android implementation is provided by :app
 * (AppModule). Phase 6 adds the Accessibility automation tools — they
 * take an [AutomationDevice] and a [MacroStore], also provided by :app.
 * Phase 7 adds the research tools — they take a [WebSearch], a
 * [PageFetcher], a [ResearchRunner], and a [DraftGenerator], provided
 * by :agent (AgentModule). Publishing tools land in Phase 8.
 * Phase 8 adds the social publishing tools — they take a
 * [PublishService] and a [SocialPublisher] (provided by :agent) and a
 * [SocialScheduler] (provided by :app via WorkManager). Every tool is
 * still gated by the Confirmation Engine at run time — registration
 * alone grants nothing.
 * Phase 9 adds the productivity & wellness tools — they take a
 * [TaskStore] and a [ReminderScheduler] (provided by :app over :data
 * + WorkManager), a [CalendarReader] and a [ScreenTimeReader]
 * (provided by :app), a [FocusSessionManager] (provided by :app),
 * and a [BriefingProvider] (provided by :agent).
 *
 * The automation, research, social, and productivity parameters
 * default to no-op implementations so existing callers (tests, the
 * planner harness) keep working without an Accessibility service,
 * network, connected social account, calendar, or usage access;
 * production always passes the real ones.
 */
object BuiltInTools {
    /** Registers every built-in tool into [registry]. Idempotent per tool name. */
    fun registerAll(
        registry: ToolRegistry,
        device: PhoneDevice,
        automationDevice: AutomationDevice = NoOpAutomationDevice,
        macroStore: MacroStore = NoMacroStore,
        killSwitch: KillSwitch = KillSwitch(),
        webSearch: WebSearch = NoOpWebSearch,
        pageFetcher: PageFetcher = NoOpPageFetcher,
        researchRunner: ResearchRunner = NoOpResearchRunner,
        draftGenerator: DraftGenerator = NoOpDraftGenerator,
        publishService: PublishService = NoOpPublishService(),
        publisher: SocialPublisher = NoOpSocialPublisher(),
        scheduler: SocialScheduler = NoOpSocialScheduler(),
        taskStore: TaskStore = NoOpTaskStore(),
        reminderScheduler: ReminderScheduler = NoOpReminderScheduler(),
        calendarReader: CalendarReader = NoOpCalendarReader(),
        screenTimeReader: ScreenTimeReader = NoOpScreenTimeReader(),
        focusSessionManager: FocusSessionManager = NoOpFocusSessionManager(),
        briefingProvider: BriefingProvider = NoOpBriefingProvider(),
    ) {
        // Phase 3: pure tools (no device access).
        registry.register(GetTimeTool())
        registry.register(CalculatorTool())
        registry.register(EchoTool())

        // Phase 5, Tier 0 (read-only).
        registry.register(GetBatteryTool(device))
        registry.register(GetNetworkTool(device))
        registry.register(GetContactsTool(device))
        registry.register(ListAppsTool(device))

        // Phase 5, Tier 1 (reversible).
        registry.register(SetFlashlightTool(device))
        registry.register(SetVolumeTool(device))
        registry.register(SetBrightnessTool(device))
        registry.register(SetWifiTool(device))
        registry.register(SetBluetoothTool(device))
        registry.register(SetAlarmTool(device))
        registry.register(SetTimerTool(device))
        registry.register(OpenAppTool(device))
        registry.register(SetDoNotDisturbTool(device))

        // Phase 5, Tier 2 (external / visible — intent-only, see Tier2PhoneTools.kt).
        registry.register(MakeCallTool(device))
        registry.register(SendSmsTool(device))
        registry.register(SendEmailTool(device))
        registry.register(ShareTextTool(device))

        // Phase 6: Accessibility automation (needs the service + the toggle).
        registry.register(FindOnScreenTool(automationDevice))
        registry.register(TapOnScreenTool(automationDevice))
        registry.register(TypeTextTool(automationDevice))
        registry.register(ScrollScreenTool(automationDevice))
        registry.register(PressBackTool(automationDevice))
        registry.register(PressHomeTool(automationDevice))
        val macroPlayer = MacroPlayer(automationDevice, killSwitch)
        registry.register(RunMacroTool(macroStore, macroPlayer))

        // Phase 7: research & content (Tier 0 except draft_post, Tier 1).
        // Nothing here publishes — drafts wait in the Drafts screen.
        registry.register(SearchWebTool(webSearch))
        registry.register(FetchPageTool(pageFetcher))
        registry.register(ResearchTopicTool(researchRunner))
        registry.register(DraftPostTool(draftGenerator))

        // Phase 8: social publishing. publish_draft / schedule_post are
        // Tier 2 (card + second confirm, exact text on the card);
        // list_scheduled_posts is Tier 0; cancel_scheduled_post is
        // Tier 1. The gate itself (APPROVED-only, content binding,
        // char-limit re-check) lives in PublishService.
        registry.register(PublishDraftTool(publishService, publisher))
        registry.register(SchedulePostTool(publishService, publisher, scheduler))
        registry.register(ListScheduledPostsTool(scheduler))
        registry.register(CancelScheduledPostTool(scheduler))

        // Phase 9: productivity & wellness. Task writes are Tier 1
        // (reversible, local state); reads are Tier 0. Focus sessions
        // are Tier 1 (DND is restored at the end). Due dates and
        // reminder times come from plain words via DueDateParser —
        // anything unparseable is asked about, never guessed.
        registry.register(CreateTaskTool(taskStore))
        registry.register(ListTasksTool(taskStore))
        registry.register(CompleteTaskTool(taskStore))
        registry.register(DeleteTaskTool(taskStore, reminderScheduler))
        registry.register(SetReminderTool(taskStore, reminderScheduler))
        registry.register(ListEventsTool(calendarReader))
        registry.register(MorningBriefingTool(briefingProvider))
        registry.register(StartFocusTool(focusSessionManager))
        registry.register(StopFocusTool(focusSessionManager))
        registry.register(GetScreenTimeTool(screenTimeReader))
    }
}

/**
 * Provides the single [ToolRegistry], pre-loaded with the built-in tools.
 * NOTE: ToolRegistry has no @Inject constructor — this provider is its
 * only binding, so Hilt never sees a duplicate.
 */
@Module
@InstallIn(SingletonComponent::class)
object ToolsModule {
    @Provides
    @Singleton
    fun provideToolRegistry(
        device: PhoneDevice,
        automationDevice: AutomationDevice,
        macroStore: MacroStore,
        killSwitch: KillSwitch,
        webSearch: WebSearch,
        pageFetcher: PageFetcher,
        researchRunner: ResearchRunner,
        draftGenerator: DraftGenerator,
        publishService: PublishService,
        publisher: SocialPublisher,
        scheduler: SocialScheduler,
        taskStore: TaskStore,
        reminderScheduler: ReminderScheduler,
        calendarReader: CalendarReader,
        screenTimeReader: ScreenTimeReader,
        focusSessionManager: FocusSessionManager,
        briefingProvider: BriefingProvider,
    ): ToolRegistry =
        ToolRegistry().also {
            BuiltInTools.registerAll(
                it,
                device,
                automationDevice,
                macroStore,
                killSwitch,
                webSearch,
                pageFetcher,
                researchRunner,
                draftGenerator,
                publishService,
                publisher,
                scheduler,
                taskStore,
                reminderScheduler,
                calendarReader,
                screenTimeReader,
                focusSessionManager,
                briefingProvider,
            )
        }
}
