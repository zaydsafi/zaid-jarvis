package com.zaid.jarvis.tools.builtin

import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.JarvisTool
import com.zaid.jarvis.tools.ToolOutcome
import com.zaid.jarvis.tools.ToolSchema
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * Evaluates a simple arithmetic expression (Tier 0, read-only, no
 * permissions, works offline). Only digits, whitespace, parentheses and
 * the operators + - * / % are accepted — this is a small hand-written
 * parser, never a script engine, so an expression cannot do anything
 * but arithmetic.
 */
class CalculatorTool : JarvisTool {
    override val name: String = "calculator"
    override val description: String = "Evaluate an arithmetic expression (numbers, +, -, *, /, %, parentheses)."
    override val riskTier: RiskTier = RiskTier.READ_ONLY
    override val requiredPermissions: List<String> = emptyList()

    override val inputSchema: JsonObject =
        ToolSchema.singleStringParam("expression", "The arithmetic expression to evaluate, e.g. \"(12 + 8) * 3\".")

    override suspend fun dryRun(params: JsonObject): String {
        val expression = params["expression"]?.jsonPrimitive?.content ?: "?"
        return "Calculate: $expression"
    }

    override suspend fun execute(params: JsonObject): JarvisResult<ToolOutcome> {
        val expression = params["expression"]?.jsonPrimitive?.content
            ?: return JarvisResult.Failure("calculator needs an 'expression' parameter")
        return try {
            val value = ExpressionParser(expression).parse()
            JarvisResult.Success(ToolOutcome("$expression = ${format(value)}"))
        } catch (e: IllegalArgumentException) {
            JarvisResult.Failure("Could not calculate '$expression': ${e.message}")
        } catch (e: IllegalStateException) {
            // The parser reports bad input via error(), e.g. division by zero.
            JarvisResult.Failure("Could not calculate '$expression': ${e.message}")
        }
    }

    private fun format(value: Double): String =
        if (value == value.toLong().toDouble() && value.isFinite()) {
            value.toLong().toString()
        } else {
            String.format(java.util.Locale.US, "%.6f", value).trimEnd('0').trimEnd('.')
        }

    /** Tiny recursive-descent parser for + - * / % and parentheses. */
    private class ExpressionParser(private val input: String) {
        private var pos = 0

        fun parse(): Double {
            val value = parseAddSub()
            skipWhitespace()
            if (pos < input.length) error("Unexpected character '${input[pos]}' at position $pos")
            return value
        }

        private fun parseAddSub(): Double {
            var value = parseMulDiv()
            while (true) {
                skipWhitespace()
                when {
                    consume('+') -> value += parseMulDiv()
                    consume('-') -> value -= parseMulDiv()
                    else -> return value
                }
            }
        }

        private fun parseMulDiv(): Double {
            var value = parseUnary()
            while (true) {
                skipWhitespace()
                when {
                    consume('*') -> value *= parseUnary()
                    consume('/') -> {
                        val divisor = parseUnary()
                        if (divisor == 0.0) error("Division by zero")
                        value /= divisor
                    }
                    consume('%') -> value %= parseUnary()
                    else -> return value
                }
            }
        }

        private fun parseUnary(): Double {
            skipWhitespace()
            if (consume('-')) return -parseUnary()
            if (consume('+')) return parseUnary()
            return parsePrimary()
        }

        private fun parsePrimary(): Double {
            skipWhitespace()
            if (consume('(')) {
                val value = parseAddSub()
                skipWhitespace()
                if (!consume(')')) error("Missing closing parenthesis")
                return value
            }
            val start = pos
            while (pos < input.length && (input[pos].isDigit() || input[pos] == '.')) pos++
            if (start == pos) error("Expected a number at position $pos")
            return input.substring(start, pos).toDoubleOrNull()
                ?: error("Invalid number '${input.substring(start, pos)}'")
        }

        private fun skipWhitespace() {
            while (pos < input.length && input[pos].isWhitespace()) pos++
        }

        private fun consume(c: Char): Boolean {
            if (pos < input.length && input[pos] == c) {
                pos++
                return true
            }
            return false
        }
    }
}
