package com.zaid.jarvis.tools.productivity

import com.zaid.jarvis.core.productivity.CalendarEvent
import com.zaid.jarvis.core.productivity.FocusSession
import com.zaid.jarvis.core.productivity.FocusSessionStatus
import com.zaid.jarvis.core.productivity.ScreenTimeSummary
import com.zaid.jarvis.core.productivity.Task
import com.zaid.jarvis.core.productivity.TaskPriority
import com.zaid.jarvis.core.productivity.TaskStatus
import com.zaid.jarvis.core.productivity.UsageEntry
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.ToolRegistry
import com.zaid.jarvis.tools.BuiltInTools
import com.zaid.jarvis.tools.phone.FakePhoneDevice
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Productivity & wellness tools (Phase 9) with in-memory fakes. */
class ProductivityToolsTest {

    /** Fixed "now": Sunday 2026-11-15 10:30 UTC. */
    private val nowMillis: Long = 1_793_050_200_000L

    private class FakeTaskStore : TaskStore {
        val tasks = mutableListOf<Task>()
        private var nextId = 1L

        override suspend fun create(task: Task): JarvisResult<Long> {
            if (task.title.isBlank()) return JarvisResult.Failure("A task needs a title.")
            val id = nextId++
            tasks += task.copy(id = id, createdAtMillis = 1L, updatedAtMillis = 1L)
            return JarvisResult.Success(id)
        }

        override suspend fun getById(id: Long): Task? = tasks.find { it.id == id }
        override suspend fun listAll(): List<Task> = tasks.toList()

        override suspend fun update(task: Task): JarvisResult<Unit> {
            val index = tasks.indexOfFirst { it.id == task.id }
            if (index < 0) return JarvisResult.Failure("No task with id ${task.id}.")
            tasks[index] = task
            return JarvisResult.Success(Unit)
        }

        override suspend fun complete(id: Long): JarvisResult<Task> {
            val task = tasks.find { it.id == id }
                ?: return JarvisResult.Failure("No task with id $id.")
            val done = task.copy(status = TaskStatus.DONE)
            tasks[tasks.indexOf(task)] = done
            return JarvisResult.Success(done)
        }

        override suspend fun delete(id: Long): JarvisResult<Unit> {
            val removed = tasks.removeAll { it.id == id }
            return if (removed) JarvisResult.Success(Unit)
            else JarvisResult.Failure("No task with id $id.")
        }

        override suspend fun setReminder(
            id: Long,
            reminderAtMillis: Long,
            workId: String?,
        ): JarvisResult<Task> {
            val task = tasks.find { it.id == id }
                ?: return JarvisResult.Failure("No task with id $id.")
            val updated = task.copy(reminderAtMillis = reminderAtMillis, reminderWorkId = workId)
            tasks[tasks.indexOf(task)] = updated
            return JarvisResult.Success(updated)
        }

        override suspend fun clearReminder(id: Long): JarvisResult<Unit> {
            val task = tasks.find { it.id == id }
                ?: return JarvisResult.Failure("No task with id $id.")
            tasks[tasks.indexOf(task)] = task.copy(reminderAtMillis = null, reminderWorkId = null)
            return JarvisResult.Success(Unit)
        }

        override suspend fun markOverdueNotified(id: Long, epochDay: Long) {
            val task = tasks.find { it.id == id } ?: return
            tasks[tasks.indexOf(task)] = task.copy(overdueNotifiedDay = epochDay)
        }
    }

    private class FakeReminderScheduler(private val store: FakeTaskStore) : ReminderScheduler {
        val scheduled = mutableMapOf<Long, Long>()
        val cancelled = mutableListOf<Long>()

        override suspend fun schedule(taskId: Long, reminderAtMillis: Long): JarvisResult<Task> {
            scheduled[taskId] = reminderAtMillis
            return store.setReminder(taskId, reminderAtMillis, "work-$taskId")
        }

        override suspend fun cancel(taskId: Long): JarvisResult<Unit> {
            scheduled.remove(taskId)
            cancelled += taskId
            return store.clearReminder(taskId)
        }
    }

    private class FakeCalendarReader(
        private val events: List<CalendarEvent> = emptyList(),
        private val access: Boolean = true,
    ) : CalendarReader {
        override fun hasCalendarAccess(): Boolean = access

        override suspend fun eventsBetween(
            startMillis: Long,
            endMillis: Long,
        ): JarvisResult<List<CalendarEvent>> {
            if (!access) return JarvisResult.Failure("No calendar access.")
            return JarvisResult.Success(events.filter { it.startMillis in startMillis until endMillis })
        }
    }

    private class FakeScreenTimeReader(
        private val summary: ScreenTimeSummary = ScreenTimeSummary(
            totalMillis = 2 * 3_600_000L + 15 * 60_000L,
            topApps = listOf(UsageEntry("com.example.chat", 3_600_000L)),
        ),
        private val access: Boolean = true,
    ) : ScreenTimeReader {
        override fun hasUsageAccess(): Boolean = access

        override suspend fun todaySummary(): JarvisResult<ScreenTimeSummary> =
            if (access) JarvisResult.Success(summary)
            else JarvisResult.Failure("No usage access.")

        override suspend fun currentContinuousMillis(nowMillis: Long): JarvisResult<Long> =
            JarvisResult.Success(45 * 60_000L)
    }

    private class FakeFocusSessionManager : FocusSessionManager {
        var current: FocusSession? = null
        val historyList = mutableListOf<FocusSession>()

        override suspend fun currentSession(): FocusSession? = current

        override suspend fun start(durationMinutes: Int): JarvisResult<FocusSession> {
            if (current != null) return JarvisResult.Failure("A focus session is already running.")
            val session = FocusSession(
                id = 1,
                startedAtMillis = 1_793_050_200_000L,
                durationMinutes = durationMinutes,
                previousDndMode = "OFF",
            )
            current = session
            return JarvisResult.Success(session)
        }

        override suspend fun stop(): JarvisResult<FocusSession?> {
            val stopped = current?.copy(
                status = FocusSessionStatus.CANCELLED,
                endedAtMillis = 1_793_050_200_000L,
            )
            current = null
            stopped?.let { historyList += it }
            return JarvisResult.Success(stopped)
        }

        override suspend fun endSession(sessionId: Long): JarvisResult<Unit> {
            current = null
            return JarvisResult.Success(Unit)
        }

        override suspend fun history(limit: Int): List<FocusSession> = historyList.take(limit)
    }

    private class FakeBriefingProvider(private val text: String = "Good morning — clear day.") :
        BriefingProvider {
        override suspend fun briefing(): JarvisResult<String> = JarvisResult.Success(text)
    }

    private fun fixture() = Fixture()

    private inner class Fixture {
        val store = FakeTaskStore()
        val reminders = FakeReminderScheduler(store)
        val calendar = FakeCalendarReader()
        val screenTime = FakeScreenTimeReader()
        val focus = FakeFocusSessionManager()
        val briefing = FakeBriefingProvider()
        val now = { nowMillis }

        val createTask = CreateTaskTool(store, now)
        val listTasks = ListTasksTool(store, now)
        val completeTask = CompleteTaskTool(store)
        val deleteTask = DeleteTaskTool(store, reminders)
        val setReminder = SetReminderTool(store, reminders, now)
        val listEvents = ListEventsTool(calendar, now)
        val morningBriefing = MorningBriefingTool(briefing)
        val startFocus = StartFocusTool(focus)
        val stopFocus = StopFocusTool(focus)
        val getScreenTime = GetScreenTimeTool(screenTime)
    }

    // ── create_task ───────────────────────────────────────────────────

    @Test
    fun `create_task creates with title and priority`() = runBlocking {
        val f = fixture()
        val result = f.createTask.execute(
            buildJsonObject {
                put("title", "Buy milk")
                put("priority", "high")
            },
        )
        assertTrue(result is JarvisResult.Success)
        assertEquals(1, f.store.tasks.size)
        assertEquals(TaskPriority.HIGH, f.store.tasks[0].priority)
        assertTrue((result as JarvisResult.Success).value.message.contains("Buy milk"))
    }

    @Test
    fun `create_task parses a plain-words due date`() = runBlocking {
        val f = fixture()
        val dryRun = f.createTask.dryRun(
            buildJsonObject {
                put("title", "Pay rent")
                put("due", "tomorrow at 5pm")
            },
        )
        assertTrue(dryRun.contains("Pay rent"))
        assertTrue(dryRun.contains("17:00") || dryRun.contains("5:00"))
        val result = f.createTask.execute(
            buildJsonObject {
                put("title", "Pay rent")
                put("due", "tomorrow at 5pm")
            },
        )
        assertTrue(result is JarvisResult.Success)
        // Tomorrow (2026-11-16) 17:00 in the system zone — must be in the future.
        assertTrue(f.store.tasks[0].dueAtMillis!! > nowMillis)
    }

    @Test
    fun `create_task refuses an unparseable due date, never guesses`() = runBlocking {
        val f = fixture()
        val dryRun = f.createTask.dryRun(
            buildJsonObject {
                put("title", "Pay rent")
                put("due", "someday soonish")
            },
        )
        assertTrue(dryRun.contains("couldn't understand"))
        val result = f.createTask.execute(
            buildJsonObject {
                put("title", "Pay rent")
                put("due", "someday soonish")
            },
        )
        assertTrue(result is JarvisResult.Failure)
        assertTrue(f.store.tasks.isEmpty())
    }

    @Test
    fun `create_task refuses a past due date and an unknown priority`() = runBlocking {
        val f = fixture()
        val past = f.createTask.execute(
            buildJsonObject {
                put("title", "Old")
                put("due", "2020-01-01")
            },
        )
        assertTrue(past is JarvisResult.Failure)
        val badPriority = f.createTask.execute(
            buildJsonObject {
                put("title", "Old")
                put("priority", "critical")
            },
        )
        assertTrue(badPriority is JarvisResult.Failure)
    }

    // ── list_tasks / complete_task / delete_task ──────────────────────

    @Test
    fun `list_tasks filters open, done, and overdue`() = runBlocking {
        val f = fixture()
        f.store.create(Task(title = "open", dueAtMillis = nowMillis + 100_000L))
        f.store.create(Task(title = "late", dueAtMillis = nowMillis - 100_000L))
        val doneId = (f.store.create(Task(title = "done")) as JarvisResult.Success).value
        f.store.complete(doneId)

        val open = f.listTasks.execute(buildJsonObject { put("filter", "open") })
        val openText = (open as JarvisResult.Success).value.message
        assertTrue(openText.contains("open"))
        assertTrue(openText.contains("late"))
        assertFalse(openText.contains("done"))

        val overdue = f.listTasks.execute(buildJsonObject { put("filter", "overdue") })
        val overdueText = (overdue as JarvisResult.Success).value.message
        assertTrue(overdueText.contains("late"))
        assertTrue(overdueText.contains("OVERDUE"))
        assertFalse(overdueText.contains("open"))

        val done = f.listTasks.execute(buildJsonObject { put("filter", "done") })
        assertTrue((done as JarvisResult.Success).value.message.contains("done"))
    }

    @Test
    fun `list_tasks caps the formatted output at 50 and says how many more there are`() = runBlocking {
        val f = fixture()
        repeat(60) { index ->
            f.store.create(Task(title = "task-$index"))
        }
        val result = f.listTasks.execute(buildJsonObject { put("filter", "all") })
        assertTrue(result is JarvisResult.Success)
        val message = (result as JarvisResult.Success).value.message
        assertTrue(message.contains("task-0"))
        assertFalse(message.contains("task-59"))
        assertTrue(message.contains("…and 10 more"))
    }

    @Test
    fun `list_tasks on an empty list says so`() = runBlocking {
        val f = fixture()
        val result = f.listTasks.execute(buildJsonObject { put("filter", "overdue") })
        assertTrue((result as JarvisResult.Success).value.message.contains("No overdue tasks"))
    }

    @Test
    fun `complete_task marks done and refuses unknown ids`() = runBlocking {
        val f = fixture()
        val id = (f.store.create(Task(title = "Buy milk")) as JarvisResult.Success).value
        val result = f.completeTask.execute(buildJsonObject { put("task_id", id.toInt()) })
        assertTrue(result is JarvisResult.Success)
        assertEquals(TaskStatus.DONE, f.store.getById(id)?.status)
        val unknown = f.completeTask.execute(buildJsonObject { put("task_id", 99) })
        assertTrue(unknown is JarvisResult.Failure)
    }

    @Test
    fun `delete_task removes the task and cancels its reminder`() = runBlocking {
        val f = fixture()
        val id = (f.store.create(
            Task(title = "Buy milk", reminderAtMillis = nowMillis + 100_000L),
        ) as JarvisResult.Success).value
        val result = f.deleteTask.execute(buildJsonObject { put("task_id", id.toInt()) })
        assertTrue(result is JarvisResult.Success)
        assertEquals(null, f.store.getById(id))
        assertTrue(f.reminders.cancelled.contains(id))
    }

    // ── set_reminder ──────────────────────────────────────────────────

    @Test
    fun `set_reminder schedules at the parsed time`() = runBlocking {
        val f = fixture()
        val id = (f.store.create(Task(title = "Buy milk")) as JarvisResult.Success).value
        val dryRun = f.setReminder.dryRun(
            buildJsonObject {
                put("task_id", id.toInt())
                put("when", "tomorrow at 9am")
            },
        )
        assertTrue(dryRun.contains("Buy milk"))
        val result = f.setReminder.execute(
            buildJsonObject {
                put("task_id", id.toInt())
                put("when", "tomorrow at 9am")
            },
        )
        assertTrue(result is JarvisResult.Success)
        assertTrue(f.reminders.scheduled.containsKey(id))
        assertTrue(f.store.getById(id)?.reminderAtMillis!! > nowMillis)
    }

    @Test
    fun `set_reminder refuses unparseable and past times`() = runBlocking {
        val f = fixture()
        val id = (f.store.create(Task(title = "Buy milk")) as JarvisResult.Success).value
        val bad = f.setReminder.execute(
            buildJsonObject {
                put("task_id", id.toInt())
                put("when", "whenever")
            },
        )
        assertTrue(bad is JarvisResult.Failure)
        val past = f.setReminder.execute(
            buildJsonObject {
                put("task_id", id.toInt())
                put("when", "2020-01-01")
            },
        )
        assertTrue(past is JarvisResult.Failure)
        assertFalse(f.reminders.scheduled.containsKey(id))
    }

    // ── list_events / morning_briefing ────────────────────────────────

    @Test
    fun `list_events shows events and handles an empty day`() = runBlocking {
        // Place the event at 18:00 on the same local day as `now`.
        val zone = java.time.ZoneId.systemDefault()
        val dayStart = java.time.LocalDate.ofInstant(
            java.time.Instant.ofEpochMilli(nowMillis),
            zone,
        ).atStartOfDay(zone).toInstant().toEpochMilli()
        val event = CalendarEvent(
            id = 1,
            title = "Dentist",
            startMillis = dayStart + 18 * 3_600_000L,
            endMillis = dayStart + 19 * 3_600_000L,
            location = "Clinic",
        )
        val reader = FakeCalendarReader(events = listOf(event))
        val tool = ListEventsTool(reader, nowMillis = { nowMillis })
        val result = tool.execute(buildJsonObject { put("day", "today") })
        val text = (result as JarvisResult.Success).value.message
        assertTrue(text.contains("Dentist"))
        assertTrue(text.contains("Clinic"))
        assertTrue(text.contains("18:00"))

        val empty = ListEventsTool(FakeCalendarReader(), nowMillis = { nowMillis })
        val emptyResult = empty.execute(buildJsonObject { put("day", "tomorrow") })
        assertTrue((emptyResult as JarvisResult.Success).value.message.contains("No events"))
    }

    @Test
    fun `list_events without calendar access fails plainly`() = runBlocking {
        val tool = ListEventsTool(FakeCalendarReader(access = false), nowMillis = { nowMillis })
        val result = tool.execute(buildJsonObject { put("day", "today") })
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("App permissions"))
    }

    @Test
    fun `morning_briefing returns the provider text`() = runBlocking {
        val f = fixture()
        val result = f.morningBriefing.execute(buildJsonObject {})
        assertEquals(
            "Good morning — clear day.",
            (result as JarvisResult.Success).value.message,
        )
    }

    // ── focus ─────────────────────────────────────────────────────────

    @Test
    fun `start_focus starts a session and refuses a second one`() = runBlocking {
        val f = fixture()
        val result = f.startFocus.execute(buildJsonObject { put("duration_minutes", 25) })
        assertTrue(result is JarvisResult.Success)
        assertTrue((result as JarvisResult.Success).value.message.contains("25 minutes"))
        val second = f.startFocus.execute(buildJsonObject { put("duration_minutes", 50) })
        assertTrue(second is JarvisResult.Failure)
        val dryRun = f.startFocus.dryRun(buildJsonObject { put("duration_minutes", 50) })
        assertTrue(dryRun.contains("already running"))
    }

    @Test
    fun `start_focus validates the duration range`() = runBlocking {
        val f = fixture()
        val tooShort = f.startFocus.execute(buildJsonObject { put("duration_minutes", 2) })
        assertTrue(tooShort is JarvisResult.Failure)
        val tooLong = f.startFocus.execute(buildJsonObject { put("duration_minutes", 500) })
        assertTrue(tooLong is JarvisResult.Failure)
    }

    @Test
    fun `stop_focus stops the session and is a no-op when none runs`() = runBlocking {
        val f = fixture()
        val none = f.stopFocus.execute(buildJsonObject {})
        assertTrue((none as JarvisResult.Success).value.message.contains("No focus session"))
        f.startFocus.execute(buildJsonObject { put("duration_minutes", 25) })
        val stopped = f.stopFocus.execute(buildJsonObject {})
        assertTrue((stopped as JarvisResult.Success).value.message.contains("stopped early"))
        assertEquals(null, f.focus.current)
    }

    // ── screen time ───────────────────────────────────────────────────

    @Test
    fun `get_screen_time shows the summary`() = runBlocking {
        val f = fixture()
        val result = f.getScreenTime.execute(buildJsonObject {})
        val text = (result as JarvisResult.Success).value.message
        assertTrue(text.contains("2h 15m"))
        assertTrue(text.contains("com.example.chat"))
    }

    @Test
    fun `get_screen_time without usage access fails plainly`() = runBlocking {
        val tool = GetScreenTimeTool(FakeScreenTimeReader(access = false))
        val result = tool.execute(buildJsonObject {})
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("usage access"))
    }

    // ── registry ──────────────────────────────────────────────────────

    @Test
    fun `registry holds all 45 built-in tools including the ten productivity tools`() {
        val registry = ToolRegistry()
        BuiltInTools.registerAll(registry = registry, device = FakePhoneDevice())
        assertEquals(45, registry.all().size)
        listOf(
            "create_task", "list_tasks", "complete_task", "delete_task", "set_reminder",
            "list_events", "morning_briefing", "start_focus", "stop_focus", "get_screen_time",
        ).forEach { name ->
            assertTrue("missing tool $name", registry.get(name) != null)
        }
    }
}
