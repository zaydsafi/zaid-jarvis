package com.zaid.jarvis.tools.social

import com.zaid.jarvis.core.confirmation.sha256Hex
import com.zaid.jarvis.core.research.ContentDraft
import com.zaid.jarvis.core.research.DraftStatus
import com.zaid.jarvis.core.social.PublishRequest
import com.zaid.jarvis.core.social.PublishResult
import com.zaid.jarvis.core.social.ScheduledPost
import com.zaid.jarvis.core.social.ScheduledPostStatus
import com.zaid.jarvis.core.social.SocialAccount
import com.zaid.jarvis.core.social.SocialPlatform
import com.zaid.jarvis.core.util.JarvisResult
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Social publishing tools (Phase 8) with fakes — no network, no
 * WorkManager, no Room. The gate itself (APPROVED-only, content
 * binding, char limits) is tested in :agent's PublishServiceTest;
 * these tests cover the tool layer: previews, parameter validation,
 * and the messages Zaid sees.
 */
class PublishingToolsTest {

    private val now = 1_700_000_000_000L

    private fun approvedDraft(id: Long = 1L, platform: String = "X / Twitter") =
        ContentDraft(
            id = id,
            title = "Test post",
            body = "Hello from Jarvis.",
            platform = platform,
            status = DraftStatus.APPROVED,
            approvedBodyHash = sha256Hex("Hello from Jarvis."),
        )

    private class FakePublishService(
        val drafts: MutableMap<Long, ContentDraft> = mutableMapOf(),
        var publishResult: JarvisResult<PublishResult> = JarvisResult.Success(
            PublishResult(SocialPlatform.X, "123", "https://x.com/zaid/status/123", 0L),
        ),
    ) : PublishService {
        var publishedDraftId: Long? = null
        var publishedImageUrl: String? = null

        override suspend fun getDraft(draftId: Long): ContentDraft? = drafts[draftId]

        override suspend fun publishDraftNow(
            draftId: Long,
            imageUrl: String?,
        ): JarvisResult<PublishResult> {
            publishedDraftId = draftId
            publishedImageUrl = imageUrl
            return publishResult
        }

        override suspend fun publishScheduled(
            scheduledPostId: Long,
        ): JarvisResult<PublishResult> = publishResult
    }

    private class FakePublisher(
        val accounts: MutableMap<SocialPlatform, SocialAccount> = mutableMapOf(),
    ) : SocialPublisher {
        override suspend fun connectedAccount(platform: SocialPlatform): SocialAccount? =
            accounts[platform]

        override suspend fun publish(request: PublishRequest): JarvisResult<PublishResult> =
            JarvisResult.Failure("FakePublisher.publish should not be called by the tools.")

        override suspend fun fetchProfile(platform: SocialPlatform): JarvisResult<SocialAccount> =
            JarvisResult.Failure("Not used in tool tests.")
    }

    private class FakeScheduler(
        val posts: MutableList<ScheduledPost> = mutableListOf(),
    ) : SocialScheduler {
        var nextId = 1L
        var scheduledImageUrl: String? = null

        override suspend fun schedule(
            draftId: Long,
            platform: SocialPlatform,
            accountHandle: String,
            scheduledAtMillis: Long,
            contentHash: String,
            imageUrl: String?,
        ): JarvisResult<ScheduledPost> {
            scheduledImageUrl = imageUrl
            val post = ScheduledPost(
                id = nextId++,
                draftId = draftId,
                platform = platform,
                accountHandle = accountHandle,
                scheduledAtMillis = scheduledAtMillis,
                contentHash = contentHash,
                imageUrl = imageUrl,
            )
            posts += post
            return JarvisResult.Success(post)
        }

        override suspend fun cancel(scheduledPostId: Long): JarvisResult<Unit> {
            val post = posts.find { it.id == scheduledPostId }
                ?: return JarvisResult.Failure("No scheduled post with id $scheduledPostId.")
            if (post.status != ScheduledPostStatus.SCHEDULED) {
                return JarvisResult.Failure("Already ${post.status.name.lowercase()}.")
            }
            posts.remove(post)
            posts += post.copy(status = ScheduledPostStatus.CANCELLED)
            return JarvisResult.Success(Unit)
        }

        override suspend fun listAll(): List<ScheduledPost> = posts.toList()

        override suspend fun getById(scheduledPostId: Long): ScheduledPost? =
            posts.find { it.id == scheduledPostId }

        override suspend fun delete(scheduledPostId: Long) {
            posts.removeAll { it.id == scheduledPostId }
        }
    }

    private fun account(platform: SocialPlatform = SocialPlatform.X) =
        SocialAccount(platform, "42", "zaid", "Zaid")

    private fun fixture(
        draft: ContentDraft? = approvedDraft(),
        connected: Boolean = true,
    ): Triple<FakePublishService, FakePublisher, FakeScheduler> {
        val service = FakePublishService()
        if (draft != null) service.drafts[draft.id] = draft
        val publisher = FakePublisher()
        if (connected) {
            publisher.accounts[SocialPlatform.X] = account()
            publisher.accounts[SocialPlatform.INSTAGRAM] =
                account(SocialPlatform.INSTAGRAM).copy(handle = "zaid.ig")
        }
        return Triple(service, publisher, FakeScheduler())
    }

    // ── publish_draft ────────────────────────────────────────────────

    @Test
    fun `publish_draft preview shows the exact text, platform, and account`() = runBlocking {
        val (service, publisher, _) = fixture()
        val tool = PublishDraftTool(service, publisher)
        val preview = tool.dryRun(buildJsonObject { put("draft_id", 1) })
        assertTrue(preview.contains("Hello from Jarvis."))
        assertTrue(preview.contains("X / Twitter"))
        assertTrue(preview.contains("@zaid"))
    }

    @Test
    fun `publish_draft preview refuses a DRAFT with a clear message`() = runBlocking {
        val draft = approvedDraft().copy(status = DraftStatus.DRAFT)
        val (service, publisher, _) = fixture(draft)
        val tool = PublishDraftTool(service, publisher)
        val preview = tool.dryRun(buildJsonObject { put("draft_id", 1) })
        assertTrue(preview.contains("not approved"))
    }

    @Test
    fun `publish_draft preview refuses a draft edited after approval`() = runBlocking {
        // Phase 11: the card must be honest — execute() already refused
        // this (PublishServiceImpl), but the preview used to offer the
        // publish anyway.
        val draft = approvedDraft().copy(
            body = "Edited text Zaid never approved.",
            approvedBodyHash = sha256Hex("Hello from Jarvis."),
        )
        val (service, publisher, _) = fixture(draft)
        val tool = PublishDraftTool(service, publisher)
        val preview = tool.dryRun(buildJsonObject { put("draft_id", 1) })
        assertTrue(preview.contains("edited after you approved it"))
    }

    @Test
    fun `publish_draft preview refuses a missing draft`() = runBlocking {
        val (service, publisher, _) = fixture(draft = null)
        val tool = PublishDraftTool(service, publisher)
        val preview = tool.dryRun(buildJsonObject { put("draft_id", 99) })
        assertTrue(preview.contains("no draft with that id"))
    }

    @Test
    fun `publish_draft preview refuses when no account is connected`() = runBlocking {
        val (service, publisher, _) = fixture(connected = false)
        val tool = PublishDraftTool(service, publisher)
        val preview = tool.dryRun(buildJsonObject { put("draft_id", 1) })
        assertTrue(preview.contains("no account connected"))
    }

    @Test
    fun `publish_draft preview warns when an Instagram post has no image URL`() = runBlocking {
        val draft = approvedDraft(platform = "Instagram")
        val (service, publisher, _) = fixture(draft)
        val tool = PublishDraftTool(service, publisher)
        val preview = tool.dryRun(buildJsonObject { put("draft_id", 1) })
        assertTrue(preview.contains("needs a photo"))
    }

    @Test
    fun `publish_draft executes and reports the post link`() = runBlocking {
        val (service, publisher, _) = fixture()
        val tool = PublishDraftTool(service, publisher)
        val result = tool.execute(buildJsonObject { put("draft_id", 1) })
        assertTrue(result is JarvisResult.Success)
        val message = (result as JarvisResult.Success).value.message
        assertTrue(message.contains("Published to X / Twitter"))
        assertTrue(message.contains("https://x.com/zaid/status/123"))
        assertEquals(1L, service.publishedDraftId)
    }

    @Test
    fun `publish_draft passes the image URL through`() = runBlocking {
        val draft = approvedDraft(platform = "Instagram")
        val (service, publisher, _) = fixture(draft)
        val tool = PublishDraftTool(service, publisher)
        tool.execute(buildJsonObject {
            put("draft_id", 1)
            put("image_url", "https://example.com/photo.jpg")
        })
        assertEquals("https://example.com/photo.jpg", service.publishedImageUrl)
    }

    @Test
    fun `publish_draft refuses edited preview content`() {
        val (service, publisher, _) = fixture()
        val tool = PublishDraftTool(service, publisher)
        val original = buildJsonObject { put("draft_id", 1) }
        assertEquals(null, tool.paramsFromEditedContent("edited text", original))
    }

    // ── schedule_post ────────────────────────────────────────────────

    @Test
    fun `schedule_post preview shows text, platform, and time`() = runBlocking {
        val (service, publisher, scheduler) = fixture()
        val tool = SchedulePostTool(service, publisher, scheduler) { now }
        val preview = tool.dryRun(buildJsonObject {
            put("draft_id", 1)
            put("delay_minutes", 60)
        })
        assertTrue(preview.contains("Hello from Jarvis."))
        assertTrue(preview.contains("X / Twitter"))
        assertTrue(preview.contains("@zaid"))
    }

    @Test
    fun `schedule_post refuses a delay under 5 minutes`() = runBlocking {
        val (service, publisher, scheduler) = fixture()
        val tool = SchedulePostTool(service, publisher, scheduler) { now }
        val result = tool.execute(buildJsonObject {
            put("draft_id", 1)
            put("delay_minutes", 3)
        })
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("5 minutes"))
        assertTrue(scheduler.posts.isEmpty())
    }

    @Test
    fun `schedule_post refuses a draft edited after approval`() = runBlocking {
        // Phase 11 regression: scheduling an edited-after-approval
        // draft used to succeed, and the worker's schedule-time hash
        // check could not catch it (the hash was recorded from the
        // edited text) — unapproved text could reach the queue and be
        // published. Both the tool and the worker now refuse it.
        val draft = approvedDraft().copy(
            body = "Edited text Zaid never approved.",
            approvedBodyHash = sha256Hex("Hello from Jarvis."),
        )
        val (service, publisher, scheduler) = fixture(draft)
        val tool = SchedulePostTool(service, publisher, scheduler) { now }
        val result = tool.execute(buildJsonObject {
            put("draft_id", 1)
            put("delay_minutes", 30)
        })
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("edited after you approved it"))
        assertTrue(scheduler.posts.isEmpty())
    }

    @Test
    fun `schedule_post preview refuses a draft edited after approval`() = runBlocking {
        val draft = approvedDraft().copy(
            body = "Edited text Zaid never approved.",
            approvedBodyHash = sha256Hex("Hello from Jarvis."),
        )
        val (service, publisher, scheduler) = fixture(draft)
        val tool = SchedulePostTool(service, publisher, scheduler) { now }
        val preview = tool.dryRun(buildJsonObject {
            put("draft_id", 1)
            put("delay_minutes", 30)
        })
        assertTrue(preview.contains("edited after you approved it"))
    }

    @Test
    fun `schedule_post schedules with the content hash of the current body`() = runBlocking {
        val (service, publisher, scheduler) = fixture()
        val tool = SchedulePostTool(service, publisher, scheduler) { now }
        val result = tool.execute(buildJsonObject {
            put("draft_id", 1)
            put("delay_minutes", 30)
        })
        assertTrue(result is JarvisResult.Success)
        assertEquals(1, scheduler.posts.size)
        val post = scheduler.posts.single()
        assertEquals(now + 30 * 60_000L, post.scheduledAtMillis)
        assertEquals(sha256Hex("Hello from Jarvis."), post.contentHash)
        assertEquals(SocialPlatform.X, post.platform)
        assertEquals("zaid", post.accountHandle)
    }

    @Test
    fun `schedule_post refuses a DRAFT`() = runBlocking {
        val draft = approvedDraft().copy(status = DraftStatus.DRAFT)
        val (service, publisher, scheduler) = fixture(draft)
        val tool = SchedulePostTool(service, publisher, scheduler) { now }
        val result = tool.execute(buildJsonObject {
            put("draft_id", 1)
            put("delay_minutes", 30)
        })
        assertTrue(result is JarvisResult.Failure)
        assertTrue(scheduler.posts.isEmpty())
    }

    // ── list_scheduled_posts ─────────────────────────────────────────

    @Test
    fun `list_scheduled_posts reports an empty list honestly`() = runBlocking {
        val (_, _, scheduler) = fixture()
        val tool = ListScheduledPostsTool(scheduler)
        val result = tool.execute(buildJsonObject {})
        assertTrue(result is JarvisResult.Success)
        assertTrue((result as JarvisResult.Success).value.message.contains("No scheduled posts"))
    }

    @Test
    fun `list_scheduled_posts shows statuses and failure reasons`() = runBlocking {
        val (_, _, scheduler) = fixture()
        scheduler.posts += ScheduledPost(
            id = 1, draftId = 1, platform = SocialPlatform.X, accountHandle = "zaid",
            scheduledAtMillis = now + 60_000L, contentHash = "abc",
            status = ScheduledPostStatus.FAILED, failureReason = "Rate limited",
        )
        scheduler.posts += ScheduledPost(
            id = 2, draftId = 1, platform = SocialPlatform.THREADS, accountHandle = "zaid",
            scheduledAtMillis = now + 3_600_000L, contentHash = "abc",
        )
        val tool = ListScheduledPostsTool(scheduler)
        val result = tool.execute(buildJsonObject {})
        val message = (result as JarvisResult.Success).value.message
        assertTrue(message.contains("failed: Rate limited"))
        assertTrue(message.contains("Threads"))
    }

    @Test
    fun `list_scheduled_posts caps the formatted output at 50 and says how many more there are`() = runBlocking {
        val (_, _, scheduler) = fixture()
        repeat(60) { index ->
            scheduler.posts += ScheduledPost(
                id = index + 1L, draftId = 1, platform = SocialPlatform.X,
                accountHandle = "zaid",
                scheduledAtMillis = now + 60_000L * (index + 1), contentHash = "abc",
            )
        }
        val tool = ListScheduledPostsTool(scheduler)
        val result = tool.execute(buildJsonObject {})
        assertTrue(result is JarvisResult.Success)
        val message = (result as JarvisResult.Success).value.message
        assertTrue(message.contains("#1 ·"))
        assertFalse(message.contains("#60 ·"))
        assertTrue(message.contains("…and 10 more"))
    }

    // ── cancel_scheduled_post ────────────────────────────────────────

    @Test
    fun `cancel_scheduled_post preview names the platform and time`() = runBlocking {
        val (_, _, scheduler) = fixture()
        scheduler.posts += ScheduledPost(
            id = 7, draftId = 1, platform = SocialPlatform.LINKEDIN, accountHandle = "Zaid",
            scheduledAtMillis = now + 3_600_000L, contentHash = "abc",
        )
        val tool = CancelScheduledPostTool(scheduler)
        val preview = tool.dryRun(buildJsonObject { put("scheduled_post_id", 7) })
        assertTrue(preview.contains("LinkedIn"))
    }

    @Test
    fun `cancel_scheduled_post cancels a scheduled post`() = runBlocking {
        val (_, _, scheduler) = fixture()
        scheduler.posts += ScheduledPost(
            id = 7, draftId = 1, platform = SocialPlatform.X, accountHandle = "zaid",
            scheduledAtMillis = now + 3_600_000L, contentHash = "abc",
        )
        val tool = CancelScheduledPostTool(scheduler)
        val result = tool.execute(buildJsonObject { put("scheduled_post_id", 7) })
        assertTrue(result is JarvisResult.Success)
        assertEquals(ScheduledPostStatus.CANCELLED, scheduler.posts.single().status)
    }

    @Test
    fun `cancel_scheduled_post refuses an unknown id`() = runBlocking {
        val (_, _, scheduler) = fixture()
        val tool = CancelScheduledPostTool(scheduler)
        val result = tool.execute(buildJsonObject { put("scheduled_post_id", 99) })
        assertTrue(result is JarvisResult.Failure)
    }
}
