package com.zaid.jarvis.tools.phone

import com.zaid.jarvis.core.util.JarvisResult

/**
 * In-memory [PhoneDevice] for tests. Holds fake device state (torch,
 * volumes, brightness, wifi, bluetooth, DND, contacts, apps) and
 * records every [SystemAction] it is asked to launch — so tests can
 * assert exactly which intent a tool produced, without a device.
 */
class FakePhoneDevice(
    var batteryInfo: BatteryInfo = BatteryInfo(percent = 72, isCharging = false),
    var networkInfo: NetworkInfo = NetworkInfo(isOnline = true, type = "Wi-Fi"),
    var contacts: List<Contact> = listOf(
        Contact(1, "John Doe", "+15550100001"),
        Contact(2, "John Smith", "+15550100002"),
        Contact(3, "Jane Doe", "+15550100003"),
        Contact(4, "Alice", "+15550100004"),
    ),
    var apps: List<AppInfo> = listOf(
        AppInfo("Maps", "com.google.android.apps.maps"),
        AppInfo("Messages", "com.google.android.apps.messaging"),
        AppInfo("Clock", "com.google.android.deskclock"),
        AppInfo("Settings", "com.android.settings"),
    ),
    var flashlightOn: Boolean = false,
    var volumes: MutableMap<VolumeStream, Int> = mutableMapOf(
        VolumeStream.MUSIC to 4,
        VolumeStream.ALARM to 7,
        VolumeStream.RING to 5,
        VolumeStream.NOTIFICATION to 5,
        VolumeStream.CALL to 3,
        VolumeStream.SYSTEM to 5,
    ),
    var volumeMax: Int = 15,
    var brightness: Int = 40,
    var autoBrightnessOn: Boolean = false,
    var wifiOn: Boolean = true,
    /** When true, setWifi reports the Android 10+ panel fallback. */
    var wifiDirectToggleUnavailable: Boolean = false,
    var bluetoothOn: Boolean = false,
    /** When true, enabling Bluetooth reports the Android 13+ dialog. */
    var bluetoothEnableNeedsDialog: Boolean = false,
    var dndModeValue: DndMode = DndMode.OFF,
    var grantedPermissions: MutableSet<String> = mutableSetOf(
        "android.permission.READ_CONTACTS",
        "android.permission.CAMERA",
        "android.permission.BLUETOOTH_CONNECT",
    ),
    /** When false, the device has no flashlight hardware. */
    var hasFlashlight: Boolean = true,
    /** When false, brightness changes are refused (no WRITE_SETTINGS). */
    var canWriteSettings: Boolean = true,
    /** When false, DND changes are refused (no policy access). */
    var hasDndAccess: Boolean = true,
) : PhoneDevice {

    /** Every SystemAction this fake was asked to launch, in order. */
    val launchedActions: MutableList<SystemAction> = mutableListOf()

    override suspend fun battery(): JarvisResult<BatteryInfo> =
        JarvisResult.Success(batteryInfo)

    override suspend fun network(): JarvisResult<NetworkInfo> =
        JarvisResult.Success(networkInfo)

    override suspend fun searchContacts(query: String): JarvisResult<List<Contact>> {
        if (!hasPermission("android.permission.READ_CONTACTS")) {
            return JarvisResult.Failure("No contacts permission.")
        }
        val q = query.lowercase()
        return JarvisResult.Success(contacts.filter { it.name.lowercase().contains(q) })
    }

    override suspend fun listApps(query: String?): JarvisResult<List<AppInfo>> {
        val q = query?.trim()?.lowercase()
        val filtered = if (q.isNullOrEmpty()) {
            apps
        } else {
            apps.filter {
                it.name.lowercase().contains(q) || it.packageName.lowercase().contains(q)
            }
        }
        return JarvisResult.Success(filtered)
    }

    override suspend fun isFlashlightOn(): JarvisResult<Boolean> =
        if (hasFlashlight) JarvisResult.Success(flashlightOn)
        else JarvisResult.Failure("This device doesn't have a flashlight.")

    override suspend fun setFlashlight(on: Boolean): JarvisResult<Boolean> {
        if (!hasFlashlight) return JarvisResult.Failure("This device doesn't have a flashlight.")
        val previous = flashlightOn
        flashlightOn = on
        return JarvisResult.Success(previous)
    }

    override suspend fun volumeInfo(stream: VolumeStream): JarvisResult<VolumeInfo> =
        JarvisResult.Success(VolumeInfo(stream, volumes.getOrDefault(stream, 0), volumeMax))

    override suspend fun setVolume(stream: VolumeStream, level: Int): JarvisResult<VolumeInfo> {
        val previous = VolumeInfo(stream, volumes.getOrDefault(stream, 0), volumeMax)
        volumes[stream] = level
        return JarvisResult.Success(previous)
    }

    override suspend fun brightnessPercent(): JarvisResult<Int> =
        JarvisResult.Success(brightness)

    override suspend fun setBrightnessPercent(percent: Int): JarvisResult<BrightnessChange> {
        if (!canWriteSettings) {
            return JarvisResult.Failure("Modify system settings not granted.")
        }
        val previous = brightness
        brightness = percent
        return JarvisResult.Success(BrightnessChange(previous, autoBrightnessOn))
    }

    override suspend fun isWifiEnabled(): JarvisResult<Boolean> =
        JarvisResult.Success(wifiOn)

    override suspend fun setWifi(enabled: Boolean): JarvisResult<WifiToggleResult> {
        if (wifiDirectToggleUnavailable) {
            launchedActions += SystemAction.OpenWifiPanel
            return JarvisResult.Success(WifiToggleResult.PanelOpened)
        }
        val previous = wifiOn
        wifiOn = enabled
        return JarvisResult.Success(WifiToggleResult.Changed(previous))
    }

    override suspend fun isBluetoothEnabled(): JarvisResult<Boolean> =
        JarvisResult.Success(bluetoothOn)

    override suspend fun setBluetooth(enabled: Boolean): JarvisResult<BluetoothToggleResult> {
        if (enabled && bluetoothEnableNeedsDialog) {
            launchedActions += SystemAction.RequestBluetoothEnable
            return JarvisResult.Success(BluetoothToggleResult.EnableDialogOpened)
        }
        val previous = bluetoothOn
        bluetoothOn = enabled
        return JarvisResult.Success(BluetoothToggleResult.Changed(previous))
    }

    override suspend fun dndMode(): JarvisResult<DndMode> =
        JarvisResult.Success(dndModeValue)

    override suspend fun setDndMode(mode: DndMode): JarvisResult<DndMode> {
        if (!hasDndAccess) {
            return JarvisResult.Failure("Do Not Disturb access not granted.")
        }
        val previous = dndModeValue
        dndModeValue = mode
        return JarvisResult.Success(previous)
    }

    override fun hasPermission(permission: String): Boolean =
        grantedPermissions.contains(permission)

    override suspend fun launch(action: SystemAction): JarvisResult<String> {
        launchedActions += action
        return JarvisResult.Success("Opened.")
    }
}
