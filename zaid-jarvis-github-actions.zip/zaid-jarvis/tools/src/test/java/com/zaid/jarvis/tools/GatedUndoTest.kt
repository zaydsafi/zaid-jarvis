package com.zaid.jarvis.tools

import com.zaid.jarvis.core.confirmation.ApprovalDecision
import com.zaid.jarvis.core.confirmation.ApprovalState
import com.zaid.jarvis.core.confirmation.AuditDecision
import com.zaid.jarvis.core.confirmation.ConfirmationEngine
import com.zaid.jarvis.core.confirmation.InMemoryAuditLog
import com.zaid.jarvis.core.confirmation.InMemoryTrustedActionStore
import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.phone.FakePhoneDevice
import com.zaid.jarvis.tools.phone.SystemAction
import com.zaid.jarvis.tools.phone.VolumeStream
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Gated execution + undo tests (Phase 5): a Tier 1 action run through
 * [GatedToolExecutor] records real undo data in the audit log; undoing
 * it shows its own approval card, restores the previous state, and a
 * denied undo changes nothing. Also covers edited-content binding:
 * an SMS body edited on the approval card is what actually gets sent
 * to the messaging app.
 */
class GatedUndoTest {

    private class Fixture {
        val device = FakePhoneDevice()
        val auditLog = InMemoryAuditLog()
        val engine = ConfirmationEngine(
            auditLog = auditLog,
            trustedStore = InMemoryTrustedActionStore(),
            killSwitch = KillSwitch(),
        )
        val registry = ToolRegistry().also {
            BuiltInTools.registerAll(it, device)
        }
        val executor = GatedToolExecutor(registry, engine)
        val scope = CoroutineScope(Dispatchers.Unconfined)

        suspend fun pendingId(): String {
            repeat(50) {
                engine.pendingRequest.value?.let { return it.id }
                delay(10)
            }
            error("No pending request appeared")
        }

        /** Approves the pending request (and the second confirmation, for Tier 2). */
        suspend fun approvePending() {
            val id = pendingId()
            assertTrue(engine.resolve(id, ApprovalDecision.Allow))
            delay(20)
            // Tier 2 moves to a second confirmation after Allow.
            engine.pendingRequest.value?.let { request ->
                if (request.state == ApprovalState.AWAITING_SECOND_CONFIRMATION) {
                    assertTrue(engine.resolve(id, ApprovalDecision.ConfirmSecond))
                }
            }
        }
    }

    @Test
    fun `a gated tier 1 action records undo data in the audit log`() = runBlocking {
        val f = Fixture()
        val job = f.scope.async {
            f.executor.execute(
                "set_volume",
                buildJsonObject { put("stream", "media"); put("level", 7) },
            )
        }
        f.approvePending()
        val result = job.await()
        assertTrue(result is JarvisResult.Success)
        assertEquals(7, f.device.volumes[VolumeStream.MUSIC])

        val entry = f.auditLog.observeAll().first().single()
        assertEquals("set_volume", entry.toolName)
        assertEquals(AuditDecision.ALLOWED, entry.decision)
        assertTrue(entry.undoable)
        assertNotNull(entry.undoData)
        assertTrue(entry.undoDescription!!.contains("4/15"))
        assertFalse(entry.undone)
    }

    @Test
    fun `undo through the gate restores the previous state`() = runBlocking {
        val f = Fixture()
        val job = f.scope.async {
            f.executor.execute(
                "set_volume",
                buildJsonObject { put("stream", "media"); put("level", 7) },
            )
        }
        f.approvePending()
        assertTrue(job.await() is JarvisResult.Success)
        assertEquals(7, f.device.volumes[VolumeStream.MUSIC])

        val entry = f.auditLog.observeAll().first().single { it.undoable }
        val undoJob = f.scope.async { f.executor.executeUndo(entry) }
        // Undo shows its own approval card.
        val undoRequestId = f.pendingId()
        assertTrue(f.engine.resolve(undoRequestId, ApprovalDecision.Allow))
        val undoResult = undoJob.await()
        assertTrue(undoResult is JarvisResult.Success)
        assertEquals(4, f.device.volumes[VolumeStream.MUSIC])
    }

    @Test
    fun `a denied undo changes nothing`() = runBlocking {
        val f = Fixture()
        val job = f.scope.async {
            f.executor.execute(
                "set_volume",
                buildJsonObject { put("stream", "media"); put("level", 7) },
            )
        }
        f.approvePending()
        assertTrue(job.await() is JarvisResult.Success)

        val entry = f.auditLog.observeAll().first().single { it.undoable }
        val undoJob = f.scope.async { f.executor.executeUndo(entry) }
        val undoRequestId = f.pendingId()
        assertTrue(f.engine.resolve(undoRequestId, ApprovalDecision.Deny))
        val undoResult = undoJob.await()
        assertTrue(undoResult is JarvisResult.Failure)
        assertEquals(7, f.device.volumes[VolumeStream.MUSIC]) // Unchanged.
    }

    @Test
    fun `undo refuses an already-undone entry`() = runBlocking {
        val f = Fixture()
        val job = f.scope.async {
            f.executor.execute(
                "set_volume",
                buildJsonObject { put("stream", "media"); put("level", 7) },
            )
        }
        f.approvePending()
        assertTrue(job.await() is JarvisResult.Success)

        val entry = f.auditLog.observeAll().first().single { it.undoable }
            .copy(undone = true)
        val result = f.executor.executeUndo(entry)
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("already undone"))
    }

    @Test
    fun `undo refuses a non-undoable entry`() = runBlocking {
        val f = Fixture()
        val job = f.scope.async { f.executor.execute("get_time", buildJsonObject {}) }
        f.approvePending()
        assertTrue(job.await() is JarvisResult.Success)

        val entry = f.auditLog.observeAll().first().single()
        assertFalse(entry.undoable)
        val result = f.executor.executeUndo(entry)
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("cannot be undone"))
    }

    @Test
    fun `a failed action records no undo data`() = runBlocking {
        val f = Fixture()
        val job = f.scope.async {
            f.executor.execute(
                "set_volume",
                buildJsonObject { put("stream", "media"); put("level", 99) },
            )
        }
        f.approvePending()
        val result = job.await()
        assertTrue(result is JarvisResult.Failure)

        val entry = f.auditLog.observeAll().first().single()
        assertFalse(entry.undoable)
        assertEquals(null, entry.undoData)
    }

    @Test
    fun `an sms body edited on the approval card is what gets sent`() = runBlocking {
        val f = Fixture()
        val job = f.scope.async {
            f.executor.execute(
                "send_sms",
                buildJsonObject { put("number", "+15550100001"); put("body", "Meet at 5?") },
            )
        }
        val requestId = f.pendingId()
        // Zaid edits the body on the card before allowing.
        val edited = "Send SMS to +15550100001:\nMeet at 6 instead?"
        assertTrue(f.engine.resolve(requestId, ApprovalDecision.Edit(edited)))
        // A new request appears for the edited content.
        delay(50)
        f.approvePending()
        val result = job.await()
        assertTrue(result is JarvisResult.Success)

        // The messaging app got the EDITED body, not the original.
        val launched = f.device.launchedActions.single()
        assertTrue(launched is SystemAction.SendSms)
        val sms = launched as SystemAction.SendSms
        assertEquals("Meet at 6 instead?", sms.body)

        // And the audit log recorded the edited parameters.
        val entry = f.auditLog.observeAll().first()
            .single { it.decision == AuditDecision.ALLOWED }
        assertTrue(entry.paramsSummary.contains("Meet at 6 instead?"))
    }

    @Test
    fun `a tool that cannot parse edited content refuses to run it`() = runBlocking {
        val f = Fixture()
        val job = f.scope.async {
            f.executor.execute(
                "set_volume",
                buildJsonObject { put("stream", "media"); put("level", 7) },
            )
        }
        val requestId = f.pendingId()
        assertTrue(
            f.engine.resolve(requestId, ApprovalDecision.Edit("Set volume to eleven, please")),
        )
        delay(50)
        f.approvePending()
        val result = job.await()
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("can't run edited content"))
        assertEquals(4, f.device.volumes[VolumeStream.MUSIC]) // Nothing changed.
    }

    @Test
    fun `the registry holds all 45 built-in tools`() {
        val f = Fixture()
        val names = f.registry.all().map { it.name }.toSet()
        assertEquals(45, names.size)
        assertTrue(names.containsAll(listOf("get_time", "calculator", "echo")))
        assertTrue(names.containsAll(listOf("get_battery", "get_network", "get_contacts", "list_installed_apps")))
        assertTrue(
            names.containsAll(
                listOf(
                    "set_flashlight", "set_volume", "set_brightness", "set_wifi",
                    "set_bluetooth", "set_alarm", "set_timer", "open_app", "set_do_not_disturb",
                ),
            ),
        )
        assertTrue(names.containsAll(listOf("make_call", "send_sms", "send_email", "share_text")))
        // Phase 6: Accessibility automation tools (registered with the
        // no-op device in this fixture — they fail clearly without the service).
        assertTrue(
            names.containsAll(
                listOf(
                    "find_on_screen", "tap_on_screen", "type_text", "scroll_screen",
                    "press_back", "press_home", "run_macro",
                ),
            ),
        )
        // Phase 7: research & content tools.
        assertTrue(
            names.containsAll(
                listOf("search_web", "fetch_page", "research_topic", "draft_post"),
            ),
        )
        // Phase 8: social publishing tools (registered with no-op
        // implementations in this fixture — they fail clearly without
        // a connected account).
        assertTrue(
            names.containsAll(
                listOf(
                    "publish_draft", "schedule_post", "list_scheduled_posts",
                    "cancel_scheduled_post",
                ),
            ),
        )
    }
}
