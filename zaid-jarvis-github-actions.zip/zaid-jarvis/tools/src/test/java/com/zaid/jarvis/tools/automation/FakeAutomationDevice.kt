package com.zaid.jarvis.tools.automation

import com.zaid.jarvis.core.automation.BlockedApps
import com.zaid.jarvis.core.automation.NodeSelector
import com.zaid.jarvis.core.automation.ScreenNode
import com.zaid.jarvis.core.automation.ScreenSnapshot
import com.zaid.jarvis.core.automation.SnapshotSanitizer
import com.zaid.jarvis.core.util.JarvisResult
import kotlinx.coroutines.delay

/**
 * In-memory [AutomationDevice] for tests. Holds a fake screen (a list
 * of nodes) and records every action — so tests can assert exactly
 * what a tool or a macro playback did, without a device.
 *
 * It mirrors the real service's guards: blocked banking packages
 * refuse snapshots and actions, password screens refuse tap/type/
 * scroll, and password nodes are dropped from snapshots (while
 * [hasPasswordField] still reports their presence).
 */
class FakeAutomationDevice(
    /** The nodes on the fake screen (password nodes are filtered from snapshots). */
    var nodes: MutableList<ScreenNode> = mutableListOf(
        ScreenNode(
            text = "Search",
            contentDescription = "Search the store",
            viewId = "com.example:id/search",
            className = "Button",
            clickable = true,
        ),
        ScreenNode(
            contentDescription = "Search box",
            viewId = "com.example:id/box",
            className = "EditText",
            clickable = true,
            editable = true,
        ),
    ),
    var packageName: String = "com.example",
    var hasPasswordField: Boolean = false,
    var automationEnabled: Boolean = true,
    var serviceConnected: Boolean = true,
    /** When false, scroll actions fail ("can't scroll any further"). */
    var canScroll: Boolean = true,
    /** When true, tap suspends for a long time (timeout tests). */
    var hangOnTap: Boolean = false,
    /** Hook run inside tap() (kill-switch tests cancel from here). */
    var onTap: (() -> Unit)? = null,
) : AutomationDevice {

    /** Every action performed, in order ("tap:Search", "type:hello", …). */
    val actions: MutableList<String> = mutableListOf()

    override suspend fun checkAvailable(): JarvisResult<Unit> {
        if (!automationEnabled) {
            return JarvisResult.Failure("Automation is turned off.")
        }
        if (!serviceConnected) {
            return JarvisResult.Failure("Accessibility service is not connected.")
        }
        return JarvisResult.Success(Unit)
    }

    override suspend fun snapshot(): JarvisResult<ScreenSnapshot> {
        BlockedApps.blockReason(packageName)?.let {
            return JarvisResult.Failure(it)
        }
        return JarvisResult.Success(
            ScreenSnapshot(
                packageName = packageName,
                nodes = nodes.filter { !it.isPassword },
                hasPasswordField = hasPasswordField || nodes.any { it.isPassword },
            ),
        )
    }

    override suspend fun tap(selector: NodeSelector): JarvisResult<String> {
        actionGuard()?.let { return it }
        if (hangOnTap) delay(5_000)
        onTap?.invoke()
        val node = nodes.firstOrNull { selector.matches(it) }
            ?: return JarvisResult.Failure(
                "I couldn't find ${selector.describe()} on the current screen.",
            )
        actions += "tap:${node.label ?: node.className}"
        return JarvisResult.Success("Tapped ${SnapshotSanitizer.describeNode(node)}.")
    }

    override suspend fun tapAt(x: Int, y: Int): JarvisResult<String> {
        actionGuard()?.let { return it }
        actions += "tapAt:$x,$y"
        return JarvisResult.Success("Tapped the point ($x, $y).")
    }

    override suspend fun typeText(selector: NodeSelector?, text: String): JarvisResult<String> {
        actionGuard()?.let { return it }
        val node = if (selector == null) {
            nodes.firstOrNull { it.editable && !it.isPassword }
        } else {
            nodes.firstOrNull { selector.matches(it) }
        } ?: return JarvisResult.Failure(
            if (selector == null) {
                "No text field is focused — tap a field first, then type."
            } else {
                "I couldn't find ${selector.describe()} to type into."
            },
        )
        if (!node.editable) {
            return JarvisResult.Failure("That element isn't an editable text field.")
        }
        actions += "type:$text"
        return JarvisResult.Success("Typed into ${SnapshotSanitizer.describeNode(node)}.")
    }

    override suspend fun scroll(forward: Boolean): JarvisResult<String> {
        actionGuard()?.let { return it }
        if (!canScroll) {
            return JarvisResult.Failure(
                "This screen can't scroll any further ${if (forward) "down" else "up"}.",
            )
        }
        actions += if (forward) "scroll:down" else "scroll:up"
        return JarvisResult.Success("Scrolled ${if (forward) "down" else "up"}.")
    }

    override suspend fun pressBack(): JarvisResult<String> {
        actions += "back"
        return JarvisResult.Success("Pressed Back.")
    }

    override suspend fun pressHome(): JarvisResult<String> {
        actions += "home"
        return JarvisResult.Success("Pressed Home.")
    }

    /** The service's guards, mirrored: blocked app / password screen. */
    private fun actionGuard(): JarvisResult.Failure? {
        BlockedApps.blockReason(packageName)?.let {
            return JarvisResult.Failure(it)
        }
        if (hasPasswordField || nodes.any { it.isPassword }) {
            return JarvisResult.Failure(
                "This screen has a password field — Jarvis never acts on " +
                    "screens with password fields.",
            )
        }
        return null
    }
}
