package com.zaid.jarvis.tools.phone

import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.ToolOutcome
import com.zaid.jarvis.tools.ToolSchema
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Phone tools tests (Phase 5): schemas, dry-run previews, execution
 * against [FakePhoneDevice], undo round-trips (state → change → undo →
 * original state), permission-missing failures, and the Tier 2 rule
 * that tools only ever *produce* a SystemAction for the system app —
 * they never place a call or send anything themselves.
 */
class PhoneToolsTest {

    // ── Tier 0 ────────────────────────────────────────────────────────

    @Test
    fun `get_battery reports level and charging state`() = runBlocking {
        val device = FakePhoneDevice(batteryInfo = BatteryInfo(72, true))
        val result = GetBatteryTool(device).execute(buildJsonObject {})
        assertEquals("Battery: 72% (charging).", successMessage(result))
    }

    @Test
    fun `get_battery handles unknown level`() = runBlocking {
        val device = FakePhoneDevice(batteryInfo = BatteryInfo(null, false))
        val result = GetBatteryTool(device).execute(buildJsonObject {})
        assertEquals("Battery: unknown (not charging).", successMessage(result))
    }

    @Test
    fun `get_network reports type and online state`() = runBlocking {
        val online = FakePhoneDevice(networkInfo = NetworkInfo(true, "Wi-Fi"))
        assertEquals("Network: Wi-Fi (online).", successMessage(GetNetworkTool(online).execute(buildJsonObject {})))
        val offline = FakePhoneDevice(networkInfo = NetworkInfo(false, "None"))
        assertEquals("No network connection (offline).", successMessage(GetNetworkTool(offline).execute(buildJsonObject {})))
    }

    @Test
    fun `get_contacts finds matches and formats them`() = runBlocking {
        val device = FakePhoneDevice()
        val result = GetContactsTool(device).execute(buildJsonObject { put("query", "John") })
        val message = successMessage(result)
        assertTrue(message.contains("John Doe — +15550100001"))
        assertTrue(message.contains("John Smith — +15550100002"))
        assertFalse(message.contains("Jane Doe"))
    }

    @Test
    fun `get_contacts reports no matches`() = runBlocking {
        val result = GetContactsTool(FakePhoneDevice()).execute(buildJsonObject { put("query", "Zzz") })
        assertEquals("No contacts matching “Zzz”.", successMessage(result))
    }

    @Test
    fun `get_contacts fails clearly without the permission`() = runBlocking {
        val device = FakePhoneDevice()
        device.grantedPermissions.remove("android.permission.READ_CONTACTS")
        val result = GetContactsTool(device).execute(buildJsonObject { put("query", "John") })
        assertTrue(result is JarvisResult.Failure)
        val message = (result as JarvisResult.Failure).message
        assertTrue(message.contains("contacts", ignoreCase = true))
        assertTrue(message.contains("Settings"))
    }

    @Test
    fun `list_installed_apps filters by query`() = runBlocking {
        val device = FakePhoneDevice()
        val all = ListAppsTool(device).execute(buildJsonObject {})
        assertTrue(successMessage(all).contains("Maps"))
        val filtered = ListAppsTool(device).execute(buildJsonObject { put("query", "clock") })
        val message = successMessage(filtered)
        assertTrue(message.contains("Clock"))
        assertFalse(message.contains("Maps"))
    }

    // ── Tier 1: flashlight ────────────────────────────────────────────

    @Test
    fun `flashlight dryRun shows the exact effect with current state`() = runBlocking {
        val device = FakePhoneDevice(flashlightOn = false)
        val preview = SetFlashlightTool(device).dryRun(buildJsonObject { put("enabled", true) })
        assertEquals("Turn flashlight ON (currently off).", preview)
    }

    @Test
    fun `flashlight on then undo restores off`() = runBlocking {
        val device = FakePhoneDevice(flashlightOn = false)
        val tool = SetFlashlightTool(device)
        val params = buildJsonObject { put("enabled", true) }
        val result = tool.execute(params)
        assertTrue(device.flashlightOn)
        val outcome = (result as JarvisResult.Success).value
        assertEquals("Flashlight turned on.", outcome.message)
        assertNotNull(outcome.undoData)

        val undo = tool.undo(params, outcome.undoData)
        assertFalse(device.flashlightOn)
        assertEquals("Flashlight turned off again.", (undo as JarvisResult.Success).value.message)
    }

    @Test
    fun `flashlight no-op records no undo data`() = runBlocking {
        val device = FakePhoneDevice(flashlightOn = true)
        val result = SetFlashlightTool(device).execute(buildJsonObject { put("enabled", true) })
        val outcome = (result as JarvisResult.Success).value
        assertEquals("Flashlight is already on.", outcome.message)
        assertNull(outcome.undoData)
    }

    @Test
    fun `flashlight fails without camera permission`() = runBlocking {
        val device = FakePhoneDevice()
        device.grantedPermissions.remove("android.permission.CAMERA")
        val result = SetFlashlightTool(device).execute(buildJsonObject { put("enabled", true) })
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("camera permission"))
    }

    @Test
    fun `flashlight fails on a device without a flash`() = runBlocking {
        val device = FakePhoneDevice(hasFlashlight = false)
        val result = SetFlashlightTool(device).execute(buildJsonObject { put("enabled", true) })
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("doesn't have a flashlight"))
    }

    // ── Tier 1: volume ────────────────────────────────────────────────

    @Test
    fun `volume dryRun shows new and previous level`() = runBlocking {
        val device = FakePhoneDevice()
        val preview = SetVolumeTool(device).dryRun(
            buildJsonObject { put("stream", "media"); put("level", 7) },
        )
        assertEquals("Set media volume to 7/15 (was 4/15).", preview)
    }

    @Test
    fun `volume set then undo restores the previous level`() = runBlocking {
        val device = FakePhoneDevice()
        val tool = SetVolumeTool(device)
        val params = buildJsonObject { put("stream", "media"); put("level", 7) }
        val result = tool.execute(params)
        assertEquals(7, device.volumes[VolumeStream.MUSIC])
        val outcome = (result as JarvisResult.Success).value
        assertTrue(outcome.message.contains("7/15 (was 4/15)"))

        val undo = tool.undo(params, outcome.undoData)
        assertEquals(4, device.volumes[VolumeStream.MUSIC])
        assertTrue((undo as JarvisResult.Success).value.message.contains("restored to 4"))
    }

    @Test
    fun `volume rejects an out-of-range level`() = runBlocking {
        val result = SetVolumeTool(FakePhoneDevice()).execute(
            buildJsonObject { put("stream", "media"); put("level", 99) },
        )
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("0 to 15"))
    }

    @Test
    fun `volume rejects an unknown stream`() = runBlocking {
        val result = SetVolumeTool(FakePhoneDevice()).execute(
            buildJsonObject { put("stream", "banana"); put("level", 3) },
        )
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("Unknown volume stream"))
    }

    @Test
    fun `volume accepts stream aliases`() = runBlocking {
        val device = FakePhoneDevice()
        val result = SetVolumeTool(device).execute(
            buildJsonObject { put("stream", "music"); put("level", 9) },
        )
        assertTrue(result is JarvisResult.Success)
        assertEquals(9, device.volumes[VolumeStream.MUSIC])
    }

    // ── Tier 1: brightness ────────────────────────────────────────────

    @Test
    fun `brightness set then undo restores the previous value`() = runBlocking {
        val device = FakePhoneDevice(brightness = 40)
        val tool = SetBrightnessTool(device)
        val params = buildJsonObject { put("percent", 60) }
        val result = tool.execute(params)
        assertEquals(60, device.brightness)
        val outcome = (result as JarvisResult.Success).value
        assertTrue(outcome.message.contains("60% (was 40%)"))

        tool.undo(params, outcome.undoData)
        assertEquals(40, device.brightness)
    }

    @Test
    fun `brightness rejects out-of-range percentages`() = runBlocking {
        val tool = SetBrightnessTool(FakePhoneDevice())
        assertTrue(tool.execute(buildJsonObject { put("percent", 101) }) is JarvisResult.Failure)
        assertTrue(tool.execute(buildJsonObject { put("percent", -1) }) is JarvisResult.Failure)
    }

    @Test
    fun `brightness notes auto-brightness when it is on`() = runBlocking {
        val device = FakePhoneDevice(autoBrightnessOn = true)
        val result = SetBrightnessTool(device).execute(buildJsonObject { put("percent", 80) })
        assertTrue(successMessage(result).contains("auto-brightness is on"))
    }

    @Test
    fun `brightness fails clearly without modify-settings access`() = runBlocking {
        val device = FakePhoneDevice(canWriteSettings = false)
        val result = SetBrightnessTool(device).execute(buildJsonObject { put("percent", 80) })
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("Modify system settings"))
    }

    // ── Tier 1: wifi / bluetooth ──────────────────────────────────────

    @Test
    fun `wifi toggle then undo restores the previous state`() = runBlocking {
        val device = FakePhoneDevice(wifiOn = true)
        val tool = SetWifiTool(device)
        val params = buildJsonObject { put("enabled", false) }
        val result = tool.execute(params)
        assertFalse(device.wifiOn)
        val outcome = (result as JarvisResult.Success).value
        tool.undo(params, outcome.undoData)
        assertTrue(device.wifiOn)
    }

    @Test
    fun `wifi panel fallback changes nothing and records no undo`() = runBlocking {
        val device = FakePhoneDevice(wifiDirectToggleUnavailable = true, wifiOn = false)
        val tool = SetWifiTool(device)
        val result = tool.execute(buildJsonObject { put("enabled", true) })
        val outcome = (result as JarvisResult.Success).value
        assertFalse(device.wifiOn) // Nothing changed on the device.
        assertNull(outcome.undoData)
        assertTrue(outcome.message.contains("settings panel"))
        assertEquals(listOf(SystemAction.OpenWifiPanel), device.launchedActions)
    }

    @Test
    fun `bluetooth toggle then undo restores the previous state`() = runBlocking {
        val device = FakePhoneDevice(bluetoothOn = false)
        val tool = SetBluetoothTool(device)
        val params = buildJsonObject { put("enabled", true) }
        val result = tool.execute(params)
        assertTrue(device.bluetoothOn)
        val outcome = (result as JarvisResult.Success).value
        tool.undo(params, outcome.undoData)
        assertFalse(device.bluetoothOn)
    }

    @Test
    fun `bluetooth enable on android 13 shows the system dialog`() = runBlocking {
        val device = FakePhoneDevice(bluetoothEnableNeedsDialog = true)
        val result = SetBluetoothTool(device).execute(buildJsonObject { put("enabled", true) })
        val outcome = (result as JarvisResult.Success).value
        assertFalse(device.bluetoothOn) // Not switched yet — the user confirms.
        assertNull(outcome.undoData)
        assertEquals(listOf(SystemAction.RequestBluetoothEnable), device.launchedActions)
    }

    @Test
    fun `bluetooth fails without the permission`() = runBlocking {
        val device = FakePhoneDevice()
        device.grantedPermissions.remove("android.permission.BLUETOOTH_CONNECT")
        val result = SetBluetoothTool(device).execute(buildJsonObject { put("enabled", true) })
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("Bluetooth permission"))
    }

    // ── Tier 1: alarm / timer / open app / DND ────────────────────────

    @Test
    fun `alarm builds the right system action`() = runBlocking {
        val device = FakePhoneDevice()
        val result = SetAlarmTool(device).execute(
            buildJsonObject { put("hour", 7); put("minute", 30); put("label", "Work") },
        )
        assertEquals("Alarm set for 07:30 (“Work”).", successMessage(result))
        assertEquals(listOf(SystemAction.SetAlarm(7, 30, "Work")), device.launchedActions)
    }

    @Test
    fun `alarm rejects invalid times`() = runBlocking {
        val tool = SetAlarmTool(FakePhoneDevice())
        assertTrue(tool.execute(buildJsonObject { put("hour", 24); put("minute", 0) }) is JarvisResult.Failure)
        assertTrue(tool.execute(buildJsonObject { put("hour", 7); put("minute", 60) }) is JarvisResult.Failure)
    }

    @Test
    fun `alarm undo opens the clock app and says so honestly`() = runBlocking {
        val device = FakePhoneDevice()
        val tool = SetAlarmTool(device)
        val params = buildJsonObject { put("hour", 7); put("minute", 30) }
        val result = tool.execute(params)
        val outcome = (result as JarvisResult.Success).value
        assertNotNull(outcome.undoData)

        val preview = tool.undoPreview(params, outcome.undoData)
        assertTrue(preview.contains("07:30"))
        assertTrue(preview.contains("can't cancel alarms directly"))

        val undo = tool.undo(params, outcome.undoData)
        assertTrue(device.launchedActions.contains(SystemAction.OpenClockApp))
        assertTrue((undo as JarvisResult.Success).value.message.contains("delete the alarm there"))
    }

    @Test
    fun `timer builds the right system action and formats durations`() = runBlocking {
        val device = FakePhoneDevice()
        val tool = SetTimerTool(device)
        val preview = tool.dryRun(buildJsonObject { put("seconds", 300) })
        assertEquals("Set a 5 minutes timer in the Clock app.", preview)
        val result = tool.execute(buildJsonObject { put("seconds", 300); put("label", "Tea") })
        assertEquals("Timer set for 5 minutes (“Tea”).", successMessage(result))
        assertEquals(listOf(SystemAction.SetTimer(300, "Tea")), device.launchedActions)
    }

    @Test
    fun `timer rejects invalid lengths`() = runBlocking {
        val tool = SetTimerTool(FakePhoneDevice())
        assertTrue(tool.execute(buildJsonObject { put("seconds", 0) }) is JarvisResult.Failure)
        assertTrue(tool.execute(buildJsonObject { put("seconds", 100000) }) is JarvisResult.Failure)
    }

    @Test
    fun `open_app launches an exact name match`() = runBlocking {
        val device = FakePhoneDevice()
        val result = OpenAppTool(device).execute(buildJsonObject { put("query", "Maps") })
        assertEquals("Opened Maps.", successMessage(result))
        assertEquals(
            listOf(SystemAction.OpenApp("com.google.android.apps.maps")),
            device.launchedActions,
        )
    }

    @Test
    fun `open_app launches an exact package match`() = runBlocking {
        val device = FakePhoneDevice()
        val result = OpenAppTool(device).execute(
            buildJsonObject { put("query", "com.google.android.deskclock") },
        )
        assertEquals("Opened Clock.", successMessage(result))
    }

    @Test
    fun `open_app returns candidates when ambiguous instead of guessing`() = runBlocking {
        val device = FakePhoneDevice()
        val result = OpenAppTool(device).execute(buildJsonObject { put("query", "m") })
        val message = successMessage(result)
        assertTrue(message.contains("Several apps match"))
        assertTrue(message.contains("Maps"))
        assertTrue(message.contains("Messages"))
        assertTrue(device.launchedActions.isEmpty()) // Nothing launched.
    }

    @Test
    fun `open_app fails when nothing matches`() = runBlocking {
        val result = OpenAppTool(FakePhoneDevice()).execute(buildJsonObject { put("query", "NoSuchApp") })
        assertTrue(result is JarvisResult.Failure)
    }

    @Test
    fun `open_app is not undoable`() {
        assertFalse(OpenAppTool(FakePhoneDevice()).supportsUndo)
    }

    @Test
    fun `dnd set then undo restores the previous mode`() = runBlocking {
        val device = FakePhoneDevice(dndModeValue = DndMode.OFF)
        val tool = SetDoNotDisturbTool(device)
        val params = buildJsonObject { put("mode", "alarms_only") }
        val result = tool.execute(params)
        assertEquals(DndMode.ALARMS_ONLY, device.dndModeValue)
        val outcome = (result as JarvisResult.Success).value
        assertTrue(outcome.message.contains("Alarms only (was Off)"))

        tool.undo(params, outcome.undoData)
        assertEquals(DndMode.OFF, device.dndModeValue)
    }

    @Test
    fun `dnd rejects unknown modes`() = runBlocking {
        val result = SetDoNotDisturbTool(FakePhoneDevice()).execute(
            buildJsonObject { put("mode", "silent-ish") },
        )
        assertTrue(result is JarvisResult.Failure)
    }

    @Test
    fun `dnd fails clearly without policy access`() = runBlocking {
        val device = FakePhoneDevice(hasDndAccess = false)
        val result = SetDoNotDisturbTool(device).execute(buildJsonObject { put("mode", "off") })
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("Do Not Disturb access"))
    }

    // ── Tier 2 ────────────────────────────────────────────────────────

    @Test
    fun `make_call by number produces a dial action, never a call`() = runBlocking {
        val device = FakePhoneDevice()
        val tool = MakeCallTool(device)
        val preview = tool.dryRun(buildJsonObject { put("number", "+15550100001") })
        assertTrue(preview.contains("Open the dialer for +15550100001"))
        assertTrue(preview.contains("never dials by itself"))

        val result = tool.execute(buildJsonObject { put("number", "+15550100001") })
        assertTrue(successMessage(result).contains("tap Call to place the call"))
        // The only thing the tool did was ask the system to open the dialer.
        assertEquals(listOf(SystemAction.Dial("+15550100001")), device.launchedActions)
    }

    @Test
    fun `make_call by contact name resolves the number`() = runBlocking {
        val device = FakePhoneDevice()
        val result = MakeCallTool(device).execute(buildJsonObject { put("contact", "Alice") })
        assertTrue(successMessage(result).contains("Alice (+15550100004)"))
        assertEquals(listOf(SystemAction.Dial("+15550100004")), device.launchedActions)
    }

    @Test
    fun `make_call asks when the contact is ambiguous`() = runBlocking {
        val device = FakePhoneDevice()
        val result = MakeCallTool(device).execute(buildJsonObject { put("contact", "John") })
        val message = successMessage(result)
        assertTrue(message.contains("Several contacts match"))
        assertTrue(message.contains("John Doe"))
        assertTrue(message.contains("John Smith"))
        assertTrue(device.launchedActions.isEmpty()) // Nothing dialled.
    }

    @Test
    fun `make_call fails when the contact does not exist`() = runBlocking {
        val result = MakeCallTool(FakePhoneDevice()).execute(buildJsonObject { put("contact", "Nobody") })
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("No contact"))
    }

    @Test
    fun `send_sms shows the full body in the preview and launches the messaging app`() = runBlocking {
        val device = FakePhoneDevice()
        val tool = SendSmsTool(device)
        val params = buildJsonObject { put("contact", "Alice"); put("body", "Meet at 5?") }
        val preview = tool.dryRun(params)
        assertEquals("Send SMS to +15550100004 (Alice):\nMeet at 5?", preview)

        val result = tool.execute(params)
        assertTrue(successMessage(result).contains("tap Send to send it"))
        assertEquals(
            listOf(SystemAction.SendSms("+15550100004", "Meet at 5?")),
            device.launchedActions,
        )
    }

    @Test
    fun `send_sms re-derives parameters from edited preview content`() {
        val tool = SendSmsTool(FakePhoneDevice())
        val edited = "Send SMS to +15550100004 (Alice):\nMeet at 6 instead?"
        val params = tool.paramsFromEditedContent(edited, buildJsonObject {})
        assertNotNull(params)
        assertEquals("+15550100004", params!!["number"]?.jsonPrimitive?.content)
        assertEquals("Meet at 6 instead?", params["body"]?.jsonPrimitive?.content)
    }

    @Test
    fun `send_sms refuses mangled edited content`() {
        val tool = SendSmsTool(FakePhoneDevice())
        assertNull(tool.paramsFromEditedContent("just some text", buildJsonObject {}))
        assertNull(tool.paramsFromEditedContent("Send SMS to :\nhello", buildJsonObject {}))
    }

    @Test
    fun `send_email launches the email app with everything pre-filled`() = runBlocking {
        val device = FakePhoneDevice()
        val tool = SendEmailTool(device)
        val params = buildJsonObject {
            put("to", "a@example.com, b@example.com")
            put("subject", "Hello")
            put("body", "See you soon.")
        }
        val preview = tool.dryRun(params)
        assertEquals("Send email to a@example.com, b@example.com:\nSubject: Hello\nSee you soon.", preview)

        val result = tool.execute(params)
        assertTrue(successMessage(result).contains("tap Send to send it"))
        assertEquals(
            listOf(SystemAction.SendEmail(listOf("a@example.com", "b@example.com"), "Hello", "See you soon.")),
            device.launchedActions,
        )
    }

    @Test
    fun `send_email rejects an invalid address`() = runBlocking {
        val result = SendEmailTool(FakePhoneDevice()).execute(
            buildJsonObject { put("to", "not-an-email"); put("body", "hi") },
        )
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("doesn't look like an email address"))
    }

    @Test
    fun `share_text launches the share sheet`() = runBlocking {
        val device = FakePhoneDevice()
        val result = ShareTextTool(device).execute(buildJsonObject { put("text", "Look at this!") })
        assertTrue(successMessage(result).contains("share sheet"))
        assertEquals(
            listOf(SystemAction.ShareText("Look at this!", "Share via Jarvis")),
            device.launchedActions,
        )
    }

    @Test
    fun `tier 2 tools are never undoable`() {
        val device = FakePhoneDevice()
        val tools = listOf(
            MakeCallTool(device), SendSmsTool(device), SendEmailTool(device), ShareTextTool(device),
        )
        assertTrue(tools.all { it.riskTier.level == 2 })
        assertTrue(tools.none { it.supportsUndo })
    }

    // ── Schemas & tiers ───────────────────────────────────────────────

    @Test
    fun `every phone tool schema accepts valid params and rejects missing required ones`() {
        val device = FakePhoneDevice()
        val cases = listOf(
            GetBatteryTool(device) to buildJsonObject {},
            GetNetworkTool(device) to buildJsonObject {},
            GetContactsTool(device) to buildJsonObject { put("query", "John") },
            ListAppsTool(device) to buildJsonObject {},
            SetFlashlightTool(device) to buildJsonObject { put("enabled", true) },
            SetVolumeTool(device) to buildJsonObject { put("stream", "media"); put("level", 5) },
            SetBrightnessTool(device) to buildJsonObject { put("percent", 50) },
            SetWifiTool(device) to buildJsonObject { put("enabled", true) },
            SetBluetoothTool(device) to buildJsonObject { put("enabled", true) },
            SetAlarmTool(device) to buildJsonObject { put("hour", 7); put("minute", 30) },
            SetTimerTool(device) to buildJsonObject { put("seconds", 60) },
            OpenAppTool(device) to buildJsonObject { put("query", "Maps") },
            SetDoNotDisturbTool(device) to buildJsonObject { put("mode", "off") },
            MakeCallTool(device) to buildJsonObject { put("number", "+15550100001") },
            SendSmsTool(device) to buildJsonObject { put("number", "+15550100001"); put("body", "hi") },
            SendEmailTool(device) to buildJsonObject { put("to", "a@b.com") },
            ShareTextTool(device) to buildJsonObject { put("text", "hi") },
        )
        for ((tool, validParams) in cases) {
            assertTrue(
                "${tool.name}: valid params should pass",
                ToolSchema.validateParams(validParams, tool.inputSchema).isEmpty(),
            )
        }
        // Wrong-typed parameters are caught.
        assertTrue(
            ToolSchema.validateParams(
                buildJsonObject { put("enabled", "yes please") },
                SetFlashlightTool(device).inputSchema,
            ).isNotEmpty(),
        )
        assertTrue(
            ToolSchema.validateParams(
                buildJsonObject { put("stream", "media"); put("level", "loud") },
                SetVolumeTool(device).inputSchema,
            ).isNotEmpty(),
        )
        // Missing required parameters are caught.
        assertTrue(
            ToolSchema.validateParams(buildJsonObject {}, SetVolumeTool(device).inputSchema).isNotEmpty(),
        )
        assertTrue(
            ToolSchema.validateParams(buildJsonObject {}, SetAlarmTool(device).inputSchema).isNotEmpty(),
        )
        assertTrue(
            ToolSchema.validateParams(buildJsonObject {}, SendSmsTool(device).inputSchema).isNotEmpty(),
        )
    }

    @Test
    fun `phone tools declare the right tiers`() {
        val device = FakePhoneDevice()
        val tier0 = listOf(GetBatteryTool(device), GetNetworkTool(device), GetContactsTool(device), ListAppsTool(device))
        assertTrue(tier0.all { it.riskTier.level == 0 })
        val tier1 = listOf(
            SetFlashlightTool(device), SetVolumeTool(device), SetBrightnessTool(device),
            SetWifiTool(device), SetBluetoothTool(device), SetAlarmTool(device),
            SetTimerTool(device), OpenAppTool(device), SetDoNotDisturbTool(device),
        )
        assertTrue(tier1.all { it.riskTier.level == 1 })
    }

    private fun successMessage(result: JarvisResult<ToolOutcome>): String {
        assertTrue("Expected success, got $result", result is JarvisResult.Success)
        return (result as JarvisResult.Success).value.message
    }
}
