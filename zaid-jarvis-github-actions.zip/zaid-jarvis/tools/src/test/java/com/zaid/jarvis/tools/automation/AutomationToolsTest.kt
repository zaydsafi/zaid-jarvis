package com.zaid.jarvis.tools.automation

import com.zaid.jarvis.core.automation.Macro
import com.zaid.jarvis.core.automation.MacroAction
import com.zaid.jarvis.core.automation.MacroStep
import com.zaid.jarvis.core.automation.NodeSelector
import com.zaid.jarvis.core.automation.ScreenNode
import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.ToolSchema
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AutomationToolsTest {

    private class FakeMacroStore(
        var macros: MutableMap<String, Macro> = mutableMapOf(),
    ) : MacroStore {
        val markedRunIds: MutableList<Long> = mutableListOf()
        override suspend fun getByName(name: String): Macro? =
            macros.entries.firstOrNull { it.key.equals(name, ignoreCase = true) }?.value

        override suspend fun markRun(id: Long) {
            markedRunIds += id
        }
    }

    private val tapMacro = Macro(
        id = 1,
        name = "Morning news",
        steps = listOf(
            MacroStep(MacroAction.TAP, NodeSelector(text = "Search")),
            MacroStep(MacroAction.SCROLL_FORWARD),
        ),
    )
    private val navOnlyMacro = Macro(
        id = 2,
        name = "Scroll down",
        steps = listOf(
            MacroStep(MacroAction.SCROLL_FORWARD),
            MacroStep(MacroAction.BACK),
        ),
    )

    private fun params(vararg pairs: Pair<String, Any>): JsonObject = buildJsonObject {
        for ((key, value) in pairs) {
            when (value) {
                is String -> put(key, value)
                is Int -> put(key, value)
                else -> error("unsupported param type in test")
            }
        }
    }

    // ── find_on_screen ────────────────────────────────────────────────

    @Test
    fun `find_on_screen lists the interactive elements`() = runBlocking {
        val device = FakeAutomationDevice()
        val result = FindOnScreenTool(device).execute(JsonObject(emptyMap()))
        assertTrue(result is JarvisResult.Success)
        val text = (result as JarvisResult.Success).value.message
        assertTrue(text.contains("[Button] “Search” (tappable)"))
        assertTrue(text.contains("[EditText] “Search box” (tappable, editable)"))
    }

    @Test
    fun `find_on_screen filters by query and reports no match`() = runBlocking {
        val device = FakeAutomationDevice()
        val found = FindOnScreenTool(device).execute(params("query" to "search box"))
        assertTrue((found as JarvisResult.Success).value.message.contains("Search box"))
        assertFalse(found.value.message.contains("[Button]"))
        val missing = FindOnScreenTool(device).execute(params("query" to "zzz"))
        assertTrue(
            (missing as JarvisResult.Success).value.message.contains("No element"),
        )
    }

    @Test
    fun `find_on_screen fails clearly when automation is off`() = runBlocking {
        val device = FakeAutomationDevice(automationEnabled = false)
        val result = FindOnScreenTool(device).execute(JsonObject(emptyMap()))
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("turned off"))
    }

    @Test
    fun `find_on_screen never shows password nodes`() = runBlocking {
        val device = FakeAutomationDevice(
            nodes = mutableListOf(
                ScreenNode(
                    text = "secret-password-text",
                    className = "EditText",
                    clickable = true,
                    editable = true,
                    isPassword = true,
                ),
            ),
            hasPasswordField = true,
        )
        val result = FindOnScreenTool(device).execute(JsonObject(emptyMap()))
        val text = (result as JarvisResult.Success).value.message
        assertFalse(text.contains("secret-password-text"))
        assertTrue(text.contains("password field"))
    }

    // ── tap_on_screen ─────────────────────────────────────────────────

    @Test
    fun `tap_on_screen taps by text and dryRun names the target`() = runBlocking {
        val device = FakeAutomationDevice()
        val tool = TapOnScreenTool(device)
        val p = params("text" to "Search")
        assertEquals("Tap text “Search” on the current screen.", tool.dryRun(p))
        val result = tool.execute(p)
        assertTrue(result is JarvisResult.Success)
        assertEquals(listOf("tap:Search"), device.actions)
    }

    @Test
    fun `tap_on_screen taps at coordinates`() = runBlocking {
        val device = FakeAutomationDevice()
        val result = TapOnScreenTool(device).execute(params("x" to 100, "y" to 200))
        assertTrue(result is JarvisResult.Success)
        assertEquals(listOf("tapAt:100,200"), device.actions)
    }

    @Test
    fun `tap_on_screen fails when the target is missing`() = runBlocking {
        val device = FakeAutomationDevice()
        val result = TapOnScreenTool(device).execute(params("text" to "Nope"))
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("couldn't find"))
        assertTrue(device.actions.isEmpty())
    }

    @Test
    fun `tap_on_screen fails without any target`() = runBlocking {
        val result = TapOnScreenTool(FakeAutomationDevice()).execute(JsonObject(emptyMap()))
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("needs a target"))
    }

    @Test
    fun `tap_on_screen refuses password screens and blocked apps`() = runBlocking {
        val passwordDevice = FakeAutomationDevice(hasPasswordField = true)
        val passwordResult = TapOnScreenTool(passwordDevice).execute(params("text" to "Search"))
        assertTrue((passwordResult as JarvisResult.Failure).message.contains("password field"))

        val blockedDevice = FakeAutomationDevice(packageName = "com.paypal.android.p2pmobile")
        val blockedResult = TapOnScreenTool(blockedDevice).execute(params("text" to "Search"))
        assertTrue((blockedResult as JarvisResult.Failure).message.contains("banking or payment app"))
    }

    // ── type_text ─────────────────────────────────────────────────────

    @Test
    fun `type_text types into the matched field`() = runBlocking {
        val device = FakeAutomationDevice()
        val tool = TypeTextTool(device)
        val p = params("text" to "hello", "viewId" to "com.example:id/box")
        assertTrue(tool.dryRun(p).contains("Type “hello”"))
        val result = tool.execute(p)
        assertTrue(result is JarvisResult.Success)
        assertEquals(listOf("type:hello"), device.actions)
    }

    @Test
    fun `type_text without a target uses the focused field`() = runBlocking {
        val device = FakeAutomationDevice()
        val result = TypeTextTool(device).execute(params("text" to "hi"))
        assertTrue(result is JarvisResult.Success)
    }

    @Test
    fun `type_text refuses a non-editable target`() = runBlocking {
        val device = FakeAutomationDevice()
        val result = TypeTextTool(device).execute(
            params("text" to "hi", "targetText" to "Search"),
        )
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("isn't an editable text field"))
    }

    @Test
    fun `type_text refuses over-long text`() = runBlocking {
        val result = TypeTextTool(FakeAutomationDevice()).execute(params("text" to "x".repeat(501)))
        assertTrue((result as JarvisResult.Failure).message.contains("too long"))
    }

    // ── scroll / back / home ──────────────────────────────────────────

    @Test
    fun `scroll_screen scrolls down by default and up on request`() = runBlocking {
        val device = FakeAutomationDevice()
        val tool = ScrollScreenTool(device)
        assertTrue(tool.execute(JsonObject(emptyMap())) is JarvisResult.Success)
        assertTrue(tool.execute(params("direction" to "up")) is JarvisResult.Success)
        assertEquals(listOf("scroll:down", "scroll:up"), device.actions)
        val bad = tool.execute(params("direction" to "sideways"))
        assertTrue((bad as JarvisResult.Failure).message.contains("must be"))
    }

    @Test
    fun `scroll_screen fails when the screen cannot scroll`() = runBlocking {
        val device = FakeAutomationDevice(canScroll = false)
        val result = ScrollScreenTool(device).execute(JsonObject(emptyMap()))
        assertTrue((result as JarvisResult.Failure).message.contains("can't scroll"))
    }

    @Test
    fun `press_back and press_home perform the global actions`() = runBlocking {
        val device = FakeAutomationDevice()
        assertTrue(PressBackTool(device).execute(JsonObject(emptyMap())) is JarvisResult.Success)
        assertTrue(PressHomeTool(device).execute(JsonObject(emptyMap())) is JarvisResult.Success)
        assertEquals(listOf("back", "home"), device.actions)
    }

    @Test
    fun `press_back still works on a password screen`() = runBlocking {
        val device = FakeAutomationDevice(hasPasswordField = true)
        // Back only navigates away — the guard does not apply to it.
        assertTrue(PressBackTool(device).execute(JsonObject(emptyMap())) is JarvisResult.Success)
    }

    // ── schemas ───────────────────────────────────────────────────────

    @Test
    fun `tool schemas validate their parameters`() {
        assertTrue(
            ToolSchema.validateParams(
                params("text" to "x"),
                TapOnScreenTool(FakeAutomationDevice()).inputSchema,
            ).isEmpty(),
        )
        assertTrue(
            ToolSchema.validateParams(
                JsonObject(emptyMap()),
                TypeTextTool(FakeAutomationDevice()).inputSchema,
            ).any { it.contains("text") },
        )
        assertTrue(
            ToolSchema.validateParams(
                JsonObject(emptyMap()),
                RunMacroTool(FakeMacroStore(), MacroPlayer(FakeAutomationDevice(), KillSwitch()))
                    .inputSchema,
            ).any { it.contains("name") },
        )
    }

    // ── run_macro ─────────────────────────────────────────────────────

    @Test
    fun `run_macro tier is 2 for tap macros and 1 for navigation-only macros`() = runBlocking {
        val store = FakeMacroStore(mutableMapOf("Morning news" to tapMacro, "Scroll down" to navOnlyMacro))
        val tool = RunMacroTool(store, MacroPlayer(FakeAutomationDevice(), KillSwitch()))
        assertEquals(RiskTier.EXTERNAL, tool.tierFor(params("name" to "Morning news")))
        assertEquals(RiskTier.REVERSIBLE, tool.tierFor(params("name" to "Scroll down")))
        assertEquals(RiskTier.EXTERNAL, tool.tierFor(params("name" to "Does not exist")))
    }

    @Test
    fun `run_macro dryRun lists every step`() = runBlocking {
        val store = FakeMacroStore(mutableMapOf("Morning news" to tapMacro))
        val tool = RunMacroTool(store, MacroPlayer(FakeAutomationDevice(), KillSwitch()))
        val preview = tool.dryRun(params("name" to "Morning news"))
        assertTrue(preview.contains("Run macro “Morning news” (2 step(s))"))
        assertTrue(preview.contains("1. Tap text “Search”"))
        assertTrue(preview.contains("2. Scroll down"))
    }

    @Test
    fun `run_macro dryRun reports a missing macro`() = runBlocking {
        val tool = RunMacroTool(FakeMacroStore(), MacroPlayer(FakeAutomationDevice(), KillSwitch()))
        assertTrue(tool.dryRun(params("name" to "Nope")).contains("no macro with that name"))
    }

    @Test
    fun `run_macro executes the macro and marks it run`() = runBlocking {
        val device = FakeAutomationDevice()
        val store = FakeMacroStore(mutableMapOf("Morning news" to tapMacro))
        val tool = RunMacroTool(store, MacroPlayer(device, KillSwitch()))
        val result = tool.execute(params("name" to "Morning news"))
        assertTrue(result is JarvisResult.Success)
        assertEquals(listOf("tap:Search", "scroll:down"), device.actions)
        assertEquals(listOf(1L), store.markedRunIds)
    }

    @Test
    fun `run_macro fails clearly for a missing macro and marks nothing`() = runBlocking {
        val device = FakeAutomationDevice()
        val store = FakeMacroStore()
        val tool = RunMacroTool(store, MacroPlayer(device, KillSwitch()))
        val result = tool.execute(params("name" to "Nope"))
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("No macro named"))
        assertTrue(store.markedRunIds.isEmpty())
        assertTrue(device.actions.isEmpty())
    }

    @Test
    fun `run_macro does not mark a failed run`() = runBlocking {
        val device = FakeAutomationDevice(nodes = mutableListOf())
        val store = FakeMacroStore(mutableMapOf("Morning news" to tapMacro))
        val tool = RunMacroTool(store, MacroPlayer(device, KillSwitch()))
        val result = tool.execute(params("name" to "Morning news"))
        assertTrue(result is JarvisResult.Failure)
        assertTrue(store.markedRunIds.isEmpty())
    }
}
