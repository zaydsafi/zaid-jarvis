package com.zaid.jarvis.tools

import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.builtin.CalculatorTool
import com.zaid.jarvis.tools.builtin.EchoTool
import com.zaid.jarvis.tools.builtin.GetTimeTool
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneId

class BuiltInToolsTest {

    @Test
    fun `calculator respects precedence and parentheses`() = runBlocking {
        val tool = CalculatorTool()
        assertSuccess(tool, "2 + 3 * 4", "2 + 3 * 4 = 14")
        assertSuccess(tool, "(2 + 3) * 4", "(2 + 3) * 4 = 20")
        assertSuccess(tool, "10 % 3", "10 % 3 = 1")
        assertSuccess(tool, "7 / 2", "7 / 2 = 3.5")
    }

    @Test
    fun `calculator rejects division by zero`() = runBlocking {
        val result = CalculatorTool().execute(
            buildJsonObject { put("expression", "1 / 0") },
        )
        assertTrue(result is JarvisResult.Failure)
    }

    @Test
    fun `calculator rejects non-arithmetic input`() = runBlocking {
        val result = CalculatorTool().execute(
            buildJsonObject { put("expression", "delete everything") },
        )
        assertTrue(result is JarvisResult.Failure)
    }

    @Test
    fun `calculator rejects missing expression`() = runBlocking {
        val result = CalculatorTool().execute(buildJsonObject {})
        assertTrue(result is JarvisResult.Failure)
    }

    @Test
    fun `get_time formats the injected clock`() = runBlocking {
        // 2026-11-15 19:47:00 UTC.
        val fixedMillis = 1794772020000L
        val tool = GetTimeTool(
            clock = { fixedMillis },
            zoneId = ZoneId.of("UTC"),
        )
        val result = tool.execute(buildJsonObject {})
        assertTrue(result is JarvisResult.Success)
        val text = (result as JarvisResult.Success).value.message
        assertTrue(text.contains("2026"))
        assertTrue(text.contains("19:47:00"))
    }

    @Test
    fun `echo repeats its message`() = runBlocking {
        val result = EchoTool().execute(
            buildJsonObject { put("message", "hello jarvis") },
        )
        assertEquals(JarvisResult.Success(ToolOutcome("hello jarvis")), result)
    }

    @Test
    fun `echo rejects missing message`() = runBlocking {
        val result = EchoTool().execute(buildJsonObject {})
        assertTrue(result is JarvisResult.Failure)
    }

    @Test
    fun `built-in tools are all tier 0 with no permissions`() {
        val tools = listOf(GetTimeTool(), CalculatorTool(), EchoTool())
        assertTrue(tools.all { it.riskTier.level == 0 })
        assertTrue(tools.all { it.requiredPermissions.isEmpty() })
    }

    private suspend fun assertSuccess(tool: CalculatorTool, expression: String, expected: String) {
        val result = tool.execute(buildJsonObject { put("expression", expression) })
        assertEquals(JarvisResult.Success(ToolOutcome(expected)), result)
    }
}
