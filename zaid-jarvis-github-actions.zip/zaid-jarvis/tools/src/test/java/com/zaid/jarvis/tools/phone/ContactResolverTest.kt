package com.zaid.jarvis.tools.phone

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Contact resolution tests (Phase 5): exact, fuzzy, ambiguous, no match. */
class ContactResolverTest {

    private val contacts = listOf(
        Contact(1, "John Doe", "+15550100001"),
        Contact(2, "John Smith", "+15550100002"),
        Contact(3, "Jane Doe", "+15550100003"),
        Contact(4, "Alice", "+15550100004"),
        Contact(5, "Bob Johnson", "+15550100005"),
    )

    @Test
    fun `exact name match wins`() {
        val result = ContactResolver.resolve("Alice", contacts)
        assertEquals(ContactResolver.Resolution.Single(contacts[3]), result)
    }

    @Test
    fun `matching is case-insensitive`() {
        val result = ContactResolver.resolve("aLiCe", contacts)
        assertEquals(ContactResolver.Resolution.Single(contacts[3]), result)
    }

    @Test
    fun `a unique prefix match resolves`() {
        val result = ContactResolver.resolve("Jane", contacts)
        assertEquals(ContactResolver.Resolution.Single(contacts[2]), result)
    }

    @Test
    fun `a matching surname word resolves`() {
        // "Doe" matches John Doe and Jane Doe equally — ambiguous.
        val result = ContactResolver.resolve("Doe", contacts)
        assertTrue(result is ContactResolver.Resolution.Ambiguous)
        val candidates = (result as ContactResolver.Resolution.Ambiguous).candidates
        assertEquals(2, candidates.size)
    }

    @Test
    fun `a shared first name is ambiguous, never a guess`() {
        val result = ContactResolver.resolve("John", contacts)
        assertTrue(result is ContactResolver.Resolution.Ambiguous)
        val candidates = (result as ContactResolver.Resolution.Ambiguous).candidates
        assertTrue(candidates.contains(contacts[0]))
        assertTrue(candidates.contains(contacts[1]))
        // "Bob Johnson" contains "john" but only as a substring — worse rank.
        assertFalse(candidates.contains(contacts[4]))
    }

    @Test
    fun `no match returns none`() {
        assertEquals(ContactResolver.Resolution.None, ContactResolver.resolve("Nobody", contacts))
        assertEquals(ContactResolver.Resolution.None, ContactResolver.resolve("", contacts))
        assertEquals(ContactResolver.Resolution.None, ContactResolver.resolve("Alice", emptyList()))
    }

    @Test
    fun `a closer match beats a substring match`() {
        // "Joh" is a prefix of both Johns (ambiguous between them) but
        // beats "Bob Johnson", where it is only a substring.
        val result = ContactResolver.resolve("Joh", contacts)
        assertTrue(result is ContactResolver.Resolution.Ambiguous)
        val candidates = (result as ContactResolver.Resolution.Ambiguous).candidates
        assertEquals(2, candidates.size)
        assertFalse(candidates.contains(contacts[4]))
    }

    @Test
    fun `phone numbers are recognized as numbers, not names`() {
        assertTrue(ContactResolver.isPhoneNumber("+1 555 010 0001"))
        assertTrue(ContactResolver.isPhoneNumber("5550100001"))
        assertFalse(ContactResolver.isPhoneNumber("Alice"))
        assertFalse(ContactResolver.isPhoneNumber("123")) // Too short.
        assertFalse(ContactResolver.isPhoneNumber("John 123"))
    }

    @Test
    fun `candidate formatting lists name and number`() {
        val formatted = ContactResolver.formatCandidates(listOf(contacts[0], contacts[1]))
        assertEquals(
            "• John Doe — +15550100001\n• John Smith — +15550100002",
            formatted,
        )
    }
}
