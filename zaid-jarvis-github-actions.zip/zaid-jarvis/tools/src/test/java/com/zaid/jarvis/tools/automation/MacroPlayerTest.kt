package com.zaid.jarvis.tools.automation

import com.zaid.jarvis.core.automation.Macro
import com.zaid.jarvis.core.automation.MacroAction
import com.zaid.jarvis.core.automation.MacroStep
import com.zaid.jarvis.core.automation.NodeSelector
import com.zaid.jarvis.core.confirmation.KillSwitch
import com.zaid.jarvis.core.util.JarvisResult
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MacroPlayerTest {

    private val searchTap = MacroStep(MacroAction.TAP, NodeSelector(text = "Search"))
    private val scrollDown = MacroStep(MacroAction.SCROLL_FORWARD)
    private val back = MacroStep(MacroAction.BACK)
    private val wait = MacroStep(MacroAction.WAIT, waitMillis = 2_000)

    private fun player(
        device: FakeAutomationDevice,
        killSwitch: KillSwitch = KillSwitch(),
        stepTimeoutMillis: Long = 10_000,
        sleeps: MutableList<Long>? = null,
    ): MacroPlayer = MacroPlayer(
        device = device,
        killSwitch = killSwitch,
        stepTimeoutMillis = stepTimeoutMillis,
        sleeper = { millis -> sleeps?.add(millis) },
    )

    @Test
    fun `a macro plays all steps in order and reports progress`() = runBlocking {
        val device = FakeAutomationDevice()
        val events = mutableListOf<MacroPlayer.PlaybackEvent>()
        val result = player(device).play(
            Macro(name = "M", steps = listOf(searchTap, scrollDown, back)),
            onEvent = { events += it },
        )
        assertTrue(result is JarvisResult.Success)
        assertTrue((result as JarvisResult.Success).value.contains("3 step(s) completed"))
        assertEquals(listOf("tap:Search", "scroll:down", "back"), device.actions)
        assertEquals(6, events.size) // Started + Finished per step.
        assertTrue(events.first() is MacroPlayer.PlaybackEvent.StepStarted)
    }

    @Test
    fun `playback stops at the first failing step and names it`() = runBlocking {
        val device = FakeAutomationDevice()
        val missingTap = MacroStep(MacroAction.TAP, NodeSelector(text = "No such button"))
        val result = player(device).play(
            Macro(name = "M", steps = listOf(searchTap, missingTap, scrollDown)),
        )
        assertTrue(result is JarvisResult.Failure)
        val message = (result as JarvisResult.Failure).message
        assertTrue(message.contains("stopped at step 2 of 3"))
        assertTrue(message.contains("No such button"))
        assertTrue(message.contains("What I see now"))
        // Step 1 ran; step 3 never did.
        assertEquals(listOf("tap:Search"), device.actions)
    }

    @Test
    fun `a missing target on a password screen gets the password hint`() = runBlocking {
        val device = FakeAutomationDevice(hasPasswordField = true)
        val result = player(device).play(
            Macro(
                name = "M",
                steps = listOf(MacroStep(MacroAction.TAP, NodeSelector(text = "Log in"))),
            ),
        )
        assertTrue(result is JarvisResult.Failure)
        assertTrue(
            (result as JarvisResult.Failure).message.contains("password field"),
        )
    }

    @Test
    fun `the kill switch stops playback between steps`() = runBlocking {
        val killSwitch = KillSwitch()
        val device = FakeAutomationDevice(
            onTap = { killSwitch.cancelAll() }, // Stopped during step 1.
        )
        val result = player(device, killSwitch).play(
            Macro(name = "M", steps = listOf(searchTap, scrollDown, back)),
        )
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("kill switch"))
        assertTrue(result.message.contains("after 1 of 3 steps"))
        assertEquals(listOf("tap:Search"), device.actions)
    }

    @Test
    fun `a step that hangs fails the run on timeout`() = runBlocking {
        val device = FakeAutomationDevice(hangOnTap = true)
        val result = player(device, stepTimeoutMillis = 100).play(
            Macro(name = "M", steps = listOf(searchTap, scrollDown)),
        )
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("timed out"))
        // The scroll never ran.
        assertEquals(emptyList<String>(), device.actions)
    }

    @Test
    fun `an invalid macro fails before anything runs`() = runBlocking {
        val device = FakeAutomationDevice()
        val result = player(device).play(Macro(name = "Empty", steps = emptyList()))
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("not valid"))
        assertTrue(device.actions.isEmpty())
    }

    @Test
    fun `a macro that is too long fails before anything runs`() = runBlocking {
        val device = FakeAutomationDevice()
        val result = player(device).play(
            Macro(name = "Too long", steps = List(51) { back }),
        )
        assertTrue(result is JarvisResult.Failure)
        assertTrue(device.actions.isEmpty())
    }

    @Test
    fun `wait steps use the injected sleeper and do not really wait`() = runBlocking {
        val device = FakeAutomationDevice()
        val sleeps = mutableListOf<Long>()
        val result = player(device, sleeps = sleeps).play(
            Macro(name = "M", steps = listOf(searchTap, wait, back)),
        )
        assertTrue(result is JarvisResult.Success)
        assertEquals(listOf(2_000L), sleeps)
        assertEquals(listOf("tap:Search", "back"), device.actions)
    }

    @Test
    fun `playback fails clearly when automation is unavailable`() = runBlocking {
        val device = FakeAutomationDevice(automationEnabled = false)
        val result = player(device).play(Macro(name = "M", steps = listOf(searchTap)))
        assertTrue(result is JarvisResult.Failure)
        assertTrue((result as JarvisResult.Failure).message.contains("turned off"))
        assertTrue(device.actions.isEmpty())
    }

    @Test
    fun `type steps verify the target field exists first`() = runBlocking {
        val device = FakeAutomationDevice()
        val type = MacroStep(
            MacroAction.TYPE_TEXT,
            NodeSelector(viewId = "com.example:id/box"),
            text = "hello",
        )
        val result = player(device).play(Macro(name = "M", steps = listOf(type)))
        assertTrue(result is JarvisResult.Success)
        assertEquals(listOf("type:hello"), device.actions)

        val missing = MacroStep(
            MacroAction.TYPE_TEXT,
            NodeSelector(viewId = "com.example:id/nope"),
            text = "hello",
        )
        val failed = player(device).play(Macro(name = "M", steps = listOf(missing)))
        assertTrue(failed is JarvisResult.Failure)
        assertTrue((failed as JarvisResult.Failure).message.contains("couldn't find"))
    }
}
