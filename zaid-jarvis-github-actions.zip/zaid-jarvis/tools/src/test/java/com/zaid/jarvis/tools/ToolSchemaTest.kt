package com.zaid.jarvis.tools

import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ToolSchemaTest {

    @Test
    fun `no-params schema accepts empty params`() {
        assertTrue(ToolSchema.validateParams(buildJsonObject {}, ToolSchema.noParams()).isEmpty())
    }

    @Test
    fun `missing required parameter is reported`() {
        val schema = ToolSchema.singleStringParam("message", "The message.")
        val errors = ToolSchema.validateParams(buildJsonObject {}, schema)
        assertEquals(1, errors.size)
        assertTrue(errors[0].contains("message"))
    }

    @Test
    fun `correct string parameter passes`() {
        val schema = ToolSchema.singleStringParam("message", "The message.")
        val params = buildJsonObject { put("message", "hello") }
        assertTrue(ToolSchema.validateParams(params, schema).isEmpty())
    }

    @Test
    fun `wrong type is reported`() {
        val schema = ToolSchema.singleStringParam("message", "The message.")
        val params = buildJsonObject { put("message", JsonPrimitive(42)) }
        val errors = ToolSchema.validateParams(params, schema)
        assertEquals(1, errors.size)
        assertTrue(errors[0].contains("string"))
    }

    @Test
    fun `unknown extra parameters are tolerated`() {
        val schema = ToolSchema.singleStringParam("message", "The message.")
        val params = buildJsonObject {
            put("message", "hello")
            put("surprise", "ignored")
        }
        assertTrue(ToolSchema.validateParams(params, schema).isEmpty())
    }
}
