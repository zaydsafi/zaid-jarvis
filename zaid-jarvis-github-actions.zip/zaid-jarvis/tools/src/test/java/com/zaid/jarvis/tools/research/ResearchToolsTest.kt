package com.zaid.jarvis.tools.research

import com.zaid.jarvis.core.confirmation.RiskTier
import com.zaid.jarvis.core.research.ContentDraft
import com.zaid.jarvis.core.research.DraftLimits
import com.zaid.jarvis.core.research.DraftStatus
import com.zaid.jarvis.core.research.PageContent
import com.zaid.jarvis.core.research.ResearchBrief
import com.zaid.jarvis.core.research.ResearchEvent
import com.zaid.jarvis.core.research.SearchResult
import com.zaid.jarvis.core.util.JarvisResult
import com.zaid.jarvis.tools.BuiltInTools
import com.zaid.jarvis.tools.ToolOutcome
import com.zaid.jarvis.tools.ToolRegistry
import com.zaid.jarvis.tools.phone.FakePhoneDevice
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Research tools (Phase 7) with fake network/LLM — no real HTTP.
 */
class ResearchToolsTest {

    private val fixedResults = listOf(
        SearchResult(
            title = "Kotlin 2.0 released",
            url = "https://kotlinlang.org/docs/whatsnew20.html",
            snippet = "Kotlin 2.0 brings the K2 compiler.",
            domain = "kotlinlang.org",
            fetchedAtMillis = 0L,
        ),
        SearchResult(
            title = "K2 compiler deep dive",
            url = "https://blog.jetbrains.com/kotlin/k2",
            snippet = "A closer look at K2.",
            domain = "blog.jetbrains.com",
            fetchedAtMillis = 0L,
        ),
    )

    private class FakeSearch(private val results: List<SearchResult>) : WebSearch {
        var lastQuery: String? = null
        var lastMax: Int? = null
        override suspend fun search(query: String, maxResults: Int): JarvisResult<List<SearchResult>> {
            lastQuery = query
            lastMax = maxResults
            return JarvisResult.Success(if (query == "nothing") emptyList() else results)
        }
    }

    private class FakeFetcher : PageFetcher {
        var lastUrl: String? = null
        override suspend fun fetch(url: String): JarvisResult<PageContent> {
            lastUrl = url
            return if (url.contains("empty")) {
                JarvisResult.Success(PageContent(url = url, title = "Empty", text = "", truncated = false))
            } else {
                JarvisResult.Success(
                    PageContent(
                        url = url,
                        title = "Fetched Page",
                        text = "Some readable page text about the topic.",
                        truncated = false,
                    ),
                )
            }
        }
    }

    private class FakeRunner : ResearchRunner {
        override fun research(topic: String): Flow<ResearchEvent> = flow {
            emit(ResearchEvent.Searching(topic))
            emit(ResearchEvent.Fetching("https://example.com/page", 1, 1))
            emit(ResearchEvent.Synthesizing)
            emit(
                ResearchEvent.Done(
                    ResearchBrief(topic = topic, summary = "Brief about $topic."),
                ),
            )
        }
    }

    private class FakeDrafts : DraftGenerator {
        var lastRequest: DraftRequest? = null
        override suspend fun generate(request: DraftRequest): JarvisResult<DraftGenerationResult> {
            lastRequest = request
            val body = "Draft about ${request.topic} for ${request.platform}"
            return JarvisResult.Success(
                DraftGenerationResult(
                    draft = ContentDraft(
                        id = 7L,
                        title = request.topic,
                        body = body,
                        platform = request.platform,
                        status = DraftStatus.DRAFT,
                        researchId = request.researchId,
                    ),
                    charLimit = DraftLimits.limitFor(request.platform),
                    truncated = false,
                    wasRewritten = false,
                ),
            )
        }
    }

    private val search = FakeSearch(fixedResults)
    private val fetcher = FakeFetcher()
    private val runner = FakeRunner()
    private val drafts = FakeDrafts()

    private val searchTool = SearchWebTool(search)
    private val fetchTool = FetchPageTool(fetcher)
    private val researchTool = ResearchTopicTool(runner)
    private val draftTool = DraftPostTool(drafts)

    private fun successMessage(result: JarvisResult<ToolOutcome>): String {
        assertTrue("Expected success, got $result", result is JarvisResult.Success)
        return (result as JarvisResult.Success).value.message
    }

    // ── search_web ───────────────────────────────────────────────────

    @Test
    fun `search_web is tier 0 and returns formatted results`() = runBlocking {
        assertEquals(RiskTier.READ_ONLY, searchTool.riskTier)
        val text = successMessage(searchTool.execute(buildJsonObject { put("query", "kotlin 2.0") }))
        assertTrue(text.contains("Kotlin 2.0 released"))
        assertTrue(text.contains("kotlinlang.org"))
        assertTrue(text.contains("https://kotlinlang.org/docs/whatsnew20.html"))
        assertEquals("kotlin 2.0", search.lastQuery)
    }

    @Test
    fun `search_web says so when nothing is found`() = runBlocking {
        val text = successMessage(searchTool.execute(buildJsonObject { put("query", "nothing") }))
        assertTrue(text.contains("No web results"))
    }

    @Test
    fun `search_web fails without a query`() = runBlocking {
        assertTrue(searchTool.execute(buildJsonObject {}) is JarvisResult.Failure)
        assertTrue(searchTool.execute(buildJsonObject { put("query", "  ") }) is JarvisResult.Failure)
    }

    @Test
    fun `search_web dryRun describes the search`() = runBlocking {
        val preview = searchTool.dryRun(buildJsonObject { put("query", "kotlin") })
        assertTrue(preview.contains("kotlin"))
        assertTrue(preview.contains("web"))
    }

    // ── fetch_page ───────────────────────────────────────────────────

    @Test
    fun `fetch_page returns title and text`() = runBlocking {
        val text = successMessage(
            fetchTool.execute(buildJsonObject { put("url", "https://example.com/page") }),
        )
        assertTrue(text.contains("Fetched Page"))
        assertTrue(text.contains("readable page text"))
        assertEquals("https://example.com/page", fetcher.lastUrl)
    }

    @Test
    fun `fetch_page refuses localhost and private ips`() = runBlocking {
        listOf(
            "http://localhost/admin",
            "http://127.0.0.1/",
            "http://192.168.1.1/",
            "ftp://example.com/file",
        ).forEach { url ->
            val outcome = fetchTool.execute(buildJsonObject { put("url", url) })
            assertTrue("expected $url to be refused", outcome is JarvisResult.Failure)
        }
        // The fetcher must never have been called with a blocked URL.
        assertFalse(fetcher.lastUrl?.contains("localhost") == true)
        assertFalse(fetcher.lastUrl?.contains("127.0.0.1") == true)
        assertFalse(fetcher.lastUrl?.contains("192.168.1.1") == true)
    }

    @Test
    fun `fetch_page reports empty pages honestly`() = runBlocking {
        val text = successMessage(
            fetchTool.execute(buildJsonObject { put("url", "https://example.com/empty") }),
        )
        assertTrue(text.contains("no readable text"))
    }

    // ── research_topic ───────────────────────────────────────────────

    @Test
    fun `research_topic collects the runner flow and returns the brief`() = runBlocking {
        val text = successMessage(
            researchTool.execute(buildJsonObject { put("topic", "quantum computing") }),
        )
        assertTrue(text.contains("Brief about quantum computing."))
    }

    @Test
    fun `research_topic dryRun shows the topic only`() = runBlocking {
        val preview = researchTool.dryRun(buildJsonObject { put("topic", "fusion energy") })
        assertTrue(preview.contains("fusion energy"))
    }

    // ── draft_post ───────────────────────────────────────────────────

    @Test
    fun `draft_post is tier 1 and its dryRun never shows generated text`() = runBlocking {
        assertEquals(RiskTier.REVERSIBLE, draftTool.riskTier)
        val preview = draftTool.dryRun(
            buildJsonObject {
                put("topic", "new collection")
                put("platform", "Instagram")
                put("tone", "warm")
            },
        )
        assertTrue(preview.contains("new collection"))
        assertTrue(preview.contains("Instagram"))
        assertTrue(preview.contains("warm"))
        // The draft does not exist yet — nothing generated may leak into the card.
        assertFalse(preview.contains("Draft about"))
    }

    @Test
    fun `draft_post saves the draft and reports character count`() = runBlocking {
        val text = successMessage(
            draftTool.execute(
                buildJsonObject {
                    put("topic", "new collection")
                    put("platform", "Instagram")
                },
            ),
        )
        assertTrue(text.contains("Draft saved"))
        assertTrue(text.contains("Instagram"))
        assertTrue(text.contains("characters"))
        assertTrue(text.contains("review"))
        assertEquals("new collection", drafts.lastRequest?.topic)
    }

    @Test
    fun `draft_post fails without a topic`() = runBlocking {
        val outcome = draftTool.execute(buildJsonObject { put("platform", "X / Twitter") })
        assertTrue(outcome is JarvisResult.Failure)
    }

    // ── registry ─────────────────────────────────────────────────────

    @Test
    fun `registry now holds 45 built-in tools including the four research tools`() {
        val registry = ToolRegistry()
        BuiltInTools.registerAll(
            registry = registry,
            device = FakePhoneDevice(),
            webSearch = search,
            pageFetcher = fetcher,
            researchRunner = runner,
            draftGenerator = drafts,
        )
        assertEquals(45, registry.all().size)
        listOf("search_web", "fetch_page", "research_topic", "draft_post").forEach { name ->
            assertTrue("missing tool $name", registry.get(name) != null)
        }
        // Phase 8: the four social publishing tools register too (with
        // no-op implementations in this fixture).
        listOf(
            "publish_draft", "schedule_post", "list_scheduled_posts",
            "cancel_scheduled_post",
        ).forEach { name ->
            assertTrue("missing tool $name", registry.get(name) != null)
        }
    }
}
